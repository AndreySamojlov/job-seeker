"""Generic opt-in external decisions, independent of AST scoring and I/O.

Mappings are passed by identity. The dispatcher never mutates them; registered
handlers own their behavior and must honor the consumer's mutation policy.
"""
from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import TypeVar

T = TypeVar('T')


def _nonblank(value: object, field: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f'external decision requires a nonblank {field}')


@dataclass(frozen=True)
class ExternalDecision:
    """Validated descriptor. Frozen fields; config retains its mapping identity."""

    code: str
    handler: str
    version: str
    config: Mapping[str, object]

    def __post_init__(self) -> None:
        _nonblank(self.code, 'code')
        _nonblank(self.handler, 'handler')
        _nonblank(self.version, 'version')
        if not isinstance(self.config, Mapping):
            raise ValueError('external decision config must be a mapping')


def load_external_decision(catalog: Mapping[str, object], code: str) -> ExternalDecision:
    """Load an explicitly enabled entry from catalog['external_decisions'].

    Missing, disabled or malformed entries fail closed with ValueError. No
    defaults enable an entry or select a handler/version/config implicitly.
    """
    _nonblank(code, 'code')
    entries = catalog.get('external_decisions') if isinstance(catalog, Mapping) else None
    if not isinstance(entries, Mapping):
        raise ValueError('external decision catalog must contain external_decisions')
    spec = entries.get(code)
    if not isinstance(spec, Mapping) or spec.get('enabled') is not True:
        raise ValueError('external decision is missing, disabled or malformed')
    return ExternalDecision(code, spec.get('handler'), spec.get('version'), spec.get('config'))


def invoke_external_decision(
    decision: ExternalDecision,
    state: Mapping[str, object],
    *,
    handlers: Mapping[str, Callable[[ExternalDecision, Mapping[str, object]], T]],
) -> T:
    """Call the registered handler once and return its identical result.

    Exceptions propagate unchanged. No fallback, scoring, serialization or I/O.
    """
    if not isinstance(decision, ExternalDecision):
        raise ValueError('external decision must be an ExternalDecision')
    handler = handlers.get(decision.handler)
    if not callable(handler):
        raise ValueError('external decision handler is not registered or callable')
    return handler(decision, state)
