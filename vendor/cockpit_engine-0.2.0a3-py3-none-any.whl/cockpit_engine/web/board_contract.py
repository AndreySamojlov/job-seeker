"""Opt-in board configuration. No product registration or database required."""
from dataclasses import dataclass
import re
from urllib.parse import urlsplit, unquote


def _key(value: str) -> None:
    if not isinstance(value, str) or not re.fullmatch(r"[a-z][a-z0-9_-]*", value):
        raise ValueError("Invalid board/domain key")


def _path(value: str) -> None:
    if not isinstance(value, str):
        raise ValueError("Expected a same-origin path")
    parsed = urlsplit(value)
    decoded = unquote(value)
    if (not value.startswith("/") or value.startswith("//") or parsed.netloc or parsed.scheme
            or parsed.query or parsed.fragment or "\\" in decoded
            or any(part in (".", "..") for part in decoded.split("/"))
            or any(ord(c) < 33 for c in decoded) or "%" in decoded or "{" in decoded or "}" in decoded):
        raise ValueError("Expected a plain same-origin absolute path")


@dataclass(frozen=True)
class BoardDomain:
    key: str
    label: str

    def __post_init__(self):
        _key(self.key)
        if not isinstance(self.label, str) or not self.label.strip():
            raise ValueError("Domain label required")


@dataclass(frozen=True)
class BoardRefreshPolicy:
    interval_ms: int = 60000
    max_snapshot_age_ms: int = 300000
    request_timeout_ms: int = 25000

    def __post_init__(self):
        if any(type(v) is not int or v <= 0 for v in (self.interval_ms, self.max_snapshot_age_ms, self.request_timeout_ms)):
            raise ValueError('Positive refresh durations required')


@dataclass(frozen=True)
class BoardSpec:
    key: str
    title: str
    page_path: str
    data_url: str
    domains: tuple[BoardDomain, ...]
    refresh: BoardRefreshPolicy | None = None

    def __post_init__(self):
        if self.refresh is not None and not isinstance(self.refresh, BoardRefreshPolicy):
            raise ValueError('Invalid refresh policy')
        _key(self.key)
        if not isinstance(self.title, str) or not self.title.strip():
            raise ValueError("Board title required")
        _path(self.page_path)
        _path(self.data_url)
        object.__setattr__(self, "domains", tuple(self.domains))
        if (not self.domains or not all(isinstance(d, BoardDomain) for d in self.domains)
                or len({d.key for d in self.domains}) != len(self.domains)):
            raise ValueError("Unique nonempty domains required")
        if (self.page_path == self.data_url or any(p == "/cockpit-assets" or p.startswith("/cockpit-assets/")
                                                   for p in (self.page_path, self.data_url))):
            raise ValueError("Board paths overlap")
