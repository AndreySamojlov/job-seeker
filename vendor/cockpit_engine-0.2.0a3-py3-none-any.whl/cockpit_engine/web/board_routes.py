"""Install only the portable board page and explicitly allowed package assets."""
from dataclasses import asdict
from importlib.resources import files
import json
import mimetypes
import re

from fastapi import HTTPException
from fastapi.responses import HTMLResponse, Response
from starlette.routing import Match

from .board_contract import BoardSpec

_ASSETS = frozenset({
    "styles.css", "core.js", "chart.umd.js", "chart-guard.js", "chart-render.js",
    "chart-overlays.js", "chart-modal.js", "chart-stage.js", "table-engine.js",
    "flat-table.js", "micro-graphics.js", "kpi-engine.js", "board-runtime.js",
    "board-table.js", "board-shell.css", "board-refresh.js",
})


def register_board_routes(app, *, board: BoardSpec) -> None:
    if not isinstance(board, BoardSpec):
        raise TypeError("board must be BoardSpec")
    for route in app.routes:
        path = getattr(route, "path", "")
        overlaps = any(route.matches({"type":"http", "method":"GET", "path":target, "root_path":""})[0] == Match.FULL
                       for target in (board.page_path, "/cockpit-assets/core.js"))
        if path == board.page_path or path == "/cockpit-assets" or path.startswith("/cockpit-assets/") or overlaps:
            raise ValueError("Existing route overlaps board routes")
    static = files("cockpit_engine.web").joinpath("static")
    config = json.dumps(asdict(board), ensure_ascii=True).replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")

    @app.get(board.page_path, response_class=HTMLResponse, include_in_schema=False)
    def board_page():
        page = static.joinpath("board.html").read_text(encoding="utf-8")
        return HTMLResponse(page.replace("__BOARD_CONFIG__", config), headers={"Cache-Control": "no-cache"})

    @app.get("/cockpit-assets/{asset:path}", include_in_schema=False)
    def board_asset(asset: str):
        if asset not in _ASSETS and not re.fullmatch(r"fonts/golos-text-(?:latin|cyrillic)-(?:400|500|600|700)\.woff2", asset):
            raise HTTPException(404)
        resource = static.joinpath(asset)
        if not resource.is_file():
            raise HTTPException(404)
        content = resource.read_bytes()
        if asset == "styles.css":
            content = content.replace(b"/static/fonts/", b"/cockpit-assets/fonts/")
        return Response(content, media_type=mimetypes.guess_type(asset)[0] or "application/octet-stream",
                        headers={"Cache-Control": "no-cache"})
