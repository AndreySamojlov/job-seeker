"use strict";

// Pure mount-scoped state machine. Browser wiring and native DOM live elsewhere.
function createBoardRefreshController({fetcher, validate, clock, scheduler, onView,
    policy={interval_ms:60000,max_snapshot_age_ms:300000,request_timeout_ms:25000}}) {
  clock=clock||{monotonicNow:()=>performance.now(),wallNow:()=>Date.now()};
  scheduler=scheduler||{setTimeout:(fn,ms)=>setTimeout(fn,ms),clearTimeout:id=>clearTimeout(id)};
  let params={},context=null,generation=0,current=null,pending=null,phase='loading';
  let visible=true,dead=false,flight=null,poll=null,expiry=null,lastFailed=false,invalidated=0;
  const interactions=new Set();
  const key=v=>JSON.stringify(Object.keys(v).sort().map(k=>[k,v[k]]));
  const age=s=>s ? s.initial+Math.max(0,clock.monotonicNow()-s.mono,clock.wallNow()-s.wall) : 0;
  const clearTimer=id=>{if(id!==null)scheduler.clearTimeout(id);};
  function expire(){
    if(pending&&age(pending)>=policy.max_snapshot_age_ms)pending=null;
    if(current&&age(current)>=policy.max_snapshot_age_ms){
      current=null;interactions.clear();invalidated++;
      if(pending){current=pending;pending=null;phase=lastFailed?'stale':'live';}
      else phase='unavailable';
    }
  }
  function state(){expire();return {phase,payload:current?current.payload:null,readId:current?current.payload.meta.read_id:null,
    ageMs:age(current),pending:!!pending,refreshing:!!flight,invalidated};}
  function notify(){if(!dead)onView(state());}
  function armExpiry(){clearTimer(expiry);expiry=null;if(!current)return;
    expiry=scheduler.setTimeout(()=>{expiry=null;expire();notify();armExpiry();},Math.max(0,policy.max_snapshot_age_ms-age(current)));}
  function schedule(){clearTimer(poll);poll=null;if(!dead&&visible)poll=scheduler.setTimeout(()=>{poll=null;request();},policy.interval_ms);}
  function reset(){current=null;pending=null;context=null;interactions.clear();invalidated++;clearTimer(expiry);expiry=null;}
  function matches(p){
    if(p.meta.domain!==params.domain)return false;
    const values=Object.fromEntries((p.filters||[]).map(f=>[f.key,String(f.value??'')]));
    for(const [name,value] of Object.entries(params)){
      if(name==='domain')continue;
      if(name==='page'){if(Number(value)!==p.meta.context.page)return false;continue;}
      if(name==='sort_key'||name==='sort_direction'){if(value!==p.meta.context[name])return false;continue;}
      const actual=Object.hasOwn(values,name)?values[name]:p.meta.context[name];
      if(String(actual??'')!==String(value??''))return false;
    }
    return !context||key(context)===key(p.meta.context);
  }
  async function request(){
    if(dead||!visible||flight)return;
    const gen=generation,abort=new AbortController(),start=clock.monotonicNow();
    let rejectTimeout;
    const timeout=new Promise((_,reject)=>{rejectTimeout=reject;});
    const token={abort,timer:null};flight=token;
    token.timer=scheduler.setTimeout(()=>{abort.abort();rejectTimeout(new Error('timeout'));},policy.request_timeout_ms);
    notify();
    try{
      // Race includes response.json; an abort-ignoring transport still cannot hold the scheduler.
      const p=await Promise.race([(async()=>{
        const response=await fetcher({...params},{signal:abort.signal});
        if(!response.ok){const e=new Error('HTTP');e.permanent=![408,429].includes(response.status)&&response.status<500;throw e;}
        try{return validate(await response.json(),{refreshEnabled:true});}catch(_){const e=new Error('Invalid contract');e.permanent=true;throw e;}
      })(),timeout]);
      if(dead||gen!==generation||flight!==token)return;
      if(p.state!=='live'||!matches(p)){const e=new Error('Context mismatch');e.permanent=true;throw e;}
      context={...p.meta.context};
      for(const f of p.filters||[])params[f.key]=String(f.value??'');
      params.page=String(context.page);params.sort_key=context.sort_key;params.sort_direction=context.sort_direction;
      const initial=p.meta.snapshot_age_ms+Math.max(0,clock.monotonicNow()-start);
      if(!Number.isFinite(initial)||initial>=policy.max_snapshot_age_ms)throw new Error('Expired response');
      const s={payload:p,initial,mono:clock.monotonicNow(),wall:clock.wallNow()};
      expire();lastFailed=false;
      if(current&&interactions.size)pending=s;
      else {current=s;pending=null;phase='live';}
    }catch(error){
      if(dead||gen!==generation||flight!==token)return;
      lastFailed=true;expire();
      if(error.permanent||current?.payload.meta.selection_required){reset();phase='unavailable';}
      else phase=current?'stale':'unavailable';
    }finally{
      clearTimer(token.timer);
      if(!dead&&gen===generation&&flight===token){flight=null;notify();armExpiry();schedule();}
    }
  }
  function setContext(next){
    if(dead)return;generation++;clearTimer(poll);poll=null;
    if(flight){flight.abort.abort();clearTimer(flight.timer);flight=null;}
    params={...next};reset();lastFailed=false;phase='loading';notify();request();
  }
  function applyPending(){expire();if(pending){current=pending;pending=null;interactions.clear();invalidated++;phase=lastFailed?'stale':'live';}notify();armExpiry();}
  return {start:setContext,setContext,
    setInteraction(token,active){if(dead)return;expire();if(active)interactions.add(token);else interactions.delete(token);if(!interactions.size&&pending)applyPending();},
    applyPending,getState:state,
    invalidate(){reset();phase="unavailable";notify();},
    setVisible(value){if(dead)return;visible=value;clearTimer(poll);poll=null;expire();notify();armExpiry();if(visible&&!flight)request();},
    destroy(){if(dead)return;dead=true;generation++;clearTimer(poll);clearTimer(expiry);if(flight){flight.abort.abort();clearTimer(flight.timer);}flight=null;current=null;pending=null;interactions.clear();}
  };
}
if(typeof module!=='undefined')module.exports={createBoardRefreshController};
