"""Типизированный сигнал решения (контракт роадмапа §4.4)."""
from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass
class Signal:
    code: str        # машинный код сигнала (у Финансов с префиксом уровня)
    level: str       # "sku" | "category" | "unit"
    entity_id: str   # sku_id или category
    severity: str    # "info" | "warning" | "critical"
    snapshot: dict   # поля-снимок (метрика, порог, контекст)
    score: float | None = None       # S17: нормированная глубина нарушения 0..1
    rule_code: str | None = None     # код правила каталога; для матчинга действий

    def to_dict(self) -> dict:
        d = asdict(self)
        d.pop("rule_code", None)     # внутренний матчинг-аид, не часть payload
        return d
