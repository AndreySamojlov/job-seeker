"""Общий доменно-агностичный конструктор AST-сигнала.

Источник fire/symptom/skews-семантики для движков Коммерции и Финансов. Чистый,
без БД.
"""
from __future__ import annotations

from . import ast_eval
from . import bands as bands_mod
from .signals import Signal


def compute_skews(skews_eval: list[dict], row: dict) -> list[dict]:
    """Список превысивших норму статей: [{component, value, norm}, ...]."""
    out = []
    for spec in skews_eval:
        v = ast_eval.evaluate(spec["value"], row)
        if isinstance(v, (int, float)) and not isinstance(v, bool) and v > spec["norm"]:
            out.append({"component": spec["component"], "value": float(v), "norm": spec["norm"]})
    return out


def _money(value_ast, row):
    v = ast_eval.evaluate(value_ast, row)
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return None
    return float(v)


def _enrich(sig: Signal, row: dict, rc: dict) -> Signal:
    """Дополнить сигнал ₽ и переразмеченным severity. Не меняет факт срабатывания."""
    value_ast = rc.get("value")
    if value_ast is not None:
        sig.snapshot["money"] = _money(value_ast, row)
    b = rc.get("bands")
    if b is not None:
        m = ast_eval.evaluate(b["metric"], row)
        sig.severity = bands_mod.grade(m, b["cuts"], sig.severity)
    return sig


def build_ast_signal(code, rc, row, level, entity_id, *, base_snapshot, threshold):
    """Построить Signal | None для (правило, строка, уровень)."""
    skews_eval = rc.get("skews_eval")
    if skews_eval is not None:
        skews = compute_skews(skews_eval, row)
        if not skews:
            return None
        snap = dict(base_snapshot)
        snap["skews"] = skews
        return _enrich(Signal(code, level, entity_id, rc["severity"], snap,
                              rule_code=rc.get("_rule_code", code)), row, rc)
    pred = rc.get("predicate")
    if pred is None or ast_eval.evaluate(pred, row, threshold) is not True:
        return None
    snap = dict(base_snapshot)
    if threshold is not None:
        snap["threshold"] = threshold
    sym = rc.get("symptom_metric")
    if sym is not None:
        tv = ast_eval.evaluate(sym, row)
        snap["triggered_value"] = tv
        direction = rc.get("symptom_direction")
        if direction is None and threshold is not None and isinstance(tv, (int, float)) \
                and not isinstance(tv, bool):
            direction = "below" if tv < threshold else "at_or_above"
        if direction is not None:
            snap["direction"] = direction
    return _enrich(Signal(code, level, entity_id, rc["severity"], snap,
                          rule_code=rc.get("_rule_code", code)), row, rc)
