"""Загрузка конфига правил из TOML (данные, не код). Пороги — без хардкода."""
from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field

from cockpit_engine.rules.features import domain_features

from .ast_eval import validate as ast_validate
from .catalog import compile_domain, load_catalog, validate_catalog

_SEVERITIES = {"critical", "warning", "info"}

_log = logging.getLogger(__name__)


def int_version(version) -> int | None:
    """Версия конфига правил → int; на нечисловой версии — None + предупреждение.

    Раньше int(cfg.version) падал (recompute, до записи секций) или молча глотался
    (web, через широкий except ValueError), пряча деградацию stale-сравнения. Теперь
    нечисло логируется явно и не роняет поток. Публичный (импортируется recompute/web)."""
    try:
        return int(version)
    except (ValueError, TypeError):
        _log.warning("Нечисловая версия конфига правил: %r — stale-сравнение деградирует",
                     version)
        return None


def _validate_cuts(cuts) -> None:
    """cut = ровно один из lt/gt + severity из словаря. Иначе ValueError."""
    for cut in cuts:
        if ("lt" in cut) == ("gt" in cut):           # оба или ни одного
            raise ValueError(f"cut требует ровно один из lt/gt: {cut!r}")
        if cut.get("severity") not in _SEVERITIES:
            raise ValueError(f"cut.severity вне словаря {_SEVERITIES}: {cut!r}")


@dataclass
class RulesConfig:
    version: str
    rules: dict  # code -> {enabled, threshold, severity, ...}
    actions: dict = field(default_factory=dict)
    completion_min_coverage: float = 0.5


def _validate_applies_to(action: dict, rules: dict) -> None:
    targets = action.get("applies_to", [])
    if not isinstance(targets, list) or not targets:
        raise ValueError(f"action.applies_to требует непустой список: {action!r}")
    for code in targets:
        if code not in rules:
            raise ValueError(f"action.applies_to ссылается на неизвестное правило {code!r}")


def _make_config(raw: dict, version: str, domain: str = "commerce") -> RulesConfig:
    """Общая пост-обработка сырого конфига (из TOML или jsonb БД)."""
    features = domain_features(domain)
    rules = raw.get("rules", {})
    for code, rc in rules.items():
        if rc.get("kind") == "ast" and "predicate_json" in rc:
            rc["predicate"] = json.loads(rc["predicate_json"])
            ast_validate(rc["predicate"], allow_threshold=True, features=features)
        if "value_json" in rc:                       # S16: ₽ для всех правил
            rc["value"] = json.loads(rc["value_json"])
            ast_validate(rc["value"], allow_threshold=False, features=features)
        if "bands" in rc:                            # S16: светофор
            b = rc["bands"]
            b["metric"] = json.loads(b["metric_json"])
            ast_validate(b["metric"], allow_threshold=False, features=features)
            _validate_cuts(b["cuts"])
        if "symptom_metric_json" in rc:
            rc["symptom_metric"] = json.loads(rc["symptom_metric_json"])
            ast_validate(rc["symptom_metric"], allow_threshold=False, features=features)
        if "skews" in rc:
            sev = []
            for entry in rc["skews"]:
                node = json.loads(entry["value_json"])
                ast_validate(node, allow_threshold=False, features=features)
                sev.append({"component": entry["component"], "value": node,
                            "norm": float(entry["norm"])})
            rc["skews_eval"] = sev
    actions = raw.get("actions", {})
    _COSTS = {"low", "med", "high"}
    _VIA_LEVELS = {"weak", "futile"}
    _EFFECT_TYPES = {"revenue", "margin_guard"}
    _CONFIDENCE = {"high", "medium", "low"}
    for acode, ac in actions.items():
        _validate_applies_to(ac, rules)
        if "applicable_when" in ac:
            ac["applicable"] = json.loads(ac["applicable_when"])
            ast_validate(ac["applicable"], allow_threshold=False, features=features)
        if "effect_value" in ac:
            ac["effect"] = json.loads(ac["effect_value"])
            ast_validate(ac["effect"], allow_threshold=False, features=features)
        if "evidence" in ac:
            ev = []
            for item in ac["evidence"]:
                node = json.loads(item["expr_json"])
                ast_validate(node, allow_threshold=False, features=features)
                ev.append({"key": item["key"], "expr": node})
            ac["evidence_eval"] = ev
        if "viability_guards" in ac:
            guards = []
            for g in ac["viability_guards"]:
                if g.get("level") not in _VIA_LEVELS:
                    raise ValueError(f"viability_guards.level вне {_VIA_LEVELS}: {g!r}")
                node = json.loads(g["when_json"])
                ast_validate(node, allow_threshold=False, features=features)
                guards.append({"when": node, "level": g["level"],
                               "reason": g.get("reason", "")})
            ac["viability_eval"] = guards
        if "cost" in ac and ac["cost"] not in _COSTS:
            raise ValueError(f"action.cost вне {_COSTS}: {ac['cost']!r}")
        ac.setdefault("effect_type", "revenue")   # тип эффекта: revenue | margin_guard
        if ac["effect_type"] not in _EFFECT_TYPES:
            raise ValueError(f"action.effect_type вне {_EFFECT_TYPES}: {ac['effect_type']!r}")
        ac.setdefault("confidence", "medium")      # ось уверенности: high | medium | low
        if ac["confidence"] not in _CONFIDENCE:
            raise ValueError(f"action.confidence вне {_CONFIDENCE}: {ac['confidence']!r}")
        for c in ac.get("conflicts_with", []):
            if c not in actions:
                raise ValueError(f"conflicts_with ссылается на неизвестное действие {c!r}")
    return RulesConfig(
        version=version,
        rules=rules,
        actions=actions,
        completion_min_coverage=float(
            raw.get("report", {}).get("completion", {}).get("min_coverage", 0.5)),
    )


def load_config(path: str | None = None, domain: str = "commerce") -> RulesConfig:
    """Конфиг домена из единого каталога (пер-доменное дерево rules/actions).
    path (или env MP_COCKPIT_RULES_CONFIG) — путь к корневой директории каталога
    (с `_catalog.toml` и `domains/`)."""
    if path is None:
        path = os.environ.get("MP_COCKPIT_RULES_CONFIG")
    rules_raw, actions_raw, meta, report = load_catalog(rules_path=path)
    validate_catalog(rules_raw, actions_raw)
    raw = compile_domain(rules_raw, actions_raw, domain, meta, report)
    return _make_config(raw, version=str(meta.get("version", "0")), domain=domain)


def load_config_db(conn, domain: str) -> RulesConfig:
    """Active-конфиг домена из rules_config. version = версия строки БД (S18)."""
    with conn.cursor() as cur:
        cur.execute("SELECT config, version FROM rules_config "
                    "WHERE domain = %s AND status = 'active'", (domain,))
        row = cur.fetchone()
    if row is None:
        raise ValueError(f"Нет active-конфига правил для домена {domain!r} в rules_config")
    raw, version = row
    return _make_config(raw, version=str(version), domain=domain)


def load_config_layered(conn, domain: str) -> RulesConfig:
    """Active-конфиг: rules_config (публикация) поверх TOML-каталога как
    гарантированной базы. Домен без публикации (нет active-строки) не выпадает —
    использует TOML напрямую (закрывает split-brain /rules↔TOML: БД —
    необязательный оверлей для будущего редактирования правил, Фаза 3/4, а не
    условие видимости). Оверлей объединяется по ключам rules/actions: опубликованное
    значение перекрывает одноимённое TOML-значение, но старая публикация не удаляет
    правила, добавленные в TOML позже. Удаление потребует явного tombstone-контракта
    будущего редактора; отсутствие ключа в старом снимке удалением не считается.

    Отсутствие публикации проверяется ЯВНО (SELECT существования), а не через
    except ValueError от load_config_db — та же ValueError летит и когда домен
    ОПУБЛИКОВАН, но jsonb-конфиг битый (_make_config/ast_validate). Слепой except
    маскировал бы реальную поломку публикации тихим откатом на TOML-тексты (урок
    int_version выше в этом же модуле: широкий except прятал деградацию)."""
    base = load_config(domain=domain)
    with conn.cursor() as cur:
        cur.execute("SELECT 1 FROM rules_config WHERE domain = %s AND status = 'active'",
                    (domain,))
        published = cur.fetchone() is not None
    if not published:
        return base

    overlay = load_config_db(conn, domain)
    return RulesConfig(
        version=overlay.version,
        rules={**base.rules, **overlay.rules},
        actions={**base.actions, **overlay.actions},
        completion_min_coverage=overlay.completion_min_coverage,
    )
