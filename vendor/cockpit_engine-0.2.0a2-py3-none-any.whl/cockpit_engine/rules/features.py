"""Наборы фич доменов: движок читает их из данных продукта, не хранит сам.

Что делает: `domain_features(domain)` → frozenset кодов из
`<package_root>/domains/<domain>/features.toml`, секция [validation].features.
Как используется: `rules.config._make_config` валидирует AST-предикаты против
набора своего домена.
От чего зависит: Registration-API (корень продукта) + tomllib.
"""
from __future__ import annotations

import tomllib
from functools import lru_cache

from cockpit_engine.registration import registration


def domain_features(domain: str) -> frozenset[str]:
    """Набор допустимых фич домена. Нет файла/секции → KeyError (fail-loud:
    молчаливый широкий набор пропустил бы опечатку в предикате)."""
    return _load(registration().package_root, domain)


@lru_cache(maxsize=None)
def _load(package_root, domain: str) -> frozenset[str]:
    fp = package_root / "domains" / domain / "features.toml"
    if not fp.is_file():
        raise KeyError(f"домен {domain!r}: нет {fp}")
    with fp.open("rb") as fh:
        raw = tomllib.load(fh)
    feats = raw.get("validation", {}).get("features")
    if not feats:
        raise KeyError(f"домен {domain!r}: в features.toml нет [validation].features")
    return frozenset(feats)
