"""Балл сигнала (S17): нормированная глубина нарушения 0..1.

Считается генерически из снапшота. Три прохода: прямые формулы (глубина за
порог, перекос затрат) -> групповые нормировки по коду (убытки,
деньги-как-метрика: money+threshold без triggered_value) -> фолбэк по
severity. Определение живёт в одном месте для всех доменов.
"""
from __future__ import annotations

from .signals import Signal

SEV_FALLBACK = {"critical": 0.7, "warning": 0.4, "info": 0.15}


def _clamp(v: float) -> float:
    return max(0.0, min(1.0, v))


def _money_is_metric(snap: dict) -> bool:
    """Деньги — метрика правила (AST «money > threshold»), а не обвес S16."""
    return ("triggered_value" not in snap and snap.get("threshold") is not None
            and snap.get("money") is not None and snap["money"] > 0)


def _base_score(snap: dict) -> float | None:
    """Прямые формулы; None — балл требует группового прохода или фолбэка."""
    v, thr = snap.get("triggered_value"), snap.get("threshold")
    if snap.get("direction") == "below" and v is not None and thr is not None and thr > 0:
        return _clamp((thr - v) / thr)
    skews = snap.get("skews")
    if skews:
        depths = [(s["value"] - s["norm"]) / s["norm"] for s in skews if s.get("norm")]
        if depths:
            return _clamp(max(depths))
    return None


def build_baseline(signals: list[Signal]) -> dict:
    """Нормировочная база: групповые максимумы по коду правила на ПОЛНОЙ популяции.

    Что делает: считает ровно то, что раньше считалось внутри `attach_scores` по
    переданному набору — худший убыток и максимум денег на код правила.
    Как используется: домен считает базу ОДИН раз на всём кабинете (без фильтра) и
    передаёт её в `attach_scores` для среза. Иначе один и тот же SKU получает разный
    приоритет на разных экранах: на срезе популяция уже, и одинокий сигнал
    нормируется сам на себя, становясь «худшим» (epic-main-19, решение владельца
    2026-07-22 — эталон всегда кабинетный; цена в виде второго прохода принята).
    От чего зависит: только входные сигналы."""
    worst_loss: dict[str, float] = {}
    max_money: dict[str, float] = {}
    for s in signals:
        if _base_score(s.snapshot) is not None:
            continue                    # прямая формула — групповая база ей не нужна
        v = s.snapshot.get("triggered_value")
        if s.snapshot.get("direction") == "below_zero" and v is not None and v < 0:
            worst_loss[s.code] = min(worst_loss.get(s.code, 0.0), v)
        if _money_is_metric(s.snapshot):
            max_money[s.code] = max(max_money.get(s.code, 0.0), s.snapshot["money"])
    return {"worst_loss": worst_loss, "max_money": max_money}


def attach_scores(signals: list[Signal], baseline: dict | None = None) -> None:
    """Проставить score всем сигналам in-place.

    `baseline=None` → база считается по самим `signals` (прежнее поведение: кабинетный
    отчёт без среза). На срезе домен обязан передать кабинетную базу (`build_baseline`
    на нефильтрованном наборе), иначе приоритеты поедут — см. её докстринг."""
    pending: list[Signal] = []
    for s in signals:
        s.score = _base_score(s.snapshot)
        if s.score is None:
            pending.append(s)
    # Групповые нормировки по коду: убытки (below_zero) и деньги-как-метрика.
    base = baseline if baseline is not None else build_baseline(pending)
    worst_loss: dict[str, float] = base["worst_loss"]
    max_money: dict[str, float] = base["max_money"]
    for s in pending:
        v = s.snapshot.get("triggered_value")
        if (s.snapshot.get("direction") == "below_zero" and v is not None
                and v < 0 and worst_loss.get(s.code)):
            s.score = _clamp(v / worst_loss[s.code])
        elif _money_is_metric(s.snapshot) and max_money.get(s.code):
            s.score = _clamp(s.snapshot["money"] / max_money[s.code])
        else:
            s.score = SEV_FALLBACK.get(s.severity, 0.15)
