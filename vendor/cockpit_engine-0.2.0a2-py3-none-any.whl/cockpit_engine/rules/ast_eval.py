"""Безопасный интерпретатор JSON-AST правил (S15 Фаза 2). Без eval.

Узел — dict одной из форм:
  {"feature": <имя из набора домена>}    — значение колонки строки (None при NULL)
  {"const": <число|bool>}                — константа
  {"param": "threshold"}                 — слот калибровки (подставляется при eval)
  {"op": <имя>, "args": [<узел>, ...]}   — операция

Семантика чисел — NULLIF: любой None-операнд арифметики → None; деление на 0/None → None.
Сравнения с None-операндом → False. Модуль самостоятелен (прод-готов), без зависимостей
на анализ-слой.
"""
from __future__ import annotations

import decimal

_ARITH = {"add", "sub", "mul", "div"}
_CMP = {"ge", "le", "gt", "lt", "eq"}
_LOGIC = {"and", "or", "not"}
_FUNC = {"min", "max", "abs", "clamp0", "is_null"}
_ARITY = {"add": 2, "sub": 2, "mul": 2, "div": 2,
          "ge": 2, "le": 2, "gt": 2, "lt": 2, "eq": 2,
          "not": 1, "abs": 1, "clamp0": 1, "is_null": 1}  # min/max/and/or: >=1 (переменная арность)


class AstError(Exception):
    """Невалидный AST (неизвестный узел/фича/операция/арность/лишний threshold)."""


def validate(node, *, allow_threshold: bool = True, features: frozenset[str]) -> int:
    """Проверить дерево; вернуть число threshold-параметров. Бросить AstError на невалид."""
    count = _validate(node, allow_threshold, features)
    if count > 1:
        raise AstError(f"больше одного threshold-параметра: {count}")
    return count


def _validate(node, allow_threshold: bool, features) -> int:
    if not isinstance(node, dict):
        raise AstError(f"узел не объект: {node!r}")
    if "feature" in node:
        if node["feature"] not in features:
            raise AstError(f"неизвестная фича: {node['feature']!r}")
        return 0
    if "const" in node:
        if not isinstance(node["const"], (int, float)):
            raise AstError(f"const не число: {node['const']!r}")
        return 0
    if "param" in node:
        if node["param"] != "threshold":
            raise AstError(f"неизвестный param: {node['param']!r}")
        if not allow_threshold:
            raise AstError("threshold не разрешён в этом выражении")
        return 1
    if "op" in node:
        op = node["op"]
        if op not in (_ARITH | _CMP | _LOGIC | _FUNC):
            raise AstError(f"неизвестная операция: {op!r}")
        args = node.get("args")
        if not isinstance(args, list) or not args:
            raise AstError(f"op {op!r}: args должен быть непустым списком")
        if op in _ARITY and len(args) != _ARITY[op]:
            raise AstError(f"op {op!r}: ожидалось {_ARITY[op]} арг., получено {len(args)}")
        return sum(_validate(a, allow_threshold, features) for a in args)
    raise AstError(f"неизвестная форма узла: {node!r}")


def evaluate(node, row: dict, threshold=None):
    """Вычислить дерево над строкой-фичей. Возвращает число | bool | None."""
    if "feature" in node:
        return row.get(node["feature"])
    if "const" in node:
        return node["const"]
    if "param" in node:
        if threshold is None:
            raise AstError("threshold не передан при вычислении")
        return threshold
    op = node["op"]
    args = [evaluate(a, row, threshold) for a in node["args"]]
    if op in _ARITH:
        a, b = args
        if a is None or b is None:
            return None
        # Postgres NUMERIC -> psycopg Decimal; TOML-константы правил -> float.
        # Смешение типов валит арифметику (сравнения/min/max/abs Decimal с float
        # работают штатно, только +-*/ — нормализуем только здесь).
        if isinstance(a, decimal.Decimal):
            a = float(a)
        if isinstance(b, decimal.Decimal):
            b = float(b)
        if op == "add":
            return a + b
        if op == "sub":
            return a - b
        if op == "mul":
            return a * b
        if op == "div":
            return None if b == 0 else a / b
    if op in _CMP:
        a, b = args
        if a is None or b is None:
            return False
        if op == "ge":
            return a >= b
        if op == "le":
            return a <= b
        if op == "gt":
            return a > b
        if op == "lt":
            return a < b
        if op == "eq":
            return a == b
    if op in {"and", "or", "not"}:
        for x in args:
            if not isinstance(x, bool):
                raise AstError(
                    f"логический оператор '{op}' требует булевы операнды, получен {type(x).__name__}")
    if op == "and":
        return all(args)
    if op == "or":
        return any(args)
    if op == "not":
        return not args[0]
    if op == "abs":
        return None if args[0] is None else abs(args[0])
    if op == "clamp0":
        return None if args[0] is None else max(0, args[0])
    if op == "is_null":
        return args[0] is None
    if op in {"min", "max"}:
        vals = [x for x in args if x is not None]
        if not vals:
            return None
        return min(vals) if op == "min" else max(vals)
    raise AstError(f"неизвестная операция при вычислении: {op!r}")
