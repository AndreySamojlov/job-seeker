"""AST → human-readable Russian text renderer.

Converts JSON predicate ASTs (applicable_when, viability_guards.when)
into compact Russian labels for the UI (filter/lever formula chips).
"""
import re
from typing import Any

_LABEL: dict[str, str] = {
    "completion_pct":       "выполнение плана",
    "required_daily_qty":   "требуемая дневная норма",
    "markup_over_floor":    "наценка над полом",
    "margin_profit":        "маржа",
    "plan_revenue":         "план выручки",
    "sales_qty":            "продажи шт.",
    "plan_qty":             "план шт.",
    "tempo_delta_pct":      "отклонение темпа",
    "commission_pct":       "доля комиссии",
    "logistics_pct":        "доля логистики",
    "revenue":              "выручка",
    "trailing_7d_avg_qty":  "средние продажи 7д",
    "price":                "цена",
    "sku_loss":             "убыток SKU",
    "ad_spend_rub_14d":     "расходы на рекламу за 14д",
    "total_impressions_14d": "показы за 14д",
    "total_cart_rate_14d":  "конверсия в корзину за 14д",
}

_PCT: frozenset[str] = frozenset({
    "completion_pct",
    "markup_over_floor", "tempo_delta_pct",
    "commission_pct", "logistics_pct",
    "total_cart_rate_14d",
})

_INVERT: dict[str, str] = {"lt": "ge", "gt": "le", "le": "gt", "ge": "lt", "eq": "ne"}
_SYM: dict[str, str]    = {"lt": "<", "gt": ">", "le": "≤", "ge": "≥", "eq": "=", "ne": "≠"}


_ARITH_SYM: dict[str, str] = {"div": "/", "mul": "×", "add": "+", "sub": "−"}
# Обёртки над выражением, а не самостоятельные величины: печатаем то, что внутри
# (иначе гард review_costs Финансов рендерился как «? + ? ≤ 0»).
_UNARY_PASSTHROUGH: frozenset[str] = frozenset({"clamp0", "abs"})


def _render_operand(node: dict) -> str:
    """Левая часть сравнения: голая фича или арифметика над фичами.

    Правило «Отстают по темпу» сравнивает ОТНОШЕНИЕ (темп 7д / требуемая норма),
    а не отдельную величину — без этой ветки витрина /rules печатала «?»."""
    if node.get("op") in _UNARY_PASSTHROUGH:
        args = node.get("args") or []
        return _render_operand(args[0] or {}) if args else "?"
    if node.get("op") in _ARITH_SYM:
        parts = [_render_operand(a or {}) for a in (node.get("args") or [])]
        return f" {_ARITH_SYM[node['op']]} ".join(p for p in parts if p)
    if "const" in node:
        return f"{node['const']:g}"
    feature = node.get("feature", "?")
    return _LABEL.get(feature, feature)


def render_predicate(node: dict | None, *, invert: bool = False) -> str:
    """Convert a predicate AST node to a short Russian string.

    Args:
        node: dict with "op" key (from actions.toml applicable_when / when_json).
        invert: if True, flip comparison direction (lt→ge etc.).

    Returns empty string for None or unrecognised ops.
    """
    if not node or not isinstance(node, dict):
        return ""
    op: str = node.get("op", "")
    args: list = node.get("args") or []

    if op in _SYM:
        left    = (args[0] or {}) if args else {}
        feature = left.get("feature", "?")
        label   = _render_operand(left)
        const   = (args[1] or {}).get("const", 0) if len(args) > 1 else 0
        sym     = _SYM[_INVERT.get(op, op) if invert else op]
        # Отношение двух величин безразмерно, и порог у него читается процентом
        # так же, как у долевых фич (0033: темп 7д против требуемой нормы).
        as_pct  = feature in _PCT or left.get("op") == "div"
        # round(..., 2) а не round(...) до целого: у существующих порогов (кратны
        # 1%) поведение то же, но total_cart_rate_14d гейтит на 0.25% -- round()
        # до целого схлопывал бы это в "0%", теряя сам смысл сравнения.
        val     = f"{round(const * 100, 2):g}%" if as_pct else f"{const:g}"
        return f"{label} {sym} {val}"

    if op == "and":
        return " и ".join(
            p for a in args if (p := render_predicate(a, invert=invert))
        )
    if op == "or":
        return " или ".join(
            p for a in args if (p := render_predicate(a, invert=invert))
        )
    if op == "is_null":
        feature = (args[0] or {}).get("feature", "?") if args else "?"
        label   = _LABEL.get(feature, feature)
        return f"{label} есть" if invert else f"нет данных: {label}"

    return ""


_PH_RE = re.compile(r"\{[^}]+\}[\s,;–—-]*")
_EMDASH_RE = re.compile(r"\s*[–—]\s*")


def strip_placeholders(text: str) -> str:
    """Remove {key} placeholders from recommendation text and capitalize.

    If text follows the pattern "Context {val} — instruction", extracts the
    instruction part after the em-dash. Otherwise strips {key} inline.

    Examples:
        "Выполнение {completion_pct} — поднять дневную норму." → "Поднять дневную норму."
        "Поднять дневную норму." → "Поднять дневную норму."
    """
    if not text:
        return ""
    if ("{" in text) and ("—" in text or "–" in text):
        parts = _EMDASH_RE.split(text)
        for part in reversed(parts):
            if "{" not in part:
                cleaned = part.strip()
                if cleaned:
                    return cleaned[0].upper() + cleaned[1:]
    cleaned = _PH_RE.sub("", text).strip()
    if cleaned:
        cleaned = cleaned[0].upper() + cleaned[1:]
    return cleaned
