"""Адаптер RuleSpec (JSON-AST) → интерфейс кандидата Фазы 1 (.fires/.value).

Позволяет переиспользовать value.score и calibrate.best_threshold без изменений.
"""
from __future__ import annotations

from cockpit_engine.rules.features import domain_features

from .ast_eval import evaluate, validate


class AstCandidate:
    def __init__(self, spec: dict):
        self.spec = spec
        self.code = spec["name"]
        self.grain = spec.get("grain", "sku")
        self.rationale = spec.get("rationale", "")
        self.has_threshold = bool(spec.get("threshold_param"))
        self._predicate = spec["predicate"]
        self._value = spec["value"]

    def fires(self, row: dict, threshold) -> bool:
        return evaluate(self._predicate, row, threshold) is True

    def value(self, row: dict) -> float:
        v = evaluate(self._value, row)
        if isinstance(v, bool) or not isinstance(v, (int, float)):
            return 0.0
        return float(v)


def from_spec(spec: dict) -> AstCandidate:
    """Валидировать RuleSpec и построить кандидата. AstError при невалидном AST."""
    features = domain_features("commerce")  # генератор кандидатов — только Коммерция
    n = validate(spec["predicate"], allow_threshold=True, features=features)
    validate(spec["value"], allow_threshold=False, features=features)
    if bool(spec.get("threshold_param")) != (n == 1):
        raise AstError_msg(spec, n)
    return AstCandidate(spec)


def AstError_msg(spec, n):
    from .ast_eval import AstError
    return AstError(
        f"{spec.get('name')!r}: threshold_param={spec.get('threshold_param')} "
        f"не согласуется с числом threshold-узлов ({n})")
