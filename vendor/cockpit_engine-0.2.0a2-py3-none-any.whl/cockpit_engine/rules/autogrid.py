"""Сетка калибровки порога из распределения данных (S15 Фаза 2).

Находит в предикате операнд, сравниваемый с {"param":"threshold"}, вычисляет его по
всем строкам и берёт перцентили — сетку свипа. Числа не у ИИ, сетка следует данным.
"""
from __future__ import annotations

from .ast_eval import evaluate

_CMP = {"ge", "le", "gt", "lt", "eq"}
DEFAULT_PERCENTILES = (5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 95)


def find_threshold_operand(node):
    """Вернуть AST-операнд, сравниваемый с threshold, или None."""
    if not isinstance(node, dict):
        return None
    if node.get("op") in _CMP:
        args = node["args"]
        is_param = [isinstance(a, dict) and a.get("param") == "threshold" for a in args]
        if any(is_param):
            for a, p in zip(args, is_param):
                if not p:
                    return a
    if "args" in node:
        for a in node["args"]:
            found = find_threshold_operand(a)
            if found is not None:
                return found
    return None


def _percentile(sorted_vals: list[float], p: float) -> float:
    if len(sorted_vals) == 1:
        return sorted_vals[0]
    k = (len(sorted_vals) - 1) * (p / 100.0)
    lo = int(k)
    hi = min(lo + 1, len(sorted_vals) - 1)
    frac = k - lo
    return sorted_vals[lo] * (1 - frac) + sorted_vals[hi] * frac


def percentile_grid(rows: list[dict], operand_ast, percentiles=DEFAULT_PERCENTILES) -> list[float]:
    """Сетка значений operand по перцентилям его распределения (None пропускаются)."""
    vals = sorted(v for r in rows
                  if (v := evaluate(operand_ast, r)) is not None and isinstance(v, (int, float)))
    if not vals:
        return []
    grid = sorted({_percentile(vals, p) for p in percentiles})
    return grid
