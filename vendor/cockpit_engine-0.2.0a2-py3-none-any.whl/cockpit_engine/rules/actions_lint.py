"""Авторский рубеж действий: знак/потолок эффекта, симметрия конфликтов, ликвидность.

Чистые проверки (знак/потолок/симметрия) не требуют данных кроме сэмпла строк для
вычисления AST. Ликвидность — становится ли действие eligible хоть на ком в сэмпле.
Возвращает (errors, warnings). errors блокируют публикацию; warnings — нет.
"""
from __future__ import annotations

from .ast_eval import evaluate as ast_evaluate

_EPS = 1e-6


def _num(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value)


def lint_actions(actions_cfg: dict, ceiling_expr: dict, sample_rows: list[dict],
                 id_key: str, fired: dict) -> tuple[list[str], list[str]]:
    """errors, warnings по каталогу действий.

    ceiling_expr: AST канонических денег-на-столе (потолок эффекта).
    sample_rows: строки для прогона AST. fired: {entity_id: set(сработавших кодов)}."""
    errors: list[str] = []
    warnings: list[str] = []
    for code, action in actions_cfg.items():
        # симметрия конфликтов
        for other in action.get("conflicts_with", []):
            back = actions_cfg.get(other, {}).get("conflicts_with", [])
            if code not in back:
                errors.append(f"{code}: конфликт с {other} не симметричен")
        effect = action.get("effect")
        eligible_count = 0
        for row in sample_rows:
            f = fired.get(row.get(id_key), set())
            triggered = any(c in f for c in action.get("applies_to", []))
            applicable = action.get("applicable")
            avail = triggered and (applicable is None or bool(ast_evaluate(applicable, row)))
            if avail:
                eligible_count += 1
            # Знак и потолок эффекта проверяем там, где действие применимо: вне
            # applicable_when runtime его effect не считает (eval_action_for_entity
            # отсекает раньше), значит и мерить потолок на неприменимых строках нечестно.
            if avail and effect is not None:
                ev = _num(ast_evaluate(effect, row))
                if ev is not None and ev < -_EPS:
                    errors.append(f"{code}: отрицательный эффект на строке {row.get(id_key)}")
                cap = _num(ast_evaluate(ceiling_expr, row))
                if ev is not None and cap is not None and ev > cap + _EPS:
                    errors.append(f"{code}: превышен потолок денег-на-столе "
                                  f"(эффект > потолок) на строке {row.get(id_key)}")
        if eligible_count == 0:
            warnings.append(f"{code}: спящее действие — 0 eligible на сэмпле")
    return errors, warnings
