"""Декларативные правила-кандидаты Тир A: предикат(порог) + ₽-выражение.

Кандидат = {code, grain, direction, fires, value}. fires(row, threshold) -> bool;
value(row) -> float (₽-на-столе у сработавшей сущности). Все ₽-выражения возвращают
0.0 при отсутствии данных (NULL → тишина, как в производственных правилах S4).
Поля берутся из v_commerce_sku_features (Task 1).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable


@dataclass
class Candidate:
    code: str
    grain: str                          # "sku"
    direction: str                      # "above" | "below" — ориентация свипа порога
    fires: Callable[[dict, float], bool]
    value: Callable[[dict], float]


def _num(row: dict, key: str) -> float | None:
    v = row.get(key)
    return v if isinstance(v, (int, float)) else None


# --- Скидочная эрозия: эффективная цена сильно ниже МРЦ ---------------------
def _discount_fires(row: dict, threshold: float) -> bool:
    gap = _num(row, "discount_gap_pct")
    return gap is not None and gap >= threshold


def _discount_value(row: dict) -> float:
    mrc = _num(row, "mrc_unit_price")
    eff = _num(row, "effective_unit_price")
    qty = _num(row, "sales_qty") or 0.0
    if mrc is None or eff is None:
        return 0.0
    return max(0.0, (mrc - eff) * qty)


DISCOUNT_EROSION = Candidate(
    code="discount_erosion", grain="sku", direction="above",
    fires=_discount_fires, value=_discount_value,
)


# --- Затухание темпа: последние 7 дней просели против среднего MTD -----------
def _tempo_fires(row: dict, threshold: float) -> bool:
    d = _num(row, "tempo_delta_pct")
    return d is not None and d <= threshold


def _tempo_value(row: dict) -> float:
    mtd = _num(row, "mtd_avg_daily_qty")
    last7 = _num(row, "trailing_7d_avg_qty")
    price = _num(row, "effective_unit_price")
    if mtd is None or last7 is None or price is None:
        return 0.0
    return max(0.0, (mtd - last7) * 7.0 * price)


TEMPO_DECAY = Candidate(
    code="tempo_decay", grain="sku", direction="below",
    fires=_tempo_fires, value=_tempo_value,
)


# --- Упущенная возможность: внеплановый SKU с заметными продажами ------------
def _spillover_fires(row: dict, threshold: float) -> bool:
    if not row.get("is_unplanned"):
        return False
    qty = _num(row, "sales_qty")
    return qty is not None and qty >= threshold


def _spillover_value(row: dict) -> float:
    return _num(row, "sales_revenue") or 0.0


SPILLOVER_OPPORTUNITY = Candidate(
    code="spillover_opportunity", grain="sku", direction="above",
    fires=_spillover_fires, value=_spillover_value,
)


MANUAL_CANDIDATES = [DISCOUNT_EROSION, TEMPO_DECAY, SPILLOVER_OPPORTUNITY]
