"""Публикация конфига правил: единый каталог (пер-доменное дерево rules/actions) из git →
версионированная строка rules_config (скомпилированная под домен).

Единственный «деплой» правил. Валидация — той же пост-обработкой, что и чтение:
битый AST/cuts/связь не попадает в БД.

CLI:
  uv run python -m cockpit_engine.rules.publish --domain commerce
  uv run python -m cockpit_engine.rules.publish --domain finance --source git:abc1234
"""
from __future__ import annotations

import argparse
import json

from .. import domain_registry
from .catalog import compile_domain, load_catalog, validate_catalog
from .config import _make_config


def publish(conn, domain: str, toml_path: str | None = None, source: str = "manual") -> int:
    """Опубликовать домен из единого каталога новой active-версией. Вернуть версию.
    toml_path — путь к корневой директории каталога (с `_catalog.toml` и `domains/`);
    дефолт — каталог пакета."""
    rules_raw, actions_raw, meta, report = load_catalog(rules_path=toml_path)
    validate_catalog(rules_raw, actions_raw)
    compiled = compile_domain(rules_raw, actions_raw, domain, meta, report)
    # Валидация на копии: _make_config мутирует на месте, в БД уходит чистый compiled.
    _make_config(json.loads(json.dumps(compiled)), version="candidate", domain=domain)
    with conn.transaction():
        with conn.cursor() as cur:
            cur.execute("SELECT COALESCE(max(version), 0) + 1 FROM rules_config "
                        "WHERE domain = %s", (domain,))
            version = cur.fetchone()[0]
            cur.execute("UPDATE rules_config SET status = 'retired' "
                        "WHERE domain = %s AND status = 'active'", (domain,))
            cur.execute("INSERT INTO rules_config (domain, version, config, status, source) "
                        "VALUES (%s, %s, %s, 'active', %s)",
                        (domain, version, json.dumps(compiled), source))
    return version


def main(argv: list[str] | None = None) -> int:
    from ..db import connect
    p = argparse.ArgumentParser(prog="cockpit_engine.rules.publish")
    p.add_argument("--domain", required=True, choices=domain_registry.DOMAIN_KEYS)
    p.add_argument("--file", default=None,
                    help="путь к корневой директории каталога (с _catalog.toml и domains/; "
                         "дефолт — каталог пакета)")
    p.add_argument("--source", default="manual", help="происхождение, напр. git:<sha>")
    args = p.parse_args(argv)
    conn = connect()
    try:
        version = publish(conn, args.domain, args.file, source=args.source)
    finally:
        conn.close()
    print(f"{args.domain}: опубликована версия {version}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
