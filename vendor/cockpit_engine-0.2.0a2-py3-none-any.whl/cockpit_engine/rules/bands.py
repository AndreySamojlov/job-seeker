"""Светофор: метрика-симптом + cuts -> уровень severity (S16).

Чистая функция, без БД и без ast_eval (числовое значение метрики подаётся снаружи).
Только переразметка: вызывается на уже сработавшем сигнале, не влияет на состав горящих.
"""
from __future__ import annotations

# Ранг строгости: чем больше, тем строже. Используется, чтобы итог не зависел от
# порядка cuts в конфиге (TD-35): опечатка «warning раньше critical» не должна
# молча увести критическую позицию в warning.
_SEVERITY_RANK = {"info": 1, "warning": 2, "critical": 3}


def grade(metric_value, cuts: list[dict], default: str) -> str:
    """Строжайший уровень среди ВСЕХ cuts, чьё сравнение (lt/gt) истинно.

    Порядко-независимо: при нескольких сработавших cut выбирается максимальный по
    строгости (critical > warning > info), а не первый по позиции. metric_value=None
    или мимо всех cuts -> default."""
    if metric_value is None:
        return default
    matched = [
        cut["severity"]
        for cut in cuts
        if ("lt" in cut and metric_value < cut["lt"])
        or ("gt" in cut and metric_value > cut["gt"])
    ]
    if not matched:
        return default
    return max(matched, key=lambda s: _SEVERITY_RANK.get(s, 0))
