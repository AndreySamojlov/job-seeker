"""Движок: прогоняет включённые AST-правила по строкам вьюх. Чистая функция, без БД."""
from __future__ import annotations

from . import ast_engine
from .config import RulesConfig
from .score import attach_scores
from .signals import Signal


def _ast_signals(sku_rows: list[dict], category_rows: list[dict], cfg: RulesConfig) -> list[Signal]:
    out: list[Signal] = []
    for code, rc in cfg.rules.items():
        if rc.get("kind") != "ast" or not rc.get("enabled"):
            continue
        level = rc.get("level", "sku")
        rows = sku_rows if level == "sku" else category_rows
        id_key = "sku_id" if level == "sku" else "category"
        for row in rows:
            base = {"discount_gap_pct": row.get("discount_gap_pct"),
                    "plan_revenue": row.get("plan_revenue"),
                    "sales_revenue": row.get("sales_revenue"),
                    "category": row.get("category"),
                    "product_name": row.get("product_name")}
            if level == "category":
                base.update({
                    "category_completion_pct": row.get("category_completion_pct"),
                    "forecast_completion": row.get("forecast_completion"),
                    "forecast_coverage_pct": row.get("forecast_coverage_pct"),
                    "forecast_types": row.get("forecast_types"),
                    "sku_count": row.get("sku_count"),
                    "category_status": row.get("category_status"),
                })
            sig = ast_engine.build_ast_signal(
                code, rc, row, level, row[id_key],
                base_snapshot=base, threshold=rc.get("threshold"))
            if sig is not None:
                out.append(sig)
    return out


def evaluate(sku_rows: list[dict], category_rows: list[dict], cfg: RulesConfig) -> list[Signal]:
    signals = _ast_signals(sku_rows, category_rows, cfg)
    attach_scores(signals)                   # S17: балл каждому сигналу
    return signals
