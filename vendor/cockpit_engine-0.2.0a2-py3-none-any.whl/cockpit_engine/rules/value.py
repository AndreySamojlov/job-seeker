"""₽-оценка правила-кандидата на снимке: деньги-на-столе + концентрация.

Чистые функции, без БД. `score` работает с любым объектом-кандидатом, у которого
есть .fires(row, threshold) -> bool и .value(row) -> float (см. candidates.Candidate).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class RuleScore:
    threshold: float
    support: int              # на скольких сущностях сработало
    total_money: float        # Σ ₽-на-столе по всем сработавшим
    concentrated_money: float # Σ ₽ по топ-`action_budget` сработавшим (бюджет действий)
    gini: float               # концентрация ₽ среди сработавших (0 = равно, →1 = в немногих)


def gini(values: list[float]) -> float:
    """Коэффициент Джини неотрицательных значений. Пусто/сумма 0 → 0.0."""
    vals = sorted(v for v in values if v is not None)
    n = len(vals)
    if n == 0:
        return 0.0
    total = sum(vals)
    if total == 0:
        return 0.0
    cum = 0.0
    for i, v in enumerate(vals, start=1):
        cum += i * v
    return (2.0 * cum) / (n * total) - (n + 1.0) / n


def score(rows: list[dict], candidate, threshold: float, action_budget: int) -> RuleScore:
    """Оценить кандидата при данном пороге: Σ₽, support, концентрированный ₽, Джини."""
    fired_values = [candidate.value(r) for r in rows if candidate.fires(r, threshold)]
    fired_values = [v for v in fired_values if v is not None]
    ranked = sorted(fired_values, reverse=True)
    return RuleScore(
        threshold=threshold,
        support=len(ranked),
        total_money=sum(ranked),
        concentrated_money=sum(ranked[:action_budget]),
        gini=gini(ranked),
    )
