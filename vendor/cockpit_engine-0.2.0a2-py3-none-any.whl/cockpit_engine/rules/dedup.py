"""Дедуп правил-кандидатов по overlap сработавших сущностей (S15 Фаза 2).

Overlap — Jaccard множеств сработавших sku_id. Порядок разрешения конфликтов:
  * рукописные правила Фазы 1 (`existing`) НИКОГДА не выбывают — пересекающийся
    кандидат поглощается ими независимо от денег (рукописное всегда в приоритете);
  * среди кандидатов между собой побеждает тот, у кого больше денег (богатейший
    обрабатывается первым и остаётся, более бедные пересекающиеся — поглощаются).
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Entry:
    label: str
    fired: set = field(default_factory=set)
    money: float = 0.0


def jaccard(a: set, b: set) -> float:
    if not a and not b:
        return 0.0
    union = a | b
    if not union:
        return 0.0
    return len(a & b) / len(union)


def dedupe(candidates: list[Entry], existing: list[Entry],
           overlap_threshold: float = 0.7) -> tuple[list[Entry], list[tuple[str, str]]]:
    """Вернуть (оставленные по убыванию денег, список (дубль, на_кого_похож))."""
    ranked = sorted(candidates, key=lambda e: e.money, reverse=True)
    kept: list[Entry] = []
    dups: list[tuple[str, str]] = []
    for cand in ranked:
        clash = None
        for other in existing + kept:
            if jaccard(cand.fired, other.fired) > overlap_threshold:
                clash = other.label
                break
        if clash is None:
            kept.append(cand)
        else:
            dups.append((cand.label, clash))
    return kept, dups
