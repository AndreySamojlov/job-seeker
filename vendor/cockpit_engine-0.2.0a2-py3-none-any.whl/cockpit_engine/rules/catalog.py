"""Единый каталог правил и действий: пер-доменное дерево (domains/<key>/{rules,
actions,features}.toml + residual _catalog.toml с [meta]/[report]/[actions.*]/
[features.*]). Компилятор раскладывает каталог по доменам в форму, которую
консумит config._make_config. Монолитный режим (единый rules.toml/actions.toml)
удалён — split дерево единственный путь загрузки (Cut 6, Task 3.1b)."""
from __future__ import annotations

import copy
import tomllib
from pathlib import Path

_CATALOG_TOML = "_catalog.toml"


def _package_root() -> Path:
    """Корень продуктового пакета (несёт _catalog.toml + domains/) — из
    Registration-API, а не от расположения этого файла: движок живёт в
    другом дистрибутиве, чем данные продукта."""
    from cockpit_engine.registration import registration
    return registration().package_root


def _registry_keys():
    """Ключи доменов из реестра (ленивый импорт — чтобы тест мог monkeypatch'ить).
    Обход строго по этому кортежу даёт детерминизм (не glob)."""
    from cockpit_engine import domain_registry
    return domain_registry.DOMAIN_KEYS


def _load_toml(fp: Path) -> dict:
    with fp.open("rb") as fh:
        return tomllib.load(fh)


def _feature_entry(spec: dict, code: str) -> dict:
    entry = {"label": spec.get("label", code)}
    if "desc" in spec:
        entry["desc"] = spec["desc"]
    if "unit" in spec:
        entry["unit"] = spec["unit"]
    return entry


def load_feature_registry(features_path: str | None = None) -> dict:
    """Реестр фич {code: {label[, desc][, unit]}}: residual [features.*] из
    _catalog.toml + пер-доменные domains/<key>/features.toml. Дубль кода фичи между
    источниками → ValueError (fail-loud). features_path falsy → дефолт
    _package_root(). Несуществующий путь → {} (рендер деградирует до raw-кодов, не
    падает); существующий, но НЕ директория (файл-монолит) → ValueError (монолит-
    режим удалён)."""
    root = Path(features_path) if features_path else _package_root()
    if not root.exists():
        return {}
    if not root.is_dir():
        raise ValueError(
            "features_path must be a catalog-root directory; monolith mode removed")
    return _load_feature_registry_split(root)


def _load_feature_registry_split(root: Path) -> dict:
    """SPLIT-режим load_feature_registry: residual [features.*] (_catalog.toml) +
    пер-доменные domains/<key>/features.toml. Дубль кода фичи между источниками →
    ValueError (fail-loud)."""
    out: dict = {}

    def _merge(features: dict, source: str) -> None:
        for code, spec in features.items():
            if code in out:
                raise ValueError(
                    f"дублирующийся код фичи {code!r} (источник {source})")
            out[code] = _feature_entry(spec, code)

    catalog_fp = root / _CATALOG_TOML
    if catalog_fp.exists():
        _merge(_load_toml(catalog_fp).get("features", {}), _CATALOG_TOML)
    for key in _registry_keys():
        fp = root / "domains" / key / "features.toml"
        if fp.exists():
            _merge(_load_toml(fp).get("features", {}), f"domains/{key}")
    return out


def load_catalog(rules_path=None, actions_path=None) -> tuple[dict, dict, dict, dict]:
    """(rules_raw, actions_raw, meta, report) из каталог-дерева: residual
    _catalog.toml ([meta]/[report.*]/[actions.*]) + пер-доменные
    domains/<key>/{rules,actions}.toml. rules_path falsy → дефолт _package_root();
    иначе должен указывать на каталог-root директорию (не файл) — иначе ValueError
    (монолит-режим удалён). actions_path принят для обратной совместимости сигнатуры,
    но в split-режиме не используется (actions живут в дереве)."""
    root = Path(rules_path) if rules_path else _package_root()
    if not root.is_dir():
        raise ValueError(
            "rules_path must be a catalog-root directory; monolith mode removed")
    return _load_catalog_split(root)


def _load_catalog_split(root: Path) -> tuple[dict, dict, dict, dict]:
    """SPLIT-режим load_catalog: _catalog.toml (residual [meta]/[report]/[actions.*])
    + пер-доменные domains/<key>/{rules,actions}.toml. Каждому правилу дописывается
    domain из имени пакета. Дубль кода правила или действия между источниками →
    ValueError (fail-loud). Полная склейка до возврата того же кортежа, что и монолит."""
    meta: dict = {}
    report: dict = {}
    rules_raw: dict = {}
    actions_raw: dict = {}

    def _merge_actions(actions: dict, source: str) -> None:
        for acode, ac in actions.items():
            if acode in actions_raw:
                raise ValueError(
                    f"дублирующийся код действия {acode!r} (источник {source})")
            actions_raw[acode] = ac

    catalog_fp = root / _CATALOG_TOML
    if catalog_fp.exists():
        catalog_doc = _load_toml(catalog_fp)
        meta = catalog_doc.get("meta", {})
        report = catalog_doc.get("report", {})
        _merge_actions(catalog_doc.get("actions", {}), _CATALOG_TOML)

    for key in _registry_keys():
        base = root / "domains" / key
        rules_fp = base / "rules.toml"
        if rules_fp.exists():
            for code, rc in _load_toml(rules_fp).get("rules", {}).items():
                if code in rules_raw:
                    raise ValueError(
                        f"дублирующийся код правила {code!r} (домен {key})")
                rc["domain"] = key
                rules_raw[code] = rc
        actions_fp = base / "actions.toml"
        if actions_fp.exists():
            _merge_actions(_load_toml(actions_fp).get("actions", {}), f"domains/{key}")

    return (rules_raw, actions_raw, meta, report)


def validate_catalog(rules_raw: dict, actions_raw: dict) -> None:
    """Целостность каталога до пер-доменной компиляции: домен у правил из словаря;
    applies_to непуст и ссылается на существующие (глобально) правила; conflicts_with
    — на существующие действия. Ловит опечатки, которые обрезка скрыла бы.

    Источник допустимых доменов — _registry_keys() (тот же ленивый импорт, что и у
    _load_catalog_split), а не domain_registry.DOMAIN_KEYS напрямую — иначе тест не
    может monkeypatch'ить набор доменов без патча самого domain_registry."""
    valid_domains = set(_registry_keys())
    for code, rc in rules_raw.items():
        dom = rc.get("domain")
        if dom not in valid_domains:
            raise ValueError(f"rule {code!r}: domain {dom!r} вне {valid_domains}")
    all_rules = set(rules_raw)
    all_actions = set(actions_raw)
    for acode, ac in actions_raw.items():
        targets = ac.get("applies_to", [])
        if not isinstance(targets, list) or not targets:
            raise ValueError(f"action {acode!r}: applies_to требует непустой список")
        for t in targets:
            if t not in all_rules:
                raise ValueError(
                    f"action {acode!r}: applies_to → неизвестное правило {t!r}")
        for c in ac.get("conflicts_with", []):
            if c not in all_actions:
                raise ValueError(
                    f"action {acode!r}: conflicts_with → неизвестное действие {c!r}")


def compile_domain(rules_raw: dict, actions_raw: dict, domain: str,
                   meta: dict, report: dict) -> dict:
    """Свернуть каталог в пер-доменный raw-конфиг (форма для _make_config):
    {meta, rules, actions, report}. С правил снимается domain-ключ; applies_to и
    conflicts_with обрезаются под набор этого домена (стор самосогласован, строгий
    _validate_applies_to не трогаем). Вход не мутируется (deepcopy)."""
    dom_rules = {}
    for code, rc in rules_raw.items():
        if rc.get("domain") == domain:
            rc2 = copy.deepcopy(rc)
            rc2.pop("domain", None)
            dom_rules[code] = rc2
    dom_actions = {}
    for acode, ac in actions_raw.items():
        targets = [t for t in ac.get("applies_to", []) if t in dom_rules]
        if not targets:
            continue
        ac2 = copy.deepcopy(ac)
        ac2["applies_to"] = targets
        dom_actions[acode] = ac2
    for ac in dom_actions.values():
        if "conflicts_with" in ac:
            ac["conflicts_with"] = [c for c in ac["conflicts_with"] if c in dom_actions]
    out = {"rules": dom_rules, "actions": dom_actions}
    if meta:
        out["meta"] = copy.deepcopy(meta)
    if report:
        out["report"] = copy.deepcopy(report)
    return out
