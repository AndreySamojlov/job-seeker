"""Рендер AST-предиката/значения правила в плоский список токенов-чипов для
кабинета правил. Чистая функция, без БД и без хардкода кодов на фронте."""
from __future__ import annotations

# Инфиксные бинарные операторы: AST op → отображаемый символ (роль "op").
_INFIX = {
    "lt": "<", "le": "≤", "gt": ">", "ge": "≥", "eq": "=", "ne": "≠",
    "add": "+", "sub": "−", "mul": "×", "div": "÷", "and": "и", "or": "или",
}
# Префиксные функции/унары: AST op → отображаемое имя (роль "func"). RU где осмысленно.
_PREFIX = {
    "min": "минимум", "max": "максимум", "abs": "модуль", "clamp0": "clamp0",
    "not": "не", "is_null": "пусто?", "median": "медиана",
}
# Пояснения функций для тултипа (одно предложение).
_FUNC_DESC = {
    "clamp0": "обрезка снизу нулём: значение не уходит в минус",
    "min": "минимум из значений",
    "max": "максимум из значений",
    "abs": "модуль (абсолютное значение)",
    "is_null": "проверка на пустоту",
    "not": "логическое отрицание",
    "median": "медиана глубины нарушения по сработавшим сущностям",
}


_COMPARISON_OPS = {"lt", "le", "gt", "ge"}
_UPPER_OPS = {"lt", "le"}  # верхняя граница диапазона (для составного and)


def feature_codes(ast) -> set:
    """Множество кодов фич, на которые ссылается AST-узел (рекурсивно)."""
    out: set = set()

    def walk(n):
        if not isinstance(n, dict):
            return
        if "feature" in n:
            out.add(n["feature"])
        for a in n.get("args", []):
            walk(a)

    walk(ast)
    return out


def top_comparison(ast):
    """Верхнее сравнение предиката. Для составного `and` — под-сравнение
    верхней границы (lt/le), иначе первое сравнение. None, если сравнения нет."""
    if not isinstance(ast, dict):
        return None
    op = ast.get("op")
    if op in _COMPARISON_OPS:
        return ast
    if op == "and":
        args = ast.get("args", [])
        upper = [a for a in args if isinstance(a, dict) and a.get("op") in _UPPER_OPS]
        if upper:
            return upper[0]
        cmps = [a for a in args if isinstance(a, dict) and a.get("op") in _COMPARISON_OPS]
        return cmps[0] if cmps else None
    return None


def _fmt_num(v) -> str:
    """Локаль-нейтральное число: 0.8 → '0.8', 0 → '0', 1.0 → '1'."""
    if isinstance(v, bool):  # bool — подкласс int, отсекаем явно
        return str(v)
    try:
        return format(v, "g")
    except (TypeError, ValueError):
        return str(v)


def _label_desc_unit(entry, code):
    """Запись реестра → (label, desc, unit). Толерантна к плоскому формату:
    значение-строка трактуется как label (обратная совместимость)."""
    if isinstance(entry, dict):
        return entry.get("label", code), entry.get("desc"), entry.get("unit")
    if isinstance(entry, str):
        return entry, None, None
    return code, None, None


def render_ast_chips(ast: dict | None, registry: dict, params: dict) -> list[dict]:
    """ast — распарсенный AST-узел (dict) или None.
    registry — {feature_code: {label[, desc][, unit]}} (или плоский {code: label});
    params — {param_name: число}.
    Возвращает [{text, role[, code][, op][, desc][, unit]}],
    role ∈ feature|func|op|value|paren."""
    if not ast or not isinstance(ast, dict):
        return []
    return _walk(ast, registry, params, top=True)


def _walk(node, reg: dict, params: dict, top: bool) -> list[dict]:
    if not isinstance(node, dict):
        return [{"text": str(node), "role": "value"}]
    if "feature" in node:
        code = node["feature"]
        label, desc, unit = _label_desc_unit(reg.get(code), code)
        tok = {"text": label, "role": "feature", "code": code}
        if desc:
            tok["desc"] = desc
        if unit:
            tok["unit"] = unit
        return [tok]
    if "param" in node:
        val = params.get(node["param"])
        return [{"text": _fmt_num(val) if val is not None else "?", "role": "value"}]
    if "const" in node:
        label = node.get("label")
        if label is not None:
            tok = {"text": label, "role": "value"}
            if node.get("desc"):
                tok["desc"] = node["desc"]
            return [tok]
        return [{"text": _fmt_num(node["const"]), "role": "value"}]
    if "op" in node:
        op = node["op"]
        args = node.get("args", [])
        if op in _INFIX and len(args) == 2:
            chips: list[dict] = []
            chips += _walk(args[0], reg, params, top=False)
            chips.append({"text": _INFIX[op], "role": "op"})
            chips += _walk(args[1], reg, params, top=False)
            return chips if top else _paren(chips)
        # префикс/функция/неизвестный op → name(args, ...), роль func
        func_tok = {"text": _PREFIX.get(op, op), "role": "func", "op": op}
        if op in _FUNC_DESC:
            func_tok["desc"] = _FUNC_DESC[op]
        chips = [func_tok, {"text": "(", "role": "paren"}]
        for i, a in enumerate(args):
            if i:
                chips.append({"text": ",", "role": "paren"})
            chips += _walk(a, reg, params, top=True)
        chips.append({"text": ")", "role": "paren"})
        return chips
    return []


def _paren(chips: list[dict]) -> list[dict]:
    return ([{"text": "(", "role": "paren"}] + chips
            + [{"text": ")", "role": "paren"}])
