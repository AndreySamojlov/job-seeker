"""Калибровка порога правила свипом по сетке.

Цель — НЕ максимум Σ₽ (он вырождается в «срабатывать на всё»), а
концентрированный ₽ в топ-`action_budget` сработавших (бюджет действий селлера).
При равном концентрированном ₽ предпочитается меньший support (более строгий,
действеннее короткий список).
"""
from __future__ import annotations

from dataclasses import dataclass

from .value import RuleScore, score


@dataclass
class CalibrationResult:
    candidate_code: str
    best_threshold: float
    best_score: RuleScore
    scores: list[RuleScore]


def sweep(rows: list[dict], candidate, grid: list[float], action_budget: int) -> list[RuleScore]:
    return [score(rows, candidate, t, action_budget) for t in grid]


def best_threshold(rows: list[dict], candidate, grid: list[float],
                   action_budget: int) -> CalibrationResult:
    scores = sweep(rows, candidate, grid, action_budget)
    # макс концентрированный ₽; tie-break — минимальный support (строгий порог)
    best = max(scores, key=lambda s: (s.concentrated_money, -s.support))
    return CalibrationResult(
        candidate_code=candidate.code,
        best_threshold=best.threshold,
        best_score=best,
        scores=scores,
    )
