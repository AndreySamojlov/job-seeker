"""Shared-хелперы чтения: резолвер кабинета + coercion Decimal->float. Commerce SQL - в domains/commerce/source.py."""
from __future__ import annotations

from decimal import Decimal


def _coerce(row: dict) -> dict:
    return {k: (float(v) if isinstance(v, Decimal) else v) for k, v in row.items()}


def resolve_cabinet_id(conn, marketplace: str, external_code: str) -> int:
    from cockpit_engine import instance_profile
    from cockpit_engine.registration import registration
    with conn.cursor() as cur:
        cur.execute("SELECT cabinet_id FROM cabinet WHERE marketplace = %s AND external_code = %s",
                    (marketplace, external_code))
        row = cur.fetchone()
    if row is None or not instance_profile.is_cabinet_allowed(
            f"{marketplace}:{external_code}", registration().env_prefix):
        raise ValueError(f"Кабинет не найден: {marketplace}:{external_code}")
    return row[0]
