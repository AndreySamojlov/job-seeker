"""Registration-API: единственный канал, которым продукт объявляет себя движку.

Что делает: хранит активную регистрацию (корень продуктового пакета, имена
пакетов с доменами, префикс env-переменных, override движковых порогов) и
отдаёт её движковым модулям.
Как используется: продукт в своём `__init__.py` зовёт `register_domains(...)`
один раз; движок зовёт `registration()` ЛЕНИВО, в телах функций.
От чего зависит: только stdlib — лист-модуль, безопасен от циклов импорта.
"""
from __future__ import annotations

import copy
import os
import tomllib
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType

_DEFAULTS_FILE = Path(__file__).resolve().parent / "_engine_defaults.toml"


@dataclass(frozen=True)
class Registration:
    """Паспорт продукта, поданный движку. Неизменяем после создания."""
    package_root: Path
    domain_packages: tuple[str, ...]
    env_prefix: str = "COCKPIT"
    settings: Mapping = field(default_factory=dict)


_ACTIVE: Registration | None = None


def _load_defaults() -> dict:
    with _DEFAULTS_FILE.open("rb") as fh:
        return tomllib.load(fh)


def _deep_merge(base: dict, override: Mapping) -> dict:
    out = copy.deepcopy(base)
    for key, value in override.items():
        if isinstance(value, Mapping) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = value
    return out


def register_domains(*, package_root: str | os.PathLike,
                     domain_packages: Sequence[str],
                     env_prefix: str = "COCKPIT",
                     settings: Mapping | None = None) -> Registration:
    """Объявить продукт движку.

    package_root — каталог продуктового пакета; движок ищет относительно него
    `domains/<key>/{rules,actions,features}.toml`, `_catalog.toml`,
    `charts/<key>_charts.toml` и `web/static/`.
    domain_packages — импортируемые имена пакетов, где лежат `<key>/spec.py`.
    env_prefix — префикс env-фильтров (`<PREFIX>_DOMAINS`, `<PREFIX>_CABINETS`).
    settings — override движковых порогов (глубокое слияние поверх
    `_engine_defaults.toml`).
    Повторный вызов заменяет активную регистрацию целиком (не сливает).
    """
    global _ACTIVE
    merged = _deep_merge(_load_defaults(), settings or {})
    _ACTIVE = Registration(
        package_root=Path(package_root),
        domain_packages=tuple(domain_packages),
        env_prefix=env_prefix,
        settings=MappingProxyType(merged),
    )
    return _ACTIVE


def registration() -> Registration:
    """Активная регистрация. Нет регистрации → RuntimeError (fail-loud)."""
    if _ACTIVE is None:
        raise RuntimeError(
            "продукт не зарегистрирован в движке: вызовите "
            "cockpit_engine.register_domains(package_root=…, domain_packages=…) "
            "при импорте продуктового пакета")
    return _ACTIVE


def reset_registration() -> None:
    """Сбросить регистрацию (тесты; в проде не зовётся)."""
    global _ACTIVE
    _ACTIVE = None


def setting(dotted: str):
    """Значение движкового порога по точечному пути ('report.completion.min_coverage').
    Неизвестный путь → KeyError (опечатка в конфиге не должна тихо давать None)."""
    node = registration().settings
    for part in dotted.split("."):
        if not isinstance(node, Mapping) or part not in node:
            raise KeyError(f"неизвестная настройка движка: {dotted!r}")
        node = node[part]
    return node
