"""Контракт домена: DomainSpec (паспорт) + typed Protocol'ы на callable-поля.

ЛИСТ-модуль (§5.1 спеки Cut 6): ТОЛЬКО stdlib, ничего из продуктового пакета на
import-time — разрывает кольцо catalog→domain_registry→сканер→domains/*/spec→domain_registry.
domains/<name>/spec.py импортит domain_spec (не domain_registry).
"""
from __future__ import annotations

import calendar
import datetime as dt
import decimal
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Protocol


def month_window(period: dt.date) -> tuple[dt.date, dt.date]:
    """Эффективное окно [period_start, period_end] для ТОЧЕЧНОГО `period`.

    Что делает: возвращает границы календарного месяца, содержащего `period`,
    ВКЛЮЧИТЕЛЬНО с обоих концов (совместимо с SQL `BETWEEN`).
    Как используется: домен, у которого `enrich_view`/`build_report_scope` получает лишь
    одиночную дату `period`, выводит из неё эффективный диапазон отчёта — вместо слепой
    дате-арифметики (`obs_date - 60`, `MAX(obs_date) - 29`), тайно выходящей за выбранный
    диапазон (epic-epic-report-window-scope-1, AC5). Агрегирующая формула затем читает
    строго `obs_date BETWEEN period_start AND period_end` — регресс на выход за нижнюю
    границу ловит `tests/window_invariant.py::assert_ignores_pre_window`.
    Формализация, а не переизобретение: это общий дом приватного `_month_bounds`
    Коммерции и SQL-приёма `date_trunc('month', obs_date) = date_trunc('month', period)`
    (`domains/commerce/source.py`) — контракт периода в одном месте (см. Protocol
    PeriodWindow ниже для явного диапазона «последние 30 дней»).
    От чего зависит: только stdlib (`datetime`/`calendar`) — модуль остаётся import-leaf."""
    start = period.replace(day=1)
    last_day = calendar.monthrange(period.year, period.month)[1]
    return start, period.replace(day=last_day)


class BuildReportScope(Protocol):
    def __call__(self, conn, cabinet_id, cabinet, period, scope, which, cfg,
                 rules_version, data_version, recomputed_at) -> tuple[dict, dict]: ...


class EnrichView(Protocol):
    # scope добавлен в Cut 5B.2: file-делегация settlement получает выбранный юнит;
    # домены без юнитов (pricing) игнорируют. Аддитивное расширение, не спец-ветка.
    # category добавлен в epic-main-19 (срез по категории) — тем же аддитивным
    # приёмом: пустая строка = «нет фильтра», старые позиционные вызовы валидны.
    def __call__(self, conn, cabinet_id, scope, period, category: tuple[str, ...] = ()) -> dict | None: ...


class LatestPeriod(Protocol):
    def __call__(self, conn, cabinet_id, scope: str = "") -> dt.date | None: ...


class ListCabinets(Protocol):
    def __call__(self, conn) -> list[dict]: ...


class ListUnits(Protocol):
    def __call__(self, conn, cabinet_id, period) -> list[dict]: ...


class CategoryPickerAvailable(Protocol):
    """Возвращает, можно ли показывать категории на текущей грани кабинета."""
    def __call__(self, conn, cabinet_id) -> bool: ...


class ListCategories(Protocol):
    """Справочник категорий кабинета — питает селектор категории (epic-main-19).

    Что делает: возвращает [{"value": <категория>, "label": <категория>}, …],
    первым элементом — {"value": "", "label": "Все категории"}.
    Как используется: `report.view_source.list_categories` диспетчерит сюда, если
    домен объявил слот; иначе работает общий дефолт по `sku_attribute`. Базовый
    список единый на кабинет; домен переопределяет его только когда его отчёт
    использует собственную классификацию. У API-грани взаиморасчётов это категории
    строк выбранного месячного SKU-отчёта, чтобы любой пункт селектора был применим.
    Пункта «Без категории» нет: товара без категории по природе данных не
    существует, наблюдаемые исключения — дефект ingest (спека §2.1, debt-main-79).
    От чего зависит: соединение с БД."""
    def __call__(self, conn, cabinet_id, period) -> list[dict]: ...


class DirectiveForms(Protocol):
    # read_api.enrich_report_based: список деклараций {"form_code": ...} после
    # read_report — generic-точка, общая для ВСЕХ report-based доменов (bug-main-11).
    def __call__(self, conn, cabinet_id) -> list[dict]: ...


class PeriodWindow(Protocol):
    """Резолюция скользящего ОКНА периода (напр. «последние 30 дней»),
    domain-agnostic контракт task-inspiring-joliot-2759b3-2 (epic-main-15, AC1/AC2).

    Домен объявляет это поле в своём `DOMAIN_SPEC`, если умеет отдавать не только
    точечный период (одна дата/месяц — `enrich_view`), но и агрегат по диапазону
    дат `[period_start, period_end]`. `web/app.py::report_view` перехватывает
    `date="last30"` и диспетчерит СЮДА через `DOMAIN_REGISTRY[domain].period_window`
    — доменных `if domain == "..."` в `app.py`/`report/view_source.py` для этого
    НЕТ и не должно появляться; новый домен подключается ОДНОЙ декларацией в своём
    `domains/<key>/spec.py` (см. `domains/commerce/spec.py::_commerce_period_window`
    — эталонный пример подключения).

    Обязательный контракт агрегации внутри реализации (спека
    `harness:docs/superpowers/archive/specs/2026-07-19-commerce-api-period-selector-design.md`
    §3.4, раздел «Domain-agnostic контракт периода»):
    - Аддитивные метрики (факты: `sales_qty`, `sales_revenue` и т.п.) — честная
      `SUM` по дням диапазона (не переиспользовать месячный MTD-трюк вьюхи).
    - Метрики-отношения (`completion_pct` и т.п.) — **ratio-of-sums**: делить
      просуммированные за окно базовые величины (`SUM(sales_qty)/SUM(plan_qty)`),
      а НЕ усреднять по дням точечные `completion_pct`. Переиспользовать ту же
      цепочку формул деления, что уже есть для дневного/месячного среза домена —
      не изобретать отдельную формулу для окна.
    - Всё, что не зависит от окна (атрибуты SKU/категории, ценовой пол, margin и
      т.п.) — снимок на `period_end`, переиспользуется как есть (без пересчёта).
    - `None` → вызывающий (`report_view`) отвечает 404 (нет данных на это окно) —
      тот же контракт, что у `enrich_view` для точечного периода.

    Сигнатура ЗЕРКАЛИТ `EnrichView` (те же `conn, cabinet_id, scope`), плюс
    `period_start`/`period_end` вместо одиночного `period`.

    `category` — срез по категории (`""` = все, epic-main-19); резолвится той же
    логикой атрибутов SKU, что уже есть в домене (единая as-of политика из эпика
    исключена — спека §2.1: товар категорию не меняет)."""
    def __call__(self, conn, cabinet_id, scope, period_start: dt.date,
                period_end: dt.date, category: tuple[str, ...] = ()) -> dict | None: ...


_CATEGORY_STRUCTURAL_FIELDS = frozenset({
    "sku_id", "product_name", "category", "actions", "rule_hits", "agg_score", "money",
    "entity_id", "id", "name", "label", "status", "assortment_quadrant",
})


def _has_business_metric(row: Mapping) -> bool:
    """Возвращает True, если строка содержит фактический ненулевой показатель.

    `decimal.Decimal` — легитимный числовой тип строк entity_tables (psycopg отдаёт
    Postgres `numeric` как Decimal, не float; bug-pricing-category-decimal-1): его
    отсутствие в допустимых типах делало проверку слепой к любому домену, чьи
    SQL-формулы не приведены к float явно (живой случай — Ценообразование:
    breakeven_floor/effective_price_lk/unit_margin_pct), и категория никогда не
    считалась доступной, хотя строки несли реальные метрики."""
    return any(
        isinstance(value, (int, float, decimal.Decimal)) and not isinstance(value, bool)
        and value != 0
        for key, value in row.items()
        if key not in _CATEGORY_STRUCTURAL_FIELDS
    )


def category_activity_from_payload(payload: Mapping) -> set[str]:
    """Пакетно определяет доступные категории из одного базового отчёта.

    Техническая строка SKU не является данными сама по себе. Категория доступна,
    когда её собственные строки содержат фактический показатель: тогда в срезе
    наполняются KPI, графики и таблица сущностей — три канонические главы.
    """
    if payload.get("empty_slice") or payload.get("slice_unsupported"):
        return set()
    available: set[str] = set()
    for table in (payload.get("entity_tables") or {}).values():
        for row in table.get("rows") or []:
            if not isinstance(row, Mapping):
                continue
            category = row.get("category")
            if isinstance(category, str) and category and _has_business_metric(row):
                available.add(category)
    return available

@dataclass(frozen=True)
class DomainSpec:
    """Паспорт домена.

    `grain` — ТЕКУЩАЯ грануляция (переходная, §4.4 спеки): цель ВЕЗДЕ `sku_daily`;
    не-дневные значения — техдолг схождения (TD-51), а не легитимная опция контракта.

    `order` — само-объявляемый порядок вкладок (commerce=10, finance=20,
    settlement=30, pricing=40); сортировка (order, key) применяется сканером ВСЕГДА
    поверх pkgutil (§5.4). Дефолт 100 — незаявленный домен уходит в хвост.

    callable-поля (Cut 2) — точки диспетчеризации Класса-2. `None` → потребитель идёт
    стандартным (report-based) путём; переопределяет только домен с иным поведением
    (on-the-fly pricing). Escape-hatch (§9.1 спеки): контракт расширяется АДДИТИВНО —
    новый опциональный слот, а не спец-ветка в диспетчере.

    `supports_category_slice` (epic-main-19) — ДЕКЛАРАЦИЯ, что домен действительно
    применяет срез по категории, а не просто принимает параметр. Дефолт False —
    честный: пока домен не научился резать, его отчёт помечается
    пустой срез, который не подписывает кабинетные цифры именем категории.
    Без этой декларации выбранная категория подписывала бы НЕфильтрованные цифры
    именем категории — молчаливое враньё опаснее пустоты. Домен снимает заглушку
    ОДНОЙ строкой в своём spec.py; ветвлений по имени домена в общих швах нет."""
    key: str
    grain: str
    order: int = 100
    levels: tuple[str, ...] | None = None          # rule_meta: префикс кодов по уровням
    build_report_scope: Callable | None = None     # recompute/build_fresh → (secs, meta)
    enrich_view: Callable | None = None            # read_api: on-the-fly payload
    latest_period: Callable | None = None          # view_source: свежий период
    list_cabinets: Callable | None = None          # view_source: список кабинетов
    list_units: Callable | None = None             # view_source: список юнитов
    list_categories: Callable | None = None        # view_source: справочник категорий
                                                    # (см. Protocol ListCategories выше)
    category_picker_available: Callable | None = None  # None = доступен на всех гранях
    category_activity: Callable = category_activity_from_payload  # CategoryIndex: пакетная активность
    supports_category_slice: bool = False          # домен УМЕЕТ применять срез по
                                                    # категории (epic-main-19)
    period_window: Callable | None = None          # web/app.py: date="last30" → окно
                                                    # (см. Protocol PeriodWindow выше —
                                                    # контракт агрегации + образец подключения)
