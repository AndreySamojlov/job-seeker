"""Конвертер toml-спек диаграмм → web/static/chart-config.js (движок Ф1).

Build-инструмент, НЕ рантайм: payload.py/charts.py/report-service не трогаются.
Генерируется в тестах/preview/деплое (Cut 4b); НЕ коммитится (.gitignore).
Запуск: uv run python -m cockpit_engine.charts.build_specs
"""
from __future__ import annotations

import json
import math
import tomllib
from pathlib import Path

_ENGINE_DIR = Path(__file__).resolve().parent          # только chart_types.toml

_UNITS = {"qty", "rub", "pct"}
_COLOR_BY = {"neutral", "sign", "marginPct", "completion", "pnl", "quadrant"}


def _spec_dir() -> Path:
    """Каталог toml-спек диаграмм продукта (<package_root>/charts)."""
    from cockpit_engine.registration import registration
    return registration().package_root / "charts"


def _static_out() -> Path:
    """Адресат генерата: статика ПРОДУКТА, не каталог пакета движка."""
    from cockpit_engine.registration import registration
    return registration().package_root / "web" / "static" / "chart-config.js"


def _load(name: str) -> dict:
    base = _ENGINE_DIR if name == "chart_types.toml" else _spec_dir()
    with open(base / name, "rb") as fh:
        return tomllib.load(fh)


def _build_types(raw: dict) -> dict:
    out = {}
    for name, t in raw.get("types", {}).items():
        if "encoding" not in t:
            raise ValueError(f"тип {name!r}: нет encoding")
        encoding = t["encoding"]
        entry = {
            "encoding": encoding,
            "overlays": list(t.get("overlays", [])),
            "health": dict(t.get("health", {})),
            "legend": list(t.get("legend", [])),
        }
        if encoding == "line":
            fo = t.get("fill_opacity", 0.05)
            if not isinstance(fo, (int, float)) or isinstance(fo, bool) or not (0 <= fo <= 1):
                raise ValueError(f"тип {name!r}: fill_opacity {fo!r} — нужно число в [0,1]")
            entry["fillOpacity"] = float(fo)
            dbr = t.get("dots_below_ref", False)
            if not isinstance(dbr, bool):
                raise ValueError(f"тип {name!r}: dots_below_ref {dbr!r} — нужен булев")
            entry["dotsBelowRef"] = dbr
        if encoding == "stacked-hbar":
            norm = t.get("normalize", False)
            if not isinstance(norm, bool):
                raise ValueError(f"тип {name!r}: normalize {norm!r} — нужен булев")
            entry["normalize"] = norm
        out[name] = entry
    return out


def _build_levels(cid: str, c: dict, chart_levels: list[str]) -> dict | None:
    """spec['levels'] (task-main-200, §3 спеки controls-design) — разрез
    категория/товар главы «Динамика». Блок `levels.<уровень>` передаётся
    почти дословно (JSON-совместимые dict/str из tomllib), валидируется
    только структура: уровень известен домену, ровно одно из series/source.
    Отсутствие блока у графика -> None (график без пары, спека: «остаются
    как есть»)."""
    levels = c.get("levels")
    if not levels:
        return None
    out = {}
    for level, lv in levels.items():
        if level not in chart_levels:
            raise ValueError(
                f"{cid}.levels.{level}: уровень не объявлен в chart_levels домена "
                f"(есть: {chart_levels})")
        has_series = "series" in lv
        has_source = "source" in lv
        if has_series == has_source:
            raise ValueError(
                f"{cid}.levels.{level}: ровно одно из series/source обязательно "
                f"(series={has_series}, source={has_source})")
        out[level] = dict(lv)
    return out


def _build_charts(raw: dict, types: dict, chart_levels: list[str] | None = None) -> list:
    chart_levels = chart_levels or []
    charts = []
    seen = set()
    any_declares_levels = False
    for cid, c in raw.get("charts", {}).items():
        tname = c.get("type")
        if tname not in types:
            raise ValueError(f"{cid}: неизвестный тип {tname!r} (есть: {sorted(types)})")
        t = types[tname]
        is_scatter = t["encoding"] in {"scatter", "date-scatter"}
        unit = unit_x = unit_y = x_label = y_label = None
        if is_scatter:
            unit_x = c.get("unit_x")
            unit_y = c.get("unit_y")
            if unit_x not in (_UNITS | {"date"} if t["encoding"] == "date-scatter" else _UNITS):
                raise ValueError(f"{cid}: unit_x {unit_x!r} вне словаря {_UNITS}")
            if unit_y not in _UNITS:
                raise ValueError(f"{cid}: unit_y {unit_y!r} вне словаря {_UNITS}")
            x_label = c.get("x_label")
            y_label = c.get("y_label")
            if not x_label:
                raise ValueError(f"{cid}: нет x_label (обязателен для scatter)")
            if not y_label:
                raise ValueError(f"{cid}: нет y_label (обязателен для scatter)")
        else:
            unit = c.get("unit")
            if unit not in _UNITS:
                raise ValueError(f"{cid}: unit {unit!r} вне словаря {_UNITS}")
        color_by = c.get("color_by")
        if color_by not in _COLOR_BY:
            raise ValueError(f"{cid}: color_by {color_by!r} вне словаря {_COLOR_BY}")
        title = c.get("title")
        if not title:
            raise ValueError(f"{cid}: нет title")
        for r in c.get("refs", []):
            if "value" not in r and "fromSeries" not in r:
                raise ValueError(f"{cid}: ref требует value или fromSeries: {r!r}")
        cid_out = c.get("series", cid)
        if cid_out in seen:
            raise ValueError(f"{cid}: дубль id {cid_out!r} (series должен быть уникален в домене)")
        seen.add(cid_out)
        spec = {
            "id": cid_out,
            "type": tname,
            "encoding": t["encoding"],
            "colorBy": color_by,
            "title": title,
            "caption": c.get("caption", ""),
            "refs": c.get("refs", []),
            "guard": c.get("guard", {}),
            # overlays: инстанс (даже пустой список) перекрывает тип-дефолт
            "overlays": c["overlays"] if "overlays" in c else list(t["overlays"]),
        }
        if is_scatter:
            spec["unitX"] = unit_x
            spec["unitY"] = unit_y
            spec["xLabel"] = x_label
            spec["yLabel"] = y_label
            if t["encoding"] == "date-scatter":
                if unit_x != "date":
                    raise ValueError(f"{cid}: date-scatter requires unit_x=date")
                low, high = c.get("y_min", 0), c.get("y_max", 100)
                if (any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v)
                        for v in (low, high)) or low >= high):
                    raise ValueError(f"{cid}: invalid y_min/y_max")
                spec["yMin"], spec["yMax"] = low, high
        else:
            spec["unit"] = unit
        if "source" in c:
            spec["source"] = c["source"]
        if "waterfall" in c:
            spec["waterfall"] = c["waterfall"]
        if "combo" in c:
            spec["combo"] = c["combo"]
        # Поля своего encoding (дефолт из типа, как overlays выше). Валидация
        # здесь обязательна: _build_charts — вторая точка входа в этот шов
        # (Chart Lab прогоняет произвольный пользовательский TOML через
        # chart_lab_store.py), одной проверки на уровне типа (_build_types)
        # недостаточно — per-chart override её обходит.
        if t["encoding"] == "line":
            fo = c.get("fill_opacity", t["fillOpacity"])
            if not isinstance(fo, (int, float)) or isinstance(fo, bool) or not (0 <= fo <= 1):
                raise ValueError(f"{cid}: fill_opacity {fo!r} — нужно число в [0,1]")
            spec["fillOpacity"] = float(fo)
            dbr = c.get("dots_below_ref", t["dotsBelowRef"])
            if not isinstance(dbr, bool):
                raise ValueError(f"{cid}: dots_below_ref {dbr!r} — нужен булев")
            spec["dotsBelowRef"] = dbr
        # normalize -- 100%-стек (Задача 5, 2026-08-21): chart-render.js читает
        # spec.normalize и делит сегменты строки на её сумму.
        if t["encoding"] == "stacked-hbar":
            norm = c.get("normalize", t["normalize"])
            if not isinstance(norm, bool):
                raise ValueError(f"{cid}: normalize {norm!r} — нужен булев")
            spec["normalize"] = norm
        legend = c.get("legend", t["legend"])
        if legend:
            spec["legend"] = legend
        if c.get("primary"):
            spec["primary"] = True
        lv = _build_levels(cid, c, chart_levels)
        if lv is not None:
            spec["levels"] = lv
            any_declares_levels = True
        charts.append(spec)
    if chart_levels and not any_declares_levels:
        raise ValueError(
            f"chart_levels={chart_levels} объявлен, но ни один график домена "
            f"не декларирует levels — мёртвая декларация")
    return charts


def _build_domain(raw: dict, types: dict) -> dict:
    # chart_levels (task-main-200, §3 спеки controls-design): разрез
    # категория/товар главы «Динамика» — сегодня объявлен только Коммерцией,
    # шесть из семи доменов не несут [meta].chart_levels и получают "charts"
    # без "levels" — не регрессия, штатный случай (спека: скоуп-пилот).
    chart_levels = list(raw.get("meta", {}).get("chart_levels", []))
    out = {"charts": _build_charts(raw, types, chart_levels)}
    if chart_levels:
        out["levels"] = chart_levels
    return out


def load_chart_types(*, portable: bool = False) -> dict:
    """Публичная загрузка общего словаря типов графиков (chart_types.toml).

    Не зависит от домена/чарта -- единственный файловый I/O, нужный вызывающему,
    который строит ОДИН график вне домена (Chart Lab, task-gracious-hopper-854d26-1).
    build_engine() ниже делает то же самое инлайн для файлового пути по всем доменам;
    здесь -- та же загрузка как отдельная публичная точка входа."""
    types = _build_types(_load("chart_types.toml"))
    if portable:
        with open(_ENGINE_DIR / "portable_chart_types.toml", "rb") as source:
            types.update(_build_types(tomllib.load(source)))
    return types


def build_domain(raw: dict, types: dict) -> dict:
    """Публичный вход в сборку набора графиков из in-memory TOML-словаря.

    Тонкая обёртка над _build_domain (находка ревью Шага 0, 2026-08-20:
    _build_domain/_build_charts УЖЕ принимают dict, не путь к файлу -- файловый
    I/O живёт только в _load()/build_engine(), сюда не просачивается). Для
    ОДНОГО отдельного графика вне домена (Chart Lab) вызывающий передаёт
    {"charts": {chart_id: <распарсенный tomllib блок>}} и берёт result["charts"][0]
    -- доменные инварианты (seen-дедуп id, chart_levels) на одиночном графике либо
    тривиальны, либо не активируются (Lab-чарт без [meta].chart_levels)."""
    return _build_domain(raw, types)


def build_engine() -> dict:
    from cockpit_engine import domain_registry

    types_raw = _load("chart_types.toml")
    types = _build_types(types_raw)
    return {
        "version": str(types_raw.get("meta", {}).get("version", "1")),
        "types": types,
        "domains": {
            key: _build_domain(_load(f"{key}_charts.toml"), types)
            for key in domain_registry.DOMAIN_KEYS
            if (_spec_dir() / f"{key}_charts.toml").exists()
        },
    }


def render_js(engine: dict) -> str:
    body = json.dumps(engine, ensure_ascii=False, indent=2)
    return (
        '"use strict";\n'
        "// СГЕНЕРИРОВАНО cockpit_engine.charts.build_specs из src/cockpit_engine/charts/*.toml.\n"
        "// Не редактировать вручную — правьте toml и перегенерируйте.\n"
        "(function (root) {\n"
        "  root.CHART_ENGINE = " + body + ";\n"
        '})(typeof window !== "undefined" ? window : globalThis);\n'
    )


def main() -> None:
    js = render_js(build_engine())
    static_out = _static_out()
    # newline="\n": LF всегда (дисциплина проекта + детерминизм генерации кросс-платформенно).
    static_out.write_text(js, encoding="utf-8", newline="\n")
    print(f"wrote {static_out} ({len(js)} bytes)")


def ensure_built():
    """Сгенерировать chart-config.js, если он отсутствует или старше toml-спек.

    Гвард против стейла в dev/preview (правка *_charts.toml при живом генерате);
    в штатном проде — дешёвый stat-no-op (Dockerfile собрал свежий)."""
    static_out = _static_out()
    if not static_out.exists():
        main()
        return
    toml_sources = list(_spec_dir().glob("*.toml")) + [_ENGINE_DIR / "chart_types.toml"]
    newest_toml = max(p.stat().st_mtime for p in toml_sources)
    if static_out.stat().st_mtime < newest_toml:
        main()


if __name__ == "__main__":
    main()
