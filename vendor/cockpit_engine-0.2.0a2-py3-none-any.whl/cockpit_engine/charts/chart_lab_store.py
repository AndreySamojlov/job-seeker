"""Изолированное CRUD-хранилище прототипов Chart Lab (task-gracious-hopper-854d26-3,
Задача 4 плана `harness:docs/superpowers/plans/2026-08-20-chart-lab.md`, спека §11-14).

`chart_lab_saved.toml` живёт рядом с продакшн-конфигами графиков
(`src/cockpit_engine/charts/*_charts.toml`), но НИКОГДА ими не читается:
`build_specs.py::build_engine()` явно перечисляет только `f"{key}_charts.toml"`
по `domain_registry.DOMAIN_KEYS` -- этот модуль в тот список не входит и не
должен входить (AC18/AC27 эпика Chart Lab).

Сохранённый прототип несёт только id/name/toml (+опционально created_at/
updated_at) -- НИКОГДА cabinet/period/category/данные результата/скриншоты
(спека §11 «Saved prototype does NOT contain»): это идея графика, а не снимок
конкретных данных.

Публичный интерфейс -- модульные функции поверх `ChartLabStore` (класс с
параметризуемым путём нужен тестам для изоляции от реального файла на диске)."""
from __future__ import annotations

import datetime as dt
import os
import tomllib
import uuid
from dataclasses import dataclass
from pathlib import Path

from cockpit_engine.charts import build_specs

_DIR = Path(__file__).parent

# Не коммитится (.gitignore) -- дев-only локальное состояние прототипов,
# аналогично src/cockpit_engine/web/static/chart-config.js.
DEFAULT_SAVED_PATH = _DIR / "chart_lab_saved.toml"


@dataclass(frozen=True)
class SavedChart:
    id: str
    name: str
    toml: str
    created_at: str | None = None
    updated_at: str | None = None


class ChartLabValidationError(Exception):
    """Тело TOML не прошло валидацию -- `code` совпадает с таксономией ошибок
    Preview (Задача 2): INVALID_TOML / INVALID_CHART_SPEC."""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


class SavedChartNotFoundError(Exception):
    """Update/Delete по несуществующему id."""

    def __init__(self, saved_id: str):
        super().__init__(f"сохранённый прототип {saved_id!r} не найден")
        self.saved_id = saved_id


def _now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


_NAMED_ESCAPES = {
    "\b": "\\b",
    "\t": "\\t",
    "\n": "\\n",
    "\f": "\\f",
    "\r": "\\r",
    '"': '\\"',
    "\\": "\\\\",
}


def _toml_basic_string(value: str) -> str:
    """Ручной, но строго по спеке TOML, энкодер basic string (однострочный,
    экранированный). Не используем сторонний писатель (`tomli-w` -- только
    dev-зависимость проекта, не тянуть её в продакшн-рантайм ради одного
    дев-only модуля) и не пытаемся класть сырой TOML в multi-line-строку
    (риск коллизии с `\"\"\"` внутри самого сохраняемого TOML) -- однострочный
    basic string с полным экранированием управляющих символов однозначен и
    проверяется штатным `tomllib` при чтении обратно."""
    out = []
    for ch in value:
        esc = _NAMED_ESCAPES.get(ch)
        if esc is not None:
            out.append(esc)
        elif ord(ch) < 0x20 or ord(ch) == 0x7F:
            out.append(f"\\u{ord(ch):04x}")
        else:
            out.append(ch)
    return '"' + "".join(out) + '"'


def _serialize(entries: dict[str, SavedChart]) -> str:
    lines: list[str] = []
    for sid, chart in entries.items():
        lines.append(f"[saved.{sid}]")
        lines.append(f"name = {_toml_basic_string(chart.name)}")
        lines.append(f"toml = {_toml_basic_string(chart.toml)}")
        if chart.created_at is not None:
            lines.append(f"created_at = {_toml_basic_string(chart.created_at)}")
        if chart.updated_at is not None:
            lines.append(f"updated_at = {_toml_basic_string(chart.updated_at)}")
        lines.append("")
    return "\n".join(lines)


def _read_all(path: Path) -> dict[str, SavedChart]:
    if not path.exists():
        return {}
    with open(path, "rb") as fh:
        raw = tomllib.load(fh)
    out: dict[str, SavedChart] = {}
    for sid, entry in raw.get("saved", {}).items():
        out[sid] = SavedChart(
            id=sid,
            name=entry.get("name", ""),
            toml=entry.get("toml", ""),
            created_at=entry.get("created_at"),
            updated_at=entry.get("updated_at"),
        )
    return out


def _write_all(path: Path, entries: dict[str, SavedChart]) -> None:
    """Атомарная запись (спека §14): временный файл -> `os.replace`. Гарантия
    ограничена одним dev-инстансом (распределённые блокировки -- вне скоупа,
    спека §14 явно)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_name(path.name + ".tmp")
    tmp_path.write_text(_serialize(entries), encoding="utf-8", newline="\n")
    os.replace(tmp_path, path)


def _validate_toml(toml_text: str) -> None:
    """Валидация тем же продакшн-парсером/билдером, что Preview (план, Задача 4,
    шаг «Create/Update must validate using the same production parser/validator
    as Preview»).

    TODO(chart-lab): заменить вызовом публичного build_chart_spec_from_mapping
    из build_specs.py после мёржа task-gracious-hopper-854d26-1 -- на момент
    этой задачи backend-core (параллельная Волна 1) ещё не смёржен, функция не
    видна в этой ветке. Временная валидация ниже вызывает уже существующий
    приватный продакшн build-path (`_build_types`/`_build_charts`, принимает
    in-memory dict уже сегодня -- см. tests/charts/test_chart_levels.py), не
    приватный Lab-DSL."""
    try:
        parsed = tomllib.loads(toml_text)
    except tomllib.TOMLDecodeError as exc:
        raise ChartLabValidationError("INVALID_TOML", str(exc)) from exc

    try:
        types_raw = build_specs._load("chart_types.toml")
        types = build_specs._build_types(types_raw)
        charts = build_specs._build_charts(parsed, types, chart_levels=[])
    except ValueError as exc:
        raise ChartLabValidationError("INVALID_CHART_SPEC", str(exc)) from exc

    if not charts:
        raise ChartLabValidationError(
            "INVALID_CHART_SPEC",
            "TOML должен содержать хотя бы один блок [charts.<id>]",
        )


class ChartLabStore:
    """CRUD над `chart_lab_saved.toml`. `path=None` -- реальный файл рядом с
    продакшн-конфигами графиков (`DEFAULT_SAVED_PATH`); тесты передают
    изолированный `tmp_path`, чтобы не трогать диск за пределами песочницы."""

    def __init__(self, path: Path | str | None = None):
        self._path = Path(path) if path is not None else DEFAULT_SAVED_PATH

    def list_saved(self) -> list[SavedChart]:
        return list(_read_all(self._path).values())

    def create_saved(self, name: str, toml_text: str) -> SavedChart:
        _validate_toml(toml_text)
        entries = _read_all(self._path)
        sid = uuid.uuid4().hex
        now = _now_iso()
        chart = SavedChart(id=sid, name=name, toml=toml_text, created_at=now, updated_at=now)
        entries[sid] = chart
        _write_all(self._path, entries)
        return chart

    def update_saved(self, saved_id: str, name: str, toml_text: str) -> SavedChart:
        _validate_toml(toml_text)
        entries = _read_all(self._path)
        existing = entries.get(saved_id)
        if existing is None:
            raise SavedChartNotFoundError(saved_id)
        updated = SavedChart(
            id=saved_id,
            name=name,
            toml=toml_text,
            created_at=existing.created_at,
            updated_at=_now_iso(),
        )
        entries[saved_id] = updated
        _write_all(self._path, entries)
        return updated

    def delete_saved(self, saved_id: str) -> None:
        entries = _read_all(self._path)
        if saved_id not in entries:
            raise SavedChartNotFoundError(saved_id)
        del entries[saved_id]
        _write_all(self._path, entries)


def list_saved() -> list[SavedChart]:
    return ChartLabStore().list_saved()


def create_saved(name: str, toml_text: str) -> SavedChart:
    return ChartLabStore().create_saved(name, toml_text)


def update_saved(saved_id: str, name: str, toml_text: str) -> SavedChart:
    return ChartLabStore().update_saved(saved_id, name, toml_text)


def delete_saved(saved_id: str) -> None:
    return ChartLabStore().delete_saved(saved_id)
