"""Движок диаграмм: toml-спеки → web/static/chart-config.js (build_specs)."""
