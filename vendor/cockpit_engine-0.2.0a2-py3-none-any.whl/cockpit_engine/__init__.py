"""Cockpit Engine — переиспользуемый движок управленческих досок.

Что делает: несёт domain-agnostic слой (правила, отчёты, веб-рендер, статика,
core-схема БД). Продукт подключается через Registration-API и остаётся движку
неизвестен по имени пакета.
Как используется: продукт в своём `__init__.py` вызывает
`cockpit_engine.register_domains(package_root=…, domain_packages=…)`.
От чего зависит: stdlib + psycopg/dotenv; НИ ОДНОГО импорта продуктового пакета.
"""
from cockpit_engine.registration import (  # noqa: F401
    Registration,
    register_domains,
    reset_registration,
    setting,
)

# Функция `registration()` НЕ ре-экспортируется здесь под тем же именем: пакетный
# атрибут `cockpit_engine.registration` обязан оставаться сабмодулем (идиома
# `from cockpit_engine import registration as reg; reg.registration()`,
# используемая тестами и внутренними модулями движка) — ре-экспорт функции под
# тем же именем затёр бы этот атрибут и сломал бы `from cockpit_engine import
# registration`. Доступ к функции — `cockpit_engine.registration.registration()`
# или `from cockpit_engine.registration import registration`.
__all__ = ["Registration", "register_domains", "reset_registration", "setting"]
