"""Единый реестр доменов — единственный источник перечня доменов И их поведения.

Что делает: держит перечень доменов и их паспорт (`DomainSpec`) в ОДНОМ месте.
Потребители берут отсюда и список (Класс-1 швов), и диспетчеризацию поведения
(Класс-2 швов): вместо `if domain == …` зовут callable из паспорта.

Как используется: `from cockpit_engine.domain_registry import DOMAIN_KEYS` (упорядоченный
кортеж ключей) либо `DOMAIN_REGISTRY` (ключ → DomainSpec). Заведение обычного домена =
одна запись реестра (+ его `build_report_scope`), 0 правок в точках диспетчеризации.

От чего зависит: НА УРОВНЕ ИМПОРТА — ничего из cockpit_engine (лист-модуль, безопасен от
циклов: `catalog` импортирует отсюда `DOMAIN_KEYS`). Доменные модули тянутся ЛЕНИВО в
телах обёрток-callables (при вызове, не при импорте) — так реестр остаётся import-leaf.

Разрезы: Cut 1 — key+grain (перечисления). Cut 2 — callables+levels (generic-диспетчер
recompute/view_source/read_api/rule_meta). Cut 6 (Фаза 3) — реестр чисто-сканерный:
все 4 домена (commerce/finance/settlement/pricing) объявляют себя через
domains/<key>/spec.py::DOMAIN_SPEC, DOMAIN_REGISTRY/DOMAIN_KEYS вычисляются ЛЕНИВО
(PEP 562 module __getattr__) как build_registry(), детерминированно (order, key).
"""
from __future__ import annotations

from cockpit_engine.domain_spec import DomainSpec


def _build_registry() -> dict[str, DomainSpec]:
    """Реестр доменов продукта: домены — только из <domain_packages>/<key>/spec.py.
    Env-фильтр (instance_profile, префикс из регистрации) сужает список для
    профиля инстанса — по умолчанию не действует."""
    from cockpit_engine import domain_scan, instance_profile
    from cockpit_engine.registration import registration
    reg = registration()
    full = domain_scan.build_registry(reg.domain_packages)
    if instance_profile.allowed_domains(reg.env_prefix) is None:
        return full
    return {k: v for k, v in full.items()
            if instance_profile.is_domain_allowed(k, reg.env_prefix)}


def __getattr__(name):                           # PEP 562 - ленивый доступ на атрибут
    if name == "DOMAIN_REGISTRY":
        return _build_registry()
    if name == "DOMAIN_KEYS":
        return tuple(_build_registry())
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
