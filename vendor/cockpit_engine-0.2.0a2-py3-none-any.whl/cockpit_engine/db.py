import os

import psycopg
from dotenv import load_dotenv

load_dotenv()


def get_dsn() -> str:
    dsn = os.environ.get("DATABASE_URL")
    if not dsn:
        raise RuntimeError(
            "DATABASE_URL is not set. Скопируйте .env.example в .env и заполните."
        )
    return dsn


def connect(autocommit: bool = False) -> psycopg.Connection:
    return psycopg.connect(get_dsn(), autocommit=autocommit)
