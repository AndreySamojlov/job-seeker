-- core/0001_historical_core.sql
-- Историческая БД: generic длинный стор наблюдений + категориальные атрибуты.
-- Мульти-кабинет / мульти-платформа. Объекты создаются без явной схемы,
-- чтобы тесты могли применять файл во временную схему (search_path).

CREATE TABLE IF NOT EXISTS cabinet (
    cabinet_id    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    marketplace   TEXT NOT NULL,
    external_code TEXT NOT NULL,
    name          TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (marketplace, external_code)
);

CREATE TABLE IF NOT EXISTS metric (
    metric_code TEXT PRIMARY KEY,
    domain      TEXT NOT NULL,
    title       TEXT NOT NULL,
    unit        TEXT,
    is_base     BOOLEAN NOT NULL DEFAULT FALSE,
    description TEXT
);

CREATE TABLE IF NOT EXISTS attribute_def (
    attr_code   TEXT PRIMARY KEY,
    grain       TEXT NOT NULL CHECK (grain IN ('sku', 'category')),
    domain      TEXT NOT NULL,
    title       TEXT NOT NULL,
    description TEXT
);

CREATE TABLE IF NOT EXISTS observation (
    cabinet_id  BIGINT  NOT NULL REFERENCES cabinet (cabinet_id),
    sku_id      TEXT    NOT NULL,
    obs_date    DATE    NOT NULL,
    metric_code TEXT    NOT NULL REFERENCES metric (metric_code),
    value       NUMERIC NOT NULL,
    loaded_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (cabinet_id, sku_id, obs_date, metric_code)
);

CREATE TABLE IF NOT EXISTS sku_attribute (
    cabinet_id BIGINT NOT NULL REFERENCES cabinet (cabinet_id),
    sku_id     TEXT   NOT NULL,
    obs_date   DATE   NOT NULL,
    attr_code  TEXT   NOT NULL REFERENCES attribute_def (attr_code),
    attr_value TEXT,
    loaded_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (cabinet_id, sku_id, obs_date, attr_code)
);

CREATE TABLE IF NOT EXISTS category_attribute (
    cabinet_id BIGINT NOT NULL REFERENCES cabinet (cabinet_id),
    category   TEXT   NOT NULL,
    obs_date   DATE   NOT NULL,
    attr_code  TEXT   NOT NULL REFERENCES attribute_def (attr_code),
    attr_value TEXT,
    loaded_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (cabinet_id, category, obs_date, attr_code)
);

CREATE INDEX IF NOT EXISTS observation_lookup
    ON observation (cabinet_id, metric_code, obs_date);
CREATE INDEX IF NOT EXISTS sku_attribute_lookup
    ON sku_attribute (cabinet_id, attr_code, obs_date);
