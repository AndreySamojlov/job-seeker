-- core/0006_report_section.sql
-- Слой понимания как адресуемые секции: строка на секцию (S20). report НЕ дропаем —
-- он остаётся посадочной полосой n8n-upsert и источником scope/AI для recompute.
-- Бэкфилл-копия из report, чтобы чтение работало сразу. Идемпотентно.

CREATE TABLE IF NOT EXISTS report_section (
    cabinet_id    BIGINT      NOT NULL REFERENCES cabinet (cabinet_id),
    domain        TEXT        NOT NULL,
    scope         TEXT        NOT NULL DEFAULT '',
    period_start  DATE        NOT NULL,
    section       TEXT        NOT NULL,
    payload       JSONB       NOT NULL,
    rules_version INTEGER,
    data_version  INTEGER,
    stale         BOOLEAN     NOT NULL DEFAULT false,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (cabinet_id, domain, scope, period_start, section),
    CONSTRAINT report_section_section_chk CHECK (section IN
        ('meta','signals','charts','digest','entity_tables','mechanics','ai'))
);

-- Бэкфилл meta + контент-секций из существующих report.payload.
INSERT INTO report_section (cabinet_id, domain, scope, period_start, section,
                            payload, rules_version, data_version, stale)
SELECT r.cabinet_id, r.domain, r.scope, r.period_start, m.section,
       r.payload -> m.key,
       CASE WHEN r.payload->'meta'->>'rules_version' ~ '^\d+$'
            THEN (r.payload->'meta'->>'rules_version')::int END,
       CASE WHEN r.payload->'meta'->>'data_version' ~ '^\d+$'
            THEN (r.payload->'meta'->>'data_version')::int END,
       false
FROM report r
CROSS JOIN (VALUES ('meta','meta'), ('signals','signals'), ('charts','chart_series'),
                   ('digest','digest'), ('entity_tables','entity_tables'),
                   ('mechanics','mechanics')) AS m(section, key)
WHERE r.payload ? m.key
ON CONFLICT (cabinet_id, domain, scope, period_start, section) DO NOTHING;

-- Бэкфилл секции ai (если есть ИИ-поля) со stale из ai_stale.
INSERT INTO report_section (cabinet_id, domain, scope, period_start, section,
                            payload, rules_version, data_version, stale)
SELECT r.cabinet_id, r.domain, r.scope, r.period_start, 'ai',
       (SELECT jsonb_object_agg(e.k, e.v) FROM jsonb_each(r.payload) AS e(k, v)
        WHERE e.k IN ('narrative','recommendations','actions','rationale')),
       CASE WHEN r.payload->'meta'->>'rules_version' ~ '^\d+$'
            THEN (r.payload->'meta'->>'rules_version')::int END,
       CASE WHEN r.payload->'meta'->>'data_version' ~ '^\d+$'
            THEN (r.payload->'meta'->>'data_version')::int END,
       COALESCE((r.payload->>'ai_stale')::boolean, false)
FROM report r
WHERE r.payload ?| ARRAY['narrative','recommendations','actions','rationale']
ON CONFLICT (cabinet_id, domain, scope, period_start, section) DO NOTHING;
