-- core/0002_category_observation.sql
-- Числовой стор на грани Категория × Date (напр. forecast_completion из «ВА по блокам»).
-- Идемпотентно; создаётся без явной схемы для тестов во временной схеме.

CREATE TABLE IF NOT EXISTS category_observation (
    cabinet_id  BIGINT  NOT NULL REFERENCES cabinet (cabinet_id),
    category    TEXT    NOT NULL,
    obs_date    DATE    NOT NULL,
    metric_code TEXT    NOT NULL REFERENCES metric (metric_code),
    value       NUMERIC NOT NULL,
    loaded_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (cabinet_id, category, obs_date, metric_code)
);

CREATE INDEX IF NOT EXISTS category_observation_lookup
    ON category_observation (cabinet_id, metric_code, obs_date);
