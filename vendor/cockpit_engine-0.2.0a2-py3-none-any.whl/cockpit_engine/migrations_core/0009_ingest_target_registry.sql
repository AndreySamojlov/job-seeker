-- Purpose: seed initial ingest targets idempotently; existing registry overrides are preserved.
CREATE TABLE IF NOT EXISTS ingest_target (
    marketplace TEXT NOT NULL,
    external_code TEXT NOT NULL,
    account_label TEXT NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (marketplace, external_code),
    UNIQUE (marketplace, account_label)
);

INSERT INTO ingest_target (marketplace, external_code, account_label, enabled)
VALUES
    ('ozon', 'cabinet190681_api', 'cabinet190681', TRUE),
    ('ozon', 'unix_api', 'unixfit', TRUE)
ON CONFLICT (marketplace, external_code) DO NOTHING;
