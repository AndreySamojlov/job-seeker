-- core/0014_ingest_coverage_source.sql
-- Ось ИСТОЧНИКА ЗАБОРА в журнале покрытия (спека 2026-08-02, §4.1;
-- task-keen-newton-beb0e0-1). Отметка перестаёт подписываться доменом и
-- начинает подписываться конкретным заходом в API.
--
-- ПОЧЕМУ ДОБАВЛЕНИЕ, А НЕ ПЕРЕИМЕНОВАНИЕ `domain` (находка прожарки, блокер).
-- Колонку `domain` читают ЧЕТЫРЕ живых потребителя вне модуля среза:
--   * ingest_api/retention.py:56,85 -- COVERAGE_DOMAINS + WHERE domain = %s.
--     Переименование => _gaps видит окно непокрытым => каждый кабинет каждую
--     ночь уходит в bootstrap на 90 дней при rate-limit 2 rps;
--   * domains/commerce/plan_generator.py:213,218 -- литерал domain='commerce'
--     в SQL; расхождение => FreshnessError => генератор плана Коммерции умирает;
--   * services/report/app/main.py:347 -- HTTP-контракт /ingest-window с n8n,
--     деплой которого от кода отвязан;
--   * ingest_api/performance_sync.py:278 -- is_range_covered чанкового
--     бэкафилла; расхождение => 145 async-отчётов заново при перезапуске.
-- Добавление колонки не задевает ни одного из них.
--
-- ПОЧЕМУ BACKFILL ОДНОЗНАЧЕН. Три снимочных забора (product_master,
-- logistics.stock, logistics.cluster_stock) покрытия НЕ ПИСАЛИ ВОВСЕ, поэтому
-- каждое историческое значение `domain` порождал ровно один раннер. Пары
-- `sales`/`product_master` (обе объявляют domain='commerce') в журнале
-- разойтись не могли -- вторая туда не писала. Соответствие держит
-- data_registry/ingest_sources.py::LEGACY_DOMAIN_TO_SOURCE (канарейка --
-- tests/data_registry/test_ingest_sources.py).
--
-- ПОЧЕМУ `source` NULLABLE. Строка, записанная старым кодом между накатом
-- миграции и выкаткой приложения, обязана лечь, а не уронить забор. Такую
-- строку измеритель просто не увидит (популяция граней ключуется источником),
-- и это честнее, чем угадать ей источник в CHECK-ограничении.
-- Идемпотентно.

ALTER TABLE ingest_coverage
    ADD COLUMN IF NOT EXISTS source TEXT;

-- `domain` перестаёт быть обязательным: у снимочных заборов легаси-домена НЕТ.
-- Это не ослабление контракта «отметка обязана быть подписана», а перенос
-- подписи на ось `source`: NULL здесь читается однозначно -- «отметка не
-- принадлежит легаси-оси, по которой резолвится окно забора».
--
-- Рассмотренная и отвергнутая альтернатива -- писать в `domain` тот же
-- идентификатор источника ('commerce.product_master'). Она сохранила бы
-- NOT NULL, но положила бы в колонку значение ДРУГОЙ ПРИРОДЫ: читатель
-- `retention` и `plan_generator` ожидает там домен, а получил бы забор, и
-- «домен известен» стало бы ложным впечатлением вместо честного «его нет».
ALTER TABLE ingest_coverage
    ALTER COLUMN domain DROP NOT NULL;

-- Рабочий доступ измерителя -- «все интервалы пары кабинет x ИСТОЧНИК,
-- задевающие окно». Симметричен существующему индексу по (cabinet_id, domain).
CREATE INDEX IF NOT EXISTS ingest_coverage_cabinet_source_range
    ON ingest_coverage (cabinet_id, source, date_to, date_from);

UPDATE ingest_coverage
SET source = CASE domain
        WHEN 'commerce'              THEN 'commerce.sales'
        WHEN 'marketing'             THEN 'marketing.ads'
        WHEN 'marketing_performance' THEN 'marketing.performance'
        WHEN 'settlement'            THEN 'settlement.transactions'
        WHEN 'settlement_mutual'     THEN 'settlement.mutual'
    END
WHERE source IS NULL
  AND domain IN ('commerce', 'marketing', 'marketing_performance',
                 'settlement', 'settlement_mutual');
