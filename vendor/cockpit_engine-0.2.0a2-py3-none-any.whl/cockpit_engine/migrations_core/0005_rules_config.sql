-- core/0005_rules_config.sql
-- S18: конфигурация правил как данные. rules_config — версионированный конфиг
-- домена (одна active-версия); ingest_run — журнал инжестов для штампа data_version.
CREATE TABLE IF NOT EXISTS rules_config (
    domain        text        NOT NULL,
    version       int         NOT NULL,
    config        jsonb       NOT NULL,
    status        text        NOT NULL CHECK (status IN ('active', 'retired', 'draft')),
    source        text        NOT NULL,
    published_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (domain, version)
);

CREATE UNIQUE INDEX IF NOT EXISTS rules_config_one_active
    ON rules_config (domain) WHERE status = 'active';

CREATE TABLE IF NOT EXISTS ingest_run (
    run_id      bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    cabinet_id  bigint      NOT NULL,
    domain      text        NOT NULL,
    finished_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ingest_run_cabinet_domain
    ON ingest_run (cabinet_id, domain);
