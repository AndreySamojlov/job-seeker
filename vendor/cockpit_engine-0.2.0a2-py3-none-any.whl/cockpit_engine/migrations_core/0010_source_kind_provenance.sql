-- core/0010_source_kind_provenance.sql
-- task-epic-data-registry-2 (эпик epic-epic-data-registry-1, спека
-- harness:docs/superpowers/archive/specs/2026-07-29-data-registry-epic-design.md §7):
-- провенанс — данные, а не скан кода. Колонка source_kind фиксирует, ЧЕМ
-- физически была записана строка, на четырёх генерик-сторах core-домена,
-- которые несёт общий шов загрузки (src/mp_cockpit/parsing/load.py):
-- observation, category_observation, sku_attribute, category_attribute.
--
-- Значения — словарь §7 плюс 'unknown' для исторических строк (карточка):
-- api / file / directive / view / python / unknown. ИСПРАВЛЕНО ПОСЛЕ РЕВЬЮ
-- (блокер 1, ревью 2026-07-29): на эти же четыре стора пишут НЕ только
-- load_rows/load_all — 'directive' ЖИВЁТ СЕГОДНЯ, а не зарезервирован на
-- будущее. Прямые писатели вне общего шва: domains/data_c/snapshot_import.py
-- (upsert_commerce_c_snapshot/upsert_logistics_c_snapshot — директивные формы
-- «C-снимок» Коммерции/Логистики, все 4 стора, ON CONFLICT DO NOTHING) и
-- domains/logistics/snapshot_import.py (upsert_logistics_snapshot —
-- директивная форма logistics_snapshot, ТОЛЬКО observation, ON CONFLICT DO
-- UPDATE). Все они правятся тем же срезом — см. итоги хода task-epic-
-- data-registry-2. 'view'/'python' на этих четырёх сторах пока не наблюдались
-- живым писателем (могут появиться позже — колонка не привязана к текущему
-- множеству производителей).
--
-- DEFAULT 'unknown' на ADD COLUMN — историческим строкам (уже накопленным до
-- этой миграции) провенанс неизвестен, это ЧЕСТНОЕ состояние (спека §7:
-- "первые дни после наката справочник честно скажет «класс неизвестен»"), не
-- подставное значение. PostgreSQL 11+ проставляет DEFAULT существующим
-- строкам без полного rewrite таблицы -- на боевом наполнении observation
-- (самая нагруженная таблица проекта) это безопасно.
--
-- Идемпотентно: ADD COLUMN IF NOT EXISTS + пересоздаваемый CHECK (DROP IF
-- EXISTS -> ADD), тот же приём, что settlement/0012.

ALTER TABLE observation
    ADD COLUMN IF NOT EXISTS source_kind TEXT NOT NULL DEFAULT 'unknown';
ALTER TABLE observation DROP CONSTRAINT IF EXISTS observation_source_kind_chk;
ALTER TABLE observation ADD CONSTRAINT observation_source_kind_chk
    CHECK (source_kind IN ('api', 'file', 'directive', 'view', 'python', 'unknown'));

ALTER TABLE category_observation
    ADD COLUMN IF NOT EXISTS source_kind TEXT NOT NULL DEFAULT 'unknown';
ALTER TABLE category_observation DROP CONSTRAINT IF EXISTS category_observation_source_kind_chk;
ALTER TABLE category_observation ADD CONSTRAINT category_observation_source_kind_chk
    CHECK (source_kind IN ('api', 'file', 'directive', 'view', 'python', 'unknown'));

ALTER TABLE sku_attribute
    ADD COLUMN IF NOT EXISTS source_kind TEXT NOT NULL DEFAULT 'unknown';
ALTER TABLE sku_attribute DROP CONSTRAINT IF EXISTS sku_attribute_source_kind_chk;
ALTER TABLE sku_attribute ADD CONSTRAINT sku_attribute_source_kind_chk
    CHECK (source_kind IN ('api', 'file', 'directive', 'view', 'python', 'unknown'));

ALTER TABLE category_attribute
    ADD COLUMN IF NOT EXISTS source_kind TEXT NOT NULL DEFAULT 'unknown';
ALTER TABLE category_attribute DROP CONSTRAINT IF EXISTS category_attribute_source_kind_chk;
ALTER TABLE category_attribute ADD CONSTRAINT category_attribute_source_kind_chk
    CHECK (source_kind IN ('api', 'file', 'directive', 'view', 'python', 'unknown'));

COMMENT ON COLUMN observation.source_kind IS
  'Провенанс строки (спека §7): api (ingest_api/* -> load_rows) | file (.xlsb -> parquet -> load_all) | directive (data_c/snapshot_import.py, logistics/snapshot_import.py — директивные формы) | unknown (строки до этой миграции — класс неизвестен, не подставное значение).';
COMMENT ON COLUMN category_observation.source_kind IS
  'Провенанс строки — см. observation.source_kind.';
COMMENT ON COLUMN sku_attribute.source_kind IS
  'Провенанс строки — см. observation.source_kind.';
COMMENT ON COLUMN category_attribute.source_kind IS
  'Провенанс строки — см. observation.source_kind.';
