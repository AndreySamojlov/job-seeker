-- core/0004_report_table.sql
-- Обобщённый историзированный report payload (мультидоменный). Дискриминатор domain;
-- нейтральные измерения scope (=business_unit; ''=весь кабинет) и period_start
-- (month_start для Финансов; obs_date — для Коммерции при будущем переносе). n8n
-- upsert'ит JSONB. Коммерческий commerce_report не затрагивается. Идемпотентно.

CREATE TABLE IF NOT EXISTS report (
    cabinet_id   BIGINT      NOT NULL REFERENCES cabinet (cabinet_id),
    domain       TEXT        NOT NULL,
    scope        TEXT        NOT NULL DEFAULT '',
    period_start DATE        NOT NULL,
    payload      JSONB       NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (cabinet_id, domain, scope, period_start)
);
