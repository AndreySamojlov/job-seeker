-- core/0017_registry_observation_shape.sql
-- НАБЛЮДЁННАЯ ФОРМА величины рядом с выведенной ожидаемой (спека 2026-08-02,
-- часть Б «довести форму до суточного снимка и журнала»).
--
-- ЗАЧЕМ ТРИ КОЛОНКИ. Форма -- строка `<расселение>/<изменчивость>/<ритм>/
-- <долговечность>`, например `entity/constant/on_change/point`
-- (`data_registry.shape`). Одна колонка `shape_observed` вместо четырёх --
-- снимок и без того широкий, а дифф журнала (`journal._TRACKED`) сравнивает
-- значения КАК СТРОКИ. `shape_expected` лежит рядом тем же приёмом, что
-- `class_expected`/`class_observed` (core/0011): расхождение обязано быть
-- воспроизводимо задним числом, а TOML к тому моменту уже поправят.
--
-- ВСЕ ТРИ NULLABLE -- И ЭТО ЗНАЧИМО. NULL значит «форма не выведена»: либо
-- наблюдений мало (`shape.MIN_TRANSITIONS`/`MIN_GRAINS`), либо снимок старше
-- этой миграции. Читается как «мерка остаётся сегодняшней» (пункт 4 закона
-- реестра: отсутствие наблюдения не спорит с декларацией) -- НЕ как «форма
-- пустая».
--
-- `shape_volatility` ХРАНИТСЯ ОТДЕЛЬНО ОТ КАТЕГОРИИ. Гистерезис
-- (`shape.LOW` = 1%, `shape.HIGH` = 5%) обязан быть воспроизводим задним
-- числом: без сырой доли переходов со сменой значения нельзя проверить,
-- ПОЧЕМУ категория в эти сутки не переключилась (число легло в зазор и
-- унаследовало вчерашнюю категорию) -- одной категорией этого не объяснить.
--
-- CHECK `data_registry_event_kind_chk` расширяется ОДНИМ именем --
-- `shape_changed` (смена наблюдённой формы, `journal._TRACKED`). Все ранее
-- допущенные имена (включая `measured_by_changed`, заведённый core/0016)
-- сохранены без изменений.
--
-- Идемпотентно: `ADD COLUMN IF NOT EXISTS`, `DROP CONSTRAINT IF EXISTS` ->
-- `ADD CONSTRAINT` -- тот же приём, что core/0010 и core/0016. Данные не
-- теряются и не мигрируют: колонки только добавляются, констрейнт только
-- расширяется, ни одна существующая строка не перестаёт ему удовлетворять.
--
-- ПРАВКА СЕМАНТИКИ `shape_expected` (core/0018, ревью 03.08). Строка выше
-- ("тем же приёмом, что class_expected/class_observed") подразумевала
-- полную строку формы -- на практике `shape.expected()` собирала все ЧЕТЫРЕ
-- оси из полей, которые декларация не утверждает, и сторож дрейфа ругался
-- на честное наблюдение (12 строк `sku_attr`/`cat_attr`, as_of-сторы без
-- `date_col`). С core/0018 колонка несёт ГОЛЫЙ ОЖИДАЕМЫЙ РИТМ строкой
-- (`"daily"`/`"monthly"`/`"on_change"`) -- см. её `COMMENT ON COLUMN`. Тип
-- (TEXT) не меняется, данные не мигрируют: следующий суточный прогон
-- перезаписывает `shape_expected` в новом виде сам (`write_snapshot`
-- удаляет-и-вставляет сутки).

ALTER TABLE data_registry_observation
    ADD COLUMN IF NOT EXISTS shape_observed TEXT;

ALTER TABLE data_registry_observation
    ADD COLUMN IF NOT EXISTS shape_expected TEXT;

ALTER TABLE data_registry_observation
    ADD COLUMN IF NOT EXISTS shape_volatility NUMERIC;

ALTER TABLE data_registry_event
    DROP CONSTRAINT IF EXISTS data_registry_event_kind_chk;
ALTER TABLE data_registry_event
    ADD CONSTRAINT data_registry_event_kind_chk CHECK (event IN (
        'baseline', 'appeared', 'disappeared', 'class_changed',
        'producer_changed', 'store_changed', 'grain_changed',
        'measured_by_changed', 'shape_changed',
        'confirm_drift', 'regression'));

COMMENT ON TABLE data_registry_event IS
  'Журнал изменений справочника (спека §7). Девять видов -- вывод диффа двух СОСЕДНИХ снимков (нет снимка за вчера -> baseline, а не appeared/disappeared; measured_by_changed -- смена способа измерения полноты, core/0015; shape_changed -- смена наблюдённой формы величины, core/0017); два вида -- ЯВНЫЕ АКТЫ человека, снимающие расхождение «наблюдение != декларация»: confirm_drift (правим декларацию) и regression (заводим карточку). Акты несут reason и переживают перезапуск суток.';
