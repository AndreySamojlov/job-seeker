-- core/0016_registry_event_measured_by_changed.sql
-- Вид события `measured_by_changed` допускается CHECK'ом журнала справочника
-- (карточка bug-great-hermann-a430d9-1).
--
-- ЗАЧЕМ. `core/0015` завела в снимке признак `measured_by` (чем измерена
-- полнота строки: фактами, отметками забора или обоими) и объявила его смену
-- событием — имя приехало в `journal._TRACKED`, но CHECK
-- `data_registry_event_kind_chk`, заведённый `core/0011`, о нём не знает.
-- `journal._diff` порождает событие по `_TRACKED`, `_write_events` пишет его в
-- `data_registry_event` — значит первая же строка, поехавшая с `facts` на
-- `both`, роняет суточную джобу `data_registry.daily` (она же гейт §9.4)
-- нарушением констрейнта. Не сработало до сих пор только потому, что ночной
-- ingest пишет отметки забора без `source`, и `measured_by` у всех строк пока
-- `facts`; как только забор начнёт проставлять `source`, значение поедет
-- массово.
--
-- ПОЧЕМУ CHECK ВООБЩЕ ЕСТЬ (сохраняем решение `core/0011`). Перечень видов
-- событий фиксирован, и новый вид обязан приезжать миграцией, а не опечаткой в
-- вызове. Отсюда и цена: код и схема ведут ДВА перечня, и они разошлись молча.
-- Сверку теперь держит канарейка `tests/data_registry/test_check_canary_db.py`
-- — она читает этот констрейнт из ЖИВОЙ схемы и сравнивает с константами
-- `journal.DIFF_EVENTS`/`ACTS`, поэтому следующее забытое имя падает тестом, а
-- не суточной джобой.
--
-- Идемпотентно: DROP CONSTRAINT IF EXISTS -> ADD CONSTRAINT, тот же приём, что
-- `core/0010` и `settlement/0012`. Данные не трогаются: перечень только
-- расширяется, ни одна существующая строка констрейнту не перестаёт
-- удовлетворять.

ALTER TABLE data_registry_event
    DROP CONSTRAINT IF EXISTS data_registry_event_kind_chk;
ALTER TABLE data_registry_event
    ADD CONSTRAINT data_registry_event_kind_chk CHECK (event IN (
        'baseline', 'appeared', 'disappeared', 'class_changed',
        'producer_changed', 'store_changed', 'grain_changed',
        'measured_by_changed',
        'confirm_drift', 'regression'));

COMMENT ON TABLE data_registry_event IS
  'Журнал изменений справочника (спека §7). Восемь видов -- вывод диффа двух СОСЕДНИХ снимков (нет снимка за вчера -> baseline, а не appeared/disappeared; measured_by_changed -- смена способа измерения полноты, core/0015); два вида -- ЯВНЫЕ АКТЫ человека, снимающие расхождение «наблюдение != декларация»: confirm_drift (правим декларацию) и regression (заводим карточку). Акты несут reason и переживают перезапуск суток.';
