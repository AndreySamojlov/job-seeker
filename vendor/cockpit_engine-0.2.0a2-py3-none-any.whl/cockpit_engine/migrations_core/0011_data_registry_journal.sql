-- core/0011_data_registry_journal.sql
-- task-epic-data-registry-4 (эпик epic-epic-data-registry-1, спека
-- harness:docs/superpowers/archive/specs/2026-07-29-data-registry-epic-design.md §7):
-- журнал справочника данных = суточный СНИМОК наблюдения плюс СОБЫТИЯ,
-- выведенные диффом двух соседних снимков.
--
-- ПОЧЕМУ ДВЕ ТАБЛИЦЫ, А НЕ ОДНА. Снимок отвечает на вопрос «что мы наблюдали
-- такого-то числа» (полное состояние, перезаписываемое прогоном суток), журнал
-- событий -- на вопрос «что изменилось» (append-only, включая ЯВНЫЕ АКТЫ
-- человека). Слить их значило бы либо потерять акты при перезапуске суток,
-- либо запретить перезапуск.
--
-- КЛЮЧ СНИМКА ВКЛЮЧАЕТ ДОМЕН. Карточка называет ключ «код x кабинет», но
-- attr_code уникален только ВНУТРИ домена: `cogs` -- строка-факт Финансов и
-- колонка вьюхи Взаиморасчётов, `ozon_min_price` -- две вьюхи (Коммерция и
-- Ценообразование). Ровно эту коллизию отдельно разруливает
-- data_completeness/address.py::_catalog_index. Без домена в ключе один домен
-- молча затирал бы наблюдение другого -- и справочник врал бы о классе.
--
-- class_observed НЕ ограничен CHECK'ом словаря A/B/B*/C/D/E: словарь живёт в
-- provenance.py (константа CLASSES) и уточняется срезами 5-7 (проектируемые
-- данные, ранги). Литера E -- пятый класс «факты есть, способ добычи
-- неизвестен»; решение владельца 2026-07-30, тем же решением существующие
-- литеры A/B/B*/C/D НЕ переименовываются. CHECK
-- на event, наоборот, ЕСТЬ -- перечень видов событий фиксирован карточкой, и
-- новый вид обязан приезжать миграцией, а не опечаткой в вызове.
--
-- Идемпотентно: CREATE TABLE IF NOT EXISTS + CREATE INDEX IF NOT EXISTS.

CREATE TABLE IF NOT EXISTS data_registry_observation (
    obs_day           DATE    NOT NULL,
    cabinet_id        INTEGER NOT NULL REFERENCES cabinet(cabinet_id) ON DELETE CASCADE,
    domain            TEXT    NOT NULL,
    code              TEXT    NOT NULL,
    class_observed    TEXT    NOT NULL,
    class_expected    TEXT    NOT NULL,
    producer_observed TEXT    NOT NULL DEFAULT '',
    store_observed    TEXT    NOT NULL DEFAULT '',
    grain             TEXT    NOT NULL,
    first_seen        DATE,
    last_seen         DATE,
    freshness         INTEGER,
    depth             INTEGER NOT NULL DEFAULT 0,
    present           INTEGER NOT NULL DEFAULT 0,
    expected          INTEGER NOT NULL DEFAULT 0,
    status            TEXT    NOT NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (obs_day, cabinet_id, domain, code)
);

COMMENT ON TABLE data_registry_observation IS
  'Суточный слепок НАБЛЮДЕНИЯ справочника данных (спека §7): класс из провенанса строк, три максимы data_completeness.maxims и статус лампочки на грань (кабинет x домен x код). Перезаписывается повторным прогоном тех же суток.';
COMMENT ON COLUMN data_registry_observation.class_observed IS
  'A/B/B*/C -- способ добычи, наблюдённый по source_kind свежих строк; D -- фактов нет; E -- факты есть, провенанс неизвестен (исторические строки до core/0010).';
COMMENT ON COLUMN data_registry_observation.class_expected IS
  'Класс, который строка ЗАЯВЛЯЕТ (data_registry.row.declared_class): class_expected TOML либо D у lifecycle=planned. Лежит в снимке, а не подтягивается на чтении, чтобы расхождение было воспроизводимо задним числом.';
COMMENT ON COLUMN data_registry_observation.freshness IS
  'Граней от последней точки до сегодня; NULL -- фактов нет вовсе (это НЕ «свежо», см. maxims.status).';

CREATE INDEX IF NOT EXISTS data_registry_observation_day_idx
    ON data_registry_observation (obs_day);

CREATE TABLE IF NOT EXISTS data_registry_event (
    event_id   BIGSERIAL PRIMARY KEY,
    obs_day    DATE    NOT NULL,
    cabinet_id INTEGER NOT NULL REFERENCES cabinet(cabinet_id) ON DELETE CASCADE,
    domain     TEXT    NOT NULL,
    code       TEXT    NOT NULL,
    event      TEXT    NOT NULL,
    from_value TEXT,
    to_value   TEXT,
    reason     TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT data_registry_event_kind_chk CHECK (event IN (
        'baseline', 'appeared', 'disappeared', 'class_changed',
        'producer_changed', 'store_changed', 'grain_changed',
        'confirm_drift', 'regression'))
);

COMMENT ON TABLE data_registry_event IS
  'Журнал изменений справочника (спека §7). Семь видов -- вывод диффа двух СОСЕДНИХ снимков (нет снимка за вчера -> baseline, а не appeared/disappeared); два вида -- ЯВНЫЕ АКТЫ человека, снимающие расхождение «наблюдение != декларация»: confirm_drift (правим декларацию) и regression (заводим карточку). Акты несут reason и переживают перезапуск суток.';
COMMENT ON COLUMN data_registry_event.from_value IS
  'Прежнее значение (у актов -- class_expected, то есть КОНКРЕТНОЕ расхождение, которое акт снимает: акт не прощает код навсегда).';

CREATE INDEX IF NOT EXISTS data_registry_event_row_idx
    ON data_registry_event (cabinet_id, domain, code, event_id DESC);
CREATE INDEX IF NOT EXISTS data_registry_event_day_idx
    ON data_registry_event (obs_day, cabinet_id);
