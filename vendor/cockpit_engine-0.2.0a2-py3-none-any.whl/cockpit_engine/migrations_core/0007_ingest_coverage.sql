-- core/0007_ingest_coverage.sql
-- Журнал ПОКРЫТИЯ забором: за какие даты мы ходили в API по паре кабинет x домен
-- (debt-nostalgic-bell-2cf5a3-7, epic-main-15/AC5). Отвечает на вопрос, на который
-- observation ответить не может: пустой день там двусмыслен («не ходили» vs
-- «ходили, операций не было»). Дыра в истории = дни окна без покрытия.
--
-- Почему отдельная таблица, а не колонки в ingest_run: ingest_run — штамп
-- data_version, пишется ТОЛЬКО при непустом заборе (src/mp_cockpit/ingest_api/
-- extractor.py). Покрытие обязано фиксировать в том числе пустой забор, а
-- поднимать data_version на заборе, ничего не изменившем, — ложный сигнал
-- «данные обновили, обсчёт забыли». Разные обязанности — разные таблицы.
--
-- Строки append-only, ≈1 в сутки на пару кабинет x домен. Идемпотентно.

CREATE TABLE IF NOT EXISTS ingest_coverage (
    coverage_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    cabinet_id  BIGINT      NOT NULL REFERENCES cabinet (cabinet_id),
    domain      TEXT        NOT NULL,
    date_from   DATE        NOT NULL,
    date_to     DATE        NOT NULL,
    fetched_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT ingest_coverage_range_chk CHECK (date_from <= date_to)
);

-- Рабочий доступ — «все интервалы пары кабинет x домен, задевающие окно».
CREATE INDEX IF NOT EXISTS ingest_coverage_cabinet_domain_range
    ON ingest_coverage (cabinet_id, domain, date_to, date_from);
