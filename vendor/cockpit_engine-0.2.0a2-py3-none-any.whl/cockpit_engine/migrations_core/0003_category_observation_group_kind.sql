-- core/0003_category_observation_group_kind.sql
-- Обобщение генерик-стора групп-наблюдений признаком грани group_kind
-- (category | product_type). Прогноз («ВА по блокам») ключуется по product_type —
-- бэкофиллим существующие forecast_completion-строки в эту грань. Идемпотентно.

ALTER TABLE category_observation
    ADD COLUMN IF NOT EXISTS group_kind TEXT NOT NULL DEFAULT 'category';

UPDATE category_observation
    SET group_kind = 'product_type'
    WHERE metric_code = 'forecast_completion' AND group_kind <> 'product_type';

ALTER TABLE category_observation DROP CONSTRAINT IF EXISTS category_observation_pkey;
ALTER TABLE category_observation
    ADD PRIMARY KEY (cabinet_id, group_kind, category, obs_date, metric_code);
