"""Env-фильтры доменов и кабинетов — штатная возможность движка.

Что делает: `<PREFIX>_DOMAINS` / `<PREFIX>_CABINETS` (CSV) сужают, какие домены и
кабинеты обслуживает инстанс. Пусто/не задано → фильтр не действует.
Как используется: движковые domain_registry / rules.source / report.view_source
берут префикс из Registration-API (`registration().env_prefix`); для mp-cockpit
это "MP_COCKPIT", то есть прежние имена переменных сохраняются дословно.
От чего зависит: только stdlib (os) — лист-модуль.
"""
from __future__ import annotations

import os


def _parse_csv(raw: str | None) -> frozenset[str] | None:
    if not raw or not raw.strip():
        return None
    items = frozenset(item.strip() for item in raw.split(",") if item.strip())
    return items or None


def allowed_domains(env_prefix: str) -> frozenset[str] | None:
    return _parse_csv(os.environ.get(f"{env_prefix}_DOMAINS"))


def allowed_cabinets(env_prefix: str) -> frozenset[str] | None:
    return _parse_csv(os.environ.get(f"{env_prefix}_CABINETS"))


def is_domain_allowed(key: str, env_prefix: str) -> bool:
    allowed = allowed_domains(env_prefix)
    return allowed is None or key in allowed


def is_cabinet_allowed(code: str, env_prefix: str) -> bool:
    allowed = allowed_cabinets(env_prefix)
    return allowed is None or code in allowed
