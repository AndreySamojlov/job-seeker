"""Страница /admin — лаунчер человеко-читаемых страниц MP Cockpit (срез
2026-08-23, дизайн — inline-спека в harness:docs/superpowers/plans/2026-08-23-admin-page.md).

Список страниц зависит только от env-флагов, читаемых один раз при старте
процесса — render_admin_page вызывается РОВНО один раз в create_app(), не на
каждый запрос: в отличие от /data (живые данные из БД), здесь нечему
устаревать между стартами приложения.
"""
from __future__ import annotations

import html

NavItem = tuple[str, str, str]  # (заголовок, описание, путь)

_REPORTS: tuple[NavItem, ...] = (
    ("Отчёт по бизнес-направлению",
     "Дашборд по домену: KPI, графики, сигналы, категории", "/report"),
    ("Витрина GA.MA (дневная экономика)",
     "Демо дневной экономики кабинета", "/reports/gama-daily"),
    ("Витрина unix-settlement",
     "Демо взаиморасчётов", "/reports/unix-settlement"),
)

_TOOLS: tuple[NavItem, ...] = (
    ("Данные",
     "Справочник классов, свежести и полноты по доменам", "/data"),
    ("Правила",
     "Каталог правил и действий", "/rules"),
    ("Граф корреляций",
     "Level A связи метрик", "/correlations/graph"),
)

# Таблица эффектов (эпик effect-table): рычаг->следствие через событийный
# измеритель, не корреляции (см. соседний "Граф корреляций" в _TOOLS выше --
# намеренно разные механизмы, общего кода нет). ТРЕБОВАНИЕ ПРОЕКТА: любая
# новая человеко-читаемая страница MP Cockpit (@app.get(...) в
# web/app.py потребителя, возвращающая FileResponse) обязана появиться здесь ЖЕ
# ходом, каким заводится сама страница -- не отдельным срезом "потом".
# Гейт от забывчивости -- tests/web/test_admin_page_completeness.py в
# репозитории mp-cockpit: падает, если человеко-читаемый роут не перечислен
# ни в одной группе этого файла.
_RECON: tuple[NavItem, ...] = (
    # Приоритетная точка входа (эпик консолидации, decomposing S5): один
    # рычаг сразу с доверием к измерению, следствиями и готовностью ответа --
    # закрывает то, что раньше требовало захода на четыре разные страницы
    # ниже. Те четыре остаются нарочно: raw-вид для аудита, кто не хочет
    # общего каркаса (решение владельца, Product Intent эпика).
    ("Рычаги",
     "Разбор одного рычага сразу: доверие к измерению, следствия, "
     "готовность ответа", "/recon/levers"),
    ("Таблица эффектов (raw)",
     "Вся сетка рычаг×следствие, ночной снимок", "/recon/matrix"),
    ("Происхождение confidence",
     "Объявленная уверенность действия рядом с измеренной", "/recon/confidence"),
    ("Сколько дней до ответа (raw)",
     "Счётчик независимых дней по рычагу", "/recon/countdown"),
    ("Прибор проверяет себя (raw)",
     "Самопроверка измерителя на плацебо", "/recon/selftest"),
    ("Паспорт рычага (raw)",
     "Профиль отклика одного рычага по всем следствиям", "/recon/passport"),
    ("Дерево разведки",
     "Накопление событий во времени, интерактивный ползунок", "/recon/tree"),
)

# Показывается только когда debug_enabled=True (см. render_admin_page) — та же
# переменная MP_COCKPIT_DEBUG_PAGE решает, регистрировать ли сами роуты
# /debug и /chart-lab (app.py::_debug_page_enabled), поэтому список здесь не
# может показать мёртвую ссылку.
_DEV: tuple[NavItem, ...] = (
    ("Отладка",
     "Механика отчёта, ручной пересчёт", "/debug"),
    ("Chart Lab",
     "Прототипирование графиков на реальных данных", "/chart-lab"),
)


def _esc(s: str) -> str:
    # quote=True — экранирует и кавычки: _esc(path) подставляется внутрь
    # атрибута href="...", и хотя сегодня все значения литеральные, заглушка
    # переключателя проекта явно объявлена местом под будущие не-литеральные
    # данные (ревью Задачи 1) — самодельный экранировщик тут не подстрахует.
    return html.escape(s, quote=True)


def _group_html(title: str, items: tuple[NavItem, ...]) -> str:
    rows = "".join(
        '<div class="adm-row">'
        '<div class="adm-row-main">'
        f'<span class="t">{_esc(name)}</span>'
        f'<span class="d">{_esc(desc)}</span>'
        "</div>"
        f'<a class="p" href="{_esc(path)}">{_esc(path)}</a>'
        "</div>"
        for name, desc, path in items
    )
    return f'<div class="adm-sec-h">{_esc(title)}</div>{rows}'


_STYLE = """
:root{
  --page:#EDEBE7; --sheet:#FFFFFF; --ink:#1C1C1A; --ink-soft:#54514B; --muted:#6F6C65;
  --hair:#E7E5E0; --hair-strong:#D8D5CE;
  --petrol:#0E5C58; --petrol-tint:#EAF1F0;
  --field:#FAF9F6;
  --r:8px; --r-lg:12px;
  --fs-title:15px; --fs-name:14px; --fs-base:13px; --fs-meta:12px; --fs-micro:11px;
  --font:"Golos Text",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
  --mono:ui-monospace,Menlo,Consolas,monospace;
}
*{box-sizing:border-box} html,body{margin:0}
body{background:var(--page);color:var(--ink);font-family:var(--font);font-size:var(--fs-base);
  line-height:1.5;-webkit-font-smoothing:antialiased}
.wrap{max-width:760px;margin:0 auto;padding:30px 22px 60px}
.top{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;margin-bottom:18px}
.brand{display:flex;align-items:center;gap:10px}
.brand .mk{width:18px;height:18px;border-radius:5px;background:var(--petrol)}
.brand h1{margin:0;font-size:var(--fs-title);font-weight:600}
.adm-proj{font-family:inherit;font-size:var(--fs-meta);color:var(--muted);
  border:1px solid var(--hair-strong);border-radius:var(--r);padding:6px 10px;
  background:var(--sheet);cursor:not-allowed}
.sheet{background:var(--sheet);border:1px solid var(--hair-strong);border-radius:var(--r-lg);overflow:hidden}
.accent{height:3px;background:var(--petrol)}
.adm-sec-h{font-size:var(--fs-micro);font-weight:600;text-transform:uppercase;letter-spacing:.05em;
  color:var(--muted);padding:12px 16px 6px;background:var(--field)}
.adm-row{display:flex;align-items:center;justify-content:space-between;gap:14px;
  padding:11px 16px;border-top:1px solid var(--hair)}
.adm-row-main{display:flex;flex-direction:column;gap:2px;min-width:0}
.adm-row .t{font-size:var(--fs-name);font-weight:600;color:var(--ink)}
.adm-row .d{font-size:var(--fs-meta);color:var(--muted)}
.adm-row .p{font-family:var(--mono);font-size:var(--fs-meta);color:var(--petrol);
  text-decoration:none;white-space:nowrap;flex:none}
.adm-row .p:hover{text-decoration:underline}
"""

_PAGE_TEMPLATE = """<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MP Cockpit — Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Golos+Text:wght@400;500;600&display=swap" rel="stylesheet">
<style>__STYLE__</style>
</head>
<body>
<div class="wrap">
  <div class="top">
    <div class="brand"><span class="mk"></span><h1>Admin</h1></div>
    <select class="adm-proj" disabled title="Переключение проектов — скоро">
      <option>MP Cockpit</option>
    </select>
  </div>
  <div class="sheet"><div class="accent"></div>
__BODY__
  </div>
</div>
</body>
</html>
"""


def render_admin_page(debug_enabled: bool) -> str:
    """Полный HTML-документ /admin. Вызывается ровно один раз в create_app()."""
    groups = [_group_html("Отчёты", _REPORTS), _group_html("Инструменты", _TOOLS),
             _group_html("Таблица эффектов", _RECON)]
    if debug_enabled:
        groups.append(_group_html("Служебное (dev)", _DEV))
    body = "".join(groups)
    return _PAGE_TEMPLATE.replace("__STYLE__", _STYLE).replace("__BODY__", body)
