"""Движковая половина веб-слоя: страницы и API, не зависящие от доменов продукта.

Что делает: отдаёт `/health`, статические страницы отчёта/правил/справочника,
отладочные страницы и (частично — см. итоговое разбиение chart-lab) API
лаборатории диаграмм; здесь же — FastAPI-зависимость соединения с БД.
Как используется: продукт создаёт FastAPI-приложение сам и зовёт
`register_engine_routes(app, static_file=…)`, после чего дописывает СВОИ
доменные маршруты (включая те chart-lab-хендлеры, что зависят от `read_api`
и `report.view_source` — см. срез E1, находка ревью Task 6).
От чего зависит: fastapi, cockpit_engine.{db,charts.chart_lab_store,web.admin_page}.
Доменных имён и `read_api` не содержит — проверяется тестом продукта.

Отклонение от буквального текста плана E1 (осознанное, задокументировано в
итогах Task 11): `register_engine_routes` НЕ принимает `get_connection`.
Изначально предполагалось, что chart-lab preview/categories тоже уедут в
движок — им соединение нужно; после находки ревью Task 6 обе эти ручки
остались в продукте (тянут `read_api`/`report.view_source`), и ни один из
движковых маршрутов соединения не открывает. Сама зависимость `get_connection`
живёт здесь и импортируется продуктом — параметр был бы мёртвым.
"""
from __future__ import annotations

import os

from fastapi import HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, Response

from cockpit_engine.charts import chart_lab_store
from cockpit_engine.db import connect
from cockpit_engine.web.admin_page import render_admin_page


def _debug_page_enabled() -> bool:
    """Страница /debug — только там, где явно разрешена (Тест-стенд, dev).

    Читается на создании приложения, не на импорте модуля: тест/preview подменяют
    окружение до create_app(). Пустая/отсутствующая переменная = выключено, поэтому
    Прод чист по построению — чтобы включить, нужно осознанное действие в compose.
    Префикс переменной — из Registration-API (`env_prefix`, продукт объявляет его
    при регистрации), не хардкод конкретного продукта — критерий 3 спеки E1."""
    from cockpit_engine.registration import registration

    prefix = registration().env_prefix
    return os.environ.get(f"{prefix}_DEBUG_PAGE", "").strip().lower() in {"1", "true", "yes", "on"}


def _admin_page_enabled() -> bool:
    """Страница /admin (лаунчер страниц) — независимый флаг от _debug_page_enabled:
    /admin может быть включена на Тесте без /debug и наоборот. Тот же паттерн
    (читается на создании приложения, не на импорте модуля; префикс — из
    Registration-API, см. `_debug_page_enabled`)."""
    from cockpit_engine.registration import registration

    prefix = registration().env_prefix
    return os.environ.get(f"{prefix}_ADMIN_PAGE", "").strip().lower() in {"1", "true", "yes", "on"}


def _saved_chart_to_dict(saved: chart_lab_store.SavedChart) -> dict:
    return {
        "id": saved.id,
        "name": saved.name,
        "toml": saved.toml,
        "created_at": saved.created_at,
        "updated_at": saved.updated_at,
    }


async def _parse_saved_chart_body(request: Request) -> tuple[str, str]:
    """Общий разбор тела POST/PUT chart-lab/saved: `{"name": ..., "toml": ...}`."""
    try:
        body = await request.json()
    except Exception as exc:
        raise HTTPException(400, f"Невалидное тело запроса: {exc}") from exc
    if not isinstance(body, dict):
        raise HTTPException(400, "Тело запроса должно быть JSON-объектом")
    name = body.get("name")
    toml_text = body.get("toml")
    if not isinstance(name, str) or not name.strip():
        raise HTTPException(400, "name обязателен и должен быть непустой строкой")
    if not isinstance(toml_text, str) or not toml_text.strip():
        raise HTTPException(400, "toml обязателен и должен быть непустой строкой")
    return name, toml_text


def get_connection():
    """Зависимость FastAPI: соединение на запрос, закрывается после ответа.

    Падение коннекта → 503 (как report-сервис S5): селлеру дружелюбнее, чем сырой 500."""
    try:
        conn = connect()
    except Exception as exc:
        raise HTTPException(503, f"Ошибка подключения к БД: {exc}") from exc
    try:
        yield conn
    finally:
        conn.close()


def register_engine_routes(app, *, static_file) -> None:
    """Навесить движковые маршруты на переданное приложение продукта.

    static_file — резолвер имени файла статики продукта (продукт знает про свои
    два каталога, движок — нет).

    Регистрируются: `/health`, `/`, `/report`, `/rules`, `/data`, `/admin`
    (под своим env-флагом), `/debug` и дев-гейченные chart-lab маршруты, НЕ
    зависящие от доменных модулей: страница `/chart-lab` и чистый CRUD
    сохранённых прототипов поверх `chart_lab_store`. Chart-lab `preview` и
    `categories` регистрирует продукт — они ходят в `read_api`/`view_source`.
    """

    @app.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/rules")
    def rules_page() -> FileResponse:
        return FileResponse(static_file("rules.html"),
                            headers={"Cache-Control": "no-cache"})

    @app.get("/data")
    def data_page() -> FileResponse:
        return FileResponse(static_file("data.html"),
                            headers={"Cache-Control": "no-cache"})

    if _admin_page_enabled():
        _admin_html = render_admin_page(_debug_page_enabled())

        @app.get("/admin")
        def admin_page() -> HTMLResponse:
            """Лаунчер всех человеко-читаемых страниц (harness:docs/superpowers/plans/
            2026-08-23-admin-page.md). HTML собран один раз выше в create_app() --
            зависит только от env-флагов, а не от БД, пересчитывать на каждый
            запрос незачем."""
            return HTMLResponse(content=_admin_html, headers={"Cache-Control": "no-cache"})

    @app.get("/")
    @app.get("/report")
    def index() -> FileResponse:
        return FileResponse(static_file("index.html"), headers={"Cache-Control": "no-cache"})

    if _debug_page_enabled():
        @app.get("/debug")
        def debug_page() -> FileResponse:
            """Внутренняя страница механики отчёта (S13). Ссылок с демо нет — прямой URL.

            Регистрируется только при MP_COCKPIT_DEBUG_PAGE=1 (Тест-стенд, dev). На Проде
            переменной нет → роут не существует, страница отладки с ручным «Пересчитать»
            наружу не торчит вовсе (не «спрятана за oauth»)."""
            return FileResponse(static_file("debug.html"), headers={"Cache-Control": "no-cache"})

        @app.get("/chart-lab")
        def chart_lab_page() -> FileResponse:
            """Chart Lab UI (эпик Chart Lab, Волна 2, Задача 5 плана docs/superpowers/
            plans/2026-08-20-chart-lab.md) -- тот же дев-гейт, что /debug: без
            MP_COCKPIT_DEBUG_PAGE роут не зарегистрирован вовсе."""
            return FileResponse(static_file("chart-lab.html"), headers={"Cache-Control": "no-cache"})

        @app.get("/v1/mp-cockpit/chart-lab/saved")
        def chart_lab_list_saved() -> dict:
            """Список сохранённых прототипов (task-gracious-hopper-854d26-3, Задача 4).

            Дев-only, как /debug — без MP_COCKPIT_DEBUG_PAGE роута не существует."""
            items = [_saved_chart_to_dict(s) for s in chart_lab_store.list_saved()]
            return {"items": items}

        @app.post("/v1/mp-cockpit/chart-lab/saved", status_code=201)
        async def chart_lab_create_saved(request: Request) -> dict:
            """Явное `Save` (спека §11) — Render НИКОГДА не сохраняет, только этот роут
            пишет chart_lab_saved.toml. Create валидирует тем же продакшн-путём, что
            Preview (см. chart_lab_store._validate_toml — временный TODO-обход, пока
            backend-core Волны 1 не смёржен)."""
            name, toml_text = await _parse_saved_chart_body(request)
            try:
                saved = chart_lab_store.create_saved(name, toml_text)
            except chart_lab_store.ChartLabValidationError as exc:
                raise HTTPException(
                    400, detail={"code": exc.code, "message": exc.message}) from exc
            return _saved_chart_to_dict(saved)

        @app.put("/v1/mp-cockpit/chart-lab/saved/{saved_id}")
        async def chart_lab_update_saved(saved_id: str, request: Request) -> dict:
            """`Update` (спека §12) — заменяет TOML/имя выбранного прототипа, новой
            записи не создаёт."""
            name, toml_text = await _parse_saved_chart_body(request)
            try:
                saved = chart_lab_store.update_saved(saved_id, name, toml_text)
            except chart_lab_store.SavedChartNotFoundError as exc:
                raise HTTPException(404, str(exc)) from exc
            except chart_lab_store.ChartLabValidationError as exc:
                raise HTTPException(
                    400, detail={"code": exc.code, "message": exc.message}) from exc
            return _saved_chart_to_dict(saved)

        @app.delete("/v1/mp-cockpit/chart-lab/saved/{saved_id}", status_code=204)
        def chart_lab_delete_saved(saved_id: str) -> Response:
            """`Delete` (спека §13) — без архива/корзины/истории версий."""
            try:
                chart_lab_store.delete_saved(saved_id)
            except chart_lab_store.SavedChartNotFoundError as exc:
                raise HTTPException(404, str(exc)) from exc
            return Response(status_code=204)
