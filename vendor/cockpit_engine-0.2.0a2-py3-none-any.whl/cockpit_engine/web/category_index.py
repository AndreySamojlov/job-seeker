"""Единое состояние категорий для селектора отчёта."""
from __future__ import annotations

from collections.abc import Iterable, Mapping


def _renderable_categories(payload: Mapping) -> set[str]:
    """Категории с данными для третьей канонической главы отчёта."""
    if payload.get("empty_slice") or payload.get("slice_unsupported"):
        return set()
    categories: set[str] = set()
    for table in (payload.get("entity_tables") or {}).values():
        for row in table.get("rows") or []:
            category = row.get("category")
            if isinstance(category, str) and category:
                categories.add(category)
    return categories


def build_category_options(catalog: Iterable[Mapping], payload: Mapping,
                           category_activity=None) -> list[dict]:
    """Возвращает полный каталог с доступностью для уже рассчитанного отчёта."""
    available = (category_activity(payload) if category_activity is not None
                 else _renderable_categories(payload))
    return [
        {
            "value": value,
            "label": str(item.get("label") or value),
            "availability": "available" if value in available else "empty",
        }
        for item in catalog
        if isinstance((value := item.get("value")), str) and value
    ]


def attach_category_options(payload: dict, catalog: Iterable[Mapping], activity_payload: Mapping,
                            category_activity=None) -> dict:
    """Добавляет CategoryIndex к payload, не меняя его активный срез."""
    meta = payload.get("meta")
    if not isinstance(meta, dict):
        meta = {}
        payload["meta"] = meta
    meta["category_options"] = build_category_options(
        catalog, activity_payload, category_activity=category_activity)
    return payload

def compare_category_availability(before: Iterable[Mapping], after: Iterable[Mapping]) -> dict:
    """Диагностика доли смены статусов без продуктового алерта."""
    previous = {str(item.get("value") or ""): item.get("availability") for item in before}
    current = {str(item.get("value") or ""): item.get("availability") for item in after}
    values = sorted((set(previous) | set(current)) - {""})
    changed = [value for value in values if previous.get(value) != current.get(value)]
    total = len(values)
    ratio = len(changed) / total if total else 0.0
    return {"total": total, "changed": changed, "ratio": ratio,
            "exceeds_limit": ratio > 0.2}