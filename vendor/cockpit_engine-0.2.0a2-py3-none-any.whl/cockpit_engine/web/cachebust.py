"""cachebust — контент-хэш ?v= для локальной статики (H4, Cut 4b).

Что делает: считает контент-хэш каждого /static/-файла и переписывает ?v=-токены ссылок на него.
Как используется: CLI `python -m cockpit_engine.web.cachebust [static_dir]` в Dockerfile при деплое
(после build_specs). От чего зависит: stdlib (hashlib, re, pathlib). Трогает только src|href на
/static/ с ?v=; относительные/внешние/inline-fetch — не трогает.
"""
import hashlib
import pathlib
import re
import sys

_REF = re.compile(r'((?:src|href)="/static/([^"?]+))\?v=[^"]*"')


def content_hash(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()[:10]


def rewrite_html(html: str, static_dirs) -> str:
    """static_dirs — Path (обратная совместимость) либо последовательность Path:
    ссылка ищется по корням по порядку, первый нашедший побеждает."""
    roots = [static_dirs] if isinstance(static_dirs, pathlib.Path) else list(static_dirs)

    def repl(m):
        prefix, rel = m.group(1), m.group(2)
        for root in roots:
            f = root / rel
            if f.is_file():
                return f'{prefix}?v={content_hash(f)}"'
        return m.group(0)
    return _REF.sub(repl, html)


def main(argv=None):
    """CLI: `python -m cockpit_engine.web.cachebust [dir ...]`. Каждый .html из
    КАЖДОГО каталога переписывается; ссылки резолвятся по всем каталогам сразу —
    страница движка ссылается на скрипт продукта и наоборот."""
    argv = sys.argv[1:] if argv is None else argv
    roots = [pathlib.Path(a) for a in argv] or [pathlib.Path(__file__).parent / "static"]
    for root in roots:
        for page in sorted(root.glob("*.html")):
            page.write_text(rewrite_html(page.read_text(encoding="utf-8"), roots),
                            encoding="utf-8", newline="\n")


if __name__ == "__main__":
    main()
