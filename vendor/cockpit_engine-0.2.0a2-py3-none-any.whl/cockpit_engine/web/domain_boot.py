"""Генератор фронт-загрузчика доменов: чистая функция, адресата записи не знает.

Что делает: из манифеста [{key, label}] строит текст domains-boot.js —
window.DOMAIN_MANIFEST + синхронную загрузку доменных <script> в порядке
манифеста через document.write (сохраняет порядок registerDomain перед app.js).
Как используется: продукт зовёт render_boot(manifest, static_dir) и сам пишет
результат в СВОЮ статику — каталог пакета движка при wheel-инсталле read-only.
От чего зависит: json + cockpit_engine.web.cachebust (само-хэширование ?v=
доменных тегов: они живут внутри JS-строк, обычный cachebust их не видит).
"""
from __future__ import annotations

import json
import logging
import pathlib

from cockpit_engine.web import cachebust


def script_ref(key: str, static_dir: pathlib.Path) -> str:
    f = static_dir / f"{key}.js"
    if not f.is_file():
        logging.getLogger(__name__).warning(
            "domain_boot: домен %r зарегистрирован, но %s отсутствует — тег без версии",
            key, f)
        return f"/static/{key}.js?v=dev"
    return f"/static/{key}.js?v={cachebust.content_hash(f)}"


def render_boot(manifest: list[dict], static_dir: pathlib.Path) -> str:
    tags = "".join(
        f'document.write(\'<script src="{script_ref(m["key"], static_dir)}"><\\/script>\');\n'
        for m in manifest)
    return (
        '"use strict";\n'
        "// СГЕНЕРИРОВАНО cockpit_engine.web.domain_boot из реестра доменов. Не редактировать.\n"
        "window.DOMAIN_MANIFEST = " + json.dumps(manifest, ensure_ascii=False) + ";\n"
        + tags
    )
