"use strict";

// signals-table.js — движок блока «Что требует внимания»: табы уровней,
// фокус-чипы, единая таблица сущностей, пейджинг, drill.
// Приватное состояние: sigState. Публичный вход: renderSignals(payload).
// Читает общий DOMAIN (объявлен в shared.js) и утиль из core.js.
//
// Что здесь БОЛЬШЕ НЕ живёт. С задачи 3 «Интерактивность табличного движка»
// (14.08): поиск по тексту и фильтр по значению колонки — механика ЛЮБОЙ
// таблицы движка (tblSearchBar/tblApplyFilters, table-engine.js); блок
// сигналов лишь объявляет, по каким колонкам искать (level.searchCols) и
// какая колонка фильтруется значениями (level.catFilter → col.filter). С
// task-main-191 (17.08) — РЕШЕНИЕ 14.08 «строка поиска и severity-кнопки
// крит/вним/ок остаются в домене» ОТМЕНЕНО владельцем (спека
// harness:docs/superpowers/archive/specs/2026-08-17-table-engine-gama-signals-unification-design.md,
// П4/П5): обе сняты с экрана целиком, их работу берут фильтры колонок того же
// движка — searchCols транслируется в col.filter="text" (withFilterDecl),
// тяжесть — виртуальная фильтруемая колонка __sev на «Правила»/«Внимание»
// (filterKey/filterLabel). Поиск в движке НЕ удалён —
// tblSearchBar/tblSearchRows/level.searchCols остаются рабочими и
// тестируемыми примитивами, просто не вызываются отсюда; вернуть строку
// поиска в UI — три строки в renderPanel (см. renderPanel ниже).
// С task-main-196 (18.08, П6 спеки 2026-08-18-table-engine-polish-design.md)
// ТИП этой воронки — "tiers": четыре строки-тира со счётчиками
// (крит/вним/ок/пусто) вместо одиночного селекта «крит/вним/ок».
//
// Что остаётся намеренно: severity как ДОМЕННОЕ ЗНАНИЕ — движок про правила
// знать не должен, colValue отдаёт ему вслепую готовую карту счётчиков через
// ключ "__sev" (fixed:true на колонках-носителях — без него filterKey
// открывает молчащий неснимаемый фильтр через cs.hidden, находка прожарки П5).
// ВАЖНОЕ РАЗДЕЛЕНИЕ (task-main-196, §П6.1): в домене живут ДВА расчёта тяжести
// с РАЗНЫМИ основаниями, и сводить их к одному нельзя —
//   sevCounts(row)          — карта счётчиков для ВОРОНКИ; строится из всех
//                             rule_hits, фокус НЕ читает (иначе фильтр
//                             перестаёт быть снимаемым);
//   rowSevFor(row, focus)   — ОДИН тир для ОКРАСКИ полоски .lead,
//                             метрик-ячеек и бара «Внимание»; от фокуса
//                             зависит, как и раньше.
// И пейджинг — нужен блоку с сотнями строк, не нужен витрине GA.MA с тремя
// десятками; этого решения 14.08 разворот не касается.

// ===== Сигналы (S17): табы уровней + фокус-чипы над единой таблицей =====

const SEV_LABELS = { crit: "крит", warn: "вним", ok: "ок" };
// Воронка тяжести (task-main-196, П6 спеки 2026-08-18): ЧЕТЫРЕ строки-тира со
// счётчиками вместо прежнего одиночного селекта «крит/вним/ок»
// (SEV_FILTER_ORDER типа "values" снят). Домен объявляет ключ, подпись и ЦВЕТ
// кружка — движок читает декларацию и не знает про правила ни слова; цвет
// повторяет ячеечный словарь кружков «Правил» (.hitsc .hit.*, styles.css),
// чтобы строка меню читалась как подпись к тому, что видно в ячейке (Р4-A).
// Четвёртый тир «пусто» объявлен БЕЗ цвета (color: null) — движок рисует его
// контурным кружком. Он разводит два смысла, которые прежний одиночный селект
// сливал в один: «худший тир — ок» и «правил не сработало вовсе» (worstSev
// стартует с "info", sevPill("info") → "ok").
const SEV_TIERS = [
  { key: "crit", label: "крит", color: "var(--sev-crit)" },
  { key: "warn", label: "вним", color: "var(--sev-warn)" },
  { key: "ok", label: "ок", color: "var(--sev-ok)" },
  { key: "none", label: "пусто", color: null },
];
const BRIEF_N = 8;
const PAGE_SIZE = 50;

// level: активный уровень; focus[level]: код правила | null; view[level]: фильтры.
const sigState = { level: undefined, focus: {}, mode: "brief", view: {}, cols: {} };

// Идентичность payload: новый объект (свежая загрузка/пересчёт) ⇒ сброс ручных ширин (авто-подгон).
let lastPayload = null;

function rowsFor(payload, levelKey) {
  const et = payload.entity_tables || {};
  return (et[levelKey] && et[levelKey].rows) || [];
}

function hitsOf(row) { return row.rule_hits || {}; }

// ЕДИНЫЙ ПРЕДИКАТ «правило засчитано» (task-main-196, §П6.2). До него предикат
// был расщеплён и давал ЖИВОЕ расхождение: hitsCell рисовал кружки только для
// объявленных правил, а hitCount (сортировка «Правил») и worstSev (окраска
// .lead/метрик/бара) перебирали ВСЕ ключи rule_hits — колонка могла показать
// 3 кружка и отсортироваться как 4, а строка без единого кружка — гореть
// красной полоской. Что это не теория, доказывает комментарий в самом коде:
// logistics.js:179-183 описывает случай, когда бэк слал коды вне объявлений и
// «оба сигнала были невидимы нигде».
// Четыре точки применения и ровно они: sevCounts, hitCount, worstSev,
// hitsCell. НЕ применяется в rowSevFor (читает один хит по коду фокуса, а
// фокус ставится только кликом по чипу — чипы строятся исключительно для
// известных кодов, см. renderPanel) и в ruleSevCounts (вызывается из того же
// цикла уже после отсева) — там предикат был бы no-op.
// Отклонено: устойчивость к отсутствию DOMAIN через typeof (идиома есть в
// chart-render.js) — ветка-фолбэк вела бы себя ПРОТИВОПОЛОЖНО правилу
// (считала бы все хиты), а тесты проверяли бы фолбэк вместо спецификации.
// DOMAIN в браузере существует всегда (shared.js), ruleDefs объявляют все семь
// доменов.
function ruleKnown(code) { return !!DOMAIN.ruleDefs[code]; }

function worstSev(row) {
  const order = { critical: 2, warning: 1 };
  let worst = "info";
  for (const [code, h] of Object.entries(hitsOf(row))) {
    if (!ruleKnown(code)) continue;
    if ((order[h.severity] || 0) > (order[worst] || 0)) worst = h.severity;
  }
  return sevPill(worst);
}

// Карта счётчиков тиров строки — значение воронки тяжести (task-main-196,
// НЕСУЩАЯ КОНСТРУКЦИЯ §П6.1, решение Р9). Строится ВСЕГДА из rule_hits строки
// и НЕ ЗАВИСИТ ОТ ФОКУСА ПРАВИЛА: rowSevFor к ней не привлекается вовсе. Это
// не упущение, а условие снимаемости фильтра — n у каждого тира не меняется
// при переключении фокуса, значит строка воронки не может пропасть из меню,
// значит поставленное ограничение всегда видно и снимаемо; и «пусто» получает
// ЕДИНСТВЕННОЕ определение (засчитанных хитов ноль), без двойного счёта.
// ЧЕСТНАЯ ЦЕНА, записанная как ОЖИДАЕМОЕ ПОВЕДЕНИЕ, а не дефект: в режиме
// фокуса видимая колонка «Внимание» красится тиром ФОКУСНОГО правила
// (rowSevFor), а воронка считает ВСЕ правила строки — поэтому фильтр
// «крит ≥ 1» вправе оставить строку с серым или зелёным баром, если крит даёт
// ДРУГОЕ правило. Приводить одно к другому нельзя: синхронизация с фокусом
// разрушила бы снимаемость фильтра (§10 п.9 спеки — отдельное продуктовое
// решение, не доводка).
// Счёт ФАКТИЧЕСКИЙ, не видимый: hitsCell сворачивает хвост в «+N» после CAP,
// но свёртка — экономия отрисовки, а не факт о данных.
function sevCounts(row) {
  const c = { crit: 0, warn: 0, ok: 0 };
  for (const [code, h] of Object.entries(hitsOf(row))) {
    if (!ruleKnown(code)) continue;
    c[sevPill(h.severity)]++;
  }
  c.none = (c.crit + c.warn + c.ok) === 0 ? 1 : 0;
  return c;
}

// Тир-разбивка хитов правила по строкам уровня: {crit, warn, ok}.
// sevPill (core.js): critical→crit, warning|warn→warn, иначе ok.
function ruleSevCounts(rows, code) {
  const c = { crit: 0, warn: 0, ok: 0 };
  for (const row of rows) {
    const h = (row.rule_hits || {})[code];
    if (h) c[sevPill(h.severity)]++;
  }
  return c;
}

// Худший присутствующий тир (crit > warn > ok) или null, если хитов нет.
function worstTier(counts) {
  if (counts.crit) return "crit";
  if (counts.warn) return "warn";
  if (counts.ok) return "ok";
  return null;
}

function rowSevFor(row, focusCode) {
  if (focusCode) {
    const h = hitsOf(row)[focusCode];
    return h ? sevPill(h.severity) : "ok";
  }
  return worstSev(row);
}

function cellText(col, row) {
  const v = row[col.key];
  if (col.kind === "pct") return fmtPctAdaptive(v);
  if (col.kind === "num") return fmtAdaptive(v);
  return v === null || v === undefined || v === "" ? "—" : String(v);
}

function scoreOf(row, focusCode) {
  if (!focusCode) return row.agg_score;
  const h = hitsOf(row)[focusCode];
  return h ? h.score : null;
}

const SEV_BAR_COLOR = { crit: "var(--sev-crit)", warn: "var(--sev-warn)", ok: "var(--sev-ok)" };

function scoreCell(row, focusCode) {
  const s = scoreOf(row, focusCode);
  const def = focusCode ? DOMAIN.ruleDefs[focusCode] : null;
  const label = def ? def.label : "Внимание";
  if (s === null || s === undefined) {
    // Правило не сработало → полностью серый бар (пустой трек), а не прочерк.
    const title = label + " · правило не сработало";
    // title -- и на <td> (весь хит-таргет ячейки, тестовый контракт S20-D),
    // и на самом баре (mkBar это несёт для остальных потребителей примитива).
    const td = el("td", { class: "r score", title });
    td.append(mkBar({ empty: true, title }));
    return td;
  }
  const sev = rowSevFor(row, focusCode);
  const h = focusCode ? hitsOf(row)[focusCode] : null;
  // Индикатор «Внимание»: бар-гейдж — длина заливки = балл, цвет = severity, без числа.
  // Серый трек остаётся видимым (S20-B); число — только в тултипе (как у кружков «Правил»).
  // Общий примитив bar-widget.js -- та же форма, что у "Готовности"/"MDE"
  // продукта mp_cockpit (доктрина унификации: три места рисовали одно и то
  // же независимо, сведено в bar-widget.js).
  const title = label + " · балл " + nf.format(Math.round((s || 0) * 100) / 100)
    + " · " + ((h && h.severity) || "");
  const td = el("td", { class: "r score", title });
  td.append(mkBar({ frac: s, color: SEV_BAR_COLOR[sev] || "var(--muted)", title }));
  return td;
}

function hitsCell(row) {
  const td = el("td", { class: "hitsc" });
  const RANK = { crit: 0, warn: 1, ok: 2 };
  const CAP = 3;
  // Цвет кружка = тир severity (как чип/бар), название — в тултипе; худшие — первыми.
  const entries = Object.entries(hitsOf(row))
    .filter(([code]) => ruleKnown(code))
    .sort((a, b) => RANK[sevPill(a[1].severity)] - RANK[sevPill(b[1].severity)]);
  const hitTitle = (e) => DOMAIN.ruleDefs[e[0]].label
    + " · балл " + nf.format(Math.round((e[1].score || 0) * 100) / 100)
    + " · " + (e[1].severity || "");
  entries.slice(0, CAP).forEach((e) =>
    td.append(el("span", { class: "hit " + sevPill(e[1].severity), title: hitTitle(e) })));
  if (entries.length > CAP) {
    // Остаток сворачивается в «+»; полный список — в тултипе.
    td.append(el("span", { class: "hit-more",
      title: entries.slice(CAP).map(hitTitle).join("\n") }, "+"));
  }
  return td;
}

// Перевод исторической декларации уровня в движковую декларацию колонки.
// Домен объявляет фильтр категории флагом уровня catFilter (задача 3) и
// колонки текстового поиска — level.searchCols (task-main-191, П4): раньше
// оба рисовали свою механику (селект в строке управления, строка поиска),
// теперь оба становятся col.filter на колонке, и воронку рисует общий
// движок. Приоритет ЗАФИКСИРОВАН и покрыт тестом-стражем (находка прожарки
// П4.1 — searchCols и catFilter ПЕРЕСЕКАЮТСЯ на "category" у четырёх доменов,
// это не случайность порядка веток): col.filter, объявленный доменом (как
// есть) > catFilter (даёт "values") > searchCols (даёт "text"). "values"
// обязан победить "text" на этой коллизии — drill по категории
// (skuCs.filters.category = {value}) читается верно только в ветке "values"
// _tblRowPasses; в ветке "text" {value} ушло бы в String(st.q) и дало бы
// «содержит undefined».
function withFilterDecl(level, c) {
  if (c.filter) return c;
  if (level.catFilter && c.key === "category") {
    return Object.assign({}, c, { filter: "values" });
  }
  if ((level.searchCols || []).includes(c.key)) {
    return Object.assign({}, c, { filter: "text" });
  }
  return c;
}

// activeCols(level, focusCode) → активный набор колонок уровня. Фильтры
// колонок объявляются ВСЕГДА, включая краткий режим (task-main-191, П2) —
// параметр withFilters упразднён вместе со вторым режимом: воронка доступна
// сразу, без «Раскрыть все», и краткая восьмёрка читается как «первые 8 по
// вниманию СРЕДИ ПРОШЕДШИХ ФИЛЬТР» (см. renderPanel), а не «первые 8 из всех».
function activeCols(level, focusCode) {
  const core = level.coreCols.map((c) => withFilterDecl(level, c));
  if (focusCode) {
    // Фокус на правиле: «Внимание» = балл этого правила (осмысленно) + колонки
    // правила. filter/filterKey/filterLabel/filterTiers — воронка тяжести
    // (П5, тип пересмотрен в task-main-196/П6): filterKey "__sev" ОБЩИЙ с
    // «Правила» ниже — состояние фильтра обязано пережить смену фокуса
    // (колонка меняется, фильтр — нет), и с новым типом это уже не технический
    // трюк: под одним ключом лежит одно и то же по смыслу значение — карта
    // счётчиков строки, от фокуса не зависящая (sevCounts).
    // fixed:true — находка прожарки: без неё filterKey открывает молчащий
    // неснимаемый фильтр через cs.hidden («скрыть Правила → сфокусировать →
    // отфильтровать Внимание → снять фокус» — воронки на экране нет).
    const score = { key: "__score", label: "Внимание", kind: "score", fixed: true,
      filter: "tiers", filterKey: "__sev", filterLabel: "Тяжесть",
      filterTiers: SEV_TIERS };
    return core.concat([score], DOMAIN.ruleDefs[focusCode].cols || []);
  }
  // По умолчанию: без «Внимание» (агрегатный балл неочевиден) — только
  // «Правила», та же воронка тяжести (см. комментарий выше).
  const hits = { key: "__hits", label: "Правила", kind: "hits", fixed: true,
    filter: "tiers", filterKey: "__sev", filterLabel: "Тяжесть",
    filterTiers: SEV_TIERS };
  return core.concat([hits]);
}

// Доменное состояние вида уровня. Поиск, фильтр категории и (с task-main-191)
// фильтр тяжести здесь БОЛЬШЕ НЕ живут — вся механика фильтрации переехала в
// общий table-engine.js и хранится в colState уровня (cs.search / cs.filters,
// включая cs.filters.__sev). Осталась одна вещь, движку не принадлежащая:
// страница пейджера — нужна блоку сигналов с сотнями строк, не нужна витрине
// GA.MA с её тремя десятками; поднимать ради одного потребителя незачем
// (решение владельца 14.08 про пейджинг — разворот 17.08 его не затронул,
// см. шапку файла).
function viewFor(levelKey) {
  if (!sigState.view[levelKey]) {
    sigState.view[levelKey] = { page: 1 };
  }
  return sigState.view[levelKey];
}

// Состояние колонок по уровню (внутри-сессия, без персиста): скрытые, сортировка, ширины.
// Сама структура и вся механика над ней — в общем table-engine.js (tblColState).
function colStateFor(levelKey) {
  if (!sigState.cols[levelKey]) sigState.cols[levelKey] = tblColState();
  return sigState.cols[levelKey];
}

// level.defaultSort (декларация домена, опционально, task-main-78 D4): { rank(row), dir }
// — для уровней без правил (agg_score всегда null, напр. LOGISTICS_LEVELS.cluster) общий
// score-порядок ниже вырождается в порядок прихода строк (де-факто алфавит из SQL ORDER
// BY). rank — чистая функция данных (select-адаптер, не DOM), объявленная доменом; движок
// лишь читает и сортирует по ней тем же null-в-конец правилом, что и по agg_score. Домены
// без defaultSort ведут себя как раньше (не в focus — сортировка по agg_score).
function sortByScore(rows, focusCode, level) {
  const ds = !focusCode && level && level.defaultSort;
  if (ds) {
    const dir = ds.dir === "desc" ? -1 : 1;
    return rows.slice().sort((a, b) => {
      const av = ds.rank(a), bv = ds.rank(b);
      if ((av === null || av === undefined) && (bv === null || bv === undefined)) return 0;
      if (av === null || av === undefined) return 1;   // без ранга — в конец, вне зависимости от dir
      if (bv === null || bv === undefined) return -1;
      return (av - bv) * dir;
    });
  }
  return rows.slice().sort((a, b) => {
    const av = scoreOf(a, focusCode), bv = scoreOf(b, focusCode);
    if ((av === null || av === undefined) && (bv === null || bv === undefined)) return 0;
    if (av === null || av === undefined) return 1;   // вне правила — в конец
    if (bv === null || bv === undefined) return -1;
    return bv - av;
  });
}

// Число сработавших правил в строке — критерий сортировки колонки «Правила».
// Под единым предикатом (ruleKnown выше) считает РОВНО нарисованные кружки,
// включая свёрнутые в «+N». НАЗВАННОЕ ИЗМЕНЕНИЕ ПОВЕДЕНИЯ: строка с хитом
// необъявленного правила опускается в порядке сортировки.
function hitCount(row) { return Object.keys(hitsOf(row)).filter(ruleKnown).length; }

// Единственный адаптер сырого значения колонки для ВСЕХ движковых механик
// уровня: сортировка, поиск, фильтры, выделение/буфер. Две колонки уровня
// виртуальные и в строке не лежат — «Внимание» (балл фокусного правила) и
// «Правила» (число хитов). Раньше эта развилка была скопирована трижды.
function colValue(row, key, focusCode) {
  if (key === "__score") return scoreOf(row, focusCode);
  if (key === "__hits") return hitCount(row);
  // "__sev" — filterKey виртуальной воронки тяжести (П5), НЕ значение
  // колонки: __score/__hits несут его ТОЛЬКО фильтру (_tblFilterKey
  // подставляет "__sev" вместо col.key при чтении/записи состояния);
  // сортировка и копирование продолжают читать __score/__hits через ветки
  // выше, этой ветки не касаясь.
  // С task-main-196 отдаёт КАРТУ СЧЁТЧИКОВ, а не строку-подпись одного тира:
  // движок читает её вслепую как «ключ → число» и режет строки по
  // объявленным тирам. focusCode здесь НЕ участвует — намеренно, см. sevCounts.
  if (key === "__sev") return sevCounts(row);
  return row[key];
}

// Сортировка по выбранной колонке (общий движок) — либо дефолт по вниманию.
function sortRows(level, rows, cs, focusCode) {
  return tblSortByColumn(rows, cs, (r, k) => colValue(r, k, focusCode))
    || sortByScore(rows, focusCode, level);
}

// Поиск по тексту и ВСЕ фильтры значений колонок, включая тяжесть, — ОБЩИЙ
// ДВИЖОК (tblApplyFilters), сквозной вызов без доменного пост-фильтра
// (task-main-191: severity ушла из ручного v.sev-фильтра в декларацию
// виртуальной колонки __sev, см. activeCols). В домене остаётся только САМ
// РАСЧЁТ — sevCounts: перенос его в движок заставил бы движок знать про
// правила и сломал бы ось «домен объявляет, движок рисует»; движок лишь
// читает готовую карту счётчиков через colValue("__sev", …) и режет строки по
// объявленным тирам (col.filterTiers), не понимая их смысла.
function filteredRows(level, cols, rows, focusCode) {
  const cs = colStateFor(level.key);
  return tblApplyFilters(cols, rows, cs, {
    searchKeys: level.searchCols,
    getValue: (r, k) => colValue(r, k, focusCode),
  });
}

// Интерактивный заголовок — общий движок; сигналы лишь объявляют выравнивание
// (колонка «Внимание» правая по своему kind) и перерисовку панели. Все колонки
// сортируемы, включая «Правила» (по количеству хитов).
// filterRows — строки уровня ДО фильтрации: из них движок собирает список
// значений воронки (а для типа "tiers" — максимум n по каждому тиру, то есть
// верхнюю границу списка «≥ k»), иначе после первого выбора список схлопнулся
// бы под рукой пользователя и вернуть «все» было бы нечем.
// rerender("filter") сбрасывает пейджер на первую страницу — сузив набор,
// пользователь иначе остался бы на странице, которой больше нет (ровно то же
// делал прежний доменный фильтр).
function buildTh(col, cs, payload, level, levelRows, focusCode) {
  return tblHeadCell(col, cs, {
    cls: (col.r || col.kind === "score") ? "r" : "",
    root: document.getElementById("sig-panel"),
    filterRows: levelRows,
    getValue: (r, k) => colValue(r, k, focusCode),
    rerender: (reason) => {
      if (reason === "filter") viewFor(level.key).page = 1;
      renderPanel(payload);
    },
  });
}

// Форматтер денег для action.effect_money: целые с разделителями + ₽.
// Использует nf0 из core.js (разделитель тысяч по ru-RU), компакт для млн/тыс.
function fmtActionMoney(n) {
  if (n === null || n === undefined) return null;
  const a = Math.abs(n);
  if (a >= 1e6) return nf.format(n / 1e6) + " млн ₽";
  if (a >= 1e3) return nf.format(n / 1e3) + " тыс. ₽";
  return nf0.format(n) + " ₽";
}


// csvName(payload, level) — имя файла «Скачать» блока сигналов (task-main-194,
// критерий 16). НЕ payload.meta.obs_date напрямую: поле отсутствует у ДВУХ
// доменов из семи — Финансы (domains/finance/payload.py:29-30 несёт "period",
// не "obs_date") и Взаиморасчёты (domains/settlement/report.py:125 — то же);
// оба объявляют мета-поле как key:"period" (finance.js:205, settlement.js:282).
// Без защиты файл назывался бы "signals-finance-sku-undefined.csv". DOMAIN.key
// объявлен всеми семью доменами (commerce.js:168, finance.js:198,
// settlement.js:275, logistics.js:229, pricing.js:241, marketing.js:49,
// assortment.js:50) — доменных ветвлений здесь нет и не нужно.
function csvName(payload, level) {
  const m = payload.meta || {};
  const stamp = m.obs_date || m.period || "";
  return "signals-" + DOMAIN.key + "-" + level.key + (stamp ? "-" + stamp : "") + ".csv";
}

// buildTable(level, pageRows, focusCode, payload, allCols, levelRows, exportRows)
// exportRows — ВЕСЬ отфильтрованный/отсортированный набор уровня (не только
// отрисованная страница pageRows и не срез краткого режима BRIEF_N) — уходит
// В КНОПКУ «Скачать» (tblWrap exportInfo). Пейджинг и краткий режим — оптика
// просмотра, не выборка (решение владельца 18.08, П4 спеки
// 2026-08-18-table-engine-polish-design.md): экспорт отдаёт то, что домен
// считает выбранным пользователем, не то, что сейчас нарисовано на экране.
function buildTable(level, pageRows, focusCode, payload, allCols, levelRows, exportRows) {
  const cs = colStateFor(level.key);
  const cols = allCols.filter((c) => !cs.hidden.has(c.key));
  const colgroup = tblColgroup(cols, cs);
  const head = el("thead", {}, el("tr", {}, cols.map((c) =>
    buildTh(c, cs, payload, level, levelRows, focusCode))));
  const bodyRows = [];
  for (const r of pageRows) {
    const sv = rowSevFor(r, focusCode);
    const tr = el("tr", {}, cols.map((c) => {
      if (c.kind === "score") return scoreCell(r, focusCode);
      if (c.kind === "hits") return hitsCell(r);
      let cls = c.r ? "r" : "";
      if (c.lead) cls = "lead " + sv + (c.r ? " r" : "");
      else if (c.metric) cls += (sv === "crit" ? " bad" : sv === "warn" ? " warnv" : " okv");
      const attrs = { class: cls.trim() };
      let txt = cellText(c, r);
      if (c.clip) {
        attrs.class = (attrs.class + " clip").trim();
        const cw = clipWords(txt, 4);
        if (cw.clipped) { attrs.title = txt; txt = cw.text; }
      }
      return el("td", attrs, txt);
    }));
    if (level.key === "category") {
      tr.classList.add("drill");
      tr.addEventListener("click", () => {
        sigState.level = "sku";
        // Категория проваливания — теперь ДВИЖКОВЫЙ фильтр значений колонки
        // (задача 3), а не доменное поле вида: на уровне товаров она видна
        // подсвеченной воронкой у колонки «Категория» и снимается там же.
        const skuCs = colStateFor("sku");
        // debt-main-187: если пользователь ранее скрыл «Категорию» кнопкой
        // «×», а затем сделал drill, фильтр становился активным (строки
        // резались), но воронки на экране не было (колонки нет вовсе) и
        // снять фильтр стандартным способом было нельзя. Drill снимает
        // скрытие ПЕРЕД установкой фильтра — симметрично тому, как он уже
        // переключает уровень/режим.
        skuCs.hidden.delete("category");
        if (!skuCs.filters) skuCs.filters = {};
        // Пишет СТАРУЮ форму состояния — {value}, не {values} (task-main-197):
        // движок обязан читать её вечно (_tblFilterValuesOf), это не
        // переходный костыль, а постоянный контракт.
        skuCs.filters.category = { value: r.category };
        viewFor("sku").page = 1;
        sigState.mode = "full";
        renderSignals(payload);
      });
    }
    bodyRows.push(tr);
  }
  const body = el("tbody", {}, bodyRows);
  const table = el("table", {}, [colgroup, head, body]);
  // toolsHost — строка табов уровней, «полный аналог gama» (слова владельца
  // 18.08): у сигналов узел создаётся в renderSignals (el("div", {class:
  // "lvl-tabs"}), ниже) БЕЗ id и пересоздаётся на каждое переключение уровня
  // — ищется ЗАНОВО на каждый вызов buildTable, ссылка не кэшируется в
  // замыкании: держать старую значило бы рисовать кнопку в узле, которого
  // уже нет в DOM после пересоздания (Р-З спеки 2026-08-18, регресс-страж —
  // test_dom_signals_download_button_survives_host_recreation_and_panel_only_rerenders,
  // tests/web/test_table_engine_interaction.py). Уборку старых .tbltools из
  // хозяина делает сам движок (table-engine.js, tblWrap) — не дублируется.
  const toolsHost = document.querySelector("#signals > .lvl-tabs");
  // Обёртка: горизонтальный скролл при нехватке ширины (строки nowrap не должны
  // обрезаться .sheet overflow:hidden) + тулбар «⊞»/«Скачать» (exportInfo).
  const wrap = tblWrap(cs, () => renderPanel(payload), {
    cols, rows: exportRows,
    filename: csvName(payload, level),
    getValue: (r, k) => colValue(r, k, focusCode),
    toolsHost,
  });
  wrap.append(table);
  // Выделение диапазона (задача 2 табличного движка) — тот же getValue,
  // которым sortRows уже читает виртуальные колонки «Внимание»/«Правила»
  // (scoreOf/hitCount). ВАЖНО (Р-Д спеки 2026-08-18, критерий 15 —
  // регресс-страж на эту ловушку в тестах): rows здесь — ИМЕННО pageRows
  // (страница на экране), а НЕ exportRows, ушедший в tblWrap выше.
  // tblEnableSelection хранит координаты выделения как индексы В ПЕРЕДАННОМ
  // МАССИВЕ (DOM-индекс строки отрисованной tbody, table-engine.js
  // _tblCellPos) — передать сюда exportRows значило бы, что Ctrl+C на
  // странице 2 молча отдаёт значения страницы 1 (индексы совпадают, массив —
  // нет). Общие поля с exportInfo выше — cols и getValue; rows — разные
  // объекты по построению (подробный разбор — комментарий tblWrap,
  // table-engine.js).
  tblEnableSelection(wrap, cs, {
    cols, rows: pageRows,
    getValue: (r, k) => colValue(r, k, focusCode),
  });
  return wrap;
}

function renderPager(count, pages, v, payload) {
  const wrap = el("div", { class: "pager" });
  const prev = el("button", { class: "pg", type: "button" }, "←");
  const next = el("button", { class: "pg", type: "button" }, "→");
  if (v.page <= 1) prev.setAttribute("disabled", "disabled");
  if (v.page >= pages) next.setAttribute("disabled", "disabled");
  prev.addEventListener("click", () => { if (v.page > 1) { v.page--; renderPanel(payload); } });
  next.addEventListener("click", () => { if (v.page < pages) { v.page++; renderPanel(payload); } });
  wrap.append(prev, el("span", { class: "pgi" },
    "стр. " + v.page + " из " + pages + " · " + count + " строк"), next);
  return wrap;
}

function renderPanel(payload) {
  const panel = document.getElementById("sig-panel");
  if (!panel) return;
  panel.replaceChildren();
  const level = DOMAIN.levels.find((l) => l.key === sigState.level);
  if (!level) return;
  const rows = rowsFor(payload, level.key);
  if (!rows.length) {
    // unify (task-main-61, ось 3): уровень без строк — канон-заглушка «Нет
    // данных» (тот же приём, что module-registry.js/shared.js для пустой
    // канон-главы), а не скрытие. Проверяем ДО фокус-описания правила — со
    // stale-фокусом на опустевшем уровне описание правила над «Нет данных»
    // было бы шумом.
    panel.append(el("div", { class: "empty-slot" }, "Нет данных"));
    return;
  }
  const focusCode = sigState.focus[level.key] || null;
  if (focusCode) {
    const rmeta = (payload.rule_meta || {})[focusCode];
    if (rmeta && rmeta.description) {
      panel.append(el("p", { class: "rdesc" }, rmeta.description));
    }
  } else if (level.hint && !colStateFor(level.key).sortKey) {
    // level.hint (декларация домена, опционально, task-main-78 D4/#3): статичная
    // подсказка уровня — напр. объясняет дефолтную сортировку и/или называет порог,
    // который иначе оставался бы незримым магическим числом. Не конфликтует с
    // rmeta.description выше — оба уровня-потребителя такого hint (LOGISTICS
    // cluster) не объявляют focus-правил. Ревью opus (task-main-78, NIT): текст
    // hint описывает ДЕФОЛТНУЮ сортировку — прячем его, если пользователь вручную
    // выбрал сортировку по колонке (cs.sortKey задан), иначе подсказка вводит в
    // заблуждение про уже неактивный порядок.
    panel.append(el("p", { class: "rdesc" }, level.hint));
  }
  if (sigState.mode === "brief") {
    const cs = colStateFor(level.key);
    // Краткий режим — «первые 8 по вниманию СРЕДИ ПРОШЕДШИХ ФИЛЬТР»
    // (task-main-191, П2): воронка доступна сразу, без «Раскрыть все» —
    // withFilters упразднён, filteredRows режет строки ДО среза до BRIEF_N.
    // Резать ПОСЛЕ среза было бы ложью: воронка появилась бы и не работала
    // бы — «первые 8» уже взяты бы из немодифицированного набора.
    const briefCols = activeCols(level, focusCode);
    const matched = filteredRows(level, briefCols, rows, focusCode);
    // sortedBrief — ВЕСЬ отфильтрованный набор, отсортированный, ДО среза до
    // BRIEF_N: краткий режим — та же оптика просмотра, что и пейджер (П4
    // спеки 2026-08-18), «Скачать» отдаёт sortedBrief целиком, не top.
    const sortedBrief = sortRows(level, matched, cs, focusCode);
    const top = sortedBrief.slice(0, BRIEF_N);
    panel.append(buildTable(level, top, focusCode, payload, briefCols, rows, sortedBrief));
    if (matched.length > BRIEF_N) {
      // Подпись — по ОТФИЛЬТРОВАННОМУ числу (matched.length), не rows.length:
      // иначе «Раскрыть все 812 →» над восемью строками из трёх отфильтрованных
      // врёт (П2 спеки).
      const more = el("button", { class: "expand", type: "button" },
        "Раскрыть все " + matched.length + " →");
      more.addEventListener("click", () => { sigState.mode = "full"; renderPanel(payload); });
      panel.append(more);
    }
    return;
  }
  const v = viewFor(level.key);
  const cs = colStateFor(level.key);
  // allCols — ПОЛНЫЙ набор объявленных колонок (со скрытыми): фильтровать надо
  // по всем объявленным, иначе фильтр скрытой колонки молча перестал бы
  // действовать. Скрытые отсеиваются уже внутри buildTable.
  const allCols = activeCols(level, focusCode);
  const sorted = sortRows(level, filteredRows(level, allCols, rows, focusCode), cs, focusCode);
  const pages = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE));
  if (v.page > pages) v.page = pages;
  const pageRows = sorted.slice((v.page - 1) * PAGE_SIZE, v.page * PAGE_SIZE);
  // sorted — уже ВЕСЬ отфильтрованный/отсортированный набор (посчитан выше
  // для самого пейджинга) — «Скачать» отдаёт его целиком, не pageRows.
  panel.append(buildTable(level, pageRows, focusCode, payload, allCols, rows, sorted));
  panel.append(renderPager(sorted.length, pages, v, payload));
  const less = el("button", { class: "expand", type: "button" }, "Свернуть");
  less.addEventListener("click", () => { sigState.mode = "brief"; renderPanel(payload); });
  panel.append(less);
}

function renderSignals(payload) {
  const root = document.getElementById("signals");
  root.replaceChildren();
  if (payload !== lastPayload) {
    for (const k of Object.keys(sigState.cols)) sigState.cols[k].widths = {};
    lastPayload = payload;
  }
  // unify (task-main-61, ось 3): уровень БЕЗ строк остаётся во вкладках —
  // состав вкладок объявляет ДОМЕН (декларация уровней), не наличие данных
  // в текущем payload. Пустой уровень получает заглушку «Нет данных» в
  // панели (renderPanel), а не скрытие вкладки. Ветка ниже — защитный
  // фолбэк на случай, если домен вовсе не объявил уровней.
  const levels = DOMAIN.levels || [];
  if (!levels.length) {
    root.append(el("div", { class: "empty-slot" }, "Нет данных"));
    return;
  }
  if (!levels.some((l) => l.key === sigState.level)) sigState.level = levels[0].key;
  // Табы уровней.
  const tabs = el("div", { class: "lvl-tabs" });
  for (const l of levels) {
    const tab = el("button", { class: "ltab" + (sigState.level === l.key ? " on" : ""),
      type: "button" }, l.label + " · " + rowsFor(payload, l.key).length);
    tab.addEventListener("click", () => {
      sigState.level = l.key; sigState.mode = "brief"; renderSignals(payload);
    });
    tabs.append(tab);
  }
  root.append(tabs);
  // Чипы правил активного уровня.
  const level = levels.find((l) => l.key === sigState.level);
  const cwrap = el("div", { class: "counts" });
  const rows = rowsFor(payload, level.key);
  const TIER_RANK = { crit: 0, warn: 1, ok: 2 };
  const chips = [];
  for (const code of level.rules) {
    const def = DOMAIN.ruleDefs[code];
    if (!def) continue;
    const counts = ruleSevCounts(rows, code);
    const tier = worstTier(counts);
    if (!tier) continue;                       // нет хитов — чипа нет
    chips.push({ code, def, counts, tier, n: counts[tier] });
  }
  // Порядок: худший тир раньше; внутри тира — больший счёт раньше; затем стабильно.
  chips.sort((a, b) =>
    (TIER_RANK[a.tier] - TIER_RANK[b.tier]) || (b.n - a.n));
  for (const c of chips) {
    const active = sigState.focus[level.key] === c.code;
    const title = ["crit", "warn", "ok"]
      .filter((t) => c.counts[t])
      .map((t) => SEV_LABELS[t] + " " + c.counts[t]).join(" · ");
    const chip = el("button", { class: "chip" + (active ? " active" : ""), type: "button",
      "data-code": c.code, title: title, "aria-pressed": active ? "true" : "false" }, [
      el("span", { class: "d " + c.tier }),
      el("b", {}, fmt(c.n)), " " + c.def.label]);
    chip.addEventListener("click", () => {
      sigState.focus[level.key] = active ? null : c.code;  // radio; повтор — общий вид
      renderSignals(payload);
    });
    cwrap.append(chip);
  }
  root.append(cwrap);
  root.append(el("div", { id: "sig-panel", class: "sig-panel" }));
  renderPanel(payload);
}
