"use strict";
(function () {
  const LIN = window.DEBUG_LINEAGE || {};
  const CODE_ORDER = ["sku_behind_plan", "sku_needs_attention",
                      "category_forecast", "category_behind"];
  const CODE_LABEL = {
    sku_behind_plan: "Отстают от плана", sku_needs_attention: "Отстают по темпу",
    category_behind: "Слабые категории",
    category_forecast: "Прогноз месяца",
  };
  const REASON_LABEL = {
    disabled: "выключено", null_value: "нет значения", above_threshold: "выше порога",
    not_priority: "не в фокусе", gate_coverage: "мало покрытия",
  };
  const LAYERS = [["excel", "Excel"], ["python", "Python"], ["sql", "SQL"], ["report", "Отчёт"]];

  const fmt = (n) => (n == null ? "—" : new Intl.NumberFormat("ru-RU").format(n));
  const pct = (v) => (v == null ? "—" : Math.round(v * 100) + "%");

  // debug.html автономна (не грузит shared.js/core.js) — свои h()/fetchWithTimeout намеренны, не дедупить.
  function h(tag, attrs, kids) {
    const e = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      if (attrs[k] == null) continue;
      if (k === "class") e.className = attrs[k];
      else if (k === "text") e.textContent = attrs[k];
      else e.setAttribute(k, attrs[k]);
    }
    (kids || []).forEach((c) => c != null && e.append(c));
    return e;
  }

  function tbl(headers, rows) {
    const head = h("tr", null, headers.map((x) => h("th", { text: x })));
    const body = rows.map((r) => h("tr", null, r.map((c, i) =>
      h(i === 0 ? "th" : "td", { class: i === 0 ? null : "num", text: c }))));
    return h("table", { class: "dbg-tbl" }, [head, ...body]);
  }

  // ---- родословная (слой «в») ----
  function lineageTable(fields) {
    const head = h("tr", null, [h("th", { text: "Поле" }), ...LAYERS.map(([, l]) => h("th", { text: l }))]);
    const rows = fields.map((key) => {
      const e = LIN[key] || {};
      if (e.ai) {
        return h("tr", { class: "ai-row" }, [
          h("th", { text: e.title || key }),
          h("td", { colspan: "4", text: `вход: ${e.input} → ${e.processor} → ${e.output}` }),
        ]);
      }
      return h("tr", null, [h("th", { text: e.title || key }),
        ...LAYERS.map(([k]) => h("td", { text: e[k] || "—" }))]);
    });
    return h("table", { class: "dbg-tbl lineage" }, [head, ...rows]);
  }

  // ---- мини-графики (слой «а») ----
  const _charts = [];
  function destroyCharts() { while (_charts.length) { try { _charts.pop().destroy(); } catch (e) {} } }
  function miniChart(series, type, datasets, scales) {
    const cv = h("canvas", { class: "mini" });
    const wrap = h("div", { class: "mini-wrap" }, [cv]);
    requestAnimationFrame(() => {
      _charts.push(new Chart(cv.getContext("2d"), {
        type, data: { labels: series.x || [], datasets },
        options: { responsive: true, maintainAspectRatio: false,
          plugins: { legend: { display: true, labels: { boxWidth: 12 } } },
          scales: scales || {} },
      }));
    });
    return wrap;
  }

  // ---- анатомия блока ----
  function part(title, node) { return h("div", { class: "part" }, [h("div", { class: "part-h", text: title }), node]); }
  function sections(elem, source, fields) {
    return [part("Элемент", elem), part("Таблица-источник", source), part("Родословная", lineageTable(fields))];
  }
  function kpiCard(label, val) { return h("div", { class: "kc" }, [h("div", { class: "kl", text: label }), h("div", { class: "kv", text: val })]); }
  function seriesById(p, id) { return ((p.chart_series || []).find((s) => s.id === id)) || { x: [], series: [] }; }

  // ---- блоки ----
  // task-main-168: карточки и «Таблица-источник» зеркалят ровно четвёрку витрины
  // «Итогов месяца» (selectCommerceKpi, commerce.js) — родословная (LIN) уже
  // знала shortfall_rub/forecast_completion/forecast_coverage_pct/tempo_actual/
  // tempo_required (debug-lineage.js), только эта панель отставала.
  function blockKpi(p) {
    const t = (p.digest && p.digest.totals) || {};
    const counts = (p.digest && p.digest.signal_counts) || {};
    const sig = Object.values(counts).reduce((a, b) => a + b, 0);
    // bug-main-40: панель отладки зеркалит гейты витрины (selectCommerceKpi,
    // commerce.js), не только сырые значения — иначе панель на пустой
    // планируемой популяции показывала бы «0» там, где витрина честно даёт
    // прочерк, и «прогноз недостоверный» там, где витрина его уже гасит.
    const emptyPlanPopulation = !t.plan_qty;
    const completionUnreliable = t.completion_pct != null && t.completion_reliable === false;
    const forecastGated = !emptyPlanPopulation && t.completion_reliable === false;
    const cards = h("div", { class: "kpi-cards" }, [
      kpiCard("Выполнение, %", (completionUnreliable || t.completion_pct == null) ? "—" : pct(t.completion_pct)),
      kpiCard("Недобор, ₽", emptyPlanPopulation ? "—" : fmt(t.shortfall_rub)),
      kpiCard("Прогноз, %", (emptyPlanPopulation || forecastGated || t.forecast_completion == null) ? "—" : pct(t.forecast_completion)),
      kpiCard("Темп, шт/день", emptyPlanPopulation ? "—" : fmt(t.tempo_actual)),
    ]);
    const src = tbl(["Поле", "Значение"], [
      ["plan_qty", fmt(t.plan_qty)], ["sales_qty_mtd", fmt(t.sales_qty_mtd)],
      ["sales_qty_planned", fmt(t.sales_qty_planned)], ["unplanned_sales_qty", fmt(t.unplanned_sales_qty)],
      ["completion_pct", t.completion_pct != null ? pct(t.completion_pct) : "—"],
      ["plan_coverage_pct", t.plan_coverage_pct != null ? pct(t.plan_coverage_pct) : "—"],
      ["completion_reliable", String(t.completion_reliable)],
      ["shortfall_rub", fmt(t.shortfall_rub)],
      ["shortfall_rub_fallback_share", t.shortfall_rub_fallback_share != null ? pct(t.shortfall_rub_fallback_share) : "—"],
      ["forecast_completion", t.forecast_completion != null ? pct(t.forecast_completion) : "—"],
      ["forecast_coverage_pct", t.forecast_coverage_pct != null ? pct(t.forecast_coverage_pct) : "—"],
      ["tempo_actual", fmt(t.tempo_actual)], ["tempo_required", fmt(t.tempo_required)],
      ["signals (Σ)", fmt(sig)],
    ]);
    return sections(cards, src, ["plan_qty", "sales_qty", "completion_pct", "shortfall_rub",
      "shortfall_rub_fallback_share", "forecast_completion", "forecast_coverage_pct",
      "tempo_actual", "tempo_required", "signals_total"]);
  }

  function blockSalesPace(p) {
    const s = seriesById(p, "sales_pace");
    const ds = (s.series || []).map((ser, i) => ({ label: ser.name, data: ser.y,
      borderColor: i ? "#c8862e" : "#3a6b46", backgroundColor: "transparent", tension: 0.2 }));
    const elem = miniChart(s, "line", ds, { x: { ticks: { maxTicksLimit: 8 } } });
    const y0 = s.series && s.series[0] ? s.series[0].y : [];
    const y1 = s.series && s.series[1] ? s.series[1].y : [];
    const src = tbl(["День", "Факт (накоп.)", "Темп плана (накоп.)"],
      (s.x || []).map((d, i) => [d, fmt(y0[i]), fmt(y1[i])]));
    return sections(elem, src, ["sales_qty", "daily_norm"]);
  }

  function blockCategoryCompletion(p) {
    const s = seriesById(p, "category_completion");
    const y = (s.series && s.series[0] ? s.series[0].y : []);
    const elem = miniChart(s, "bar",
      [{ label: "Выполнение, %", data: y.map((v) => v != null ? Math.round(v * 100) : null), backgroundColor: "#3a6b46" }], {});
    const src = tbl(["Категория", "Выполнение"], (s.x || []).map((c, i) => [c, y[i] != null ? pct(y[i]) : "—"]));
    return sections(elem, src, ["category_completion_pct"]);
  }

  function blockCategorySplit(p) {
    const s = seriesById(p, "category_sales_split");
    const planned = (s.series && s.series[0] ? s.series[0].y : []);
    const unp = (s.series && s.series[1] ? s.series[1].y : []);
    const elem = h("div", null, [
      h("div", { class: "schema-note", text: "схема (точный вид — на /report)" }),
      miniChart(s, "bar", [
        { label: "Продажи плановых", data: planned, backgroundColor: "#3a6b46", stack: "s" },
        { label: "Вне плана", data: unp, backgroundColor: "#b9b0a4", stack: "s" },
      ], { x: { stacked: true }, y: { stacked: true } }),
    ]);
    const src = tbl(["Категория", "План.прод", "Вне плана", "План", "Выполн."],
      (s.x || []).map((c, i) => [c, fmt(planned[i]), fmt(unp[i]),
        fmt(s.plan ? s.plan[i] : null), s.completion && s.completion[i] != null ? pct(s.completion[i]) : "—"]));
    return sections(elem, src, ["sales_qty", "unplanned_sales_qty", "plan_qty", "category_completion_pct"]);
  }

  function funnelTable(p) {
    const rules = (((p.mechanics || {}).stages || []).find((s) => s.id === "rules") || {}).rules || [];
    if (!rules.length) return h("p", { class: "muted", text: "нет mechanics в снимке" });
    const head = h("tr", null, ["Правило", "Проверено", "Отсев", "Сработало"].map((x) => h("th", { text: x })));
    const rows = rules.map((r) => {
      const f = r.funnel || {};
      const drop = (f.dropped || []).map((d) => `${REASON_LABEL[d.reason] || d.reason}: ${fmt(d.count)}`).join("; ") || "—";
      let fired = fmt(f.fired);
      if (f.fired_breakdown) fired += ` (ok ${fmt(f.fired_breakdown.ok)}/risk ${fmt(f.fired_breakdown.risk)})`;
      return h("tr", null, [h("th", { text: CODE_LABEL[r.code] || r.code }),
        h("td", { class: "num", text: fmt(f.evaluated) }), h("td", { text: drop }),
        h("td", { class: "num", text: fired })]);
    });
    return h("div", null, [h("div", { class: "part-sub", text: "Воронка правил (работа обработки)" }),
      h("table", { class: "dbg-tbl" }, [head, ...rows])]);
  }

  function blockSignals(p) {
    const counts = (p.digest && p.digest.signal_counts) || {};
    const chips = h("div", { class: "chips" }, CODE_ORDER.filter((c) => c in counts).map((c) =>
      h("span", { class: "chip", text: `${CODE_LABEL[c]}: ${fmt(counts[c])}` })));
    const srcTable = tbl(["Сигнал", "Строк в таблице"],
      CODE_ORDER.filter((c) => c in counts).map((c) => [CODE_LABEL[c], fmt(counts[c])]));
    const src = h("div", null, [srcTable, funnelTable(p)]);
    return sections(chips, src, ["completion_pct", "trailing_7d_avg_qty", "required_daily_qty",
      "category_status", "special_status", "forecast_completion", "forecast_coverage_pct",
      "category_completion_pct"]);
  }

  function blockAi(p) {
    const elem = h("div", { class: "ai-out" });
    if (p.narrative) elem.append(h("p", { text: p.narrative }));
    const list = (t, a) => {
      if (!(a || []).length) return;
      elem.append(h("h4", { text: t }), h("ul", null, a.map((x) =>
        h("li", { text: typeof x === "string" ? x : (x.text || JSON.stringify(x)) }))));
    };
    list("Рекомендации", p.recommendations); list("Действия", p.actions);
    if (!p.narrative && !(p.recommendations || []).length)
      elem.append(h("p", { class: "muted", text: "ИИ-разбор отсутствует (mock/частичный снимок)" }));
    const d = p.digest || {};
    const src = tbl(["Вход ИИ (digest)", "Значение"], [
      ["signal_counts (Σ)", fmt(Object.values(d.signal_counts || {}).reduce((a, b) => a + b, 0))],
      ["top_behind_sku", fmt((d.top_behind_sku || []).length)],
      ["top_behind_category", fmt((d.top_behind_category || []).length)],
      ["completion_pct", d.totals && d.totals.completion_pct != null ? pct(d.totals.completion_pct) : "—"],
    ]);
    return sections(elem, src, ["narrative", "recommendations", "actions"]);
  }

  const BLOCKS = [
    { id: "kpi", title: "Итоги месяца (KPI)", build: blockKpi },
    { id: "sales_pace", title: "График 1 — Продажи vs темп плана", build: blockSalesPace },
    { id: "category_completion", title: "График 2 — Выполнение по категориям", build: blockCategoryCompletion },
    { id: "category_split", title: "График 3 — Продажи по категориям (схема)", build: blockCategorySplit },
    { id: "signals", title: "Что требует внимания (сигналы)", build: blockSignals },
    { id: "ai", title: "Вывод и действия (ИИ)", build: blockAi },
  ];

  function section(id, title, parts) {
    const head = h("button", { class: "block-head", type: "button", "aria-expanded": "true" }, [h("span", { text: title })]);
    const body = h("div", { class: "block-body" }, parts);
    head.addEventListener("click", () => {
      const open = head.getAttribute("aria-expanded") === "true";
      head.setAttribute("aria-expanded", String(!open));
      body.hidden = open;
    });
    return h("section", { class: "block", "data-block": id }, [head, body]);
  }

  function render(p) {
    destroyCharts();
    const root = document.getElementById("blocks");
    root.innerHTML = "";
    const meta = p.meta || {};
    const ml = document.getElementById("meta-line");
    if (ml) ml.textContent = `${meta.cabinet || "—"} · ${meta.obs_date || "—"} · ${meta.business_unit_label || ""} · правила v${(p.mechanics || {}).rules_version || "?"}`;
    BLOCKS.forEach((b) => root.append(section(b.id, b.title, b.build(p))));
  }

  async function fetchJSON(u) { const r = await fetch(u); if (!r.ok) throw new Error(u + " " + r.status); return r.json(); }

  function fetchWithTimeout(url, opts, ms) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), ms || 60000);
    return fetch(url, Object.assign({}, opts, { signal: ctrl.signal }))
      .finally(() => clearTimeout(t));
  }

  async function boot() {
    if (window.__MOCK_PAYLOAD__) { render(window.__MOCK_PAYLOAD__); return; }
    const cab = document.getElementById("cabinet-select");
    const unit = document.getElementById("unit-select");
    let cabs = [];
    try { cabs = (await fetchJSON("/v1/mp-cockpit/cabinets")).cabinets; } catch (e) {}
    cabs.forEach((c) => cab.append(h("option", { value: c.cabinet, text: c.cabinet })));
    async function loadUnits() {
      const us = (await fetchJSON(`/v1/mp-cockpit/units?cabinet=${encodeURIComponent(cab.value)}`)).units;
      unit.innerHTML = ""; us.forEach((u) => unit.append(h("option", { value: u.value, text: u.label })));
    }
    async function loadReport() {
      try {
        const p = await fetchJSON(`/v1/mp-cockpit/report-view?cabinet=${encodeURIComponent(cab.value)}&scope=${encodeURIComponent(unit.value || "")}`);
        render(p);
      } catch (e) {
        const r = document.getElementById("blocks"); r.innerHTML = "";
        r.append(h("p", { class: "muted", text: "Не удалось загрузить отчёт: " + e.message }));
      }
    }
    cab.addEventListener("change", async () => { await loadUnits(); await loadReport(); });
    unit.addEventListener("change", loadReport);
    const recompBtn = document.getElementById("recompute-btn");
    const recompMsg = document.getElementById("recompute-msg");
    async function doRecompute() {
      if (!cab.value) { if (recompMsg) recompMsg.textContent = "Выберите кабинет."; return; }
      recompBtn.disabled = true; recompBtn.textContent = "Пересчитываю…";
      if (recompMsg) recompMsg.textContent = "";
      try {
        const r = await fetchWithTimeout(
          "/v1/mp-cockpit/recompute?cabinet=" + encodeURIComponent(cab.value) + "&domain=commerce",
          { method: "POST" }, 60000);
        if (!r.ok) throw new Error("HTTP " + r.status);
        await loadReport();
        if (recompMsg) recompMsg.textContent = "Готово — отчёт обновлён.";
      } catch (e) {
        const why = e && e.name === "AbortError" ? "превышено время ожидания" : (e.message || "ошибка");
        if (recompMsg) recompMsg.textContent = "Пересчёт не удался: " + why;
      } finally {
        recompBtn.disabled = false; recompBtn.textContent = "Пересчитать";
      }
    }
    if (recompBtn) recompBtn.addEventListener("click", doRecompute);
    if (cabs.length) { await loadUnits(); await loadReport(); }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
