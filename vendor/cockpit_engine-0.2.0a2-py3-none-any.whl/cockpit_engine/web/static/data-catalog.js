"use strict";
// Витрина справочника данных /data (спека 2026-07-29 §10, срез 7).
//
// ЧТО РЕНДЕРИТ. Таблицу строк реестра (пара классов «ожидание ↔ факт» + три
// максимы) и три раздела уровня страницы под ней: «Проектируемое (D)», «Карта
// источника» и «Лента событий реестра».
//
// ЧЕГО НЕ ДЕЛАЕТ — И ЭТО ГЛАВНОЕ. Не считает НИ ОДНОГО числа и не выбирает НИ
// ОДНОГО слова. Свежесть, глубина, полнота, статус, деления шкал (полоски
// полноты `completeness_bars`, секции круга глубины `depth_bucket`), единицы
// подписи и признак расхождения классов приезжают из payload готовыми
// (`read_api.build_data_catalog` -> `data_registry.observation`). Любая
// арифметика здесь была бы очередной независимой меркой поверх серверной —
// ровно та болезнь, которую чинит эпик справочника данных. Доктрина унификации
// (CLAUDE.md §5): /data — обзорная страница вне канона пяти глав, но принцип
// «код один — данные разные» действует и тут — доменных веток в этом файле нет
// ни одной, всё различие доменов приезжает данными.
(function () {
  // data.html автономна (свои el()/fetch, как rules-observatory.js — намеренно не дедупить).
  function el(tag, attrs, children) {
    var n = document.createElement(tag);
    attrs = attrs || {};
    for (var k in attrs) {
      if (attrs[k] == null) continue;
      if (k === "class") n.className = attrs[k]; else n.setAttribute(k, attrs[k]);
    }
    var kids = [].concat(children == null ? [] : children);
    for (var i = 0; i < kids.length; i++) {
      var c = kids[i];
      if (c == null) continue;
      n.append(c instanceof Node ? c : document.createTextNode(c));
    }
    return n;
  }

  var ENTITY_RU = { metric: "SKU", view: "SKU", sku_attr: "SKU",
    sku_table: "SKU",
    cat_attr: "Категория", cabinet_attr: "Кабинет",
    cabinet: "Кабинет", cluster: "Кластер" };
  var CADENCE_SUFFIX = { daily: " × день", monthly: " × месяц", static: "" };

  function grainLabel(r) {
    var entityKey = r.entity || r.store;
    return (ENTITY_RU[entityKey] || entityKey) + (CADENCE_SUFFIX[r.granularity] || "");
  }

  // Кириллическое имя строки (task-main-165, спека 2026-08-11 §4). `attr_code`
  // — латинский технический код, он же ключ TOML и ключ связей
  // depends_on/history_from — переименовать нельзя; title_ru его не заменяет
  // физически, только то, что показывает колонка «Атрибут».
  function displayName(r) {
    return r.title_ru || r.attr_code;
  }

  var RANK_RU = { technical: "технический", low: "низкий", medium: "средний", high: "высокий" };
  var EVENT_RU = {
    baseline: "базовый слепок", appeared: "появился", disappeared: "исчез",
    class_changed: "класс сменился", producer_changed: "производитель сменился",
    store_changed: "стор сменился", grain_changed: "грань сменилась",
    shape_changed: "форма величины сменилась",
    measured_by_changed: "способ измерения полноты сменился",
    confirm_drift: "декларация подтверждена", regression: "заведена карточка"
  };

  var state = { domains: [], active: null, query: "",
    planned: { declared: [], discovered: [] }, retired: [], sourceMap: [], events: [],
    // Блокер 2 (ревью 30.07): сбой разбора карты/чтения журнала на сервере
    // (`read_api._source_map_entries`/`_registry_events`) обязан быть отличим
    // от честной пустоты -- иначе опечатка в source-map.toml или БД без
    // миграции журнала выглядели бы для владельца одинаково «нечего сверять».
    sourceMapDegraded: false, eventsDegraded: false,
    layout: localStorage.getItem("mp-data-layout") === "wide" ? "wide" : "compact" };
  state.sort = { key: null, dir: null, half: null, step: 0 };

  var COLS = [
    { key: "attr_code", label: "Атрибут" },
    { key: "db", label: "Код в БД" },
    { key: "class_expected", label: "Класс", legend: "class" },
    { key: "rank", label: "Ранг" },
    { key: "granularity", label: "Грань", legend: "granularity" },
    { key: "dependents", label: "Зависимые", legend: "dependents" },
    { key: "completeness", label: "Полнота", legend: "completeness" },
    { key: "freshness", label: "Свежесть", legend: "freshness" },
    { key: "depth", label: "Глубина", legend: "depth" }
  ];

  var WIDE_COLS = [
    { key: "attr_code", label: "Атрибут" },
    { key: "platform_name", label: "Платформа" },
    { key: "file_col", label: "Файл" },
    { key: "api_field", label: "API" },
    { key: "db", label: "Код в БД" },
    { key: "class_expected", label: "Класс", legend: "class" },
    { key: "rank", label: "Ранг" },
    { key: "granularity", label: "Грань", legend: "granularity" },
    { key: "dependents", label: "Зависимые", legend: "dependents" },
    { key: "completeness", label: "Полнота", legend: "completeness" },
    { key: "freshness", label: "Свежесть", legend: "freshness" },
    { key: "depth", label: "Глубина", legend: "depth" },
    { key: "meaning", label: "Смысл" }
  ];
  // «Свежесть» намеренно НЕ сортируется: она меряется гранями источника, и «2
  // дня» против «1 месяца» между строками несравнимы. Полнота и глубина
  // сортируются ДОЛЕЙ — безразмерной и потому сопоставимой между строками
  // разных граней, но у каждой своя доля (решение 2026-08-09): полнота — от
  // накопленной глубины (та же, что рисует полоски), глубина — от окна (та
  // же, что рисует круг).
  var SORTABLE_KEYS = { attr_code: 1, db: 1, class_expected: 1, rank: 1,
    completeness: 1, depth: 1, dependents: 1 };

  // Заказываемые классы (спека 2026-08-01). Шире словаря TOML (A/B/C): `B*` в
  // файле ВЫВОДИТСЯ из операндов, а заказать его можно прямо; `D` -- «данных
  // здесь не жду». `E` не заказывается -- это наблюдение «происхождение
  // неизвестно», а не желание. Перечень дублирует серверный
  // `expected_override.ORDERABLE` НАМЕРЕННО: сервер отвергнет чужое значение
  // (400), клиент лишь не предлагает заведомо невозможного.
  var ORDERABLE = ["A", "B*", "B", "C", "D"];

  var CLASS_ORDER = { A: 0, "B*": 1, B: 2, C: 3, E: 4, D: 5 };
  var RANK_ORDER = { technical: 0, low: 1, medium: 2, high: 3 };

  var LEGEND = {
    class: [["A", "приходит от API площадки"],
      ["B*", "вычисляется формулой из операндов A/B* — независим от ручного ввода, как A"],
      ["B", "вычисляется формулой, но зависит от ручного ввода через операнд"],
      ["C", "требует ручного ввода"],
      ["D", "данных нет — глубина 0, полнота 0"],
      ["E", "факты есть, способ добычи неизвестен"],
      ["слева ↔ справа", "класс сегодня (объявлен в каталоге домена) ↔ факт "
        + "(наблюдение по данным); подсвечено — расхождение, которое "
        + "останавливает суточную проверку. Долгой нормой быть не может"],
      ["→ справа от пары", "заказ: «эту величину надо перевести в такой-то "
        + "класс». Пометка работы — на данные и на проверки не влияет"],
      ["клик по левому", "заказать перевод в другой класс"]],
    // Три максимы стоят тремя колонками, поэтому и легенда разведена на три:
    // одна общая всплывашка на трёх заголовках отвечала бы на вопрос соседа.
    completeness: [["полоски", "какая доля НАКОПЛЕННОЙ ГЛУБИНЫ заполнена — "
        + "пять ярких полосок значит вся история без единого пропуска "
        + "(решение 2026-08-09; до этого доля считалась от окна ~90 дней и "
        + "занижала молодые источники)"],
      ["подпись", "процент от той же накопленной глубины — сколько дней/"
        + "месяцев истории реально заполнены данными"],
      ["—", "наблюдения по строке нет — это не ноль"],
      ["вклад в статус строки", "зелёная, когда заполнено 95% и больше от "
        + "НАКОПЛЕННОЙ истории — ТА ЖЕ доля, что красит полоски и подпись "
        + "(до 2026-08-09 полоски мерили окно, а лампочку уже тогда красили "
        + "дыры глубины — расхождение снято). У безвременной величины дыр не "
        + "считают вовсе, а у событийной (синяя точка свежести) полнота в "
        + "статус строки не входит совсем"],
      ["сортировка", "по той же доле глубины, что и полоски: она безразмерна "
        + "и сравнима между строками разных граней"]],
    freshness: [["точка", "сколько граней прошло с последних данных"],
      ["цвет точки", "только про свежесть: зелёный — молчание короче порога "
        + "строки, жёлтый — ровно порог (последний день, когда молчание ещё "
        + "норма), красный — дольше порога либо данных не было вовсе, "
        + "синий — ритм не судим вовсе"],
      ["синяя точка", "величина обновляется ПО СОБЫТИЮ, а не по расписанию "
        + "(ставки и себестоимость продавца, его плановые допущения): молчание "
        + "у неё не сигнал, поэтому возраст показан, но не судится. Статус "
        + "такой строки тоже держится на одной свежести: ни глубину, ни "
        + "полноту к ней не прикладывают. Данных, "
        + "которых не было вовсе, синий не выкупает — такая строка красная"],
      ["порог", "объявлен строкой реестра в её собственных гранях; не объявлен "
        + "— две грани. Полнота и глубина цвет этой точки не меняют — у них "
        + "свои колонки, а сводный статус строки стоит значком у её имени"],
      ["подпись", "возраст последних данных в гранях источника — днях или месяцах"],
      ["без сортировки", "«2 дня» и «1 месяц» между строками несравнимы"]],
    depth: [["круг", "какая доля окна накоплена — полный круг значит истории "
        + "не меньше, чем длина окна"],
      ["подпись", "сколько истории накоплено в гранях источника"],
      ["—", "наблюдения по строке нет — это не ноль"],
      ["вклад в статус строки", "зелёная от 60 дней либо 2 месяцев истории "
        + "(порог строка реестра вправе объявить свой); безвременной величине "
        + "довольно одного значения, а у событийной (синяя точка свежести) "
        + "глубина в статус строки не входит совсем"],
      ["синий круг", "мерку к строке не прикладываем: либо величина "
        + "не меняется во времени, либо источник отдаёт только снимок на "
        + "сегодня и прошлого у него нет; сколько истории накоплено, показано, "
        + "но в статус строки не входит (причину называет подсказка круга)"]],
    granularity: [["SKU × день", "факт, обновляется каждый день"],
      ["SKU × месяц", "директивный ввод/агрегат, обновляется раз в месяц"],
      ["SKU", "статичный атрибут сущности, время не при чём"],
      ["Категория", "атрибут категории, не по SKU"],
      ["Кабинет × месяц", "директивный конфиг всего кабинета, не по SKU"]],
    dependents: [["слева", "сколько строк реестра прямо используют этот код в своей формуле"],
      ["справа", "сколько доменов заденет правка этого кода — считая косвенные зависимости"],
      ["выход", "строка терминальная: она сама и есть результат, её никто не пересчитывает"],
      ["0", "код не используется ни одной другой строкой"],
      ["полный список", "в развороте строки — с доменом и пометкой, где правка "
        + "потребует пересбора данных, а не пересчёта"]]
  };

  // Подписи классов для меню заказа — из ТОЙ ЖЕ легенды, что показывает
  // всплывашка колонки: две копии текста разошлись бы на первой же правке
  // словаря (литера `D` уже сменила смысл решением владельца 2026-08-01).
  var LEGEND_CLASS_TEXT = LEGEND.class.reduce(function (acc, pair) {
    acc[pair[0]] = pair[1]; return acc;
  }, {});

  function fetchTimeout(url, ms) {
    var ctrl = new AbortController();
    var t = setTimeout(function () { ctrl.abort(); }, ms || 60000);
    return fetch(url, { signal: ctrl.signal }).finally(function () { clearTimeout(t); });
  }

  // Бюджет ОДНОЙ попытки за каталогом. Половина прежних 60 с: попыток теперь две
  // (`fetchRetry`), и худшее ожидание владельца обязано остаться прежним.
  var TRY_MS = 30000;

  // Транспортный срыв -- не мнение сервера, а пропавший канал: оборванное
  // соединение или аборт по таймауту. Такой запрос повторяется один раз, и
  // разовый обрыв превращается в задержку вместо пустой страницы. Ответ С КОДОМ
  // сюда не попадает: он приходит успешным промисом, и проверка `r.ok` живёт
  // ВЫШЕ по цепочке -- 404 «кабинет не найден» обязан дойти до владельца сразу,
  // второй круг его не переубедит.
  //
  // Повод (диагноз 03.08): ssh-туннель до Тест-стенда умирал посреди запроса, а
  // `/data` рисуется ОДНИМ запросом -- сорвался он, и не отрисовалось ничего,
  // хотя сервер здоров. То же спасает селлера с дрожащим мобильным каналом.
  function fetchRetry(url, attempts) {
    return fetchTimeout(url, TRY_MS).catch(function (e) {
      if (attempts <= 1) throw e;
      return fetchRetry(url, attempts - 1);
    });
  }

  function activeDomain() {
    return state.domains.filter(function (d) { return d.key === state.active; })[0];
  }

  // Сортировка полноты — той же долей НАКОПЛЕННОЙ ГЛУБИНЫ, что рисует ячейку
  // (решение 2026-08-09: до этого сортировка была по окну, а подпись/полоски
  // -- по глубине, и порядок строк расходился с видимым процентом). Доля
  // безразмерна и потому сравнима между строками разных граней, а «3 месяца»
  // против «90 дней» — нет. Строки без наблюдения уходят в конец: отсутствие
  // числа не является нулём.
  function completenessRank(r) {
    if (r.status == null) return -1;
    return r.depth > 0 ? r.present / r.depth : 0;
  }

  // Глубина сортируется той же долей окна, что рисует круг (`depth_bucket` от
  // сервера), а не абсолютным числом: «3 месяца» и «90 дней» несравнимы, доля
  // окна — сравнима.
  // Неприменимая глубина (безвременная величина) сортируется НИЖЕ «нет данных»
  // (-1), а не вперемешку с ним: -1 значит «должны были измерить, но пусто»,
  // а неприменимость -- «измерять нечего», более крайний случай. `undefined`
  // (строка старого снимка без поля) в это условие не попадает -- для неё
  // действует прежнее правило «мерим как раньше» (строгое `=== false`).
  function depthRank(r) {
    if (r.depth_applicable === false) return -2;
    return r.status == null ? -1 : (r.depth_bucket || 0);
  }

  // Половины пары сортируются ОДНОЙ колонкой (решение владельца 2026-08-01):
  // клик по «Класс» крутит пять состояний -- ожидание A→E, ожидание E→A,
  // факт A→E, факт E→A, без сортировки. Отдельного заголовка на факт нет:
  // колонка одна, вопрос к ней тоже один -- «как тут с классами».
  var CLASS_SORT_CYCLE = [
    { half: "expected", dir: "asc" }, { half: "expected", dir: "desc" },
    { half: "observed", dir: "asc" }, { half: "observed", dir: "desc" }
  ];
  var HALF_RU = { expected: "ожидание", observed: "факт" };
  // Сентинел -1 у строк без числа — тот же приём, что у `completenessRank`: отсутствие
  // данных (граф не построился) не является нулём зависимостей и обязано уходить
  // в конец сортировки, а не смешиваться с настоящими нулями.
  function dependentsRank(r) {
    return r.dependents_direct == null ? -1 : r.dependents_direct;
  }

  function cmpRows(a, b, key, dir, half) {
  var av, bv;
  if (key === "class_expected") {
    if (half === "observed") {
      // Строка без наблюдения уходит в конец В ОБЕ стороны: отсутствие факта
      // -- не значение, и переворот сортировки не имеет права поднимать его
      // наверх как «самое большое».
      if (!a.class_observed || !b.class_observed) {
        if (a.class_observed === b.class_observed) return 0;
        return a.class_observed ? -1 : 1;
      }
      av = CLASS_ORDER[a.class_observed]; bv = CLASS_ORDER[b.class_observed];
    } else { av = CLASS_ORDER[a.class_expected]; bv = CLASS_ORDER[b.class_expected]; }
  }
  else if (key === "rank") { av = RANK_ORDER[a.rank]; bv = RANK_ORDER[b.rank]; }
  else if (key === "completeness" || key === "depth") {
    // Строка без наблюдения уходит в конец В ОБЕ стороны — то же правило, что у
    // половины «факт» в паре классов. Одного сентинела -1 для этого мало: при
    // убывании он делал пустые строки «самыми большими» и поднимал их наверх,
    // хотя отсутствие числа не является ни нулём, ни максимумом.
    if (a.status == null || b.status == null) {
      if ((a.status == null) === (b.status == null)) return 0;
      return a.status == null ? 1 : -1;
    }
    av = key === "completeness" ? completenessRank(a) : depthRank(a);
    bv = key === "completeness" ? completenessRank(b) : depthRank(b);
  }
  else if (key === "dependents") { av = dependentsRank(a); bv = dependentsRank(b); }
  // «Атрибут» сортируется ПОКАЗАННЫМ значением (спека §4: title_ru, если
  // объявлен, иначе attr_code) -- не сырым attr_code, иначе порядок строк
  // разошёлся бы с тем, что видит владелец.
  else if (key === "attr_code") { av = displayName(a).toLowerCase(); bv = displayName(b).toLowerCase(); }
  else { av = String(a[key] || "").toLowerCase(); bv = String(b[key] || "").toLowerCase(); }
  var base = (typeof av === "number") ? av - bv : av.localeCompare(bv, "ru");
  return dir === "desc" ? -base : base;
}

  function toggleSort(key) {
    if (key === "class_expected") {
      var step = state.sort.key === key ? state.sort.step + 1 : 0;
      var mode = CLASS_SORT_CYCLE[step];
      if (!mode) { state.sort = { key: null, dir: null, half: null, step: 0 }; }
      else { state.sort = { key: key, dir: mode.dir, half: mode.half, step: step }; }
    }
    else if (state.sort.key !== key) { state.sort = { key: key, dir: "asc", half: null, step: 0 }; }
    else if (state.sort.dir === "asc") { state.sort.dir = "desc"; }
    else { state.sort = { key: null, dir: null, half: null, step: 0 }; }
    renderHeader(); renderRows();
  }

  function sortedRows(rows) {
    if (!state.sort.key) return rows;
    return rows.slice().sort(function (a, b) {
      return cmpRows(a, b, state.sort.key, state.sort.dir, state.sort.half);
    });
  }

  function renderTabs() {
    var box = document.getElementById("data-tabs");
    box.replaceChildren.apply(box, state.domains.map(function (d) {
      var cls = "tab" + (d.available ? "" : " soon") + (d.key === state.active ? " on" : "");
      var kids = [d.label];
      if (!d.available) kids.push(el("span", { class: "soon-b" }, "скоро"));
      // Счётчик красных строк домена (решение владельца 2026-08-07): вкладка
      // отвечает не только «какой домен», но и «сколько тут горит», иначе беду
      // видно лишь у того домена, который сейчас открыт. Число считает СЕРВЕР
      // (`read_api._red_rows`) -- клиент не пересчитывает лампочки сам
      // (шапка файла). Ноль -- БЕЗ значка: пустая пилюля на шести здоровых
      // вкладках читалась бы как сигнал, а не как его отсутствие.
      var red = d.red_rows;
      var t = el("button", { class: cls, type: "button" }, kids);
      if (typeof red === "number" && red > 0) {
        t.append(el("span", { class: "tab-b" }, String(red)));
        t.setAttribute("title", "красных строк в домене: " + red);
      }
      if (d.available) t.addEventListener("click", function () {
        state.active = d.key; state.sort = { key: null, dir: null, half: null, step: 0 };
        renderTabs(); renderHeader(); renderRows();
      });
      return t;
    }));
  }

  function renderHeader() {
    var box = document.getElementById("data-hrow");
    if (!box) return;
    var wide = state.layout === "wide";
    var cols = wide ? WIDE_COLS : COLS;
    var cells = cols.map(function (c) {
      var sortable = !!SORTABLE_KEYS[c.key];
      var kids = [el("span", { class: "hlab" }, c.label)];
      if (sortable && state.sort.key === c.key) {
        // Какая ПОЛОВИНА пары сортирует — читаемо в заголовке: иначе третий
        // клик по «Класс» переставляет строки без единого видимого повода.
        if (state.sort.half) kids.push(el("span", { class: "hhalf" }, HALF_RU[state.sort.half]));
        kids.push(el("i", { class: "ti ti-chevron-" + (state.sort.dir === "asc" ? "up" : "down") + " hsort" }));
      }
      if (c.legend) kids.push(el("i", { class: "ti ti-info-circle legend-i", "data-legend": c.legend }));
      var cell = el("span", { class: "hcell" + (sortable ? "" : " static") }, kids);
      if (sortable) cell.addEventListener("click", function (e) {
        if (e.target.closest && e.target.closest(".legend-i")) return;
        toggleSort(c.key);
      });
      return cell;
    });
    if (!wide) cells.push(el("span", { class: "hcell static" }));
    box.className = "hrow" + (wide ? " wide" : "");
    box.replaceChildren.apply(box, cells);
  }

  function legendPopover() {
    var pop = document.getElementById("legend-pop");
    if (!pop) return;
    function hide() { pop.classList.remove("show"); pop.setAttribute("aria-hidden", "true"); }
    function show(icon) {
      var rows = (LEGEND[icon.getAttribute("data-legend")] || []).map(function (pair) {
        return el("div", { class: "lg-row" }, [el("b", {}, pair[0]), " — " + pair[1]]);
      });
      pop.replaceChildren.apply(pop, rows);
      pop.classList.add("show");
      pop.setAttribute("aria-hidden", "false");
      var r = icon.getBoundingClientRect();
      var pr = pop.getBoundingClientRect();
      var left = Math.max(8, Math.min(r.left, window.innerWidth - pr.width - 8));
      pop.style.left = left + "px";
      pop.style.top = (r.bottom + 8) + "px";
    }
    document.addEventListener("mouseover", function (e) {
      var icon = e.target.closest && e.target.closest(".legend-i[data-legend]");
      if (icon) show(icon);
    });
    document.addEventListener("mouseout", function (e) {
      var icon = e.target.closest && e.target.closest(".legend-i[data-legend]");
      if (icon) hide();
    });
  }

  // Список потребителей живёт в развороте строки, а не только в подсказке: на
  // тач-устройстве наведения нет вовсе, а поповер легенды умеет лишь статические
  // тексты. Разворот — единственный путь, работающий и на десктопе, и на телефоне.
  function consumersSection(r) {
    var cons = r.dependents_consumers || [];
    var soft = r.dependents_soft || [];
    // Доктрина унификации (CLAUDE.md §5): нет данных → заглушка, не скрытие.
    // Остальные пары панели заглушку уже показывают через `line`/`.v.empty` —
    // секция потребителей раньше молча пропадала, что читалось как «раздела
    // нет», а не как честная пустота.
    if (!cons.length && !soft.length) {
      var stub = r.dependents_terminal
        ? "терминальная строка: её результат никто не пересчитывает"
        : "ни одна строка реестра этот код не использует";
      return [el("div", { class: "k" }, "Потребители"),
        el("div", { class: "v empty" }, stub)];
    }
    var items = cons.map(function (c) {
      // metric/sku_table — физический ряд: правка потребует бэкфилла или
      // повторного сбора, тогда как view пересчитается сам.
      var physical = c.store === "metric" || c.store === "sku_table";
      var marks = [];
      if (physical) marks.push("пересбор данных");
      if (c.lifecycle === "planned") marks.push("проектируется");
      return el("div", { class: "cons-row" }, [
        el("b", {}, c.code), " · " + c.domain + (marks.length ? " · " + marks.join(", ") : "")]);
    });
    if (soft.length) {
      items.push(el("div", { class: "cons-row soft" }, [
        "ещё " + soft.length + " деградируют без этого кода: "
          + soft.map(function (c) { return c.code; }).join(", ")]));
    }
    return [el("div", { class: "k" }, "Потребители"),
      el("div", { class: "v cons-list" }, items)];
  }

  function panel(r) {
    function line(k, v) {
      var empty = !v;
      return [el("div", { class: "k" }, k),
              el("div", { class: "v" + (empty ? " empty" : "") }, empty ? "не показан / нет" : v)];
    }
    var grid = el("div", { class: "grid" }, [].concat(
      // Технический код остаётся видимым «в карточке строки» (спека §4) --
      // колонка «Атрибут» может показывать title_ru вместо него.
      line("Код атрибута", r.attr_code),
      line("Платформа", r.platform_name),
      line("Файл", r.file_col),
      line("API", r.api_field),
      line("БД", r.db),
      line("Гранулярность", grainLabel(r)),
      line("Производитель", r.producer),
      line("Наблюдён", r.producer_observed),
      line("Свежесть", maximText(r.freshness, r.freshness_unit)),
      line("Глубина", maximText(r.depth, r.depth_unit)),
      // Знаменатель -- глубина, не окно `expected` (решение 2026-08-09): та же
      // величина, что красит полоски и подпись компактной ячейки, иначе
      // разворот строки называл бы другое число для той же «Полноты».
      line("Полнота", r.status == null ? ""
        : r.present + " из " + r.depth + " " + (r.depth_unit || "")
          + (r.completeness_pct == null ? "" : " (" + r.completeness_pct + "%)")),
      consumersSection(r),
      [el("div", { class: "meaning" }, r.meaning || "Смысл пока не описан.")]));
    return el("div", { class: "panel" }, grid);
  }

  function togglePanel(rowEl, r) {
    var next = rowEl.nextElementSibling;
    if (next && next.classList && next.classList.contains("panel")) {
      next.remove(); rowEl.classList.remove("open"); return;
    }
    rowEl.classList.add("open");
    rowEl.parentNode.insertBefore(panel(r), rowEl.nextSibling);
  }

  // Ячейка обратного графа: «прямых / доменов». Терминальная строка (view без
  // потребителей) помечается словом, а не нулём: margin_pct и ad_roas — выход
  // системы, а не мёртвый груз, и таких 12 из 30 строк ранга high.
  function dependentsCell(r) {
    if (r.dependents_direct == null) return el("span", { class: "deps empty" }, "—");
    if (r.dependents_terminal) {
      return el("span", { class: "deps term", title: "терминальная строка: результат, "
        + "который никто не пересчитывает" }, "выход");
    }
    var title = r.dependents_direct
      ? "прямо зависят: " + r.dependents_direct + " · заденет доменов: " + r.dependents_domains
        + " · всего в шлейфе: " + r.dependents_trail + " — полный список в развороте строки"
      : "этот код не используется ни одной другой строкой реестра";
    return el("span", { class: "deps" + (r.dependents_direct ? "" : " zero"), title: title },
      r.dependents_direct + " / " + r.dependents_domains);
  }

  function classCls(cls) {
    if (!cls) return "cls-none";
    return cls === "B*" ? "cls-Bstar" : "cls-" + cls;
  }

  // ── Пара классов «ожидание ↔ факт» ──────────────────────────────────────
  // Пара показывается ВСЕГДА, даже когда половины совпали: колонка отвечает на
  // вопрос «сходится ли декларация с данными», и одиночный бейдж этот вопрос
  // молча снимал бы. Совпадение приглушено, расхождение подсвечено — красит
  // сервер (`class_drift` = `provenance.is_drift`, та же функция, которой судит
  // гейт суточной джобы), клиент только рисует.
  // ── Заказ: «эту величину надо перевести в такой-то класс» ───────────────
  // Решение владельца 2026-08-01. Заказ -- ПОМЕТКА ТРЕКЕРА ЗАДАЧ, поэтому он
  // рисуется ОТДЕЛЬНЫМ значком СБОКУ от пары и ни одной её половины не
  // подменяет: левая -- что величина есть сегодня (git), правая -- что видно по
  // данным, расхождение между ними -- сигнал проверки. Первая редакция
  // подставляла заказ в левую половину, и он уехал в снимок суточной джобы,
  // подменив собой описание реальности.
  //
  // Страница НЕ пересчитывает ни расхождение, ни подсветку сама (шапка файла:
  // ни одного числа и ни одного слова здесь не выбирается), поэтому после
  // сохранения каталог перечитывается целиком.
  function closeOrderMenu() {
    var open = document.getElementById("class-menu");
    if (open) open.remove();
  }

  function sendOrder(r, value) {
    closeOrderMenu();
    var sel = document.getElementById("data-cabinet");
    return fetch("/v1/mp-cockpit/data-catalog/class-target", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ domain: state.active, code: r.attr_code,
                             class_target: value })
    }).then(function (resp) {
      if (!resp.ok) throw new Error("HTTP " + resp.status);
      loadCatalog(sel ? sel.value : null);
    }).catch(function (e) {
      var box = document.getElementById("data-rows");
      box.prepend(el("div", { class: "note" }, "Заказ не сохранён: " + e.message));
    });
  }

  function openOrderMenu(anchor, r) {
    var wasOpen = document.getElementById("class-menu");
    closeOrderMenu();
    if (wasOpen && wasOpen.getAttribute("data-code") === r.attr_code) return;
    var items = ORDERABLE.map(function (cls) {
      // Отмечен ТЕКУЩИЙ ЗАКАЗ, а не класс строки: меню отвечает на вопрос «куда
      // переводим», и галочка напротив сегодняшнего класса читалась бы как
      // «заказано то, что и так есть».
      var on = cls === r.class_target;
      var b = el("button", { class: "cm-item" + (on ? " on" : ""), type: "button" },
        [el("span", { class: "badge " + classCls(cls) }, cls),
         el("span", { class: "cm-note" }, LEGEND_CLASS_TEXT[cls] || "")]);
      b.addEventListener("click", function (e) { e.stopPropagation(); sendOrder(r, cls); });
      return b;
    });
    if (r.class_target) {
      var back = el("button", { class: "cm-item cm-back", type: "button" }, "снять заказ");
      back.addEventListener("click", function (e) { e.stopPropagation(); sendOrder(r, null); });
      items.push(back);
    }
    var menu = el("div", { class: "class-menu", id: "class-menu", "data-code": r.attr_code },
      [el("div", { class: "cm-head" }, "перевести в класс")].concat(items));
    document.body.append(menu);
    var box = anchor.getBoundingClientRect();
    var mr = menu.getBoundingClientRect();
    menu.style.left = Math.max(8, Math.min(box.left, window.innerWidth - mr.width - 8)) + "px";
    menu.style.top = (box.bottom + 6 + mr.height > window.innerHeight
      ? box.top - mr.height - 6 : box.bottom + 6) + "px";
  }

  function classPair(r) {
    var observed = r.class_observed;
    var same = !!observed && observed === r.class_expected;
    var expected = el("span", {
      class: "badge orderable " + classCls(r.class_expected),
      title: "класс сегодня: " + r.class_expected
        + " · клик — заказать перевод в другой класс"
    }, r.class_expected);
    expected.addEventListener("click", function (e) {
      e.stopPropagation();  // клик по бейджу не раскрывает панель строки (AC3)
      openOrderMenu(expected, r);
    });
    var kids = [expected];
    kids.push(el("i", { class: "ti ti-arrows-horizontal pair-arrow" }));
    kids.push(observed
      ? el("span", { class: "badge " + classCls(observed) + (same ? " ghost" : "") }, observed)
      : el("span", { class: "badge cls-none" }, "—"));
    var title = "класс: " + r.class_expected + " · факт: " + (observed || "не наблюдался");
    if (r.class_drift) title += " · расхождение — суточная проверка остановится на этой строке";
    var pair = el("span", { class: "clspair" + (r.class_drift ? " drift" : ""), title: title }, kids);
    // Трек заказа занимает место ВСЕГДА, даже пустой: иначе строки с заказом и
    // без него разъехались бы, а колонка заводилась ради выравнивания.
    var target = r.class_target
      ? el("span", { class: "cls-target", title: "заказано перевести в " + r.class_target
          + " — пометка работы, на данные не влияет" },
        [el("i", { class: "ti ti-arrow-narrow-right tgt-arrow" }),
         el("span", { class: "badge " + classCls(r.class_target) }, r.class_target)])
      : el("span", { class: "cls-target" });
    return el("span", { class: "clscell" }, [pair, target]);
  }

  // ── Три максимы: три колонки ───────────────────────────────────────────
  // Полнота — шкала из пяти полосок (яркие/бледные), свежесть — точка, глубина
  // — секторный круг (решение владельца 01.08). Каждая стоит СВОЕЙ колонкой
  // (решение владельца 2026-08-01): одной ячейкой три разные величины читались
  // как один индикатор, а заголовок «Данные» не говорил, что именно меряет
  // каждый значок. Полоски и круг нормированы РАЗНЫМИ знаменателями (ниже) —
  // это намеренная развязка, не рассинхрон.
  //
  // ПОЧЕМУ ПОЛОСКИ, А НЕ ВТОРОЙ КРУГ. Два одинаковых круга подряд человек не
  // различает — шкала уровня и доля окружности читаются как разные вещи.
  // Полоски и круг МОНОХРОМНЫ; цвет статуса несёт только точка свежести (CSS
  // .mx-fresh в data.html), иначе цветными оказывались бы и чистые шкалы.
  //
  // ЗНАЧОК + ПОДПИСЬ. Рядом со значком стоит подпись: свежесть/глубина —
  // само число с единицей сервера («90 дней»), полнота — готовый процент
  // `completeness_pct` (решение владельца 2026-08-09, взамен пары
  // `present/expected`: НЕ доля окна, а доля НАКОПЛЕННОЙ ГЛУБИНЫ — короткая
  // история иначе занижалась знаменателем, которого источник ещё не мог
  // накопить). Значок даёт сравнение глазом по столбцу, подпись — точную
  // величину. Единицу выбирает СЕРВЕР (`*_unit`), клиент не склоняет и не
  // переводит — иначе это была бы пятая мерка (`debt-main-102`).
  //
  // Числа делений считает СЕРВЕР (`completeness_bars` — доля глубины,
  // `depth_bucket` — доля окна) — здесь ни одной арифметики, кроме перевода
  // готовой секции в проценты дуги.
  function statusCls(status) {
    return status ? "s-" + status : "s-none";
  }

  // Подпись ячейки: у строки без наблюдения — прочерк, а не ноль и не пустота
  // (доктрина унификации: честная заглушка вместо скрытия).
  function maximCell(extraCls, mark, label, title) {
    return el("span", { class: "mx-cell " + extraCls, title: title },
      [mark, el("span", { class: "mx-label" + (label ? "" : " empty") }, label || "—")]);
  }

  function maximText(value, unit) {
    return value == null ? "" : value + " " + (unit || "");
  }

  function completenessBars(r) {
    var lit = r.completeness_bars || 0;
    var bars = [];
    for (var i = 0; i < 5; i++) {
      bars.push(el("i", { class: "mx-bar" + (i < lit ? " on" : "") }));
    }
    // Доля НАКОПЛЕННОЙ ГЛУБИНЫ (решение владельца 2026-08-09), не окна
    // `expected` — обе половины подсказки те же, что красят полоски.
    var title = r.status == null ? "полнота: нет данных"
      : "полнота: " + r.present + " из " + r.depth + " " + (r.depth_unit || "")
        + " (" + (r.completeness_pct == null ? 0 : r.completeness_pct) + "%)";
    return el("span", { class: "mx-bars", title: title }, bars);
  }

  function freshnessDot(r) {
    var title = r.freshness == null ? "свежесть: данных не было"
      : "свежесть: последние данные " + maximText(r.freshness, r.freshness_unit) + " назад";
    // Синий обязан ОБЪЯСНЯТЬСЯ на месте: цвет, которого нет ни в подсказке, ни
    // в легенде, неотличим от сбоя рендера (находка ревью 06.08). Число при
    // этом остаётся -- синий снимает суд над ритмом, а не прячет возраст.
    if (r.freshness_status === "blue") {
      title += " — обновляется по событию, ритм не судим";
    }
    return el("span", { class: "mx-dot", title: title });
  }

  function depthCircle(r) {
    var pct = (r.depth_bucket || 0) * 25;
    var style = "background:conic-gradient(currentColor 0% " + pct + "%, transparent "
      + pct + "% 100%)";
    var title = r.status == null ? "глубина: нет данных"
      : "глубина: " + maximText(r.depth, r.depth_unit);
    // Синий обязан ОБЪЯСНЯТЬСЯ на месте -- тот же довод, что у точки свежести:
    // цвет, которого нет ни в подсказке, ни в легенде, неотличим от сбоя
    // рендера. Число рядом остаётся: синий снимает суд над длиной истории, а не
    // прячет накопленный возраст.
    //
    // ПРИЧИН ТРИ, И ОНИ НЕ ВЗАИМОЗАМЕНЯЕМЫ (task-main-155). Прежний текст был
    // один на всех и утверждал «величина не меняется во времени» -- про снимок
    // цены это ЛОЖЬ по замеру самого проекта (`mrc` меняется в 46% переходов).
    // Причину решает СЕРВЕР (`depth_reason`), клиент только подставляет слова;
    // поля нет -- значит мерку сняло наблюдение формы, и текст прежний.
    if (r.depth_applicable === false) {
      title += r.depth_reason === "snapshot_no_history"
        ? " — источник отдаёт только снимок на сегодня, прошлого у площадки нет:"
          + " длину истории не судим"
        : r.depth_reason === "client_no_backfill"
        ? " — ретроспектива клиентом не подаётся: длину истории не судим"
        : " — величина не меняется во времени, длину истории не судим";
    }
    return el("span", { class: "mx-circle", style: style, title: title });
  }

  function completenessCell(r) {
    var bars = completenessBars(r);
    // Один процент вместо пары `present/expected` (решение владельца
    // 2026-08-09): готовое число с сервера, клиент не делит сам.
    var label = (r.status == null || r.completeness_pct == null)
      ? "" : r.completeness_pct + "%";
    return maximCell("mx-completeness", bars, label, bars.getAttribute("title"));
  }

  // Точка судит ТОЛЬКО свежесть (`freshness_status` с сервера) -- находка
  // владельца 03.08 (`bug-freshness-dot-1`). Прежде её красил СВОДНЫЙ статус
  // строки, и колонка отвечала не на свой вопрос: источник с сегодняшними
  // данными краснел из-за недобора полноты («0 дней» рядом с красным пятном), а
  // сосед с двухдневным молчанием зеленел, потому что его окно закрыто. Шкалы
  // полноты и глубины остаются монохромными -- цвет в строке несут ровно два
  // знака: точка свежести и значок сводного статуса у имени (`nameCell`).
  function freshnessCell(r) {
    var dot = freshnessDot(r);
    var label = maximText(r.freshness, r.freshness_unit);
    return maximCell("mx-fresh " + statusCls(r.freshness_status), dot, label,
      dot.getAttribute("title"));
  }

  // Сводный статус строки -- отдельным значком у имени. Он не исчез вместе с
  // переездом цвета точки: «окно не добрано» и «истории меньше порога» иначе
  // перестали бы читаться как сигнал вообще. Форма НАМЕРЕННО другая (квадрат
  // против круга свежести) -- два одинаковых кружка в строке спорили бы.
  // Подсказка называет все три мерки: рядом с зелёной точкой красный значок
  // обязан читаться как «дело в соседней колонке», а не как противоречие.
  // Событийная строка -- исключение, и подсказка обязана назвать его вслух:
  // зелёный значок рядом с полупустой шкалой полноты иначе читается как
  // ошибка счёта, а не как снятая мерка (решение владельца 07.08).
  function nameCell(r, text, code) {
    var title = r.status == null ? "статус строки: наблюдения нет"
      : r.freshness_status === "blue"
        ? "статус строки: обновляется по событию — судим только свежесть, "
          + "глубину и полноту к такой строке не прикладываем"
      : "статус строки: сводный по трём меркам — полнота, свежесть, глубина; "
        + "зелёный, когда все три зелёные либо синие (синяя мерка к строке не "
        + "прикладывается — см. подсказку своей колонки)";
    var kids = [el("span", { class: "row-status " + statusCls(r.status), title: title }),
      text];
    // `code` — attr_code рядом с title_ru (спека §4: технический код остаётся
    // видимым в широком режиме). Передаётся только когда «Атрибут» показывает
    // НЕ attr_code -- иначе метка дублировала бы сам текст ячейки. Класс
    // `dbcode` переиспользован намеренно (селектор `.row .dbcode` в
    // встроенном `<style>` data.html уже задаёт моноширинный приглушённый
    // вид -- второй копии CSS не заводим; правка CSS вне модуля этой задачи).
    // Разделитель обязателен (ревью task-main-165, блокер 2): без него текст и
    // код клеятся в одно слово ("План продаж, штplan_qty") -- `.row>*` держит
    // `white-space:nowrap`, так что пробел не потеряется как "схлопнувшийся".
    if (code) kids.push(" ", el("span", { class: "dbcode", title: "attr_code: " + code }, code));
    return kids;
  }

  // Глубина неприменима у безвременных величин (форма `.../constant/...`) --
  // СЕКТОР И ПОДПИСЬ ОСТАЮТСЯ, синим красится сам сектор (решение владельца
  // 07.08.2026). Прежде здесь стоял прочерк без числа, и накопленный возраст
  // величины пропадал со страницы вовсе: колонка отвечала «мерить нечего»
  // вместо «столько есть, но не судим». Синий -- ровно тот же язык, что у точки
  // свежести (`.mx-fresh.s-blue`): мерку к строке не прикладываем, число рядом
  // остаётся, в сводную лампу строки она по-прежнему не входит (это решает
  // СЕРВЕР -- `maxims.depth_status` возвращает "blue", а `status` его не судит).
  // Признак решает тоже СЕРВЕР (`data_registry.shape.depth_applicable`), клиент
  // только читает готовое поле -- ни выбора слова, ни арифметики здесь нет
  // (докстринг файла). Сравнение строго с `false`: у строки старого снимка
  // поле может отсутствовать (`undefined`) -- это «мерим как раньше».
  function depthCell(r) {
    var circle = depthCircle(r);
    var label = r.status == null ? "" : maximText(r.depth, r.depth_unit);
    var cls = "mx-depth" + (r.depth_applicable === false ? " s-blue" : "");
    return maximCell(cls, circle, label, circle.getAttribute("title"));
  }

  function row(r) {
    var rowEl = el("div", { class: "row" }, [
      // Компакт — единственная колонка с именем (у широкого своя «Платформа»
      // рядом), поэтому фолбэк на platform_name сохраняется поверх title_ru
      // (ревью task-main-165, блокер 1): без него домены, ещё не прошедшие
      // ревизию §4, теряли бы читаемое имя и показывали голый attr_code там,
      // где раньше стояло platform_name.
      el("div", {}, [el("div", { class: "name" },
        nameCell(r, r.title_ru || r.platform_name || r.attr_code))]),
      el("span", { class: "dbcode" }, r.db),
      classPair(r),
      el("span", { class: "rank" }, RANK_RU[r.rank] || r.rank),
      el("span", { class: "granularity" }, grainLabel(r)),
      dependentsCell(r),
      completenessCell(r),
      freshnessCell(r),
      depthCell(r),
      el("i", { class: "ti ti-chevron-down chev" })]);
    rowEl.addEventListener("click", function () { togglePanel(rowEl, r); });
    return rowEl;
  }

  function wideCell(val, extraCls) {
    var empty = !val;
    var attrs = { class: "wide-cell" + (extraCls ? " " + extraCls : "") + (empty ? " empty" : "") };
    if (val) attrs.title = val;
    return el("span", attrs, empty ? "—" : val);
  }

  function rowWide(r) {
    // Ячейка имени режется тем же `nowrap`+`ellipsis` (`.row>*`), что и
    // соседние `wideCell` -- title_ru (до 25 символов) плюс пробел плюс
    // attr_code переполняют видимую ширину легко; тултип -- тот же приём,
    // что у wideCell, только собран здесь вручную (в nameCell дублировать
    // сборку текста незачем -- он уже знает display/code раздельно).
    var nameTitle = r.title_ru ? (r.title_ru + " (" + r.attr_code + ")") : r.attr_code;
    var rowEl = el("div", { class: "row wide" }, [
      el("span", { class: "name", title: nameTitle },
        nameCell(r, displayName(r), r.title_ru ? r.attr_code : null)),
      wideCell(r.platform_name),
      wideCell(r.file_col),
      wideCell(r.api_field),
      el("span", { class: "dbcode" }, r.db),
      classPair(r),
      el("span", { class: "rank" }, RANK_RU[r.rank] || r.rank),
      el("span", { class: "granularity" }, grainLabel(r)),
      dependentsCell(r),
      completenessCell(r),
      freshnessCell(r),
      depthCell(r),
      wideCell(r.meaning, "meaning")
    ]);
    rowEl.addEventListener("click", function () { togglePanel(rowEl, r); });
    return rowEl;
  }

  function visibleRows(dom) {
    var q = state.query.trim().toLowerCase();
    var rows = dom.rows || [];
    if (!q) return rows;
    // title_ru -- показанное значение колонки «Атрибут» (спека §4: «поиск
    // идёт по показанному значению»); attr_code остаётся в списке рядом, а не
    // вместо него -- технический код ищут тоже.
    return rows.filter(function (r) {
      return [r.attr_code, r.title_ru, r.db, r.platform_name, r.meaning].some(function (s) {
        return (s || "").toLowerCase().indexOf(q) >= 0;
      });
    });
  }

  function renderRows() {
    var box = document.getElementById("data-rows");
    var dom = activeDomain();
    box.replaceChildren();
    if (!dom || !dom.available) {
      box.append(el("div", { class: "note" }, "Домен ещё не наполнен."));
      renderSections();
      return;
    }
    var rows = sortedRows(visibleRows(dom));
    if (!rows.length) {
      box.append(el("div", { class: "note" }, "Ничего не найдено."));
      renderHeader(); renderSections();
      return;
    }
    var build = state.layout === "wide" ? rowWide : row;
    rows.forEach(function (r) { box.append(build(r)); });
    renderHeader();
    renderSections();
  }

  // ── Разделы уровня страницы ────────────────────────────────────────────
  // Все три фильтруются по АКТИВНОМУ домену — вкладка отвечает за домен
  // целиком, а не только за его таблицу. Пустой раздел не прячется: доктрина
  // унификации требует честную заглушку «Нет данных», потому что скрытие
  // неотличимо от «раздела не существует».
  function section(id, title, hint, rows, emptyText) {
    var head = el("div", { class: "sec-head" },
      [el("span", { class: "sec-title" }, title),
       hint ? el("span", { class: "sec-hint" }, hint) : null]);
    var body = rows.length ? rows : [el("div", { class: "note" }, emptyText)];
    return el("section", { class: "sheet sec", id: id },
      [head].concat(body));
  }

  function plannedRow(r) {
    return el("div", { class: "sec-row" }, [
      // title_ru -- та же строка каталога, что и в главной таблице (спека §4:
      // имя обязательно ВСЕМ строкам отревизованного домена, «обнаруженные»
      // кандидаты его не несут -- у них нет строки реестра вовсе).
      el("span", { class: "name" }, r.title_ru || r.platform_name || r.attr_code || r.field_id),
      el("span", { class: "dbcode" }, r.db || r.field_id),
      el("span", { class: "sec-meta" },
        r.will_be ? "станет классом " + r.will_be : ("сверено " + (r.checked_at || ""))),
      el("span", { class: "sec-note", title: r.meaning || r.note }, r.meaning || r.note || "—")
    ]);
  }

  function retiredRow(r) {
    // `plannedRow` печатает «станет классом X» — у выведенной строки будущего
    // класса нет, и это поле было бы обещанием сбора, который прекращён.
    // Вместо него — чем величина БЫЛА, пока её собирали.
    return el("div", { class: "sec-row" }, [
      el("span", { class: "name" }, r.title_ru || r.platform_name || r.attr_code),
      el("span", { class: "dbcode" }, r.db || r.attr_code),
      el("span", { class: "sec-meta" },
        r.still_arriving
          // Сбор объявлен прекращённым, а данные идут. Молчать об этом — врать
          // в обратную сторону: раздел обещал бы отсутствие сбора там, где он
          // продолжается (директивная форма, файловый парсер).
          ? "данные всё ещё приходят · наблюдается " + r.class_observed
          : (r.class_was ? "была классом " + r.class_was : "снята с учёта")),
      el("span", { class: "sec-note", title: r.meaning }, r.meaning || "—")
    ]);
  }

  function sourceMapRow(e) {
    return el("div", { class: "sec-row" }, [
      el("span", { class: "name" }, e.field_id),
      el("span", { class: "dbcode" }, e.registered ? "в реестре" : "нет строки"),
      el("span", { class: "sec-meta" }, "сверено " + e.checked_at),
      el("span", { class: "sec-note", title: e.note }, e.note || "—")
    ]);
  }

  function eventRow(e) {
    var what = EVENT_RU[e.event] || e.event;
    var subject = e.count != null ? e.count + " строк" : (e.code || "");
    var change = (e.from_value || e.to_value)
      ? (e.from_value || "—") + " → " + (e.to_value || "—") : "";
    return el("div", { class: "sec-row ev-row" }, [
      el("span", { class: "name" }, subject),
      el("span", { class: "ev-kind ev-" + e.event }, what),
      el("span", { class: "sec-meta" }, e.obs_day + (change ? " · " + change : "")),
      el("span", { class: "sec-note", title: e.reason }, e.reason || "—")
    ]);
  }

  function renderSections() {
    var box = document.getElementById("data-sections");
    if (!box) return;
    var key = state.active;
    var declared = (state.planned.declared || []).filter(function (r) { return r.domain === key; });
    var discovered = (state.planned.discovered || []).filter(function (r) { return r.domain === key; });
    var retired = (state.retired || []).filter(function (r) { return r.domain === key; });
    var map = (state.sourceMap || []).filter(function (e) { return e.domain === key; });
    var events = (state.events || []).filter(function (e) { return e.domain === key; });

    var plannedRows = [];
    if (declared.length) {
      plannedRows.push(el("div", { class: "sec-sub" }, "Заявленное — решение владельца"));
      declared.forEach(function (r) { plannedRows.push(plannedRow(r)); });
    }
    if (discovered.length) {
      plannedRows.push(el("div", { class: "sec-sub" },
        "Обнаруженное — поля источника без строки реестра; вносит владелец"));
      discovered.forEach(function (r) { plannedRows.push(plannedRow(r)); });
    }

    // Блокер 2 (ревью 30.07): пустой список у карты/ленты — ДВА разных факта
    // (честная пустота vs сбой чтения на сервере), и подпись обязана их не
    // путать: сбой печатает свою фразу, а не утверждает отсутствие данных.
    var mapEmpty = state.sourceMapDegraded
      ? "Карта источника не читается — см. журнал сервера."
      : "Источник этого домена ещё не сверялся.";
    var eventsEmpty = state.eventsDegraded
      ? "Журнал событий недоступен — см. журнал сервера."
      : "Событий по этому домену нет.";
    box.replaceChildren(
      section("sec-planned", "Проектируемое (D)",
        "данных ещё нет — в измерении не участвуют", plannedRows,
        "Проектируемых данных в домене нет."),
      section("sec-retired", "Выведено (D)",
        "сбор прекращён решением владельца — в измерении не участвуют",
        retired.map(retiredRow), "Выведенных из употребления данных в домене нет."),
      section("sec-source-map", "Карта источника",
        "что мы знали об источнике на дату сверки", map.map(sourceMapRow), mapEmpty),
      section("sec-events", "Лента событий реестра",
        "изменения, замеченные суточной проверкой", events.map(eventRow), eventsEmpty));
  }

  var loadGen = 0;  // счётчик поколений -- защита от гонки при быстром двойном переключении кабинета

  function loadCabinets() {
    // Эндпоинт общий на четырёх потребителей (справочник/отчёт/rules-observatory/
    // debug) — решение "файловый кабинет не место в справочнике данных" (владелец
    // 31.07) принимает ЭТОТ потребитель по грани в данных, не безусловный
    // фильтр на бэке (тот выкинул бы ozon:unix и из селектора отчёта тоже).
    // initCabinetSelector ниже уже откатывается на первый кабинет списка, если
    // ?cabinet= не найден среди отфильтрованных — прямой заход по ссылке на
    // файловый кабинет сам откроет первый API-кабинет, отдельной ветки не нужно.
    // Тот же повтор, что у каталога: срыв этого запроса не гасит страницу
    // (ниже откат на пустой список), но обесточивает СЕЛЕКТОР кабинетов --
    // владелец остаётся с одним кабинетом из адреса и без права переключиться.
    return fetchRetry("/v1/mp-cockpit/cabinets?domain=commerce", 2).then(function (r) {
      return r.ok ? r.json() : { cabinets: [] };
    }).then(function (data) {
      return (data.cabinets || []).filter(function (c) { return c.grain !== "file"; });
    }).catch(function () { return []; });
  }

  function initCabinetSelector(cabs) {
    var sel = document.getElementById("data-cabinet");
    sel.replaceChildren();
    var current = new URLSearchParams(location.search).get("cabinet");
    if (cabs.length) {
      cabs.forEach(function (c) { sel.append(el("option", { value: c.cabinet }, c.cabinet)); });
      sel.value = cabs.some(function (c) { return c.cabinet === current; }) ? current : cabs[0].cabinet;
    } else if (current) {
      sel.append(el("option", { value: current }, current));
    }
    sel.onchange = function () {
      var q = new URLSearchParams(location.search);
      q.set("cabinet", sel.value);
      history.replaceState(null, "", location.pathname + "?" + q.toString());
      loadCatalog(sel.value);
    };
    return sel.value;
  }

  function loadCatalog(cabinet) {
    var gen = ++loadGen;
    var box = document.getElementById("data-rows");
    var sections = document.getElementById("data-sections");
    // Блокер 1 (ревью 30.07): раньше на старте запроса и в `catch` перерисовывался
    // ТОЛЬКО `#data-rows` -- `renderSections()` зовётся исключительно из
    // `renderRows()` по успешному ответу. При смене кабинета на упавшем/долгом
    // запросе таблица честно писала «Ошибка загрузки», а прямо под ней
    // оставалась лента событий/карта источника ПРЕЖНЕГО кабинета -- молчаливое
    // смешение кабинетов, от которого остальной код защищается явно. Обе точки
    // (старт и `catch`) обязаны очищать оба контейнера синхронно.
    box.replaceChildren(el("div", { class: "note" }, "Загрузка…"));
    if (sections) sections.replaceChildren(el("div", { class: "note" }, "Загрузка…"));
    var url = "/v1/mp-cockpit/data-catalog" + (cabinet ? "?cabinet=" + encodeURIComponent(cabinet) : "");
    fetchRetry(url, 2).then(function (r) {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.json();
    }).then(function (data) {
      if (gen !== loadGen) return;
      state.domains = data.domains || [];
      state.planned = data.planned || { declared: [], discovered: [] };
      state.retired = data.retired || [];
      // Блокер 2 (ревью 30.07): `source_map`/`events` — теперь `{entries,
      // degraded}`, не голый список (`read_api._source_map_entries`/
      // `_registry_events`): сбой разбора карты / чтения журнала обязан быть
      // отличим от честной пустоты, а не тонуть под тем же пустым списком.
      var sourceMap = data.source_map || { entries: [], degraded: false };
      var events = data.events || { entries: [], degraded: false };
      state.sourceMap = sourceMap.entries || [];
      state.sourceMapDegraded = !!sourceMap.degraded;
      state.events = events.entries || [];
      state.eventsDegraded = !!events.degraded;
      var stillActive = state.domains.some(function (d) { return d.key === state.active; });
      if (!stillActive) {
        var firstAvail = state.domains.filter(function (d) { return d.available; })[0];
        state.active = firstAvail ? firstAvail.key : (state.domains[0] && state.domains[0].key);
      }
      renderTabs(); renderRows();
    }).catch(function (e) {
      if (gen !== loadGen) return;
      box.replaceChildren(el("div", { class: "note" }, "Ошибка загрузки: " + e.message));
      if (sections) sections.replaceChildren(el("div", { class: "note" }, "Ошибка загрузки: " + e.message));
    });
  }

  function load() {
    loadCabinets().then(function (cabs) {
      var cabinet = initCabinetSelector(cabs);
      loadCatalog(cabinet);
    });
  }

  // Вид объявляется атрибутом на body: ширина страницы у компакта и широкого
  // разная (у компакта десять колонок против тринадцати), а `.wrap` лежит выше
  // строк таблицы — до него класс `wide` со строки не достаёт.
  function markLayout() {
    if (document.body) document.body.setAttribute("data-layout", state.layout);
  }

  document.addEventListener("DOMContentLoaded", function () {
    var search = document.getElementById("data-search");
    search.addEventListener("input", function () { state.query = search.value; renderRows(); });
    var toggle = document.getElementById("layout-toggle");
    toggle.setAttribute("aria-checked", state.layout === "wide" ? "true" : "false");
    markLayout();
    toggle.addEventListener("click", function () {
      state.layout = state.layout === "wide" ? "compact" : "wide";
      localStorage.setItem("mp-data-layout", state.layout);
      toggle.setAttribute("aria-checked", state.layout === "wide" ? "true" : "false");
      markLayout();
      renderHeader(); renderRows();
    });
    legendPopover();
    // Меню заказа закрывается кликом мимо и Esc: оно перекрывает соседние
    // строки, и «висящее» меню читалось бы как часть таблицы.
    document.addEventListener("click", function (e) {
      if (!e.target.closest || !e.target.closest("#class-menu")) closeOrderMenu();
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") closeOrderMenu();
    });
    renderHeader();
    load();
  });
})();
