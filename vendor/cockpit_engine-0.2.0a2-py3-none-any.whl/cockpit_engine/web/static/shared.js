"use strict";

let DOMAIN = null;  // активный домен-конфиг (COMMERCE | FINANCE), ставит renderReport
let loadGen = 0;  // поколение загрузки: ответ перекрытого (устаревшего) запроса отбрасываем

function bumpLoadGen() {
  // Захватить новое поколение СИНХРОННО, в момент решения о переключении (клика домена),
  // а не внутри loadReport — иначе при быстром переключении доменов порядок «чей
  // асинхронный initSelector отработал последним» не совпадает с порядком кликов (у
  // доменов разное время ответа промежуточного запроса), и тело отчёта может
  // отрисоваться данными домена, переключённого РАНЬШЕ (баг найден живьём 2026-07-08).
  return ++loadGen;
}

// Индикатор перехода (unify: общий для всех доменов/кабинетов — живёт в shared.js, не
// в доменном коде). Включается на весь путь клик→ответ (switchDomain и/или loadReport),
// выключается только из терминальных точек текущего поколения (renderReport/showEmpty) —
// те уже гейтятся на loadGen выше по стеку, поэтому устаревший ответ индикатор не погасит.
function setLoading(on) {
  const bar = document.getElementById("accent-top");
  const pad = document.getElementById("pad");
  if (bar) bar.classList.toggle("is-loading", on);
  if (pad) pad.classList.toggle("is-loading", on);
  // task-main-96 (спека §Бейджи): пока отчёт грузится — бейджей в оглавлении панели
  // нет вовсе, не только нулей. renderRailToc(payload) сам их пересчитает после
  // ответа; здесь только гасим старые (иначе бейдж предыдущего домена мигал бы
  // поверх загрузки следующего).
  if (on && typeof clearRailToc === "function") clearRailToc();
}
// DOMAIN живёт здесь (оболочка-владелец активного домена); core.js и
// signals-table.js читают его как общий handle. sigState приватен в signals-table.js.

// Срез A т.1: полный набор eligible-действий из entity_tables (все SKU/категории).
// Дайджест (digest.eligible_actions) режется до топ-12 — для листания берём полный
// per-entity список (cap=3 на сущность, но все сущности). Фолбэк на дайджест: мок
// и домены без проводки действий entity_tables.* действий не несут.
function collectEligibleActions(payload) {
  const et = (payload && payload.entity_tables) || {};
  const out = [];
  for (const level of Object.values(et)) {
    const rows = (level && Array.isArray(level.rows)) ? level.rows : [];
    for (const r of rows) {
      const acts = Array.isArray(r.actions) ? r.actions : [];
      for (const a of acts) {
        if ((a.viability || "ok") !== "futile") out.push(a);
      }
    }
  }
  if (out.length === 0) {
    const dig = payload && payload.digest && Array.isArray(payload.digest.eligible_actions)
      ? payload.digest.eligible_actions : [];
    return dig.slice();
  }
  return out;
}

function fmtDate(period) {
  if (!period) return "";
  const d = new Date(period);
  if (isNaN(d.getTime())) return String(period);
  return d.toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" });
}

function renderNarrative(payload) {
  const root = document.getElementById("narrative");
  const eligibleActions = collectEligibleActions(payload);
  const hasCards = eligibleActions.length > 0;

  // unify: пустую главу не прячем — скелет уже несёт заглушку; движок для пустой
  // главы не зовётся из renderReport. Этот guard остаётся только для прямых вызовов:
  // рисуем заглушку в узел, заголовок не трогаем.
  if (!hasCards) {
    root.replaceChildren();
    root.append(el("div", { class: "empty-slot" }, "Нет данных"));
    return;
  }

  const box = el("div", { class: "concl" });

  // === Карточки действий ===
  const COST_LABEL = { low: "лёгкое", med: "среднее", high: "сложное" };
  const VIAB_LABEL = { ok: "есть", weak: "ограничен" };
  const CONF_LABEL = { high: "высокая", medium: "средняя", low: "низкая" };
  const VIAB_DOT = { ok: "ok", weak: "weak", futile: "futile" };
  const PCT_KEYS = new Set(["markup_over_floor", "markup_over_min_price",
    "completion_pct",
    "commission_pct", "logistics_pct", "margin_pct", "cost_share", "cab_cost_share"]);
  // Sub-1% значения (напр. конверсия в корзину) -- Math.round(v*100) схлопывает
  // их в "0%"/"1%", различий не видно. Два знака после запятой держат
  // различимость (boost_visibility_ads: диапазон 0.25%-0.87% на реальных SKU).
  const PCT_KEYS_PRECISE = new Set(["total_cart_rate_14d"]);

  function interpolateWhy(text, ev) {
    if (!text || !ev) return text;
    return text.replace(/\{(\w+)\}/g, function (m, key) {
      if (!(key in ev) || ev[key] === null || ev[key] === undefined) return m;
      const v = ev[key];
      if (PCT_KEYS.has(key)) return Math.round(v * 100) + "%";
      if (PCT_KEYS_PRECISE.has(key)) return nf2.format(v * 100) + "%";
      return String(v);
    });
  }

  function buildWhyText(a) {
    const interpolated = interpolateWhy(a.recommendation, a.evidence);
    if (interpolated) return interpolated;
    if (Array.isArray(a.evidence) && a.evidence.length) {
      return a.evidence
        .map((e) => (typeof e === "string" ? e : (e && (e.text || e.signal)) || ""))
        .filter(Boolean).join("; ");
    }
    return null;
  }

  function buildMetaLine(a) {
    const parts = [];
    if (a.cost && COST_LABEL[a.cost])
      parts.push(el("span", {}, ["Стоимость ", el("b", {}, COST_LABEL[a.cost])]));
    if (a.confidence && CONF_LABEL[a.confidence])
      parts.push(el("span", { title: "Оценка класса совета; per-case появится с данными Ozon (TD-44)" },
        ["Надёжность ", el("b", {}, CONF_LABEL[a.confidence])]));
    return parts.length ? el("div", { class: "act-card-meta" }, parts) : null;
  }

  function buildLeverLine(a) {
    const viab = a.viability || "ok";
    if (viab === "futile") return null;
    return el("div", { class: "act-card-lever" }, [
      el("span", { class: "act-dot " + (VIAB_DOT[viab] || "ok"), "aria-hidden": "true" }),
      "Рычаг " + (VIAB_LABEL[viab] || viab)]);
  }

  // buildSkuPanel читает aiCtxMap из замыкания renderNarrative
  function buildSkuPanel(a) {
    const panel = el("div", { class: "act-card-panel" });
    const lever = buildLeverLine(a);
    if (lever) panel.append(lever);
    // Строка «Приоритет»
    const priorityRow = el("div", { class: "act-card-row" });
    priorityRow.append(el("span", { class: "act-card-row-lbl" }, "Приоритет"));
    if (a.effect_type === "margin_guard") {
      const shield = el("span", { class: "act-card-shield" });
      shield.append(el("span", { class: "act-card-shield-mark", "aria-hidden": "true" }, "▸"));
      shield.append(el("span", {}, "защищает маржу"));
      priorityRow.append(shield);
    } else {
      const score = typeof a.effect_score === "number" ? Math.max(0, Math.min(1, a.effect_score)) : 0;
      const moneyStr = fmtActionMoney(a.effect_money);
      const barWrap = el("div", { class: "act-card-bar-wrap" });
      const barTrack = el("div", { class: "act-card-bar-track" });
      const barFill = el("div", { class: "act-card-bar-fill",
        style: "width:" + Math.round(score * 100) + "%" });
      barTrack.append(barFill);
      barWrap.append(barTrack);
      if (moneyStr) barWrap.append(el("span", {
        class: "act-card-money",
        title: "Недобор по полу = План выручки × доля невыполненного плана"
      }, "~" + moneyStr));
      priorityRow.append(barWrap);
    }
    panel.append(priorityRow);
    // «Почему» (engine-computed, per-entity)
    const whyText = buildWhyText(a);
    if (whyText) panel.append(el("div", { class: "act-card-why" }, whyText));
    return panel;
  }

  function renderActionChips(container, actions) {
    const groups = new Map();
    for (const a of actions) {
      const code = a.action_code || "";
      if (!groups.has(code)) groups.set(code, []);
      groups.get(code).push(a);
    }
    const sortedGroups = Array.from(groups.entries()).map(([code, items]) => {
      const total = items.reduce((s, a) =>
        s + (typeof a.effect_money === "number" ? a.effect_money : 0), 0);
      return { code, items, total };
    }).sort((a, b) => b.total - a.total);

    const wrap = el("div", { class: "act-chips-col" });
    for (const group of sortedGroups) {
      const sorted = group.items.slice().sort((a, b) =>
        (typeof b.effect_money === "number" ? b.effect_money : 0) -
        (typeof a.effect_money === "number" ? a.effect_money : 0));
      const rep = sorted[0];
      const groupCard = el("div", { class: "act-card act-card-chips" });

      const header = el("div", { class: "act-card-header" });
      const titleWrap = el("div", { class: "act-card-title" });
      titleWrap.append(el("span", { class: "act-card-icon", "aria-hidden": "true" }, "◈"));
      titleWrap.append(el("span", { class: "act-card-label" }, rep.label || rep.action_code || ""));
      header.append(titleWrap);
      groupCard.append(header);

      const meta = buildMetaLine(rep);
      if (meta) groupCard.append(meta);

      const chipsStrip = el("div", { class: "act-chips-strip" });
      const CHIPS_PER_PAGE = 10;
      let panelEl = buildSkuPanel(sorted[0]);
      groupCard.append(chipsStrip);
      groupCard.append(panelEl);

      function selectChip(a, chipBtn) {
        chipsStrip.querySelectorAll(".act-chip").forEach((c) => c.classList.remove("act-chip-active"));
        chipBtn.classList.add("act-chip-active");
        const newPanel = buildSkuPanel(a);
        groupCard.replaceChild(newPanel, panelEl);
        panelEl = newPanel;
      }

      function makeChip(a, isFirst) {
        const viab = a.viability || "ok";
        const chip = el("button", {
          class: "act-chip" + (isFirst ? " act-chip-active" : ""), type: "button"
        }, [el("span", { class: "act-dot " + (VIAB_DOT[viab] || "ok"), "aria-hidden": "true" }),
            String(a.entity_id || "")]);
        chip.addEventListener("click", function () { selectChip(a, chip); });
        return chip;
      }

      let shown = 0;
      const moreBtn = el("button", { class: "act-chip-more", type: "button" }, "");
      const lessBtn = el("button", { class: "act-chip-more", type: "button" }, "‹");
      function revealPage() {
        const next = sorted.slice(shown, shown + CHIPS_PER_PAGE);
        for (let i = 0; i < next.length; i++)
          chipsStrip.insertBefore(makeChip(next[i], shown === 0 && i === 0), moreBtn);
        shown += next.length;
        const rest = sorted.length - shown;
        if (rest > 0) moreBtn.textContent = "ещё " + rest;
        else moreBtn.remove();
        if (shown > CHIPS_PER_PAGE && !chipsStrip.contains(lessBtn))
          chipsStrip.append(lessBtn);
      }
      function collapsePage() {
        Array.from(chipsStrip.querySelectorAll(".act-chip")).forEach(function (c) { c.remove(); });
        lessBtn.remove();
        shown = 0;
        if (!chipsStrip.contains(moreBtn)) chipsStrip.append(moreBtn);
        const newPanel = buildSkuPanel(sorted[0]);
        groupCard.replaceChild(newPanel, panelEl);
        panelEl = newPanel;
        revealPage();
      }
      chipsStrip.append(moreBtn);
      revealPage();
      moreBtn.addEventListener("click", revealPage);
      lessBtn.addEventListener("click", collapsePage);

      wrap.append(groupCard);
    }
    container.append(wrap);
  }

  const actContainer = el("div", {});
  renderActionChips(actContainer, eligibleActions);
  box.append(actContainer);

  root.replaceChildren(box);
}

// «Сводка» рисуется ТОЛЬКО из текста ИИ (state_summary/signals_brief). Прежде
// здесь жил buildDeterministicSummary — суррогат «Выполнение плана: X · покрытие
// плана: Y · сигналов: N» под шапкой «◈ Автосводка», который подставлялся, когда
// ИИ-текста нет. Он не нёс интерпретации (пересказ цифр, уже стоящих в KPI выше)
// и маскировал реальное положение: генератора ИИ-текста в продукте нет — он жил
// только в дормантном n8n+DeepSeek-флоу. Требование владельца (29.07): вместо
// суррогата — честная заглушка «Нет данных» во всех доменах и кабинетах.
function renderSummary(payload) {
  const root = document.getElementById("summary");
  if (!root) return;

  const aiState = (payload.state_summary && typeof payload.state_summary === "string")
    ? payload.state_summary : null;
  const aiSigs = (payload.signals_brief && typeof payload.signals_brief === "string")
    ? payload.signals_brief : null;

  // unify: не прячем #block-summary — скелет несёт заглушку; для пустой «Сводки»
  // renderSummary из renderReport вообще не зовётся. При прямом вызове — заглушка в узел.
  if (!aiState && !aiSigs) {
    root.replaceChildren();
    root.append(el("div", { class: "empty-slot" }, "Нет данных"));
    return;
  }

  const box = el("div", { class: "concl" });
  const attrParts = ["◈ ИИ"];
  if (payload.meta && payload.meta.period) attrParts.push(fmtDate(payload.meta.period));
  if (payload.meta && payload.meta.domain) attrParts.push(domainLabel(payload.meta.domain));
  attrParts.push("на основе данных страницы");
  const attrClass = "ai-attr" + (payload.ai_stale ? " stale" : "");
  box.append(el("div", { class: attrClass }, attrParts.join(" · ")));
  if (aiState) box.append(el("div", { class: "ai-state" }, aiState));
  if (aiSigs) box.append(el("div", { class: "ai-sigs" }, aiSigs));

  root.replaceChildren(box);
}

// syncCabinetDirectiveInput(payload) — единственная точка вызова кабинетного
// движка директивного ввода (directive-form-engine.js, правка 25.08). Дёргается
// из renderMeta (домен-нейтральна, зовётся на КАЖДЫЙ рендер отчёта) — но
// перезапрашивает /registry и перерисовывает кнопки ТОЛЬКО когда payload.meta.
// cabinet реально ИЗМЕНИЛСЯ (переключение кабинета в rail-фильтрах), не на
// каждый рендер и не на смену домена: тот же кабинет -> тот же гейтованный
// список форм, кнопки уже настроены правильно, повторный запрос был бы лишним
// сетевым походом на каждое переключение главы/домена.
let _dfiLastCabinet = null;
function syncCabinetDirectiveInput(payload) {
  const cabinet = (payload && payload.meta && payload.meta.cabinet) || "";
  if (!cabinet || cabinet === _dfiLastCabinet) return;
  _dfiLastCabinet = cabinet;
  if (typeof fetchCabinetDirectiveForms !== "function"
      || typeof renderCabinetDirectiveInput !== "function") return;
  fetchCabinetDirectiveForms(cabinet).then((forms) => {
    // Найдено ревью 25.08: без этой проверки более медленный ответ по СТАРОМУ
    // кабинету может прийти позже более быстрого ответа по новому и перезаписать
    // кнопки (onclick/onchange) обратно на старый кабинет — пользователь видит
    // новый, а файл уйдёт в старый. _dfiLastCabinet синхронно указывает на
    // последний запрошенный кабинет, поэтому отбрасываем устаревший ответ.
    if (cabinet !== _dfiLastCabinet) return;
    renderCabinetDirectiveInput(cabinet, forms);
  });
}

function renderMeta(payload) {
  const meta = (payload && payload.meta) || {};
  const span = document.getElementById("meta-inline");
  if (span) {
    // Версия/дата правил (доменные metaFields) сняты из этой строки (правка
    // владельца 25.08) -- meta-inline несёт теперь только активный срез
    // категорий. Активный срез печатается ОБЩИМ кодом из payload.meta, без
    // доменных metaFields (epic-main-19, спека §3): скриншот отчёта обязан
    // говорить, по чему он срезан. Пусто -> схлопывается (.meta-inline:empty,
    // styles.css), не пустая строка на весь line-height.
    const values = ((meta.category_selection || {}).values || []);
    span.textContent = values.length ? "Категории: " + values.join(", ") : "";
  }
  renderLastUpdated(payload);
  syncCabinetDirectiveInput(payload);
}

// AC3 (epic-main-15): дата последнего обновления ДАННЫХ кабинета — max(obs_date) по
// факт-метрикам домена (payload.meta.data_last_updated, стампится бэкендом каждого
// домена в его enrich-функции на каждый запрос), а НЕ дата генерации отчёта
// (meta.recomputed_at) и НЕ дата просматриваемого периода (meta.obs_date/meta.period —
// при выборе прошлого месяца это другая дата). Общий рендер, без доменных веток:
// markup — статичный слот в index.html (секция «Статус» панели: #rail-status-dot/
// #last-updated-val), эта функция лишь наполняет текст+класс точки, домен ничего не
// декларирует и не рендерит сам (доктрина унификации, ось 2). Нет данных ещё (кабинет
// без единого факта) -> честная заглушка "нет данных", не пустая строка (ось 3).

// Подпись статуса данных (task-main-170): СЧЁТ СТРОК, требующих внимания, а не
// доля окна. Прежняя формула («N дней заполнены на NN%») врала соседством: число
// было долей ОКНА (present/expected), а цвет решался долей ГЛУБИНЫ — два ответа
// на разные вопросы в одном элементе. Дата снимка обязательна: лампа читает
// ночной снимок справочника, и лаг обязан быть виден, а не подразумеваться.
//
// Фраза приходит ГОТОВОЙ с сервера (`info.attention_text`, read_api::
// _attention_text) — клиент её не склоняет. Своего склонятеля в этом файле нет
// с среза 7 эпика справочника, и заводить второй значило бы вернуть развилку
// `debt-main-102`.
// Фраза берётся с сервера ДЛЯ ВСЕХ статусов, включая «неизвестно» (ревью
// 13.08). Раньше клиент собирал текст «неизвестно» сам и называл единственную
// причину — протухший снимок, — хотя причин три (`snapshot.fold_counts`:
// no_snapshot / stale / no_rows), и на СВЕЖЕМ снимке без строк домена подсказка
// прямо врала. Различить их по одному `snapshot_day` клиент не может: у
// no_rows дата сегодняшняя и валидная. Дата дописывается ОДИНАКОВО ко всем
// статусам, у кого она есть — форматом владеет клиент (fmtDate), фразой сервер.
function completenessTitle(info) {
  const label = domainLabel(DOMAIN && DOMAIN.key);
  // Домен ещё не выбран (showEmpty до первой загрузки) — без висячего ": ".
  const prefix = label ? label + ": " : "";
  if (!info) return prefix + "состояние неизвестно — данные не загружены";
  // Серверной фразе верим, только когда сервер прислал ЗНАКОМЫЙ статус (три
  // цвета либо честное "unknown"). Испорченные данные — статус вне этого набора
  // — обязаны дать нейтральную заглушку, а не бодрый «2 строки требуют
  // внимания» рядом с бесцветной точкой: цвет мы в таком случае не рисуем, и
  // подпись не имеет права утверждать больше, чем показывает лампа
  // (страховка ревью task-main-104, находка 5 — сохранена на новом носителе).
  const known = info.status === "unknown" || _LAMP_STATUSES.has(info.status);
  if (!known) return prefix + "состояние неизвестно";
  const text = info.attention_text || "состояние неизвестно";
  const day = info.snapshot_day ? " · снимок от " + fmtDate(info.snapshot_day) : "";
  return prefix + text + day;
}

// Точка у даты несёт СТАТУС ДАННЫХ (task-main-170). Прежние .fresh/.stale
// («расчёт отстал») уехали: тот же сигнал уже показывает баннер «Пересчитать»
// (renderStaleBanner), и держать его вторым каналом значило смешивать в одном
// цвете два вопроса — состояние данных и здоровье пересчёта.
//
// try/catch (наследует ревью-находку 5 task-main-104, найдено при переносе
// test_render_completeness_survives_internal_exception на эту функцию Task 5):
// рендер точки статуса не имеет права увести renderReport в аварию — старый
// renderCompleteness был обёрнут точно так же, а при переезде на
// renderLastUpdated (Task 4) обёртка молча потерялась. Симметрично изоляции
// app.py (report_view откатывает completeness в None на сбое расчёта).
function renderLastUpdated(payload) {
  try {
    const meta = (payload && payload.meta) || {};
    const val = document.getElementById("last-updated-val");
    if (val) {
      const d = meta.data_last_updated;
      val.textContent = d ? fmtDate(d) : "нет данных";
    }
    const dot = document.getElementById("rail-status-dot");
    const row = document.querySelector(".rail-status-row");
    if (!dot) return;
    dot.classList.remove("c-green", "c-yellow", "c-red");
    const domains = (payload && payload.completeness && payload.completeness.domains) || null;
    const info = domains && DOMAIN && DOMAIN.key ? domains[DOMAIN.key] : null;
    const status = _lampStatus(info);
    const title = completenessTitle(info);
    if (row) row.title = title;
    if (status !== "unknown") dot.classList.add("c-" + status);
    // Точка несёт СМЫСЛ, а не декор — озвучиваем её скринридеру (ревью 13.08
    // вернуло свойство, которое ревью task-main-104 уже защищало находкой 6 у
    // снятых меню-бейджей: title на неинтерактивном узле клавиатурой и AT не
    // достаётся, aria-hidden прятал бы статус целиком).
    dot.setAttribute("aria-label", title);
    dot.removeAttribute("aria-hidden");
  } catch (e) {
    console.warn("renderLastUpdated: рендер статуса данных упал", e);
  }
}

// Человеческое имя домена — ДАННЫЕ: window.DOMAIN_MANIFEST генерируется
// продуктом из его реестра доменов (domain_boot). Движок словарей имён не
// держит (ось 2 доктрины унификации, срез E1). Единственная функция для
// обеих точек вызова — атрибуции ИИ-сводки (renderSummary) и подсказки
// лампочки (АС3/АС5, completenessTitle) — E1 Task 8 сначала развела их по
// историческим точкам вызова, слияние сделано отдельно после ревью.
function domainLabel(key) {
  const manifest = (typeof window !== "undefined" && Array.isArray(window.DOMAIN_MANIFEST))
    ? window.DOMAIN_MANIFEST : [];
  const found = manifest.find((m) => m.key === key);
  return found ? found.label : (key || "");
}

// Белый список статусов лампы (ревью-находка 5, наследует task-main-170):
// status вне {green,yellow,red} — испорченные/незнакомые данные, а не повод
// собрать невалидный CSS-класс ("c-" + status → "c-undefined"). "unknown" —
// честное состояние ("не знаем"), четвёртое ЗНАЧЕНИЕ прямо тут, не новая
// ветка по имени домена: домена нет в снимке ИЛИ снимок протух (fold_counts) —
// то же "unknown", не молчаливый зелёный (AC1 запрещает показывать зелёные,
// "unknown" зелёным не является).
const _LAMP_STATUSES = new Set(["green", "yellow", "red"]);

function _lampStatus(info) {
  return info && _LAMP_STATUSES.has(info.status) ? info.status : "unknown";
}

// keepExtras=true (срез, epic-main-19): скелет ТОЛЬКО что посеял «Нет данных» в узлы
// экстр, а clearExtras домена вычистил бы эту заглушку — остался бы висячий заголовок
// без тела, ровно то, что доктрина унификации запрещает. DOM экстр пересоздан
// скелетом, так что чистить в этом случае нечего.
function clearCharts(keepExtras) {
  const specs = (DOMAIN && DOMAIN.chartSpecs) || [];
  for (const spec of specs) {
    const c = document.getElementById("chart-" + spec.id);
    const ch = c && typeof Chart.getChart === "function" ? Chart.getChart(c) : null;
    if (ch) ch.destroy();
  }
  if (!keepExtras && DOMAIN && typeof DOMAIN.clearExtras === "function") DOMAIN.clearExtras();
}

function showEmpty(msg) {
  // Полное отсутствие отчёта (HTTP/сеть). Скелет и панель-оглавление строятся из
  // ОДНОГО skeletonPayload (task-main-96, ревью-блокер 4: раньше renderRailToc не
  // звался в этом пути вовсе, а скелет пересевался лишь когда #kpi ещё не
  // существовал — первая упавшая загрузка давала 5 глав в отчёте при пустой панели;
  // уход с домена с экстрами (Взаиморасчёты) на упавший запрос оставлял в #pad и в
  // панели рассинхрон между собой). Ребилд теперь безусловный: набор глав (в т.ч.
  // экстры settlement) совпадает по построению, а не по случайному совпадению
  // условий. meta.domain —
  // из уже поставленного DOMAIN (обе ветки loadReport ставят DOMAIN = cfg ДО
  // showEmpty) — экстры остаются на месте СВОЕГО домена, просто с «Нет данных»,
  // а не пропадают в одном месте и остаются в другом.
  setLoading(false);
  const skeletonPayload = { meta: { domain: DOMAIN && DOMAIN.key } };
  const pad = document.getElementById("pad");
  if (pad && typeof renderSkeleton === "function") {
    pad.innerHTML = renderSkeleton(MODULE_REGISTRY, skeletonPayload);
  }
  for (const id of ["meta-inline", "last-updated-val",
                    "kpi", "signals", "summary", "narrative"]) {
    const n = document.getElementById(id); if (n) n.replaceChildren();
  }
  // Точка статуса данных (task-main-170) — та же дисциплина, что last-updated-val
  // выше: сброс явный, иначе цвет ПРЕДЫДУЩЕГО домена/кабинета виден поверх
  // пустого состояния текущего. renderLastUpdated(null) — один рендер, один
  // источник текста/класса вместо ручной чистки узла.
  if (typeof renderLastUpdated === "function") renderLastUpdated(null);
  clearCharts();
  if (typeof renderRailToc === "function") renderRailToc(skeletonPayload);
  // #empty раскрывается ДО восстановления якоря (мелочь ревью, фаза 2-3 эпика):
  // #empty — последний узел #pad (renderSkeleton), e.hidden=false добавляет ему
  // текст и паддинг — геометрия страницы обязана устояться ДО scrollIntoView
  // внутри restoreRailScrollAnchorOnce, иначе раскрытие сообщения сдвигает
  // содержимое уже ПОСЛЕ того, как позиция прокрутки вычислена.
  const e = document.getElementById("empty");
  e.hidden = false; e.textContent = msg;
  // Путь ошибки — уже финальное состояние (нет дальнейших движков, которые бы ещё
  // росли #pad), поэтому, в отличие от renderReport, восстановление якоря безопасно
  // сразу здесь (task-main-97, см. комментарий в renderReport/rail.js).
  if (typeof restoreRailScrollAnchorOnce === "function") restoreRailScrollAnchorOnce();
}

function fetchWithTimeout(url, opts, ms) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms || 60000);
  return fetch(url, Object.assign({}, opts, { signal: ctrl.signal }))
    .finally(() => clearTimeout(t));
}

function renderStaleBanner(payload) {
  const existing = document.getElementById("stale-banner");
  if (existing) existing.remove();
  const st = payload.stale || {};
  if (!st.rules && !st.data) return;
  const why = st.data ? "загружены новые данные" : "обновлены правила";
  const box = el("div", { id: "stale-banner",
    style: "margin:10px 0;padding:10px 14px;border:1px solid #D2A878;" +
           "background:#FBF3E8;border-radius:8px;font-size:13px;color:#6B4F2A;" });
  box.append("Расчёт отстал: " + why + ". ");
  const btn = el("button", { class: "expand", type: "button" }, "Пересчитать");
  btn.addEventListener("click", () => {
    btn.disabled = true; btn.textContent = "Пересчитываю…";
    const m = payload.meta || {};
    fetchWithTimeout("/v1/mp-cockpit/recompute?cabinet=" + encodeURIComponent(m.cabinet || "") +
          "&domain=" + encodeURIComponent(DOMAIN.key), { method: "POST" }, 60000)
      .then((r) => { if (!r.ok) throw new Error(r.status); window.location.reload(); })
      .catch((e) => { btn.disabled = false;
        btn.textContent = e && e.name === "AbortError"
          ? "Пересчитать (время вышло, ещё раз)" : "Пересчитать (ошибка, ещё раз)"; });
  });
  box.append(btn);
  const anchor = document.getElementById("kpi");
  if (anchor && anchor.parentNode) anchor.parentNode.insertBefore(box, anchor);
}

// Селектор периода в шапке: опции из meta.available_months (+ синтетический "last30",
// если meta.rolling_30d) — переключение re-fetch report-view с выбранным значением через
// тот же параметр date (значение "last30" — специальный маркер, см. app.py report_view).
// Гейт показа НЕ завязан на имя домена/грань кабинета — только на форму данных (общий
// приём и для settlement, и для commerce): <2 месяцев истории и нет rolling_30d ->
// поле остаётся видимым и неактивным (task-main-96, ось 3 доктрины унификации: в
// панели скрытие через hidden дало бы дыру и прыжок нижних секций — АС4, Логистика).
function syncMonthSelector(payload) {
  const wrap = document.getElementById("month-selector");
  const sel = document.getElementById("month-select");
  if (!wrap || !sel) return;
  const meta = payload.meta || {};
  const months = Array.isArray(meta.available_months) ? meta.available_months : [];
  const rolling = !!meta.rolling_30d;
  const monthVal = document.getElementById("month-val");
  // Handler перевязывается ВСЕГДА и ПЕРВЫМ делом — до любого раннего выхода: он
  // замкнут на meta текущего payload, и старый handler от досрезового отчёта увёл бы
  // смену месяца обратно на meta.category = "" — срез снялся бы молча, при том что
  // pill и URL продолжают показывать категорию (epic-main-19).
  sel.onchange = () => {
    if (monthVal && sel.options[sel.selectedIndex]) monthVal.textContent = sel.options[sel.selectedIndex].text;
    // Период пишется в URL (устойчиво липкие селекторы, решение владельца 2026-07-28):
    // раньше выбор месяца жил только в состоянии select и терялся на F5 — history
    // здесь не трогал никто, в отличие от кабинета/категории.
    const q = new URLSearchParams(location.search);
    if (sel.value) q.set("date", sel.value); else q.delete("date");
    history.replaceState(null, "", location.pathname + "?" + q.toString() + location.hash);
    // Срез восстанавливается из meta (эхо активного среза, epic-main-19): без этого
    // смена месяца молча теряет и юнит, и категорию.
    loadReport(meta.cabinet || "", DOMAIN.key, sel.value, meta.scope || "",
               undefined, ((meta.category_selection || {}).values || []));
  };
  function setInactive(reason) {
    wrap.classList.add("rail-field-disabled");
    wrap.title = reason;
    sel.disabled = true;
    if (monthVal) monthVal.textContent = "—";
  }
  function setActive() {
    wrap.classList.remove("rail-field-disabled");
    wrap.title = "Месяц";
    sel.disabled = false;
  }
  // Пустой срез не знает истории домена (отчёта на этот срез просто нет), но выход из
  // него не должен сводиться к снятию фильтра: список месяцев остаётся тем, каким его
  // наполнил предыдущий отчёт — иначе тот же срез нельзя сравнить в другом месяце
  // (epic-main-19 §6). Перестраиваем только опции, handler уже перевязан выше.
  if (payload.empty_slice && !months.length && sel.options.length) { setActive(); return; }
  if (months.length < 2 && !rolling) {
    setInactive("Недостаточно истории для выбора периода");
    return;
  }
  const MON = ["янв", "фев", "мар", "апр", "май", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"];
  const label = (iso) => { const p = iso.split("-"); return MON[(+p[1]) - 1] + " " + p[0]; };
  const options = months.map((iso) => ({ value: iso, text: label(iso) }));
  if (rolling) options.unshift({ value: "last30", text: "Последние 30 дней" });
  const selectedValue = meta.period_kind === "last30" ? "last30" : meta.period;
  sel.replaceChildren(...options.map((o) =>
    el("option", o.value === selectedValue ? { value: o.value, selected: "selected" } : { value: o.value }, o.text)));
  if (monthVal && sel.options[sel.selectedIndex]) monthVal.textContent = sel.options[sel.selectedIndex].text;
  setActive();
}

// renderReport — центральный оркестратор. Скелет-первый (unify): renderSkeleton
// генерит .pad из реестра (заглушка там, где select→null), затем движки наполняют
// НЕПУСТЫЕ узлы. Пустая глава уже несёт «Нет данных» из скелета — движок для неё не
// зовётся, висячего заголовка нет. Экстры settlement — после канона (registry их и
// эмитит только для settlement).
function renderReport(payload, cfg) {
  DOMAIN = cfg;
  // Признаки среза считаем ДО рендера: они гасят и канон, и экстры (epic-main-19).
  const sliceBlocks = !!(payload && (payload.slice_unsupported || payload.empty_slice));
  const pad = document.getElementById("pad");
  if (pad && typeof renderSkeleton === "function") {
    pad.innerHTML = renderSkeleton(MODULE_REGISTRY, payload);
  }
  document.getElementById("empty").hidden = true;
  renderMeta(payload);
  if (typeof syncCategorySelectorOptions === "function") syncCategorySelectorOptions(payload);
  syncMonthSelector(payload);
  renderStaleBanner(payload);
  // Панель-оглавление (task-main-96, rail.js): набор глав + бейдж критических сигналов
  // зависят от payload (settlement-экстры/директивные формы/severity), поэтому
  // пересчитывается на каждую загрузку, тем же местом, что syncMonthSelector.
  if (typeof renderRailToc === "function") renderRailToc(payload);
  // kpi/charts перестали быть безусловными (epic-main-19): на срезе, который грань не
  // умеет, и на пустом срезе их select возвращает null — заглушка «Нет данных» уже в
  // скелете, а движок звать нельзя (на пустом payload он бы упал и увёл в showEmpty,
  // то есть в «нет отчёта» вместо честного пустого среза).
  if (_registrySelect("kpi", payload)) {
    renderKpiCards(document.getElementById("kpi"), cfg.renderKpi(payload));
  }
  // keepExtras на срезе: иначе clearExtras домена стёр бы заглушку, посеянную скелетом.
  clearCharts(sliceBlocks);
  if (_registrySelect("charts", payload)) renderCharts(cfg.chartSpecs, payload);
  // Доменная секция-расширение (напр. «Отчётность» Взаиморасчётов) — после графиков,
  // т.к. clearCharts() уже вызвал DOMAIN.clearExtras() и очистил её хосты.
  // Экстры и директивные формы — тот же гейт, что у канона (epic-main-19): движок
  // домена среза не знает и нарисовал бы кабинетные суммы (Т-счёт P&L, калькулятор)
  // рядом с заглушками канона. Скелет уже посеял «Нет данных» в их узлы.
  if (!sliceBlocks && typeof cfg.renderExtras === "function") cfg.renderExtras(payload);
  sigState.level = undefined; sigState.focus = {}; sigState.mode = "brief"; sigState.view = {};
  if (_registrySelect("signals", payload)) renderSignals(payload);
  if (_registrySelect("summary", payload)) renderSummary(payload);
  if (_registrySelect("narrative", payload)) renderNarrative(payload);
  setLoading(false);
  // Восстановление якоря из URL — В САМОМ КОНЦЕ (task-main-97, найдено CDP-
  // верификацией): #kpi/#charts-host/#signals ещё пустые узлы сразу после скелета
  // (renderRailToc выше зовётся ДО renderKpiCards/renderCharts/renderSignals),
  // документ короче своей финальной высоты в разы — scrollIntoView на этом кадре
  // промахивался мимо итоговой позиции блока. Здесь, после всех движков, геометрия
  // уже финальна. Срабатывает РОВНО один раз за жизнь страницы (см. rail.js).
  if (typeof restoreRailScrollAnchorOnce === "function") restoreRailScrollAnchorOnce();
}

// Хелпер: значение select канон-записи по id (null ⇒ глава пуста ⇒ движок не зовём,
// заглушка из скелета остаётся). Реестр объявлен в module-registry.js (грузится раньше).
function _registrySelect(id, payload) {
  const reg = (typeof MODULE_REGISTRY !== "undefined") ? MODULE_REGISTRY : [];
  const entry = reg.find((e) => e.id === id);
  return entry ? entry.select(payload, (payload && payload.meta) || {}) : true;
}

// Слой A кэша report-view (спека 2026-07-23): per-tab, ключ -- URL запроса
// (уже кодирует cabinet+domain+date+scope+category). Живёт только в памяти
// вкладки -- обнуляется на F5, несвежесть внутри одной сессии не угрожает при
// суточном цикле обновления данных (слой B на сервере подстрахует в любом
// случае через run_id/rules_version). Карточка НЕ пересматривает "полнота
// считается на каждый запрос, без серверного кэша" -- это про app.py
// (report_cache, Слой B), отдельный контур.
const REPORT_VIEW_CACHE = new Map();
const REPORT_VIEW_CACHE_CAP = 40;

function reportViewCacheSet(url, data) {
  // completeness -- ЕДИНСТВЕННОЕ некэшируемое поле payload (ревью task-main-104,
  // находка 3, форма поля обновлена task-main-170): бэкенд честно пересчитывает
  // лампу на КАЖДЫЙ запрос (AC2), а этот кэш живёт по URL часами в рамках
  // вкладки -- без исключения возврат на посещённый домен рендерил бы
  // completeness с момента ПЕРВОЙ загрузки, даже если за это время отработал
  // ingest. Точнее TTL: на cache-hit рендер честно получает
  // completeness===undefined -> renderLastUpdated уже трактует это как
  // "неизвестно" (находка 1), не как вмороженный старый цвет.
  // Копия, не мутация — вызывающий (loadReport) рендерит ЭТОТ ЖЕ объект СРАЗУ
  // после кэширования, ему completeness ещё нужен.
  const cacheable = Object.assign({}, data);
  delete cacheable.completeness;
  REPORT_VIEW_CACHE.set(url, cacheable);
  if (REPORT_VIEW_CACHE.size > REPORT_VIEW_CACHE_CAP) {
    REPORT_VIEW_CACHE.delete(REPORT_VIEW_CACHE.keys().next().value);
  }
}

function reportViewCacheClear() {
  REPORT_VIEW_CACHE.clear();
}

// debt-main-101: cache-hit в loadReport ниже рендерит payload БЕЗ completeness
// (reportViewCacheSet сознательно вырезал его выше) -- без этой функции
// возврат на посещённый домен обычным кликом по меню молча гасил точку
// статуса в "неизвестно" (renderLastUpdated так честно трактует отсутствие
// payload.completeness -- находка 1 выше), хотя секунду назад точка
// показывала реальный yellow/red. Найдено критической приёмкой epic-main-22
// (2026-07-29), воспроизведено живьём в браузере; форма поля обновлена
// task-main-170 (status/attention/snapshot_day вместо fraction/exceptions),
// логика дозапроса не изменилась.
//
// Решение -- дозапрос, не отдельный TTL-кэш: тело отчёта рендерится МГНОВЕННО
// из кэша (Слой A, спека 2026-07-23, свою скорость не теряет), а полнота
// дозапрашивается ОДНИМ живым запросом на тот же URL в фоне -- бэкенд и так
// честно пересчитывает completeness на КАЖДЫЙ запрос (AC2, app.py::
// report_view), отдельный кэш с TTL на фронте держал бы то же самое
// "вморожено на N секунд", просто короче. Обновляется ТОЛЬКО точка статуса
// (renderLastUpdated), не весь renderReport -- дозапрос не имеет права
// дёрнуть скролл/графики/сигналы ради значения, которое эти узлы не
// показывают вовсе.
//
// gen -- поколение ЭТОЙ загрузки (уже захвачено вызывающим до входа в
// cache-hit ветку loadReport, та же переменная, что использует основной,
// сетевой путь). Если пользователь успел переключиться на другой домен/
// кабинет, пока фоновый запрос летел, loadGen уже другой -- устаревший ответ
// отбрасывается ДО показа (не перерисовываем точку чужого домена).
//
// try/catch на верхнем уровне (не только внутри renderLastUpdated): сетевой
// сбой ЭТОГО дозапроса -- фоновая, необязательная операция поверх уже
// показанного (пусть и "неизвестного") тела отчёта, она не имеет права
// всплыть необработанным отказом промиса и что-либо уронить.
async function refreshCompletenessAfterCacheHit(url, cfg, gen) {
  try {
    const resp = await fetchWithTimeout(url, {}, 60000);
    if (gen !== loadGen || !resp.ok) return;
    const data = await resp.json();
    if (gen !== loadGen) return;
    reportViewCacheSet(url, data);  // освежить тело в кэше на будущее попадание
    DOMAIN = cfg;  // renderLastUpdated читает DOMAIN.key
    renderLastUpdated(data);
  } catch (e) {
    // Тихий фолбэк (см. комментарий выше): точка остаётся в уже нарисованном
    // cache-hit'ом состоянии ("неизвестно"), не хуже, чем было до дозапроса --
    // не новая поломка, просто неудавшееся обновление.
  }
}

async function loadReport(cabinet, domain, date, scope, gen, category, _isPeriodRetry) {
  const cfg = window.DOMAINS[domain];
  // gen может быть уже захвачен вызывающим (switchDomain, bumpLoadGen) — тогда
  // используем его как есть, не создавая новое поколение поверх.
  if (gen === undefined) gen = ++loadGen;
  // category не передана явно — берём из URL: срез липкий, и любой вызов loadReport
  // из кода, не знающего о срезе, обязан его сохранить, а не обнулить (epic-main-19).
  if (category === undefined) {
    category = new URLSearchParams(location.search).getAll("category");
  }
  category = Array.isArray(category) ? category : (category ? [category] : []);
  category = [...new Set(category.filter((value) => typeof value === "string" && value))];
  if (typeof setCategoryPickerRequestContext === "function") {
    setCategoryPickerRequestContext(cabinet, domain, date, scope);
  }
  const url = "/v1/mp-cockpit/report-view?cabinet=" + encodeURIComponent(cabinet)
    + "&domain=" + encodeURIComponent(domain)
    + (date ? "&date=" + encodeURIComponent(date) : "")
    + (scope ? "&scope=" + encodeURIComponent(scope) : "")
    + category.map((value) => "&category=" + encodeURIComponent(value)).join("");
  const cached = REPORT_VIEW_CACHE.get(url);
  if (cached !== undefined) {
    renderReport(cached, cfg);
    // debt-main-101: тело уже нарисовано мгновенно из кэша -- полноту
    // дозапрашиваем в фоне, не блокируя возврат из loadReport (см. комментарий
    // у refreshCompletenessAfterCacheHit выше).
    refreshCompletenessAfterCacheHit(url, cfg, gen);
    return true;
  }
  setLoading(true);
  try {
    const resp = await fetchWithTimeout(url, {}, 60000);
    if (gen !== loadGen) return false;            // перекрыт более новой загрузкой
    if (!resp.ok) {
      // Сохранённый период (липкий при смене кабинета/вкладки-домена, решение владельца
      // 2026-07-28) мог не пережить переезд — у нового кабинета/домена нет отчёта именно
      // на эту дату (app.py report_view -> 404). Один retry без date вместо тупикового
      // экрана "Нет отчёта", с видимой плашкой (app.js notifySliceReset) при успехе.
      if (date && !_isPeriodRetry) {
        const recovered = await loadReport(cabinet, domain, "", scope, gen, category, true);
        // date из URL убираем ТОЛЬКО при успешном восстановлении (ревью общего шва):
        // если у нового домена/кабинета нет отчёта вообще (retry тоже упал), сохранённый
        // date не трогаем — он ещё может быть валиден при следующем переключении на
        // домен/кабинет, где отчёт на эту дату есть.
        if (recovered && gen === loadGen) {
          const q = new URLSearchParams(location.search);
          q.delete("date");
          history.replaceState(null, "", location.pathname + "?" + q.toString() + location.hash);
          if (typeof notifySliceReset === "function") {
            notifySliceReset("Выбранный период недоступен в этом кабинете — показан последний доступный отчёт");
          }
        }
        return recovered;
      }
      DOMAIN = cfg; showEmpty("Нет отчёта (HTTP " + resp.status + ").");
      return false;
    }
    const data = await resp.json();
    if (gen !== loadGen) return false;
    reportViewCacheSet(url, data);
    renderReport(data, cfg);
    return true;
  } catch (e) {
    if (gen !== loadGen) return false;
    DOMAIN = cfg; showEmpty("Ошибка загрузки отчёта: " + e.message);
    return false;
  }
}
