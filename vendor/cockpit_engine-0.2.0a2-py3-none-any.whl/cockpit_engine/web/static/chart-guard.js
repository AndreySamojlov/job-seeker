"use strict";

// Гард качества графика. Чистые функции над сырой серией payload. На верхнем
// уровне только декларации (как core.js) — файл грузится в Node для юнит-тестов.
// DOM/Chart не трогаются.

const GUARD = {
  minLinePoints: 3,   // линия < 3 точек → sparse
  minBars: 2,         // бар < 2 категорий → sparse
  flatCv: 0.01,       // stdev / |mean| < 1% → flat
  dominance: 0.95,    // один сегмент ≥ 95% суммы → dominance
  overflow: 8,        // > 8 категорий → overflow
  outlier: 5,         // один > 5× второго по модулю → outlier-squeeze
};

function _gNums(arr) {
  return (arr || []).filter((v) => v !== null && v !== undefined);
}

function chartStats(values) {
  const v = _gNums(values);
  const n = v.length;
  const sum = v.reduce((a, b) => a + b, 0);
  const mean = n ? sum / n : 0;
  const variance = n ? v.reduce((a, b) => a + (b - mean) * (b - mean), 0) / n : 0;
  const std = Math.sqrt(variance);
  const sorted = v.map(Math.abs).sort((a, b) => b - a);
  const max = sorted[0] || 0;
  const second = sorted[1] || 0;
  return {
    n: n, sum: sum, mean: mean, std: std, max: max, second: second,
    cv: mean ? std / Math.abs(mean) : (max ? std / max : 0),
    domRatio: second ? max / second : (max ? Infinity : 0),  // Infinity лоссится в JSON, но внутри assess безопасно
    topShare: sum ? Math.abs(max / sum) : 0,
  };
}

// Главная (первая) серия — по ней судим о ФОРМЕ графика (flat/dominance/overflow/
// outlier): их семантика пер-серийна (сравнение баров одной серии).
function primaryValues(series) {
  const s = (series && series.series && series.series[0]) || {};
  return s.y || [];
}

// Значения ВСЕХ серий — для суждения «есть ли данные вообще». Многосерийные
// кодировки (stacked-hbar/grouped-bar) могут иметь нулевую ПЕРВУЮ серию при
// ненулевых остальных (assortment category_quadrant_rollup: квадрант «успешный»
// нулевой по топ-категориям, «недостаточно истории» — реальный). Судить о пустоте
// только по первой серии — ложное «Нет данных за период» (debt-main-45).
function allSeriesValues(series) {
  const list = (series && series.series) || [];
  return list.reduce((acc, s) => acc.concat((s && s.y) || []), []);
}

// Эффективный гард спеки: глобальные дефолты + spec.guard (спека побеждает).
// ЕДИНСТВЕННЫЙ источник порогов — и для диагноза (assess), и для лечения
// (applyGuard/aggregateOther): иначе спека объявляет overflow в своём toml, а
// свёртка хвоста режет по глобальному дефолту.
function guardFor(spec) {
  return Object.assign({}, GUARD, (spec && spec.guard) || {});
}

// Порог «без свёртки» для развёрнутого (полноэкранного) показа. 9999 — принятое
// в проекте соглашение (commerce_charts.toml, logistics_charts.toml), не
// Infinity: серии и без того обрезаны бэкендом до top-N. Дефолт, когда спека
// НЕ объявляет свой guard.expandedOverflow (35 из 39 спек проекта на 18.08).
const EXPANDED_OVERFLOW = 9999;

// Спека для развёрнутого показа: на большом холсте хвост категорий помещается
// целиком (или почти целиком — плотная товарная грань объявляет собственный
// потолок), поэтому свёртку в «Прочие (N)» снимаем/поднимаем. Поднимается
// overflow: guard.expandedOverflow спеки, если объявлен (task-main-200, toml
// `guard = { overflow, expandedOverflow }`), иначе прежние 9999 — обратная
// совместимость, этим порогом сегодня пользуются все домены. Пороги,
// объявленные самой спекой (dominance/outlier/flatCv), остаются её
// редакционным решением. Pure: исходную спеку не мутирует.
function expandedSpec(spec) {
  const base = (spec && spec.guard) || {};
  const lifted = (typeof base.expandedOverflow === "number")
    ? base.expandedOverflow : EXPANDED_OVERFLOW;
  const g = Object.assign({}, base, { overflow: lifted });
  return Object.assign({}, spec, { guard: g });
}

function assess(spec, series) {
  if (spec && (spec.encoding === "pie" || spec.encoding === "date-scatter")) {
    const useful = spec.encoding === "pie"
      ? allSeriesValues(series).some(v => Number.isFinite(v) && v > 0)
      : ((series && series.series) || []).some(s => Array.isArray(s.data) && s.data.length > 0);
    return {action:useful ? "as-is" : "value-card",note:useful ? null : "Нет данных",symptoms:[],reencodeTo:null};
  }
  const g = guardFor(spec);
  const isLine = spec && spec.encoding === "line";
  // axis:"time" (report/daily_table.py, через deriveSeries) — временная ось не
  // имеет "хвоста по величине", свёртка/усечение overflow для неё бессмысленны
  // (task-gracious-hopper-854d26-5). Остальные симптомы (flat/dominance/
  // outlier-squeeze/zero-range) остаются в силе — они осмысленны и для времени.
  const isTimeAxis = series && series.axis === "time";
  const st = chartStats(primaryValues(series));
  // Пустоту графика оцениваем по ВСЕМ сериям (не только первой) — иначе
  // многосерийный график с нулевой первой серией ложно прячется (debt-main-45).
  const stAll = chartStats(allSeriesValues(series));
  const symptoms = [];

  if (stAll.n === 0 || (stAll.max === 0 && stAll.sum === 0)) symptoms.push("zero-range");
  if (isLine && st.n === 1) symptoms.push("single-point");
  if (st.n >= 1 && ((isLine && st.n < g.minLinePoints) || (!isLine && st.n < g.minBars)))
    symptoms.push("sparse");
  if (st.n >= 2 && st.max !== 0 && st.cv < g.flatCv) symptoms.push("flat");
  if (!isLine && st.n >= 2 && st.topShare >= g.dominance) symptoms.push("dominance");
  if (!isLine && !isTimeAxis && st.n > g.overflow) symptoms.push("overflow");
  if (!isLine && st.n >= 2 && st.domRatio > g.outlier && st.topShare < g.dominance)
    symptoms.push("outlier-squeeze");

  let action = "as-is", note = null, reencodeTo = null;
  if (symptoms.includes("zero-range")) { action = "value-card"; note = "Нет данных за период"; }
  else if (symptoms.includes("single-point")) { action = "value-card"; note = "Одна точка за период"; }
  else if (symptoms.includes("sparse") && isLine) { action = "reencode"; reencodeTo = "bar"; }
  else if (symptoms.includes("flat")) { action = "value-card"; note = "Значение не менялось в периоде"; }
  else if (symptoms.includes("overflow")) {
    // aggregateOther СУММИРУЕТ хвост — верно для рублей/штук, бессмысленно для
    // долей (unit="pct": хвост из сотен товаров дал бы бар в тысячи процентов).
    // Процентные графики поэтому не сворачиваются, а отсекаются: truncate,
    // сноска со счётом вместо бара «Прочие» (спека 2026-08-18-chart-engine-
    // controls-design.md §3 «Свёртка хвоста по природе величины»). Решение —
    // по spec.unit, без знания о домене.
    if (spec && spec.unit === "pct") {
      action = "truncate";
      // Нейтральная к порядку формулировка (правка 3 ревью epic-main-31):
      // truncateOther режет ПО ПОЗИЦИИ, не по величине — товарная серия
      // выполнения плана приходит от бэкенда отсортированной худшими вперёд
      // (build_sku_completion), то есть показываются худшие, а не
      // «крупнейшие». Старый текст врал направлением отбора.
      note = "Показаны " + g.overflow + " из " + st.n;
    } else {
      action = "aggregate";
    }
  }
  else if (symptoms.includes("dominance")) { action = "annotate"; note = "Значения сильно различаются — сравнение затруднено"; }
  else if (symptoms.includes("outlier-squeeze")) { action = "annotate"; note = "Один выброс сжимает остальные"; }

  return { symptoms: symptoms, action: action, note: note, reencodeTo: reencodeTo };
}

// Свернуть длинный хвост категорий в «Прочие (N)»: топ-(topN−1) по суммарному
// модулю всех серий + агрегат остального. Сохраняет форму series[{name,y}].
// Необязательный extra — массив, параллельный labels (напр. completion-доли):
// переносится в том же порядке keep, слот «Прочие» = null (агрегат доли не определён).
function aggregateOther(labels, seriesList, topN, extra) {
  const n = labels.length;
  if (n <= topN) return { labels: labels, series: seriesList, extra: extra };
  const total = labels.map((_, i) =>
    seriesList.reduce((a, s) => a + Math.abs(s.y[i] || 0), 0));
  const order = labels.map((_, i) => i).sort((a, b) => total[b] - total[a]);
  const keep = order.slice(0, topN - 1).sort((a, b) => a - b);
  const rest = order.slice(topN - 1);
  return {
    labels: keep.map((i) => labels[i]).concat(["Прочие (" + rest.length + ")"]),
    series: seriesList.map((s) => ({
      name: s.name,
      y: keep.map((i) => s.y[i]).concat([rest.reduce((a, i) => a + (s.y[i] || 0), 0)]),
    })),
    extra: extra ? keep.map((i) => extra[i]).concat([null]) : extra,
  };
}

// Отсечь длинный хвост процентных серий (action="truncate", assess() выше):
// держит ПОЗИЦИОННЫЙ порядок как есть — в отличие от aggregateOther, который
// пересортировывает по величине и оставляет самые крупные бары. Для долей
// пересортировка по величине была бы неверна: товарная серия выполнения плана
// приходит от бэкенда уже отсортированной худшими вперёд (build_sku_completion,
// domains/commerce/charts.py) — усечение ПО ПОЗИЦИИ снимает благополучный
// хвост (спека, риск 5), а не переоткрывает его как «крупнейший». shown/total
// в возврате — те же числа, что уже несёт assess().note («показаны N из M»),
// здесь для вызывающего кода, которому нужны голые числа, а не готовая строка.
function truncateOther(labels, seriesList, topN, extra) {
  const n = labels.length;
  if (n <= topN) return { labels: labels, series: seriesList, extra: extra, shown: n, total: n };
  return {
    labels: labels.slice(0, topN),
    series: seriesList.map((s) => ({ name: s.name, y: s.y.slice(0, topN) })),
    extra: extra ? extra.slice(0, topN) : extra,
    shown: topN,
    total: n,
  };
}
