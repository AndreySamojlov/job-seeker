"use strict";

// ledger-engine.js — общий движок «Т-счёт» (белый список рендер-примитивов, §3
// доктрины унификации). Рисует группы строк с подытогами + опциональную строку-
// сверку. Домен-нейтрален: НИ одного доменного имени/ключа — источник данных — spec.
//
// Контракт: renderLedger(container, spec)
//   spec.layout: "columns" — группы бок о бок (CSS grid auto-fit);
//                "stacked"  — группы одна под другой (flex-column).
//   spec.groups[]: { title, accent(CSS-var|null), totalAccent(CSS-var|null|undefined),
//                    rows:[{label,value}], total:{label,value}|null }
//     totalAccent — необязательное поле: цвет ИТОГОВОЙ строки отдельно от accent шапки.
//     Не передан (undefined) → фоллбэк на accent (итог красится тем же цветом, что
//     шапка). Явный null → итог всегда ink, НЕЗАВИСИМО от accent шапки. ВАЖНО для
//     будущих потребителей: если итог семантически нейтрален (не должен красится в
//     цвет шапки) — передавайте totalAccent:null ЯВНО, иначе получите тихий
//     accent-цвет вместо ожидаемого ink (не упадёт, просто визуально неверно).
//   spec.reconciliation: { parts:[{label,value,emphasis:"muted"|"strong"}],
//                          result:{label,value,pct,positive:true|false|null} } | null
//     result.positive — трёхзначно: true→grass, false→terra, null/undefined→ink
//     (нейтрально, без кодирования по знаку). Если результат не должен зависеть от
//     знака — передавайте positive:null ЯВНО, не полагайтесь на дефолт молча.
//
// Зависимости: el/fmtPct/nf0 из core.js.
//
// Форматтеры — локальные (движок не тянет доменный модуль): целые рубли; ledRub —
// KPI/подытоги/сверка (0→«0», null→«Нет данных» — отсутствие данных ≠ нулю);
// ledFmt0 — строки выписки (0/пропуск→«—», бух-конвенция, там нуля по факту нет).
const ledRub  = (n) =>
  (n === null || n === undefined) ? "Нет данных" : nf0.format(n);
const ledFmt0 = (n) =>
  (n === null || n === undefined || n === 0) ? "—" : nf0.format(n);

// Строка выписки: метка слева, целое значение справа. isTotal — подытог секции
// (жирнее, верхняя линия, цвет значения = accent, прижат к низу колонки). 0 → «—».
function _ledgerRow(label, rawValue, isTotal, accent) {
  const isDash = (rawValue === null || rawValue === undefined || rawValue === 0);
  const labColor = isTotal ? "var(--ink)" : "var(--ink-soft)";
  const valColor = isTotal ? (accent || "var(--ink)")
                           : (isDash ? "var(--muted)" : "var(--ink-soft)");
  return el("div", {
    style: "display:flex;justify-content:space-between;align-items:baseline;gap:12px;" +
           "padding:8px 0;" +
           (isTotal ? "border-top:1px solid var(--hair-strong);margin-top:auto;"
                    : "border-bottom:1px solid var(--hair);"),
  }, [
    el("span", {
      style: "font-size:var(--fs-sm);color:" + labColor +
             (isTotal ? ";font-weight:600;" : ";"),
    }, label),
    el("span", {
      class: "num",
      style: "white-space:nowrap;font-size:" +
             (isTotal ? "var(--fs-base)" : "var(--fs-sm)") +
             ";font-weight:" + (isTotal ? "700" : "500") +
             ";color:" + valColor + ";",
    }, ledFmt0(rawValue)),
  ]);
}

// Колонка/секция Т-счёта: flex-column (для выравнивания подытога по низу). accent —
// цвет тихой метки секции (шапка); null → var(--ink) (секция без акцента). Цвет
// значения подытога развязан от шапки: group.totalAccent (если задан, в т.ч. null —
// чистый ink) переопределяет accent шапки; отсутствие поля → фоллбэк на group.accent
// (шапка и итог одного цвета — исходное поведение для колонок file-грани).
// title=null → шапка секции не рисуется (стек-секции с общей шапкой снаружи).
function _ledgerGroup(group) {
  const accent = group.accent || "var(--ink)";
  const kids = [];
  if (group.title) {
    kids.push(el("div", {
      style: "font-size:var(--fs-xs);font-weight:600;letter-spacing:.07em;" +
             "text-transform:uppercase;color:" + accent + ";margin:0 0 2px;",
    }, group.title));
  }
  const col = el("div", { style: "display:flex;flex-direction:column;" }, kids);
  for (const r of (group.rows || [])) col.append(_ledgerRow(r.label, r.value, false, null));
  const totalAccent = (group.totalAccent !== undefined) ? group.totalAccent : group.accent;
  if (group.total) col.append(_ledgerRow(group.total.label, group.total.value, true, totalAccent));
  return col;
}

// Строка-сверка (лёгкая, без бокса): слева слагаемые (parts), справа результат
// (result с уменьшенным героем). emphasis части: "strong" — акцент ink, "muted" — ink-soft.
// result.positive кодирует знак цветом: true → grass, false → terra; null/undefined —
// нейтральный var(--ink) (сверка-тождество без знаковой семантики, не «прибыль/убыток»).
function _ledgerReconciliation(rec) {
  const parts = rec.parts || [];
  const result = rec.result || {};
  const left = el("div", {
    style: "display:flex;gap:26px;flex-wrap:wrap;align-items:baseline;",
  }, parts.map((p) => {
    const valColor = (p.emphasis === "strong") ? "var(--ink)" : "var(--ink-soft)";
    const valWeight = (p.emphasis === "strong") ? "600" : "500";
    return el("span", { style: "font-size:var(--fs-sm);color:var(--muted);" }, [
      p.label,
      el("span", {
        class: "num",
        style: "color:" + valColor + ";font-weight:" + valWeight + ";margin-left:6px;",
      }, ledRub(p.value)),
    ]);
  }));
  const resColor = (result.positive === null || result.positive === undefined)
    ? "var(--ink)"
    : (result.positive ? "var(--grass)" : "var(--terra)");
  const resText = (result.pct === null || result.pct === undefined)
    ? result.label
    : result.label + " · " + fmtPct(result.pct);
  const right = el("div", {
    style: "font-size:var(--fs-sm);color:var(--muted);white-space:nowrap;",
  }, [
    resText,
    el("span", {
      class: "num",
      style: "font-size:var(--fs-lg);font-weight:700;letter-spacing:-.01em;" +
             "margin-left:8px;color:" + resColor + ";",
    }, ledRub(result.value)),
  ]);
  return el("div", {
    style: "border-top:1px solid var(--hair-strong);margin-top:18px;padding-top:14px;" +
           "display:flex;justify-content:space-between;align-items:baseline;" +
           "gap:18px;flex-wrap:wrap;",
  }, [left, right]);
}

// Публичный вход: рендер Т-счёта из spec в container.
function renderLedger(container, spec) {
  if (!container) return;
  spec = spec || {};
  const groups = spec.groups || [];
  let body;
  if (spec.layout === "stacked") {
    // Секции одна под другой: общий flex-column-контейнер, шапки — внутри групп.
    body = el("div", { style: "display:flex;flex-direction:column;gap:2px;" },
      groups.map((g) => _ledgerGroup(g)));
  } else {
    // "columns": группы бок о бок через grid auto-fit.
    body = el("div", {
      style: "display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));" +
             "gap:14px 44px;align-items:stretch;",
    }, groups.map((g) => _ledgerGroup(g)));
  }
  const kids = [body];
  if (spec.reconciliation) kids.push(_ledgerReconciliation(spec.reconciliation));
  container.replaceChildren(el("div", {}, kids));
}

if (typeof window !== "undefined") window.renderLedger = renderLedger;
if (typeof module !== "undefined" && module.exports) module.exports = { renderLedger };
