"use strict";

// Оверлеи графиков (Ф3): чистые трансформы серий + сегмент-контрол на слайд.
// Доменно-агностичен. Грузится после chart-render.js. Верхний уровень — только
// декларации (Node-тестируемо); DOM/Chart/sessionStorage — лишь в телах функций.

// Бегущая сумма (накопительно). null пропускается, сумма не растёт.
function cumulative(y) {
  let s = 0;
  return (y || []).map((v) => (v == null ? null : (s += v)));
}

// Скользящее среднее окна w (тренд). Пока точек < w → null.
function movingAverage(y, w) {
  const a = y || [];
  return a.map((_, i) => {
    if (i < w - 1) return null;
    let sum = 0, cnt = 0;
    for (let k = i - w + 1; k <= i; k++) if (a[k] != null) { sum += a[k]; cnt++; }
    return cnt ? sum / cnt : null;
  });
}

// Потолок оси по 2-му максимуму (для «без выброса»; данные не режем).
function axisMaxExcludingOutlier(y) {
  const v = (y || []).filter((x) => x != null).map(Math.abs).sort((a, b) => b - a);
  if (v.length < 2) return v[0] || 0;
  return v[1] * 1.1;
}

// Словарь оверлеев: label + apply(chart, baseSeries, on) — мутирует chart.* (без update).
// Оверлей "sort" ретайрен task-main-199 (§4 спеки controls-design, риск 2):
// два механизма сортировки на одном графике не сосуществуют. Трёхпозиционный
// перещёлкиватель (default/asc/desc) живёт теперь в chart-render.js
// (sortOrder3 + opts.sortMode у chartConfig) и в sortControl ниже — он не
// оверлей (не мутирует живой chart.data через apply(on)), а часть owner-
// пересборки buildChartSlide (единая точка владения инстансом, риск 1).
const OVERLAY_DEFS = {
  cumulative: {
    label: "Накопительно",
    apply: (chart, base, on) => {
      const y = (base.series[0] && base.series[0].y) || [];
      chart.data.datasets[0].data = on ? cumulative(y) : y.slice();
    },
  },
  trend: {
    label: "Тренд",
    apply: (chart, base, on) => {
      const y = (base.series[0] && base.series[0].y) || [];
      const id = "__trend";
      const i = chart.data.datasets.findIndex((d) => d.__id === id);
      if (on && i < 0) {
        chart.data.datasets.push({
          __id: id, type: "line", label: "Тренд",
          data: movingAverage(y, 7),
          borderColor: "#B45309", borderWidth: 2, borderDash: [6, 3],
          pointRadius: 0, fill: false, spanGaps: true,
        });
      } else if (!on && i >= 0) {
        chart.data.datasets.splice(i, 1);
      }
    },
  },
  "plan-toggle": {
    label: "Скрыть план",
    apply: (chart, base, on) => {
      const i = chart.data.datasets.findIndex((d) => d.type === "line");
      if (i >= 0) chart.setDatasetVisibility(i, !on);
    },
  },
  "no-outlier": {
    label: "Без выброса",
    apply: (chart, base, on) => {
      const y = (base.series[0] && base.series[0].y) || [];
      chart.options.scales.y.max = on ? axisMaxExcludingOutlier(y) : undefined;
    },
  },
  bridges: {
    label: "Мостики",
    default: true,
    apply: (chart, base, on) => {
      const wb = chart.options.plugins && chart.options.plugins.waterfallBridges;
      if (wb) wb.on = on;
    },
  },
};

// Сегмент-контрол оверлеев слайда. Возвращает элемент или null (если оверлеев нет).
// Состояние липкое в sessionStorage (сброс при перезагрузке).
function overlayControl(spec, chart, baseSeries, domainKey) {
  const ovs = (spec && spec.overlays) || [];
  if (!ovs.length || !chart) return null;
  const wrap = el("div", { class: "ov-ctrl" });
  for (const ov of ovs) {
    const def = OVERLAY_DEFS[ov];
    if (!def) continue;
    const key = "ov:" + (domainKey || "") + ":" + spec.id + ":" + ov;
    let on = !!def.default;
    try { const v = sessionStorage.getItem(key); if (v !== null) on = (v === "1"); } catch (e) { /* noop */ }
    const btn = el("button", { class: "ov-seg" + (on ? " on" : ""), type: "button" }, def.label);
    const fire = () => { def.apply(chart, baseSeries, on); chart.update("active"); };
    btn.addEventListener("click", () => {
      on = !on;
      try { sessionStorage.setItem(key, on ? "1" : "0"); } catch (e) { /* noop */ }
      btn.classList.toggle("on", on);
      fire();
    });
    // Восстановить липкое состояние — БЕЗУСЛОВНО (правка 2 ревью epic-main-31).
    // Раньше вызывался только при on===true: если конфиг по умолчанию рисует
    // (напр. waterfallBridges.on:true) и пользователь в прошлый раз выключил
    // (sessionStorage="0"), on здесь false, `if (on) fire()` пропускал apply —
    // кнопка показывала «выкл», а мостики оставались нарисованными (chart
    // унаследовал дефолт из chartConfig, apply() ни разу не вызывался). apply
    // всех шести оверлеев идемпотентен на конкретном значении on — безусловный
    // fire() синхронизирует реальное состояние графика с кнопкой всегда, а не
    // только когда on истинно.
    fire();
    wrap.append(btn);
  }
  return wrap;
}

// ===== task-main-199 (§4 спеки controls-design): ориентация + сортировка =====
// Оба контрола — ЧИСТЫЕ UI-билдеры: НЕ трогают Chart, только читают/пишут
// sessionStorage и зовут onChange() при клике. Пересборка (destroy+create на
// одном холсте) — забота owner-замыкания buildChartSlide (chart-render.js,
// риск 1 спеки: единая точка владения инстансом). Это и отличает их от
// OVERLAY_DEFS-оверлеев выше, которые мутируют живой chart.data напрямую.

// Сегмент-пара «Верт/Гор» (AC4). current — уже разрешённое значение ("v"|"h",
// липкое состояние читает и передаёт вызывающий, buildChartSlide) — этот
// билдер сам по себе состояние не резолвит, только рисует и пишет клик.
function orientationControl(storKey, current, onChange) {
  const wrap = el("div", { class: "ov-ctrl" });
  const mk = (mode, label) => {
    const btn = el("button",
      { class: "ov-seg" + (current === mode ? " on" : ""), type: "button" }, label);
    btn.addEventListener("click", () => {
      if (current === mode) return;
      try { sessionStorage.setItem(storKey, mode); } catch (e) { /* noop */ }
      onChange();
    });
    return btn;
  };
  wrap.append(mk("v", "Верт"), mk("h", "Гор"));
  return wrap;
}

// Трёхпозиционный перещёлкиватель сортировки: default -> asc -> desc ->
// default (АС4). Один кликабельный .ov-seg, текст меняется по состоянию —
// вся вычислительная часть (sortOrder3, применение к labels/датасетам/
// цветам) — chartConfig(opts.sortMode) в chart-render.js, здесь только UI.
const SORT_CYCLE = { default: "asc", asc: "desc", desc: "default" };
const SORT_LABEL = { default: "Сортировка", asc: "Сортировка ↑", desc: "Сортировка ↓" };
function sortControl(storKey, current, onChange) {
  const cur = SORT_LABEL[current] ? current : "default";
  const next = SORT_CYCLE[cur];
  const btn = el("button",
    { class: "ov-seg" + (cur !== "default" ? " on" : ""), type: "button" }, SORT_LABEL[cur]);
  btn.addEventListener("click", () => {
    try { sessionStorage.setItem(storKey, next); } catch (e) { /* noop */ }
    onChange();
  });
  return btn;
}
