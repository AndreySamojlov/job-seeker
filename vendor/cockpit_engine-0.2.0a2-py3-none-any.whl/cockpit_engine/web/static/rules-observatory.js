"use strict";
(function () {
  // rules.html автономна (не грузит shared.js/core.js) — свои el()/форматтеры/fetch намеренны, не дедупить.
  function el(tag, attrs, children) {
    var n = document.createElement(tag);
    attrs = attrs || {};
    for (var k in attrs) {
      if (attrs[k] == null) continue;
      if (k === "class") n.className = attrs[k];
      else n.setAttribute(k, attrs[k]);
    }
    var kids = [].concat(children == null ? [] : children);
    for (var i = 0; i < kids.length; i++) {
      var c = kids[i];
      if (c == null) continue;
      n.append(c instanceof Node ? c : document.createTextNode(c));
    }
    return n;
  }

  var nf1 = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 1 });
  var nf0 = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 0 });
  var nf2 = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 2 });
  function fmtInt(n) { return (n == null) ? "—" : nf0.format(n); }
  function fmtMoney(n) {
    if (!n) return "0 ₽";
    var a = Math.abs(n);
    if (a >= 1e6) return nf1.format(n / 1e6) + " млн ₽";
    if (a >= 1e3) return nf1.format(n / 1e3) + " тыс. ₽";
    return nf0.format(n) + " ₽";
  }
  function fmtThr(t) { return (t == null) ? "—" : nf2.format(t); }
  function fmtCondValue(t) {
    if (t == null) return "—";
    if (Math.abs(t) >= 100) return fmtMoney(t);
    if (Math.abs(t) <= 1.5) return nf1.format(t * 100) + "%";
    return nf2.format(t);
  }
  function fetchTimeout(url, ms) {
    var ctrl = new AbortController();
    var t = setTimeout(function () { ctrl.abort(); }, ms || 60000);
    return fetch(url, { signal: ctrl.signal }).finally(function () { clearTimeout(t); });
  }

  var DOMAIN_LABEL = {};
  (window.DOMAIN_MANIFEST || []).forEach(function (d) { DOMAIN_LABEL[d.key] = d.label; });
  var SEV_RU = { critical: "красный", warning: "жёлтый", info: "норма" };
  var OP_RU = { lt: "<", le: "≤", gt: ">", ge: "≥" };
  var LEVEL_RU = { sku: "SKU", category: "Категория", unit: "Юнит", brand: "Бренд" };
  var COST_LABEL = { low: "лёгкое", med: "среднее", high: "сложное" };
  var CONF_LABEL = { high: "высокая надёжность", medium: "средняя надёжность", low: "низкая надёжность" };

  // Тяжелейшее ФАКТИЧЕСКОЕ срабатывание (для кружка строки): из sev_counts,
  // не из объявленной severity правила. Спит (нет срабатываний) → null → muted.
  function heaviestSev(rule) {
    var s = rule.sev_counts || {};
    if (s.critical) return "critical";
    if (s.warning) return "warning";
    if (s.info) return "info";
    return null;
  }

  var state = { data: null, domain: "", sort: "hits", query: "", level: "",
                cabinet: null, cabinetList: [] };

  // ── Реестр ──────────────────────────────────────────────────────────────
  function kpis(data) {
    var rules = 0, hits = 0, money = 0, active = 0;
    (data.domains || []).forEach(function (d) {
      (d.rules || []).forEach(function (r) {
        rules += 1; hits += r.hits || 0; money += r.money || 0;
        if (r.enabled) active += 1;
      });
    });
    return [["правил в каталоге", fmtInt(rules)], ["активных", fmtInt(active)],
            ["срабатываний", fmtInt(hits)], ["на столе", fmtMoney(money)]];
  }

  function severityDot(sev) {
    var cls = sev === "critical" ? "crit" : sev === "warning" ? "warn"
            : sev === "info" ? "info" : "muted";
    return el("span", { class: "dot " + cls });
  }

  function row(rule) {
    var sleeping = !rule.hits;
    var sub = rule.code
            + " · порог " + fmtThr(rule.threshold)
            + " · " + (rule.score != null ? "глубина " + rule.score.toFixed(2) : "спит");
    var right = el("div", { class: "right" }, [
      el("span", { class: "cell hits" }, sleeping ? "0" : fmtInt(rule.hits)),
      el("span", { class: "cell money" }, sleeping ? "" : fmtMoney(rule.money))]);
    var lvls = rule.levels || [];
    var lvl = lvls.length
      ? el("span", { class: "lvl" },
          lvls.map(function (l) { return LEVEL_RU[l] || l; }).join(" · "))
      : null;
    var domChip = rule.domain
      ? el("span", { class: "dom-chip" }, DOMAIN_LABEL[rule.domain] || rule.domain)
      : null;
    var meta = (domChip || lvl) ? el("div", { class: "rowmeta" }, [domChip, lvl]) : null;
    var r = el("div", { class: "row" + (sleeping ? " sleep" : "") }, [
      severityDot(sleeping ? null : heaviestSev(rule)),
      el("div", { class: "grow" }, [
        el("div", { class: "name" }, rule.title || rule.code),
        el("div", { class: "sub" }, sub)]),
      meta,
      right,
      el("span", { class: "tgl" + (rule.enabled ? "" : " off") }, el("i", {})),
      el("i", { class: "ti ti-chevron-down chev" })]);
    r.addEventListener("click", function () { toggleTicket(r, rule); });
    return r;
  }

  // ── Тикет ───────────────────────────────────────────────────────────────
  function token(text, cls) {
    return el("span", { class: "tok " + (cls || "") }, text);
  }

  function pipelineLine(items) {
    return el("div", { class: "pipe-line" }, items.map(function (x) {
      if (typeof x === "string") return token(x);
      return x;
    }));
  }

  function chipNode(c) {                 // лист: op / разделитель / число / фича
    if (c.role === "op" || c.role === "paren")  // paren здесь = «,» между аргументами
      return el("span", { class: "pipe-op" }, c.text);
    if (c.role === "value") {
      var v = token(c.text, "num");
      if (c.desc) { v.setAttribute("data-desc", c.desc); v.setAttribute("title", c.desc); }
      return v;
    }
    var a = { class: "tok" };            // feature
    if (c.code) { a["data-code"] = c.code; a["data-label"] = c.text; }
    if (c.desc) a["data-desc"] = c.desc;
    if (c.unit) a["data-unit"] = c.unit;
    return el("span", a, c.text);
  }

  // Функция-применение рисуется РАМКОЙ-контейнером (заголовок fx + тело-аргументы),
  // а не `имя(...)`: скобки самой функции становятся границами рамки. Инфикс остаётся
  // инлайн; непарные «инфиксные» скобки рисуются символом. Вложенность → рамка в рамке.
  // Реконструкция вложенности из плоского списка токенов render_ast_chips
  // (контракт бэкенда не меняем): за токеном func всегда идёт его «(» … парная «)».
  function renderChips(chips) {
    chips = chips || [];
    var i = 0;
    function group(closeOnParen) {       // собрать узлы до «)» текущего уровня
      var out = [];
      while (i < chips.length) {
        var c = chips[i];
        if (c.role === "paren" && c.text === ")") {
          i += 1;
          if (closeOnParen) return out;  // съели парную «)» — рамка/скобка закрыта
          continue;                      // непарная «)» — пропустить
        }
        if (c.role === "func") {
          i += 1;                        // съесть func
          var boxed = chips[i] && chips[i].role === "paren" && chips[i].text === "(";
          if (boxed) i += 1;             // съесть «(» — это граница рамки
          out.push(el("span", { class: "fn-group", "data-fn": c.text, "data-desc": c.desc || null }, [
            el("span", { class: "fn-head" }, el("i", { class: "ti ti-math-function" })),
            el("span", { class: "fn-body" }, group(boxed))]));
          continue;
        }
        if (c.role === "paren" && c.text === "(") {
          i += 1;                        // инфиксная группировка → скобки символом
          out.push(el("span", { class: "paren-group" },
            [el("span", { class: "pipe-op" }, "(")]
              .concat(group(true), [el("span", { class: "pipe-op" }, ")")])));
          continue;
        }
        out.push(chipNode(c));
        i += 1;
      }
      return out;
    }
    return pipelineLine(group(false));
  }

  function formulaBlock(rule) {
    return el("div", { class: "xb pipe-card formula" }, [
      el("div", { class: "k" }, "формула правила"),
      renderChips(rule.formula_chips)]);
  }

  // Строка применимости «применяется при …» — гейт правила (рендер предиката).
  // Рисуется ТОЛЬКО когда бэкенд отдал непустой gate_chips (предикат трогает фичи
  // помимо symptom-метрики). Полноширинная строка под блоками механики.
  function gateBlock(rule) {
    if (!rule.gate_chips || !rule.gate_chips.length) return null;
    return el("div", { class: "mech-gate" }, [
      el("span", { class: "mech-gate-k" }, "применяется при"),
      renderChips(rule.gate_chips)]);
  }

  function conditionBlock(rule) {
    var cuts = (rule.bands && rule.bands.cuts) || [];
    var ml = rule.bands && rule.bands.metric_label;
    // metric_label есть → метрика-коэффициент (cost_skew): порог = голое число (1, 2),
    // а не % (fmtCondValue трактует ≤1.5 как проценты — для «× нормы» это ложь). Подпись несёт единицу.
    var fmtVal = ml ? function (v) { return nf1.format(v); } : fmtCondValue;
    var rows = cuts.map(function (c) {
      var isLt = ("lt" in c);
      var cmp = cuts.length === 1 && rule.condition_op ? (OP_RU[rule.condition_op] || rule.condition_op)
              : isLt ? "<" : ">";
      var val = isLt ? c.lt : c.gt;
      var scls = c.severity === "critical" ? "crit"
               : c.severity === "warning" ? "warn" : "info";
      return pipelineLine([
        el("span", { class: "pipe-op" }, cmp),
        token(fmtVal(val), "num"),
        el("span", { class: "pipe-op" }, "→"),
        el("span", { class: "sev " + scls }, SEV_RU[c.severity] || c.severity)]);
    });
    if (!rows.length) rows = [pipelineLine([token("порог не задан", "muted")])];
    var head = [el("div", { class: "k" }, "условие")];
    if (ml) head.push(el("div", { class: "cond-metric muted" }, ml));
    return el("div", { class: "xb pipe-card condition" }, head.concat(rows));
  }

  function moneyBlock(rule) {
    var body = (rule.value_chips && rule.value_chips.length)
      ? renderChips(rule.value_chips)
      : pipelineLine([token("—", "muted")]);
    return el("div", { class: "xb pipe-card" }, [
      el("div", { class: "k" }, "деньги на столе"),
      body]);
  }

  function scoreBlock(rule) {
    var body = (rule.score_chips && rule.score_chips.length)
      ? renderChips(rule.score_chips)
      : pipelineLine([token("глубина не определена", "muted")]);
    return el("div", { class: "xb pipe-card" }, [
      el("div", { class: "k" }, "глубина симптома"),
      body]);
  }

  function textBlock(rule) {
    var nodes = [];
    if (rule.description) nodes.push(el("p", {}, rule.description));
    if (rule.formula) nodes.push(el("p", {}, [el("b", {}, "Как посчитано: "), rule.formula]));
    if (rule.rationale) nodes.push(el("p", {}, [el("b", {}, "Зачем смотреть: "), rule.rationale]));
    if (!nodes.length) nodes.push(el("p", { class: "muted" }, "Описание правила пока не задано."));
    return el("div", { class: "sec rule-text" }, [
      el("div", { class: "seclbl" }, "описание"),
      el("div", { class: "ticket-text" }, nodes)]);
  }

  // Бар срабатываний по тяжести: красный=critical, жёлтый=warning (доли от hits).
  // Серого нет — info-остаток виден как пустой трек бара (фон --hair).
  function sevBar(rule) {
    var s = rule.sev_counts || {};
    var hits = rule.hits || 0;
    var obs = rule.observations || hits;          // знаменатель: все наблюдения
    var crit = s.critical || 0, warn = s.warning || 0, info = s.info || 0;
    var success = Math.max(0, obs - hits);         // не сработало = успешное наблюдение
    var segs = [];
    function seg(n, color) {
      if (obs && n)
        segs.push(el("i", { style: "width:" + (n / obs * 100) + "%;background:" + color }));
    }
    seg(crit, "var(--crit)");
    seg(warn, "var(--warn)");
    seg(info, "var(--info)");
    seg(success, "var(--muted)");
    var title = obs
      ? crit + " красных · " + warn + " жёлтых · " + success + " успешных"
      : null;
    var bar = el("span", { class: "bar seg", title: title }, segs);
    var lvls = rule.levels || [];
    var denomWord = lvls.length === 1 ? (LEVEL_RU[lvls[0]] || lvls[0]) : "наблюдений";
    var numText = obs ? (fmtInt(hits) + " из " + fmtInt(obs) + " " + denomWord) : fmtInt(hits);
    var vrow = el("div", { class: "vrow" }, [bar, el("span", { class: "num" }, numText)]);
    return el("div", { class: "stat" }, [el("div", { class: "k" }, "срабатываний"), vrow]);
  }

  function statBar(label, fillPct, fillColor, num, titleAttr) {
    var vrow;
    if (fillPct != null) {
      var bar = el("span", { class: "bar", title: titleAttr || null },
        el("i", { style: "width:" + fillPct + "%;background:" + fillColor }));
      vrow = el("div", { class: "vrow" }, [bar, el("span", { class: "num" }, num)]);
    } else {
      vrow = el("div", { class: "vrow" }, el("span", { class: "num" }, num));
    }
    return el("div", { class: "stat" }, [el("div", { class: "k" }, label), vrow]);
  }

  var _VIAB_DOT  = { ok: "act-dot-ok", weak: "act-dot-weak", futile: "act-dot-futile" };
  var _VIAB_CHIP = { ok: "act-fchip-green", weak: "act-fchip-yellow", futile: "act-fchip-muted" };

  function viabRow(level, formula, count) {
    return el("div", { class: "act-formula-row" }, [
      el("span", { class: "act-row-dot " + (_VIAB_DOT[level] || "act-dot-futile") }),
      el("span", { class: "act-row-lbl" }, "рычаг:"),
      el("span", { class: "act-fchip " + (_VIAB_CHIP[level] || "act-fchip-muted") }, formula),
      el("span", { class: "act-row-arr" }, "→"),
      el("span", { class: "act-row-cnt" }, fmtInt(count))
    ]);
  }

  function buildActExpand(a) {
    var leftRows = [];

    // Filter row
    var awText = a.applicable_when_text || "—";
    leftRows.push(
      el("div", { class: "act-formula-row" }, [
        el("span", { class: "act-row-dot-ph" }),
        el("span", { class: "act-row-lbl" }, "фильтр:"),
        el("span", { class: "act-fchip act-fchip-gray" }, awText),
        el("span", { class: "act-row-arr" }, "→"),
        el("span", { class: "act-row-cnt" }, fmtInt(a.eligible))
      ])
    );

    // Lever rows
    var vb = a.viability_breakdown || {};
    var fg = a.fired_guards || [];
    var hasLevers = fg.length > 0 || (a.ok_formula && vb.ok > 0);

    if (a.ok_formula && vb.ok > 0) {
      leftRows.push(viabRow("ok", a.ok_formula, vb.ok));
    }
    fg.forEach(function (g) {
      leftRows.push(viabRow(g.level, g.formula_text, g.count));
    });

    var colLeft  = el("div", { class: "act-col-left" }, leftRows);
    var colRight = el("div", { class: "act-col-right" }, [
      el("p", { class: "act-rec" }, a.recommendation_text || "")
    ]);

    var expandClass = "act-expand" + (hasLevers ? "" : " no-guards");
    return el("div", { class: expandClass }, [colLeft, colRight]);
  }

  function toggleActExpand(rowEl, a) {
    var actKey = a.code || a.label;
    var next = rowEl.nextElementSibling;
    if (next && next.classList && next.classList.contains("act-expand") &&
        next.getAttribute("data-actkey") === actKey) {
      next.remove();
      rowEl.classList.remove("open");
      return;
    }
    rowEl.classList.add("open");
    var expand = buildActExpand(a);
    expand.setAttribute("data-actkey", actKey);
    rowEl.parentNode.insertBefore(expand, rowEl.nextSibling);
  }

  function actlinkRow(a) {
    var costTxt = COST_LABEL[a.cost] || "";
    var confTxt = CONF_LABEL[a.confidence] || "";
    var metaParts = [];
    if (costTxt) metaParts.push(costTxt);
    if (confTxt) metaParts.push(el("span", { class: "actmeta-sep" }, "·"), confTxt);
    var chev = el("i", { class: "ti ti-chevron-right act-chev" });
    var row = el("div", { class: "actlink" }, [
      el("i", { class: "ti ti-bolt lead" }),
      el("span", { class: "t" }, [
        el("b", {}, a.label),
        el("span", {}, " · подходит " + fmtInt(a.eligible))
      ]),
      el("span", { class: "actspc" }),
      metaParts.length ? el("span", { class: "actmeta" }, metaParts) : null,
      chev
    ].filter(Boolean));
    row.addEventListener("click", function () { toggleActExpand(row, a); });
    return row;
  }

  function ticket(rule) {
    var mechKids = [
      el("div", { class: "mechhead" }, [
        el("div", { class: "eyebrow" }, "механика"),
        el("button", { class: "btn", disabled: "" },
          [el("i", { class: "ti ti-edit" }), "Редактировать"])]),
      el("div", { class: "blocks" }, [
        formulaBlock(rule), conditionBlock(rule), moneyBlock(rule), scoreBlock(rule)])];
    var gate = gateBlock(rule);
    if (gate) mechKids.push(gate);
    var mech = el("div", { class: "mech" }, mechKids);

    var summary = el("div", { class: "summary" }, [
      sevBar(rule),
      statBar("на столе", null, null, fmtMoney(rule.money)),
      statBar("глубина симптома", rule.score != null ? Math.round(rule.score * 100) : null,
              "var(--muted)", rule.score != null ? rule.score.toFixed(2) : "—")]);

    var acts = (rule.actions || []).filter(function (a) { return !a.sleeping; });
    var actNodes = acts.length
      ? acts.map(function (a) { return actlinkRow(a); })
      : [el("div", { class: "muted" }, "действий пока нет")];

    var details = el("div", { class: "details" }, [
      textBlock(rule),
      el("div", { class: "sec" }, [el("div", { class: "seclbl" }, "действия"),
        el("div", { class: "actrow" }, actNodes)]),
      el("div", { class: "sec" }, [el("div", { class: "seclbl" }, "кабинеты"),
        el("div", { class: "cabs" }, (rule.cabinets || []).map(function (c) {
          return el("span", { class: "cab-chip" }, c); }))])]);

    return el("div", { class: "ticket" },
      [mech, el("div", { class: "body" }, [summary, details])]);
  }

  // Функция-рамка (.fn-group) принципиально однострочна (nowrap, Срез 2 «fnbox»):
  // в узкой колонке .blocks она переполняет карточку. Усечение — СПРАВА НАЛЕВО по
  // листьям-чипам: режем текст самого правого чипа справа (потерянное → литерал «..»),
  // после каждого шага перемеряя; влезло — стоп. Чип ужат до голого «..», но всё ещё
  // не влезает → переходим к следующему слева. Так пока не влезет ИЛИ пока все чипы не
  // станут «..»; если и это не помогло — оставляем как есть (поведение «как сейчас»),
  // никакой логики сверх этого. Полный текст feature-чипа доступен в поповере через
  // нетронутый data-label; для не-feature чипа (число/оператор) кладём title как резерв.
  // Требует DOM (offsetWidth) → запускается ПОСЛЕ вставки тикета, не в renderChips.
  function clipOneFnGroup(group) {
    var avail = group.parentNode.clientWidth;
    if (!avail || group.offsetWidth <= avail) return;     // влезает — ничего не делаем
    var leaves = group.querySelectorAll(".tok, .pipe-op");
    for (var i = leaves.length - 1; i >= 0; i--) {
      var leaf = leaves[i];
      var full = leaf.textContent;
      if (full.length <= 2) continue;                     // короткий чип (оператор/скобка) не режем: «..» его не короче
      if (leaf.classList.contains("num")) continue;       // число (напр. 0.8) не режем — теряется значение
      if (!leaf.hasAttribute("data-code") && !leaf.hasAttribute("title"))
        leaf.setAttribute("title", full);                 // резерв для не-feature чипа
      var s = full;
      while (s.length && group.offsetWidth > avail) {
        s = s.slice(0, -1);
        leaf.textContent = s + "..";                      // обрезок + маркер (или голое «..»)
      }
      if (group.offsetWidth <= avail) return;             // влезло — стоп
    }
  }

  function clipFnGroups(root) {
    var groups = root.querySelectorAll(".fn-group");
    for (var i = 0; i < groups.length; i++) {
      // вложенную рамку отдельно не трогаем — её листья режутся в составе внешней
      if (groups[i].parentNode.closest && groups[i].parentNode.closest(".fn-group")) continue;
      clipOneFnGroup(groups[i]);
    }
  }

  function toggleTicket(rowEl, rule) {
    var chev = rowEl.querySelector(".chev");
    var next = rowEl.nextElementSibling;
    if (next && next.classList && next.classList.contains("ticket")) {
      next.remove();
      rowEl.classList.remove("open");
      if (chev) chev.className = "ti ti-chevron-down chev";
      return;
    }
    rowEl.classList.add("open");
    if (chev) chev.className = "ti ti-chevron-up chev";
    var tk = ticket(rule);
    rowEl.parentNode.insertBefore(tk, rowEl.nextSibling);
    clipFnGroups(tk);                                      // усечь переполненные рамки
  }

  // ── Сборка вида ─────────────────────────────────────────────────────────
  // Цикл значений фильтра уровня: "" (все) + уровни, реально присутствующие в
  // данных ТЕКУЩЕГО домена (если домен выбран). Data-driven — для пилота-
  // Коммерции это sku/category.
  function levelCycle() {
    if (!state.data) return [""];          // до загрузки данных — только «все уровни»
    var set = {};
    (state.data.domains || []).forEach(function (d) {
      if (state.domain && d.domain !== state.domain) return;
      (d.rules || []).forEach(function (r) {
        (r.levels || []).forEach(function (l) { set[l] = 1; });
      });
    });
    return [""].concat(Object.keys(set));
  }

  function visibleRules() {
    var out = [];
    (state.data.domains || []).forEach(function (dom) {
      if (state.domain && dom.domain !== state.domain) return;
      (dom.rules || []).forEach(function (r) { r.domain = r.domain || dom.domain; out.push(r); });
    });
    if (state.level) out = out.filter(function (r) {
      return (r.levels || []).indexOf(state.level) >= 0;
    });
    var q = state.query.trim().toLowerCase();
    if (q) out = out.filter(function (r) {
      return (r.title || "").toLowerCase().indexOf(q) >= 0
          || (r.code || "").toLowerCase().indexOf(q) >= 0;
    });
    out.sort(function (a, b) {
      if (state.sort === "money") return (b.money || 0) - (a.money || 0);
      return (b.hits || 0) - (a.hits || 0);
    });
    return out;
  }

  function renderKpis() {
    var box = document.getElementById("rules-kpis");
    box.replaceChildren.apply(box, kpis(state.data).map(function (kv) {
      return el("div", { class: "kpi" }, [
        el("div", { class: "k" }, kv[0]), el("div", { class: "v" }, kv[1])]);
    }));
  }

  function render() {
    if (!state.data) return;
    var rows = document.getElementById("rules-rows");
    var items = visibleRules();
    rows.replaceChildren();
    if (!items.length) {
      rows.append(el("div", { class: "note" }, "Нет правил под фильтром."));
      return;
    }
    items.forEach(function (r) { rows.append(row(r)); });
  }

  function cabinetFromUrl() {
    var m = /[?&]cabinet=([^&]+)/.exec(window.location.search);
    return m ? decodeURIComponent(m[1]) : "ozon:unix";
  }

  function load() {
    var cab = cabinetFromUrl();
    state.cabinet = cab;
    var sel = document.getElementById("rules-cabinet");
    sel.replaceChildren(cab.replace(":", " · "), el("i", { class: "ti ti-chevron-down" }));
    var rows = document.getElementById("rules-rows");
    rows.replaceChildren(el("div", { class: "note" }, "Загрузка…"));
    var url = "/v1/mp-cockpit/rules-observatory?cabinet=" + encodeURIComponent(cab);
    fetchTimeout(url, 60000).then(function (r) {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.json();
    }).then(function (data) {
      state.data = data;
      renderKpis();
      syncNavBtn("level");
      render();
    }).catch(function (e) {
      rows.replaceChildren(el("div", { class: "note" }, "Ошибка загрузки: " + e.message));
    });
  }

  // Список кабинетов для попапа переключения — якорь на commerce (владелец
  // 2026-07-16): без бэкенд-правок, /v1/mp-cockpit/cabinets домен-скопирован.
  function loadCabinets() {
    fetchTimeout("/v1/mp-cockpit/cabinets?domain=commerce", 60000).then(function (r) {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.json();
    }).then(function (data) {
      state.cabinetList = (data.cabinets || []).map(function (c) { return c.cabinet; });
    }).catch(function () { state.cabinetList = []; });
  }

  function fchipPopover() {
    var pop = document.getElementById("fchip-pop");
    if (!pop) return;
    function hide() { pop.classList.remove("show"); pop.setAttribute("aria-hidden", "true"); }
    function show(chip) {
      var kids;
      if (chip.hasAttribute("data-fn")) {
        var fdesc = chip.getAttribute("data-desc");
        kids = [
          el("div", { class: "ttl" }, chip.getAttribute("data-fn")),
          el("div", { class: "cod" }, [el("i", { class: "ti ti-math-function" }), "функция"])];
        if (fdesc) kids.push(el("div", { class: "dsc" }, fdesc));
      } else {
        var code = chip.getAttribute("data-code");
        var desc = chip.getAttribute("data-desc");
        var unit = chip.getAttribute("data-unit");
        kids = [
          el("div", { class: "ttl" }, chip.getAttribute("data-label") || chip.textContent),
          el("div", { class: "cod" }, [el("i", { class: "ti ti-database" }),
            el("code", {}, code), "код фичи"])];
        if (desc) kids.push(el("div", { class: "dsc" }, desc));
        if (unit) kids.push(el("div", { class: "unt" }, unit));
      }
      pop.replaceChildren.apply(pop, kids);
      pop.classList.add("show");
      pop.setAttribute("aria-hidden", "false");
      var r = chip.getBoundingClientRect();
      var pr = pop.getBoundingClientRect();
      var left = Math.max(8, Math.min(r.left, window.innerWidth - pr.width - 8));
      var top = r.top - pr.height - 8;
      if (top < 8) top = r.bottom + 8;
      pop.style.left = left + "px";
      pop.style.top = top + "px";
    }
    document.addEventListener("mouseover", function (e) {
      var chip = e.target.closest && e.target.closest(".tok[data-code], .fn-group[data-fn]");
      if (chip) show(chip);
    });
    document.addEventListener("mouseout", function (e) {
      var chip = e.target.closest && e.target.closest(".tok[data-code], .fn-group[data-fn]");
      if (chip) hide();
    });
  }

  function navOptions(kind) {
    if (kind === "domain")
      return [{ value: "", label: "все домены" }].concat(
        (window.DOMAIN_MANIFEST || []).map(function (d) {
          return { value: d.key, label: d.label }; }));
    if (kind === "level")
      return levelCycle().map(function (l) {
        return { value: l, label: l ? (LEVEL_RU[l] || l) : "все уровни" }; });
    if (kind === "cabinet")
      return state.cabinetList.map(function (c) {
        return { value: c, label: c.replace(":", " · ") }; });
    return [{ value: "hits", label: "срабатывания" }, { value: "money", label: "деньги" }];
  }

  var NAV = {
    domain: { icon: "ti-category-2", get: function () { return state.domain; },
              set: function (v) { state.domain = v; state.level = ""; } },
    level:  { icon: "ti-stack-2",    get: function () { return state.level; },
              set: function (v) { state.level = v; } },
    sort:   { icon: "ti-arrows-sort", get: function () { return state.sort; },
              set: function (v) { state.sort = v; } },
    cabinet: { icon: "ti-building-store", get: function () { return state.cabinet; },
               set: function (v) {
                 var q = new URLSearchParams(location.search);
                 q.set("cabinet", v);
                 history.replaceState(null, "", location.pathname + "?" + q.toString());
               } }
  };
  function navLabel(kind) {
    var cur = NAV[kind].get();
    var opts = navOptions(kind);
    for (var i = 0; i < opts.length; i++) if (opts[i].value === cur) return opts[i].label;
    return opts[0].label;
  }
  function syncNavBtn(kind) {
    var btn = document.getElementById("nav-" + kind);
    btn.querySelector(".lbl").textContent = navLabel(kind);
    var active = kind === "sort" ? false : !!NAV[kind].get();
    btn.classList.toggle("on", active);
  }

  function navPopover() {
    var pop = document.getElementById("nav-pop");
    var openKind = null;
    function close() { pop.classList.remove("show"); openKind = null; }
    function open(kind, btn) {
      openKind = kind;
      var cur = NAV[kind].get();
      var opts = navOptions(kind);
      if (kind === "cabinet" && !opts.length) {
        // Список кабинетов ещё не пришёл (клик до резолва loadCabinets) или
        // запрос упал — пустой попап без единой опции не даёт понять пользователю,
        // что происходит; показать заметку вместо тишины.
        pop.replaceChildren(el("button", { class: "nav-opt disabled", disabled: "disabled" },
          "Загрузка кабинетов…"));
        pop.classList.add("show");
        var er = btn.getBoundingClientRect();
        var epr = pop.getBoundingClientRect();
        pop.style.left = Math.max(8, Math.min(er.left, window.innerWidth - epr.width - 8)) + "px";
        pop.style.top = (er.bottom + 6) + "px";
        return;
      }
      pop.replaceChildren.apply(pop, opts.map(function (o) {
        var b = el("button", { class: "nav-opt" + (o.value === cur ? " sel" : "") }, o.label);
        b.addEventListener("click", function (e) {
          e.stopPropagation();
          NAV[kind].set(o.value);
          close();
          // cabinet — смена кабинета данные не фильтрует, а требует их
          // заново с бэкенда (как app.js::initSelector), не локальный render().
          if (kind === "cabinet") { load(); return; }
          syncNavBtn("domain"); syncNavBtn("level"); syncNavBtn("sort");
          render();
        });
        return b;
      }));
      pop.classList.add("show");
      var r = btn.getBoundingClientRect();
      var pr = pop.getBoundingClientRect();
      pop.style.left = Math.max(8, Math.min(r.left, window.innerWidth - pr.width - 8)) + "px";
      pop.style.top = (r.bottom + 6) + "px";
    }
    ["domain", "level", "sort"].forEach(function (kind) {
      var btn = document.getElementById("nav-" + kind);
      btn.addEventListener("click", function (e) {
        e.stopPropagation();
        if (openKind === kind) { close(); return; }
        open(kind, btn);
      });
    });
    // Триггер кабинета — #rules-cabinet, не в семье nav-<kind> id (живёт в
    // шапке .controls, не в тулбаре фильтров) — тот же open/close, отдельная
    // регистрация вместо id-соглашения "nav-" + kind.
    var cabBtn = document.getElementById("rules-cabinet");
    cabBtn.addEventListener("click", function (e) {
      e.stopPropagation();
      if (openKind === "cabinet") { close(); return; }
      open("cabinet", cabBtn);
    });
    document.addEventListener("click", function () { if (openKind) close(); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && openKind) close(); });
  }

  document.addEventListener("DOMContentLoaded", function () {
    var search = document.getElementById("rules-search");
    search.addEventListener("input", function () { state.query = search.value; render(); });
    navPopover();
    syncNavBtn("domain"); syncNavBtn("level"); syncNavBtn("sort");
    load();
    loadCabinets();
    fchipPopover();
  });
})();
