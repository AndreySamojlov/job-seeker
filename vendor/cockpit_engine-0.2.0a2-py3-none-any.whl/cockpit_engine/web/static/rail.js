"use strict";

// rail.js — общий движок правой панели навигации отчёта (task-main-96, epic-main-21).
// Доктрина унификации, ось 2: домен влияет на панель ТОЛЬКО через
// window.DOMAIN_MANIFEST (список доменов, domains-boot.js) и MODULE_REGISTRY
// (оглавление, module-registry.js через tocEntries/signalBadgeCount) — ни одного
// доменного имени и ни одного литерального списка глав в этом файле нет и не будет
// (гейт — tests/test_web_static.py). Секция «Домены» рендерится существующим
// renderDomainSwitcher (app.js) в контейнер #domain-switcher — тот код уже
// домен-нейтрален (читает DOMAIN_MANIFEST), дублировать его здесь незачем.
//
// Строковые функции ниже исполнимы в Node без document (тот же приём, что
// module-registry.js) — DOM-склейка вынесена в отдельные тонкие функции под
// window-гардом внизу файла.

// --- секция «Данные»: декларативный список полей, НЕ 4 захардкоженных блока в
// index.html (задача task-main-96). pillId сохраняет id категории и месяца,
// которые используют app.js и shared.js через getElementById. Общая панель
// остаётся одинаковой во всех доменах и кабинетах.
const RAIL_FILTERS = [
  { key: "cabinet",  label: "Кабинет",   pillId: "cabinet-pill",   selectId: "cabinet-select",  valId: "cabinet-val" },
  { key: "category", label: "Категория", pillId: "category-pill",  picker: true, valId: "category-val" },
  { key: "month",    label: "Месяц",     pillId: "month-selector", selectId: "month-select",    valId: "month-val" },
];

function _esc(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function _railFilterField(f) {
  if (f.picker) {
    return '<div class="rail-field category-picker-host" id="' + f.pillId + '" title="' + _esc(f.label) + '">' +
      '<span class="rail-field-lbl">' + _esc(f.label) + '</span>' +
      '<button id="category-trigger" class="category-trigger" type="button" aria-haspopup="dialog" aria-expanded="false"><span class="rail-field-val" id="' + f.valId + '">Все категории</span><span class="rail-field-arr" aria-hidden="true">▾</span></button>' +
      '<div id="category-picker" class="category-picker" role="dialog" aria-label="Выбор категорий" hidden></div>' +
    '</div>';
  }
  return '<div class="rail-field" id="' + f.pillId + '" title="' + _esc(f.label) + '">' +
    '<span class="rail-field-lbl">' + _esc(f.label) + '</span>' +
    '<span class="rail-field-val" id="' + f.valId + '"></span>' +
    '<span class="rail-field-arr" aria-hidden="true">▾</span>' +
    '<select id="' + f.selectId + '"></select>' +
  '</div>';
}

// renderRailFiltersHTML() → строка секции «Данные» (все поля из RAIL_FILTERS).
function renderRailFiltersHTML() {
  return RAIL_FILTERS.map(_railFilterField).join("");
}

// --- секция «Разделы»: оглавление из MODULE_REGISTRY.tocEntries(payload) ----------
// badgeCount — bare-число критических сигналов ТОЛЬКО у одного конкретного пункта
// (спека §Бейджи, якорь ниже: ноль -> без бейджа, во время загрузки -> бейджей нет
// вовсе — вызывающая сторона просто не даёт badgeCount при loading). Единственная
// строковая привязка к конкретному якорю канона — это НЕ литеральный список глав
// (тот приходит из entries), а точечная декларация "куда класть бейдж", прямо
// описанная спекой; список/порядок/заголовки — целиком из tocEntries().
const _BADGE_ANCHOR_ID = "block-signals";

function renderRailTocHTML(entries, badgeCount) {
  return '<ol class="rail-toc">' + entries.map(function (e, i) {
    const showBadge = e.id === _BADGE_ANCHOR_ID && typeof badgeCount === "number" && badgeCount > 0;
    const badge = showBadge ? '<span class="rail-badge">' + badgeCount + '</span>' : "";
    return '<li><a href="#' + _esc(e.id) + '">' +
      '<span class="rail-toc-n">' + (i + 1) + '</span>' +
      '<span class="rail-toc-t">' + _esc(e.title) + '</span>' + badge +
    '</a></li>';
  }).join("") + '</ol>';
}

// ---------------------------------------------------------------------------------
// DOM-склейка (браузер). Гарды на отсутствующие узлы — rail.js подключён только в
// главной странице отчёта; офлайн-демо-страницы и служебные страницы его не грузят
// и хостов панели не несут (вне скоупа задачи, спека «Соседние страницы»).

function renderRailFilters() {
  const host = document.getElementById("rail-filters");
  if (host) host.innerHTML = renderRailFiltersHTML();
}

// renderRailToc(payload) — вызывается из renderReport (shared.js) на каждую загрузку
// отчёта: набор экстр (см. module-registry.js) и бейдж зависят от payload.
function renderRailToc(payload) {
  const host = document.getElementById("rail-toc-host");
  if (!host) return;
  if (typeof MODULE_REGISTRY === "undefined" || typeof tocEntries !== "function") return;
  const entries = tocEntries(MODULE_REGISTRY, payload);
  // Бейдж считает сущности ДЕФОЛТНОГО уровня (module-registry.js, блокер 5) —
  // "дефолтный" в смысле signals-table.js: DOMAIN.levels[0]. DOMAIN — глобаль
  // shared.js; к моменту этого вызова (renderReport зовёт renderRailToc ПОСЛЕ
  // DOMAIN = cfg) она уже указывает на активный домен.
  const levels = (typeof DOMAIN !== "undefined" && DOMAIN && Array.isArray(DOMAIN.levels))
    ? DOMAIN.levels : null;
  const badgeCount = (typeof signalBadgeCount === "function") ? signalBadgeCount(payload, levels) : null;
  host.innerHTML = renderRailTocHTML(entries, badgeCount);
  // task-main-97: renderSkeleton (module-registry.js) только что пересоздал .block-узлы
  // #pad, а строка выше — ссылки оглавления. Наблюдатель и обработчик клика обязаны
  // ссылаться на СВЕЖИЕ узлы — пересобираем на каждый вызов (renderRailToc зовётся на
  // каждую загрузку отчёта, и на путь ошибки showEmpty — оба места сеют одинаковый
  // набор блоков через renderSkeleton).
  //
  // restoreRailScrollAnchorOnce() ЗДЕСЬ НЕ ЗОВЁТСЯ (найдено CDP-верификацией, было
  // до фикса): renderRailToc вызывается из renderReport (shared.js) СРАЗУ ПОСЛЕ
  // renderSkeleton, но ДО renderKpiCards/renderCharts/renderSignals — на этот момент
  // #kpi/#charts-host/#signals ещё ПУСТЫЕ узлы (скелет резервирует их без содержимого,
  // module-registry.js), документ короче своей финальной высоты в разы. Скролл к якорю
  // на этом кадре промахивается мимо итоговой позиции блока. Restore зовётся ПОСЛЕ
  // полного renderReport (и из showEmpty на пути ошибки) — см. shared.js.
  _wireRailTocClicks(host);
  _setupRailTocObserver();
}

// clearRailToc() — во время загрузки бейджей нет вовсе (спека §Бейджи), не только
// нулей: вызывается из setLoading(true) (shared.js), пункты остаются, бейдж гасится.
function clearRailToc() {
  const host = document.getElementById("rail-toc-host");
  if (!host) return;
  host.querySelectorAll(".rail-badge").forEach(function (b) { b.remove(); });
}

// ================================================================================
// Каркас прокрутки: подсветка активной главы, якорь в адресе, восстановление позиции
// (task-main-97, epic-main-21, спека §Модель прокрутки/§Оглавление/§Доступность).
//
// Модель: страница не прокручивается вовсе — единственная скроллящаяся область
// отчёта — #sheet-scroll (index.html). renderSkeleton (module-registry.js)
// ПЕРЕСОЗДАЁТ .block-узлы внутри неё на каждую загрузку отчёта (pad.innerHTML =
// renderSkeleton(...), shared.js) — наблюдатель НЕ переживает такой рендер, поэтому
// пересобирается в _setupRailTocObserver на каждый вызов renderRailToc (тот и так
// зовётся на каждую загрузку — см. выше).
//
// То, что здесь проверяется E2E-скриншотом/браузерным измерением, а НЕ Node-гейтом
// (в этом браузере нет DOM: window.matchMedia/IntersectionObserver/scrollIntoView
// не исполнимы без document) — сама подсветка при реальной прокрутке и реальная
// неподвижность рамки. Гейты test_web_static.py проверяют ТОЛЬКО текст источника:
// что механизмы (IntersectionObserver/scrollIntoView/replaceState/подавление на
// время программной прокрутки/reduced-motion) присутствуют и стоят в нужных местах.

let _railTocObserver = null;        // пересобирается в _setupRailTocObserver
let _railScrollSuppressed = false;  // на время программной прокрутки наблюдатель молчит
let _railInitialAnchorDone = false; // якорь из URL восстанавливается РОВНО один раз

// Порог распускания каркаса (task-main-98, спека §Модель прокрутки): ЧИСЛО ОБЯЗАНО
// совпадать с @media (max-width:1080px) в styles.css — тесты сверяют оба места.
// Ниже порога корень IntersectionObserver и корень прокрутки — то #sheet-scroll
// (широкий экран), то вьюпорт/документ (узкий, каркас распущен): в проекте до этого
// эпика не было НИ ОДНОГО слушателя resize/matchMedia (риск спеки), поэтому
// пересборка ниже — нетто-новый код без соседнего образца.
const RAIL_NARROW_QUERY = "(max-width:1080px)";

// Высота липкой полосы панели на узком экране (ревью-блокер 2, фаза 2-3 эпика):
// ЧИСЛО ОБЯЗАНО совпадать с max-height .rail и scroll-margin-top #pad .block внутри
// @media(max-width:1080px) в styles.css — тесты сверяют все три места. Полоса —
// position:sticky сверху (styles.css), физически закрывает столько же вьюпорта,
// сколько её max-height: без учёта этой величины и scrollIntoView({block:"start"}),
// и полоса детекции IntersectionObserver целятся в область, часть которой на самом
// деле скрыта под полосой (замер на 900×800: заголовок главы на −4px, ~220px
// содержимого под полосой; активной становится невидимая глава).
const RAIL_NARROW_STICKY_H = 260;

function _railIsNarrow() {
  return typeof window !== "undefined" && typeof window.matchMedia === "function" &&
    window.matchMedia(RAIL_NARROW_QUERY).matches;
}

// Корень прокрутки: #sheet-scroll на широком экране (единственная прокручиваемая
// область каркаса, task-main-97), document.scrollingElement на узком (каркас
// распущен — страница прокручивается целиком, styles.css @media 1080px). Общая
// точка для scrollReportToBlock и _setupRailTocObserver — оба обязаны сходиться
// в одном и том же корне на одной и той же ширине экрана.
function _railScrollRoot() {
  if (typeof document === "undefined") return null;
  if (_railIsNarrow()) return document.scrollingElement || document.documentElement || null;
  return document.getElementById("sheet-scroll");
}

function _railPrefersReducedMotion() {
  return typeof window !== "undefined" && typeof window.matchMedia === "function" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

// Доскроллили до конца прокручиваемой области -> активна последняя глава (спека
// §Оглавление): короткая последняя глава иначе никогда не станет "самой видимой"
// ни при каком threshold IntersectionObserver'а.
function _railScrolledToEnd(scroller) {
  return scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 2;
}

function _setRailTocActive(id) {
  const host = document.getElementById("rail-toc-host");
  if (!host) return;
  host.querySelectorAll(".rail-toc a.on").forEach(function (a) {
    a.classList.remove("on"); a.removeAttribute("aria-current");
  });
  if (!id) return;
  const link = host.querySelector('.rail-toc a[href="#' + id + '"]');
  if (link) { link.classList.add("on"); link.setAttribute("aria-current", "true"); }
}

// scrollReportToBlock(id) — единственная точка входа в программную прокрутку отчёта
// (клик по оглавлению + восстановление якоря из URL). Подавляет наблюдатель на время
// анимации (спека §Оглавление: "иначе подсветка пробегает промежуточные пункты").
// prefers-reduced-motion или opts.instant -> мгновенный прыжок, не smooth.
// _railScrollRoot() (не жёстко "sheet-scroll", task-main-98): на узком экране каркас
// распущен, скроллится документ, а не #sheet-scroll — scrollIntoView сам находит
// актуального прокручиваемого предка, здесь только слушатель 'scrollend'/сторож.
//
// _railScrollEventTarget (мелочь ревью, найдено без живого браузера — вывод из
// спецификации, не CDP-замером): 'scroll'/'scrollend' вьюпорта летят в document, НЕ в
// document.scrollingElement (тот просто хранит scrollTop/scrollHeight, отдельный от
// document EventTarget) — слушатель на самом scroller'e на узком экране НЕ СРАБАТЫВАЛ
// БЫ никогда, подавление снималось бы только 700мс-фолбэком (комментарий раньше
// утверждал обратное). На широком scroller — сам #sheet-scroll, обычный элемент,
// событие летит в него же.
function _railScrollEventTarget(scroller) {
  if (typeof document !== "undefined" && scroller === document.scrollingElement) return document;
  return scroller;
}

function scrollReportToBlock(id, opts) {
  const scroller = _railScrollRoot();
  const target = document.getElementById(id);
  if (!scroller || !target) return;
  _railScrollSuppressed = true;
  const instant = !!(opts && opts.instant) || _railPrefersReducedMotion();
  target.scrollIntoView({ behavior: instant ? "auto" : "smooth", block: "start" });
  const releaseTarget = _railScrollEventTarget(scroller);
  let released = false;
  function release() {
    if (released) return;
    released = true;
    _railScrollSuppressed = false;
    releaseTarget.removeEventListener("scrollend", release);
  }
  releaseTarget.addEventListener("scrollend", release, { once: true });
  setTimeout(release, 700);  // фолбэк: 'scrollend' поддержан не в каждом браузере
}

// Клик по пункту оглавления (спека §Оглавление): перехватываем нативный переход по
// якорю (мгновенный, без подавления наблюдателя и без контроля над reduced-motion) —
// прокручиваем сами и сами пишем адрес через replaceState ("ссылку на главу можно
// отправить, историю не засоряет"). Делегирование на #rail-toc-host: узел не
// пересоздаётся между рендерами (меняется только innerHTML), обработчик вешается
// РОВНО один раз (см. _wireRailTocClicks).
function _railTocClickHandler(e) {
  const a = e.target.closest("a");
  if (!a) return;
  const id = (a.getAttribute("href") || "").replace(/^#/, "");
  if (!id) return;
  e.preventDefault();
  _setRailTocActive(id);
  scrollReportToBlock(id);
  history.replaceState(null, "", location.pathname + location.search + "#" + id);
}

function _wireRailTocClicks(host) {
  if (host.dataset.railTocWired) return;
  host.addEventListener("click", _railTocClickHandler);
  host.dataset.railTocWired = "1";
}

// _setupRailTocObserver() — (пере)собирает IntersectionObserver по СВЕЖИМ .block-узлам
// #pad и свежим ссылкам оглавления. Полоса детекции — верхние ~20% прокручиваемой
// области (root): активна ПОСЛЕДНЯЯ из глав, чей верхний край вошёл в полосу —
// устойчивее к разной высоте глав, чем наивный "максимальный intersectionRatio" (тот
// фаворитил бы короткие полностью видимые главы над длинными, где ratio физически не
// может достичь 1).
//
// task-main-98 (спека §Модель прокрутки, риск "два режима прокрутки"): корень — то
// #sheet-scroll (широкий экран), то вьюпорт (root:null, узкий — каркас распущен).
// Вызывающая сторона обязана пересобрать наблюдатель заново при пересечении порога
// 1080px (см. matchMedia-подписку ниже) — root у живого IntersectionObserver сменить
// нельзя, только пересоздать целиком.
function _setupRailTocObserver() {
  if (_railTocObserver) { _railTocObserver.disconnect(); _railTocObserver = null; }
  if (typeof IntersectionObserver === "undefined") return;
  const narrow = _railIsNarrow();
  const scroller = _railScrollRoot();
  const host = document.getElementById("rail-toc-host");
  if (!scroller || !host) return;
  const ids = Array.from(host.querySelectorAll(".rail-toc a"))
    .map(function (a) { return (a.getAttribute("href") || "").replace(/^#/, ""); })
    .filter(Boolean);
  const blocks = ids.map(function (id) { return document.getElementById(id); }).filter(Boolean);
  if (!blocks.length) return;
  // stickyOffset (ревью-блокер 2): на узком экране верхние RAIL_NARROW_STICKY_H
  // вьюпорта физически закрыты липкой полосой панели (position:sticky, styles.css) —
  // без сдвига полоса детекции считалась бы от НАСТОЯЩЕГО верха вьюпорта, а не от
  // видимой границы под полосой, и "активной" становилась глава, чей заголовок
  // скрыт под панелью (найдено анализом геометрии, тот же сдвиг нужен и scrollIntoView
  // — см. scroll-margin-top в styles.css). На широком экране офсет 0 — там нет
  // перекрывающей панели, #sheet-scroll не липкий.
  const stickyOffset = narrow ? RAIL_NARROW_STICKY_H : 0;
  const visibleH = Math.max(1, scroller.clientHeight - stickyOffset);
  const bandPx = Math.max(1, Math.round(visibleH * 0.2));
  const topMargin = -stickyOffset;
  const bottomMargin = bandPx + stickyOffset - scroller.clientHeight;  // отрицательный отступ снизу
  const intersecting = {};
  _railTocObserver = new IntersectionObserver(function (entries) {
    if (_railScrollSuppressed) return;
    entries.forEach(function (e) { intersecting[e.target.id] = e.isIntersecting; });
    if (_railScrolledToEnd(scroller)) { _setRailTocActive(ids[ids.length - 1]); return; }
    let activeId = null;
    for (let i = 0; i < ids.length; i++) if (intersecting[ids[i]]) activeId = ids[i];
    if (activeId) _setRailTocActive(activeId);
  }, {
    // root:null означает "вьюпорт" для IntersectionObserver — _railScrollRoot()
    // на узком экране возвращает document.scrollingElement (годится для
    // scrollTop/clientHeight/scrollHeight выше), но САМ documentElement как root
    // наблюдателя — не то же самое, что вьюпорт, поэтому здесь отдельная ветка.
    root: narrow ? null : scroller,
    rootMargin: topMargin + "px 0px " + bottomMargin + "px 0px",
    threshold: 0,
  });
  blocks.forEach(function (b) { _railTocObserver.observe(b); });
}

// Пересборка наблюдателя на пересечении порога 1080px (task-main-98, спека §Модель
// прокрутки, риск "два режима прокрутки"): без неё подсветка глав замирает, а клик по
// оглавлению целится в контейнер, который перестал скроллиться, после перетаскивания
// окна через порог. matchMedia("change") — единственный слушатель resize/matchMedia во
// всём проекте до этого среза; addListener — фолбэк для Safari<14 (не несёт
// addEventListener на MediaQueryList).
if (typeof window !== "undefined" && typeof window.matchMedia === "function") {
  const _railNarrowMql = window.matchMedia(RAIL_NARROW_QUERY);
  const _onRailNarrowChange = function () { _setupRailTocObserver(); };
  if (typeof _railNarrowMql.addEventListener === "function") {
    _railNarrowMql.addEventListener("change", _onRailNarrowChange);
  } else if (typeof _railNarrowMql.addListener === "function") {
    _railNarrowMql.addListener(_onRailNarrowChange);
  }
}

// restoreRailScrollAnchorOnce() — якорь из URL восстанавливается ПОСЛЕ загрузки
// отчёта (спека §Оглавление: "renderReport пересоздаёт узлы, нативная докрутка
// потерялась бы"), не на DOMContentLoaded. Вызывается из shared.js — из САМОГО КОНЦА
// renderReport (после renderKpiCards/renderCharts/renderSignals: скролл к якорю ДО
// заполнения этих узлов промахивается — они у скелета пустые, документ короче своей
// финальной высоты, см. CDP-находку в комментарии renderRailToc выше) и из showEmpty
// (путь ошибки — там сразу финальное состояние). Восстановление — РОВНО один раз за
// жизнь страницы: переключение домена/кабинета/фильтра само решает свою позицию
// прокрутки (спека §Позиция прокрутки, см. app.js switchDomain).
function restoreRailScrollAnchorOnce() {
  if (_railInitialAnchorDone) return;
  _railInitialAnchorDone = true;
  const id = (location.hash || "").replace(/^#/, "");
  if (!id) return;
  scrollReportToBlock(id, { instant: true });
  _setRailTocActive(id);
}

if (typeof window !== "undefined") {
  window.RAIL_FILTERS = RAIL_FILTERS;
  window.renderRailFiltersHTML = renderRailFiltersHTML;
  window.renderRailTocHTML = renderRailTocHTML;
  window.renderRailFilters = renderRailFilters;
  window.renderRailToc = renderRailToc;
  window.clearRailToc = clearRailToc;
  window.scrollReportToBlock = scrollReportToBlock;
  // _railScrollRoot (блокер 3, ревью фаза 2-3 эпика): switchDomain (app.js) должен
  // сбрасывать позицию прокрутки того контейнера, который реально скроллится сейчас
  // (то #sheet-scroll, то документ на узком экране), а не жёстко #sheet-scroll —
  // тот на узком экране уже не скролл-контейнер (см. styles.css, task-main-98),
  // scrollTop на нём всегда 0, страница молча остаётся где была.
  window._railScrollRoot = _railScrollRoot;
}
if (typeof module !== "undefined" && module.exports) {
  module.exports = { RAIL_FILTERS, renderRailFiltersHTML, renderRailTocHTML };
}
