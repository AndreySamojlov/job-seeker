"use strict";

// module-registry.js — канон-реестр 5 модулей-глав + генератор скелета.
//
// Доктрина «Код один — данные разные»: отчёт = 5 универсальных глав. Реестр —
// единственный источник структуры .pad; renderSkeleton(registry, payload) строит
// HTML-строку всех канон-глав (+ settlement-экстры) с заглушкой «Нет данных» там,
// где select(payload) вернул null. Чистая функция БЕЗ document/побочек — исполнима
// и в браузере (реальный рендер), и в Node (гейты). НЕ использует el()/core.js.
//
// select(payload, meta) — тонкий is-empty-предикат этого среза: truthy ⇒ «есть что
// рендерить» (движок домена наполнит узел), null ⇒ «глава пуста» ⇒ заглушка. Полная
// декларатизация данных — task-main-3 (kpi) / task-main-4 (таблицы).

// --- generic-предикаты пустоты (канон, домен-агностично) ------------------
function _hasEntityRows(payload) {
  const et = (payload && payload.entity_tables) || {};
  for (const level of Object.values(et)) {
    // axis:"time" (report/daily_table.py) -- бессигнальная дневная таблица,
    // не считается для главы «Что требует внимания» (task-gracious-hopper-854d26-5).
    if (level && level.axis === "time") continue;
    if (level && Array.isArray(level.rows) && level.rows.length) return true;
  }
  return false;
}

function _hasEligibleActions(payload) {
  const et = (payload && payload.entity_tables) || {};
  for (const level of Object.values(et)) {
    const rows = (level && Array.isArray(level.rows)) ? level.rows : [];
    for (const r of rows) {
      const acts = Array.isArray(r.actions) ? r.actions : [];
      for (const a of acts) if ((a.viability || "ok") !== "futile") return true;
    }
  }
  const dig = payload && payload.digest && Array.isArray(payload.digest.eligible_actions)
    ? payload.digest.eligible_actions : [];
  return dig.length > 0;
}

// «Сводка» непуста ТОЛЬКО когда есть текст ИИ. Прежде сюда же засчитывались
// digest.totals/signal_counts — на них shared.js клеил детерминированную
// «Автосводку» («Выполнение плана: X · покрытие плана: Y · сигналов: N»),
// то есть блок пересказывал цифры KPI и выдавал это за сводку. Генератора
// ИИ-текста в продукте сейчас нет (жил только в дормантном n8n+DeepSeek), и
// суррогат маскировал этот факт. Ось 3 доктрины: нет данных → честная
// заглушка «Нет данных», не подмена.
function _hasAiSummary(payload) {
  const st = payload && typeof payload.state_summary === "string" && payload.state_summary;
  const sb = payload && typeof payload.signals_brief === "string" && payload.signals_brief;
  return !!(st || sb);
}

// Срез по категории (epic-main-19): две ситуации, в которых цифру на срезе объяснить
// нельзя, и потому она НЕ показывается — заглушка «Нет данных», единый текст без
// диагноза (доктрина унификации §1.3). Признак приходит ДАННЫМИ из payload, рендер
// одинаков во всех гранях и доменах — ветвления по домену/грани здесь нет и не будет.
//   slice_unsupported — грань физически не умеет срез (предрасчитанный report_section);
//   empty_slice       — срез валиден, но пуст (не 404: канон-5 рисуется всегда, §6).
function _sliceBlocksNumbers(payload) {
  return !!(payload && (payload.slice_unsupported || payload.empty_slice));
}

// --- канон-реестр ----------------------------------------------------------
// Порядок = канонический порядок глав в .pad. select→null ⇒ заглушка.
// blockId (task-main-95, epic-main-21): якорь <div class="block" id="...">, тем же
// механизмом, что settlement-экстры (blockId, addExtra). Префикс "block-" ОБЯЗАТЕЛЕН:
// entry.id совпадает с entry.innerId для summary/kpi/signals/narrative (только charts
// отличается: innerId="charts-host"), и без префикса якорь блока столкнулся бы с id
// внутреннего контент-узла — document.getElementById(innerId) в shared.js/
// signals-table.js/chart-render.js поймал бы ПЕРВЫЙ узел с таким id в DOM-порядке
// (сам блок-обёртку, а не контент), молча ломая рендер домена. Якорь — публичный
// контракт адреса будущей панели-оглавления.
const MODULE_REGISTRY = [
  { id: "summary",     title: "Сводка",                innerId: "summary",
    blockId: "block-summary",
    // Текст ИИ пишет внешний n8n прямо в БД и среза не знает (спека §4) — на любом
    // активном срезе он про весь кабинет, поэтому не показывается.
    select: (p) => ((_hasAiSummary(p) && !(((p && p.meta && p.meta.category_selection) || {}).values || []).length)
                    ? true : null) },
  { id: "kpi",         title: "Итоги месяца",          innerId: "kpi",
    blockId: "block-kpi",
    innerClass: "kpi", select: (p) => (_sliceBlocksNumbers(p) ? null : true) },
  { id: "charts",      title: "Динамика",              innerId: "charts-host",
    blockId: "block-charts", headActionsId: "charts-head-act",
    select: (p) => (_sliceBlocksNumbers(p) ? null : true) },
  { id: "signals",     title: "Что требует внимания",  innerId: "signals",
    blockId: "block-signals",
    select: (p) => ((_hasEntityRows(p) && !_sliceBlocksNumbers(p)) ? true : null) },
  { id: "narrative",   title: "Приоритетные действия", innerId: "narrative",
    blockId: "block-narrative",
    select: (p) => ((_hasEligibleActions(p) && !_sliceBlocksNumbers(p)) ? true : null) },
];

// Экстра-главы домена. Движок их НЕ перечисляет: доменный <d>.js объявляет свой
// список через registerDomainExtras(key, [...]), а движок только раскладывает их
// по якорям. Так домен job-board получает механизм бесплатно, а движок остаётся
// без мёртвых веток чужих доменов (ось 2 доктрины унификации, срез E1).
// Их пустота управляется самим renderExtras домена (Т-счёт/матрица), поэтому select
// у экстр всегда truthy: скелет лишь резервирует заголовок+узел, домен наполняет.
const DOMAIN_EXTRAS = {};

function registerDomainExtras(key, extras) {
  DOMAIN_EXTRAS[key] = extras.slice();
}

// --- строковые хелперы (без document) --------------------------------------
function _esc(s) {
  return String(s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function _canonBlock(entry, payload) {
  const filled = entry.select(payload, (payload && payload.meta) || {}) !== null;
  const innerCls = entry.innerClass ? ' class="' + entry.innerClass + '"' : "";
  const inner = filled
    ? '<div' + innerCls + ' id="' + entry.innerId + '"></div>'
    : '<div' + innerCls + ' id="' + entry.innerId + '">' +
        '<div class="empty-slot">Нет данных</div></div>';
  // Слот действий (task-main-200, §3 спеки controls-design, риск 3): только
  // у записи с headActionsId (сегодня — "charts"/«Динамика»), рендерится
  // ПУСТЫМ внутри .h-sec сразу после заголовка — renderCharts (chart-
  // render.js) наполняет его на фронте, _canonBlock не знает о переключателе
  // уровней. Запись БЕЗ headActionsId — .h-sec ПОБАЙТОВО прежний один <div>,
  // общий шов для остальных четырёх канон-глав всех семи доменов не тронут.
  const headActions = entry.headActionsId
    ? '<div id="' + entry.headActionsId + '"></div>' : "";
  return '<div class="block" id="' + entry.blockId + '"><div class="h-sec">' +
         _esc(entry.title) + headActions + '</div>' + inner + '</div>';
}

function _extraBlock(entry, payload) {
  // Экстры гаснут вместе с каноном (epic-main-19): их наполняет renderExtras домена,
  // который среза не знает и нарисовал бы кабинетные суммы рядом с заглушками канона.
  const inner = _sliceBlocksNumbers(payload)
    ? '<div id="' + entry.innerId + '"><div class="empty-slot">Нет данных</div></div>'
    : '<div id="' + entry.innerId + '"></div>';
  return '<div class="block" id="' + entry.blockId + '">' +
         '<div class="h-sec">' + _esc(entry.title) + '</div>' + inner + '</div>';
}

// _collectExtras(payload) → { anchorId: [ex, ...] }. Единственное место, где решается
// КАКИЕ экстры применимы — renderSkeleton и tocEntries (task-main-96, ниже) читают
// ОДИН и тот же расчёт, чтобы оглавление панели не могло разойтись со скелетом .pad
// структурно (не только по значению title/anchor, но и по самому НАБОРУ экстр).
// Домен определяется по payload.meta.domain и разложен через registerDomainExtras
// (E1, ось 2 доктрины — движок не перечисляет домены сам). Директивных форм здесь
// БОЛЬШЕ НЕТ: ввод переехал с уровня domain-payload на уровень кабинета
// (epic-directive-input-cabinet-unification-1), рендер — в directive-form-engine.js
// по кабинетному реестру, скелет глав его не касается. Массив на якорь: несколько
// экстр могут указывать на один канон-id — порядок добавления решает визуальный
// порядок между ними.
function _collectExtras(payload) {
  const meta = (payload && payload.meta) || {};
  const extrasByAnchor = {};
  function addExtra(ex) {
    if (!extrasByAnchor[ex.after]) extrasByAnchor[ex.after] = [];
    extrasByAnchor[ex.after].push(ex);
  }
  for (const ex of DOMAIN_EXTRAS[meta.domain] || []) addExtra(ex);
  return extrasByAnchor;
}

// renderSkeleton(registry, payload) → строка ВНУТРЕННОСТИ .pad (без обёртки .pad).
// emitAfter рекурсивен на случай, если будущая экстра сама станет якорем для другой
// (сегодня не требуется).
function renderSkeleton(registry, payload) {
  const extrasByAnchor = _collectExtras(payload);

  function emitAfter(anchorId, parts) {
    const list = extrasByAnchor[anchorId];
    if (!list) return;
    for (const ex of list) {
      parts.push(_extraBlock(ex, payload));
      emitAfter(ex.id, parts);
    }
  }

  const parts = [];
  for (const entry of registry) {
    parts.push(_canonBlock(entry, payload));
    emitAfter(entry.id, parts);
  }
  parts.push('<div id="empty" class="empty" hidden></div>');
  return parts.join("\n");
}

// tocEntries(registry, payload) → [{id, title}, ...] — панель-оглавление (task-main-96,
// epic-main-21) читает ЭТО, не собственный список глав: порядок и набор идентичны
// renderSkeleton (тот же _collectExtras), только вместо HTML отдаём {якорь, заголовок}.
// ВСЕ записи (канон + экстры), включая пустые (select→null) — ось 3 доктрины
// унификации: глава без данных остаётся в оглавлении и ведёт к блоку с «Нет данных»,
// а не исчезает из списка.
function tocEntries(registry, payload) {
  const extrasByAnchor = _collectExtras(payload);

  function emitAfter(anchorId, out) {
    const list = extrasByAnchor[anchorId];
    if (!list) return;
    for (const ex of list) {
      out.push({ id: ex.blockId, title: ex.title });
      emitAfter(ex.id, out);
    }
  }

  const out = [];
  for (const entry of registry) {
    out.push({ id: entry.blockId, title: entry.title });
    emitAfter(entry.id, out);
  }
  return out;
}

// signalBadgeCount(payload, levels) — число СУЩНОСТЕЙ на уровне, который таблица
// сигналов открывает по умолчанию (task-main-96 §Бейджи; ревью-блокеры 1 и 5).
//
// Блокер 1: гейт бейджа — РОВНО тот же предикат, что решает пустоту главы
// «Что требует внимания» (entry.select канон-записи "signals", а не копия его
// условия) — иначе срез, который грань не умеет (slice_unsupported) или пустой
// срез (empty_slice), гасит главу заглушкой «Нет данных», а бейдж, посчитанный по
// сырому payload, продолжает показывать число рядом с ней. select→null ⇒ бейджа
// нет ВООБЩЕ (не «0» — спека: «ноль -> пункт есть, бейджа нет», null здесь то же
// самое отсутствие, по той же кнопке rail.js typeof-проверки).
//
// Блокер 5: НЕ сумма критических попаданий правил по ВСЕМ уровням (SKU с двумя
// критическими правилами не должен считаться дважды, а критические хиты
// category-уровня не должны прибавляться к SKU-уровню) — пользователь ищет число
// строк, которые реально увидит, открыв таблицу, а таблица по умолчанию открывает
// levels[0] (тот же порядок, что sigState.level = levels[0].key в signals-table.js,
// когда явный уровень ещё не выбран). levels — DOMAIN.levels; вызывающая сторона
// (rail.js, в браузере) читает его из глобали DOMAIN. Без levels (легаси/тестовый
// вызов без домена) -> null: не гадаем число, раз не знаем, какой уровень таблица
// откроет первым.
function signalBadgeCount(payload, levels) {
  const entry = MODULE_REGISTRY.find((e) => e.id === "signals");
  if (entry && entry.select(payload, (payload && payload.meta) || {}) === null) return null;

  const levelKey = Array.isArray(levels) && levels[0] && levels[0].key;
  if (!levelKey) return null;
  const et = (payload && payload.entity_tables) || {};
  const rows = (et[levelKey] && Array.isArray(et[levelKey].rows)) ? et[levelKey].rows : [];
  let n = 0;
  for (const r of rows) {
    const hits = r && r.rule_hits;
    if (hits && Object.values(hits).some((h) => h && h.severity === "critical")) n++;
  }
  return n;
}

if (typeof window !== "undefined") {
  window.MODULE_REGISTRY = MODULE_REGISTRY;
  window.renderSkeleton = renderSkeleton;
  window.registerDomainExtras = registerDomainExtras;
  window.tocEntries = tocEntries;
  window.signalBadgeCount = signalBadgeCount;
}
if (typeof module !== "undefined" && module.exports) {
  module.exports = { MODULE_REGISTRY, renderSkeleton, registerDomainExtras, DOMAIN_EXTRAS,
    tocEntries, signalBadgeCount, _canonBlock };
}
