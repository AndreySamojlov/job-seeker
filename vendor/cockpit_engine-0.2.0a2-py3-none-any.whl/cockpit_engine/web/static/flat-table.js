"use strict";

// flat-table.js — общий движок «простая таблица» (белый список рендер-примитивов,
// §3 доктрины). Колонки/строки по декларации. Домен-нейтрален: источник — аргументы.
//
// Контракт: renderFlatTable(container, columns, rows)
//   columns[]: { key, label, kind:"num"|"text", r(bool, right-align), metric(bool) }
//   rows[]: объекты, читаемые по column.key.
//
// Зависимости: el/nf0 из core.js. Числовые ячейки: 0/пропуск → «—» (бух-конвенция).
const _flatFmt0 = (n) =>
  (n === null || n === undefined || n === 0) ? "—" : nf0.format(n);

// Построить <table> по columns/rows (без контейнера — вызывающий кладёт в .tblwrap).
function buildFlatTable(columns, rows, options = {}) {
  const head = el("tr", {}, columns.map((c) => el("th", {
    style: "text-align:" + (c.r ? "right" : "left") + ";font-size:var(--fs-2xs);" +
           "text-transform:uppercase;letter-spacing:.04em;color:var(--muted);" +
           "padding:0 10px 8px" + (c.r ? "" : " 0") + ";border-bottom:1px solid var(--hair-strong);",
  }, c.label)));
  const body = rows.map((r) => el("tr", {}, columns.map((c) => {
    const v = r[c.key];
    const isNum = (c.kind === "num");
    const txt = isNum ? _flatFmt0(v) : (v == null || v === "" ? "—" : String(v));
    return el("td", {
      style: "text-align:" + (c.r ? "right" : "left") + ";padding:6px 10px" +
             (c.r ? "" : " 6px 0") + ";font-size:var(--fs-sm);white-space:nowrap;" +
             (isNum ? "font-variant-numeric:tabular-nums;" : "") +
             (c.metric ? "font-weight:600;" : ""),
    }, options.cellContent ? options.cellContent(c, r) : txt);
  })));
  return el("table", { style: "width:100%;border-collapse:collapse;" },
    [el("thead", {}, head), el("tbody", {}, body)]);
}

// Публичный вход: рендер простой таблицы в container (обёрнута в .tblwrap).
function renderFlatTable(container, columns, rows) {
  if (!container) return;
  container.replaceChildren(
    el("div", { class: "tblwrap" },
      buildFlatTable(columns || [], rows || [])));
}

if (typeof window !== "undefined") {
  window.renderFlatTable = renderFlatTable;
  window.buildFlatTable = buildFlatTable;
}
if (typeof module !== "undefined" && module.exports) {
  module.exports = { renderFlatTable, buildFlatTable };
}
