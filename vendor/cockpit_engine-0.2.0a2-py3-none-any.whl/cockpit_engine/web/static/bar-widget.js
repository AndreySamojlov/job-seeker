"use strict";

// bar-widget.js — общий примитив полосы-индикатора для табличных ячеек:
// трек + заливка (+ необязательная риска-порог). Домен передаёт только
// СМЫСЛ (цвет заливки, долю, позицию риски, текст подсказки) — форму
// рисует этот модуль (доктрина унификации, ось 2).
//
// Правка после живого ревью владельца: три места изобретали одну и ту же
// форму независимо, с разными константами и разным словарём цветов —
//   - score-бар "Что требует внимания" (signals-table.js): 7px/3px, три
//     severity-класса (crit/warn/ok);
//   - "Готовность" (recon-levers.js, S4): 5px/3px, бинарный (done);
//   - "MDE" (recon-levers.js): 8px/4px, направление эффекта + риска порога.
// Все три уже несли ОДИН И ТОТ ЖЕ приём: число — только в title, цвет —
// от домена, трек+заливка — div/span-в-div/span. Сведено в одно.
//
// Контракт:
//   mkBar({ frac, color, notchAt, title, empty })
//     frac    -- доля заливки 0..1 (клампится)
//     color   -- CSS-значение цвета заливки (например "var(--grass)") --
//                смысл цвета целиком на домене, здесь только рисование
//     notchAt -- необязательная риска-порог, доля 0..1 (например 0.8 у
//                MDE). Рисуется В DOM ПЕРЕД заливкой: оба узла
//                position:absolute без z-index, поздний узел красится
//                поверх, поэтому как только заливка дорастает до риски и
//                дальше, та физически исчезает под цветом -- без
//                отдельного правила синхронизации.
//     title   -- текст подсказки (число -- только сюда, не в саму ячейку)
//     empty   -- true: пустой трек без заливки и без риски ("правило не
//                сработало"/данных нет) -- решает домен, движок только
//                рисует то, что сказано.
//   Возвращает готовый <span class="bw"> для вставки в ячейку.
//
// Зависимостей нет специально (тот же приём, что у micro-graphics.js):
// платформенный примитив собирается сам через document.createElement, не
// диктует порядок подключения скриптов страницам, которые его используют.

function mkBar(opts) {
  opts = opts || {};
  var span = document.createElement("span");
  span.className = "bw";
  if (opts.title) span.title = opts.title;
  if (opts.empty) return span;

  if (typeof opts.notchAt === "number") {
    var notch = document.createElement("i");
    notch.className = "bw-notch";
    notch.style.left = (Math.max(0, Math.min(1, opts.notchAt)) * 100) + "%";
    span.appendChild(notch);
  }
  var fill = document.createElement("i");
  fill.className = "bw-fill";
  fill.style.width = (Math.max(0, Math.min(1, opts.frac || 0)) * 100) + "%";
  fill.style.background = opts.color || "var(--muted)";
  span.appendChild(fill);
  return span;
}

if (typeof window !== "undefined") {
  window.mkBar = mkBar;
}
if (typeof module !== "undefined" && module.exports) {
  module.exports = { mkBar: mkBar };
}
