"use strict";

function validateBoardPayload(p) {
  const fail = () => {throw new Error("Invalid board payload");};
  const record = v => v && typeof v === "object" && !Array.isArray(v);
  const array = Array.isArray;
  if (!record(p) || p.schema_version !== 1 || !["live","unavailable"].includes(p.state)) fail();
  if (!record(p.meta) || typeof p.meta.domain !== "string" || !record(p.meta.filters)) fail();
  try { new Intl.DateTimeFormat("ru-RU", {timeZone:p.meta.timezone || "Europe/Moscow"}); } catch (_) {fail();}
  if (!array(p.filters) || !array(p.kpis) || !record(p.charts) || !array(p.charts.specs) || !array(p.charts.chart_series)) fail();
  if (!record(p.table) || !array(p.table.columns) || !array(p.table.rows)) fail();
  const t = p.table;
  if (![t.total_rows,t.page,t.page_size].every(Number.isSafeInteger) || t.total_rows<0 || t.page<0 || t.page_size<1 || t.rows.length>t.page_size || t.rows.length>t.total_rows) fail();
  const keys = new Set();
  for (const c of t.columns) {
    if (!record(c) || typeof c.key !== "string" || !c.key || keys.has(c.key) || typeof c.label !== "string" || !["text","number","link","datetime"].includes(c.kind)) fail();
    keys.add(c.key);
  }
  for (const row of t.rows) {
    if (!record(row)) fail();
    for (const c of t.columns) if (c.kind === "number" && row[c.key] != null && !Number.isFinite(row[c.key])) fail();
  }
  for (const k of p.kpis) if (!record(k) || typeof k.label !== "string" || typeof k.value !== "string") fail();
  const ids = new Set();
  for (const s of p.charts.specs) {
    if (!record(s) || typeof s.id !== "string" || !/^[a-zA-Z][\w-]*$/.test(s.id) || ids.has(s.id) || !["bar","hbar","line","grouped-bar","stacked-hbar","pie","date-scatter"].includes(s.encoding)) fail();
    ids.add(s.id);
  }
  for (const f of p.filters) {
    if (!record(f) || !/^[a-zA-Z][\w_]*$/.test(f.key) || ["domain","page","sort_key","sort_direction"].includes(f.key) || typeof f.label !== "string" || !["select","date"].includes(f.kind)) fail();
    if (f.kind === "select" && (!array(f.options) || !f.options.every(o=>record(o)&&typeof o.value==="string"&&typeof o.label==="string"))) fail();
  }
  return p;
}

function createBoardLoader(dataUrl, onData, onError, fetcher) {
  fetcher = fetcher || fetch;
  let generation = 0, controller = null, destroyed = false;
  return {
    async load(params) {
      if (destroyed) return;
      const id = ++generation;
      if (controller) controller.abort();
      controller = new AbortController();
      try {
        const query = new URLSearchParams(params);
        const response = await fetcher(dataUrl + "?" + query.toString(), {signal:controller.signal, credentials:"same-origin", cache:"no-store"});
        if (!response.ok) throw new Error("Source unavailable");
        const payload = validateBoardPayload(await response.json());
        if (!destroyed && id === generation) onData(payload);
      } catch (error) {
        if (!destroyed && id === generation && error.name !== "AbortError") onError(new Error("Данные недоступны"));
      }
    },
    destroy() {destroyed = true; generation++; if (controller) controller.abort();}
  };
}

function mountBoard(root, config) {
  let chartStage = null, disposeTable = null, tableState = tblColState();
  let params = {domain:config.domains[0].key, page:"0"};
  root.classList.add("page-shell");
  const content = el("main", {class:"sheet",id:"sheet"});
  const accent = el("div", {class:"accent-top"});
  const scroll = el("div", {class:"sheet-scroll",id:"sheet-scroll",role:"region","aria-label":"Область отчёта",tabindex:"0"});
  const title = el("h1", {class:"report-title"}, config.domains[0].label);
  const subtitle = el("p", {class:"report-sub"}, "");
  const pad = el("div", {class:"pad",id:"pad"});
  const section = (id, label, node) => el("section", {class:"block",id}, [el("h2", {class:"h-sec"},label),node]);
  const kpis = el("div", {class:"kpi"});
  const charts = el("div", {id:"charts-host"});
  const table = el("div", {class:"ce-board-table-host"});
  pad.append(section("board-kpi","Главные показатели",kpis),section("board-charts","Динамика и распределения",charts),section("board-table","Таблица",table));
  scroll.append(el("div",{class:"app-bar"},el("div",{class:"brand"},[el("span",{class:"mk"}),config.title])),
    el("header",{class:"report-head"},[title,subtitle]),pad);
  content.append(accent,scroll);
  const navigation = el("aside", {class:"rail",id:"rail",tabindex:"-1","aria-label":"Навигация и фильтры"});
  const domains = el("nav", {class:"rail-domains","aria-label":"Источники"});
  const filters = el("form", {class:"rail-filters"});
  const toc = el("ol", {class:"rail-toc"});
  [["board-kpi","Показатели"],["board-charts","Диаграммы"],["board-table","Таблица"]].forEach(([id,label],i)=>{
    const link=el("a",{href:"#"+id},[el("span",{class:"rail-toc-n"},String(i+1)),el("span",{class:"rail-toc-t"},label)]);
    link.addEventListener("click",event=>{event.preventDefault();pad.querySelector("#"+id).scrollIntoView({behavior:"smooth",block:"start"});});
    toc.append(el("li",{},link));
  });
  const status = el("span", {role:"status"});
  const statusDot=el("span",{class:"rail-status-dot"});
  function railSection(label,node,cls) {return el("div",{class:"rail-sec "+cls},[el("div",{class:"rail-h"},label),node]);}
  navigation.append(railSection("Источники",domains,"rail-domains-zone"),railSection("Данные",filters,"rail-data-zone"),
    railSection("Разделы",toc,"rail-toc-zone"),el("div",{class:"rail-status-zone"},railSection("Статус",el("div",{class:"rail-status"},
      el("div",{class:"rail-status-row"},[statusDot,status])),"")),el("a",{class:"skip-link",href:"#sheet-scroll"},"К отчёту"));
  root.replaceChildren(content,navigation);
  document.title=config.title;
  const clear=()=>{
    if(typeof closeChartModal==="function") closeChartModal();
    if(chartStage) chartStage.destroy(); chartStage=null;
    if(disposeTable) disposeTable(); disposeTable=null;
    kpis.replaceChildren();charts.replaceChildren();table.replaceChildren();
  };
  const failed=()=>{clear();status.textContent="Данные недоступны";statusDot.className="rail-status-dot c-red";
    accent.classList.remove("is-loading");pad.classList.remove("is-loading");content.removeAttribute("aria-busy");};
  const refresh=()=>{status.textContent="Загрузка…";accent.classList.add("is-loading");pad.classList.add("is-loading");
    content.setAttribute("aria-busy","true");return loader.load(params);};
  const loader=createBoardLoader(config.data_url,payload=>{
    try {
      if(payload.meta.domain!==params.domain || payload.state!=="live") throw new Error("Unavailable");
      clear();
      title.textContent=config.domains.find(d=>d.key===params.domain).label;
      subtitle.textContent=payload.meta.selection_required ? "Выберите кандидата в панели справа" : "";
      status.textContent=payload.meta.fetched_at ? new Intl.DateTimeFormat("ru-RU",{dateStyle:"short",timeStyle:"short",timeZone:payload.meta.timezone||"Europe/Moscow"}).format(new Date(payload.meta.fetched_at)) : "";
      statusDot.className="rail-status-dot c-green";
      filters.replaceChildren();
      payload.filters.forEach(f=>{
        const input=f.kind==="date" ? el("input",{type:"date",name:f.key,"aria-label":f.label}) : el("select",{name:f.key,"aria-label":f.label});
        if(f.kind==="select") f.options.forEach(o=>input.append(el("option",{value:o.value},o.label)));
        input.value=params[f.key]==null ? String(f.value==null ? "" : f.value) : params[f.key];
        if(params[f.key]==null && input.value!=="") params[f.key]=input.value;
        const selected=f.kind==="select" ? f.options.find(o=>o.value===input.value) : null;
        const field=el("label",{class:"rail-field"+(f.kind==="date" ? " ce-board-date" : "")},[
          el("span",{class:"rail-field-lbl"},f.label),
          ...(f.kind==="select" ? [el("span",{class:"rail-field-val"},selected ? selected.label : "—"),el("span",{class:"rail-field-arr","aria-hidden":"true"},"⌄")] : []), input]);
        input.addEventListener("change",()=>{params[f.key]=input.value;params.page="0";refresh();});
        filters.append(field);
      });
      domains.querySelectorAll("button").forEach(b=>{b.classList.toggle("on",b.dataset.domain===params.domain);b.setAttribute("aria-pressed",String(b.dataset.domain===params.domain));});
      renderKpiCards(kpis,payload.kpis);
      chartStage=mountStage(charts,payload.charts.specs,{meta:payload.meta,chart_series:payload.charts.chart_series});
      const t=payload.table;
      disposeTable=renderBoardTable(table,t.columns,t.rows,{columnState:tableState,totalRows:t.total_rows,page:t.page,pageSize:t.page_size,timezone:payload.meta.timezone,
        sortKey:params.sort_key,sortDirection:params.sort_direction,
        onPage:page=>{params.page=String(page);refresh();},
        onSort:(key,direction)=>{if(key){params.sort_key=key;params.sort_direction=direction;}else{delete params.sort_key;delete params.sort_direction;}params.page="0";refresh();}});
      accent.classList.remove("is-loading");pad.classList.remove("is-loading");content.removeAttribute("aria-busy");
    } catch(_){failed();}
  },failed);
  config.domains.forEach(d=>{
    const button=el("button",{class:"dtab"+(d.key===params.domain ? " on" : ""),type:"button","data-domain":d.key,"aria-pressed":String(d.key===params.domain)},d.label);
    button.addEventListener("click",()=>{params={domain:d.key,page:"0"};tableState=tblColState();refresh();});
    domains.append(button);
  });
  filters.addEventListener("submit",event=>event.preventDefault());
  refresh();
  return {destroy(){loader.destroy();clear();root.replaceChildren();}};
}

if (typeof module !== "undefined") module.exports={validateBoardPayload,createBoardLoader,mountBoard};
if (typeof window !== "undefined") window.CockpitBoard={mount:mountBoard};
