"use strict";

// core.js — generic-утиль для всех модулей UI: форматтеры, el(), sev-хелперы,
// newChart(). Ноль знаний о домене. Грузится первым после chart.umd.js.

const nf = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 1 });
const nf0 = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 0 });
// Ровно 2 знака после запятой, русский разделитель (min= обязателен -- без
// него Intl обрезает хвостовые нули: 0.0080 -> "0,8" вместо "0,80").
const nf2 = new Intl.NumberFormat("ru-RU", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
// Адаптивная точность для ячеек таблицы: |x|>=100 → без десятых, иначе 1 знак.
// Отдельно от fmt/fmtPct, которые шарятся с KPI-картами и тултипами графиков.
const fmtAdaptive = (n) => (n === null || n === undefined ? "—"
  : (Math.abs(n) >= 100 ? nf0 : nf).format(n));
// Адаптивная точность для долей: |frac*100|>=100 → 0 знаков, иначе 1 знак.
const fmtPctAdaptive = (frac) => {
  if (frac === null || frac === undefined) return "—";
  const p = frac * 100;
  return (Math.abs(p) >= 100 ? nf0 : nf).format(p) + "%";
};
// Обрезка текста до n слов. clipped=true, если резали (для title с полным текстом).
function clipWords(text, n) {
  const s = String(text);
  const words = s.trim().split(/\s+/);
  if (words.length <= n) return { text: s, clipped: false };
  return { text: words.slice(0, n).join(" ") + "…", clipped: true };
}
const fmt = (n) => (n === null || n === undefined ? "—" : nf.format(n));
const fmtPct = (frac) => (frac === null || frac === undefined ? "—" : nf.format(frac * 100) + "%");
// Компактный формат больших чисел для осей/тултипов: ≥1e6 → «1,2 млн»,
// ≥1e3 → «1,2 тыс.», иначе nf. Не заменяет nf/fmt (KPI, таблицы, точные тултипы).
function fmtCompact(n) {
  if (n === null || n === undefined) return "—";
  const a = Math.abs(n);
  if (a >= 1e6) return nf.format(n / 1e6) + " млн";
  if (a >= 1e3) return nf.format(n / 1e3) + " тыс.";
  return nf.format(n);
}

function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === null || v === undefined) continue;
    if (k === "class") node.className = v;
    else node.setAttribute(k, v);
  }
  for (const c of [].concat(children)) {
    if (c === null || c === undefined) continue;
    node.append(c instanceof Node ? c : document.createTextNode(c));
  }
  return node;
}

function sevByCompletion(p) {
  if (p === null || p === undefined) return "warn";
  if (p < 0.5) return "crit";
  if (p < 0.8) return "warn";
  return "ok";
}

function sevPill(severity) {
  if (severity === "critical") return "crit";
  if (severity === "warning" || severity === "warn") return "warn";
  return "ok";
}

function seriesById(payload, id) {
  return (payload.chart_series || []).find((s) => s.id === id);
}

// Резолвер мини-языка metaFields (декларация полей шапки → массив пар [label, value]).
// Домен-нейтрален (renderMeta в shared.js это потребляет). Мини-язык минимален по
// решению владельца: только fallback (запасное значение при пустом поле) + version
// (склейка "v" + value). Ветвления/вычисляемых полей сверх этого НЕТ.
//   fields[]: { label, key, fallback?, version? }
//   пусто (null/undefined/"") → fallback; version:true и не пусто → "v" + value.
function resolveMetaFields(fields, meta) {
  meta = meta || {};
  return (fields || []).map((f) => {
    const raw = meta[f.key];
    const empty = (raw === null || raw === undefined || raw === "");
    let v;
    if (empty) v = f.fallback;
    else v = f.version ? ("v" + raw) : raw;
    return [f.label, v];
  });
}

function newChart(canvasId, config) {
  const canvas = document.getElementById(canvasId);
  const existing = (typeof Chart.getChart === "function") ? Chart.getChart(canvas) : null;
  if (existing) existing.destroy();
  return new Chart(canvas, config);
}
