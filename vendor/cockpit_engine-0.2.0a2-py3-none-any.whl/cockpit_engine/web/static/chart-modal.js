"use strict";

// Развёртывание графика на большой экран. Доменно-агностичен. Грузится после
// chart-render.js и chart-overlays.js. Верхний уровень — только декларации
// (Node-безопасно); DOM/Chart — лишь в телах функций.
//
// Контракт:
//   expandButton(spec, payload) → кнопка для слота .ch-head-actions;
//   openChartModal(spec, payload) → смонтированный показанный <dialog>;
//   closeChartModal() → закрыть открытый (renderCharts, chart-render.js:602,
//     зовёт её перед перерисовкой — направление обратное прежней записи).
//
// Зависимости: el/newChart (core.js), buildChartSlide (chart-render.js).
// Нативный <dialog>.showModal() даёт Esc, фокус-трап, top-layer и ::backdrop —
// своей реализации оверлея не пишем.
//
// task-main-198 (§2 спеки controls-design): карточка больше не показывает
// оверлеи (overlayControl зовётся только при expanded, chart-render.js) —
// расходиться карточке и модалке стало нечем, поэтому прежний механизм
// липкой синхронизации ретайрен целиком (флаг переключения, условный колбэк
// закрытия и его тихий обход, проброс из сцены) — см. историю коммита.

// Иконка «стрелки в углы». SVG, не глиф: у Golos Text нет гарантии на U+2921.
const EXPAND_ICON =
  '<svg viewBox="0 0 16 16" width="13" height="13" aria-hidden="true" focusable="false">' +
  '<path d="M6 1H1v5M10 15h5v-5M1 1l5 5M15 15l-5-5" fill="none" stroke="currentColor"' +
  ' stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';

// Единственный открытый диалог: модалка модальна, второй смысла не имеет.
let _openModal = null;

function closeChartModal() {
  if (_openModal) _openModal.close();
}

function expandButton(spec, payload) {
  const btn = el("button", { class: "ch-exp", type: "button",
    title: "Развернуть график", "aria-label": "Развернуть график" });
  btn.innerHTML = EXPAND_ICON;
  btn.addEventListener("click", () => openChartModal(spec, payload));
  return btn;
}

function openChartModal(spec, payload) {
  closeChartModal();
  const dlg = el("dialog", { class: "ch-modal", "aria-label": "Развёрнутый график" });
  const box = el("div", { class: "ch-modal-box" });
  const close = el("button", { class: "ch-modal-close", type: "button",
    "aria-label": "Закрыть" }, "×");
  close.addEventListener("click", () => dlg.close());
  box.append(close);
  const slide = buildChartSlide(spec, payload, { expanded: true, idSuffix: "-x" });
  box.append(slide.el);
  dlg.append(box);
  document.body.append(dlg);
  _openModal = dlg;

  // Порядок обязателен: холст должен попасть в УЖЕ показанный диалог — у скрытого
  // нулевые размеры, Chart.js снял бы их и раздул канвас на первом ресайзе.
  dlg.showModal();
  slide.mount();

  // Клик мимо коробки = клик по самому <dialog>: подложку рисует он.
  dlg.addEventListener("click", (e) => { if (e.target === dlg) dlg.close(); });

  dlg.addEventListener("close", () => {
    // slide.destroy() — НЕ chart.destroy() на когда-то захваченном значении
    // (риск 1 спеки controls-design, task-main-199): переключение ориентации/
    // сортировки внутри buildChartSlide пересобирает Chart на том же холсте
    // (mount() зовёт сам себя), и захваченная здесь ссылка устарела бы после
    // первого же клика — slide.destroy() всегда знает АКТУАЛЬНЫЙ инстанс.
    slide.destroy();
    dlg.remove();
    if (_openModal === dlg) _openModal = null;
  });
  return dlg;
}
