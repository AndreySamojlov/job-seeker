"use strict";

// matrix-table.js — общий движок «сворачиваемая матрица» (белый список рендер-
// примитивов, §3 доктрины). Строки × колонки, сгруппированные в сворачиваемые блоки
// с подытогами. Домен-нейтрален: НИ одного доменного имени/ключа — источник — spec.
//
// Контракт: renderMatrix(container, spec)
//   spec.columns[]: { key, label, anchor } — ТОЛЬКО колонки значений («Показатель» —
//                    неявная первая колонка-подпись, движок рисует её сам).
//   spec.groups[]: { key, label, color, hint, isRef, isResult,
//                    rows:[{label, values:{[colKey]:number|null}, isRef}],
//                    total:{values:{[colKey]:number|null}} | null }
//
// Свёрнуто-по-умолчанию: числа подытога на строке-заголовке; при разворачивании
// уходят в строку-итог под слагаемыми. Зависимости: el/fmtCompact/nf0 из core.js.
//
// Компактное число матрицы; 0/пропуск → «—». Точное значение → нативный тултип.
const _mtxCompact = (n) => (n === null || n === undefined) ? "Нет данных" : (n === 0 ? "—" : fmtCompact(n));
const _mtxTitle = (n) => (n === null || n === undefined) ? "" : nf0.format(n) + " ₽";

// Закреплённые колонки: подпись (label) слева всегда, первая и последняя
// колонка данных — по краям прокручиваемой середины (индекс, не домен-флаг —
// движок не знает про «бренд»/«категорию», см. спеку унификации детализации
// P&L §4 в harness:docs/superpowers/specs/). i/n — индекс/длина spec.columns.
const _MTX_LABEL_W = 230;
const _MTX_PIN_W = 112;
const _MTX_MID_W = 104;
function _mtxPinStyle(i, n, bg) {
  if (i === 0) {
    return "position:sticky;left:" + _MTX_LABEL_W + "px;z-index:2;width:" +
      _MTX_PIN_W + "px;background:" + bg + ";box-shadow:2px 0 4px rgba(28,22,10,.05);";
  }
  if (i === n - 1) {
    return "position:sticky;right:0;z-index:2;width:" + _MTX_PIN_W +
      "px;background:" + bg + ";box-shadow:-2px 0 4px rgba(28,22,10,.05);";
  }
  return "width:" + _MTX_MID_W + "px;";
}

// Свернуть/развернуть блок. Свёрнуто: числа подытога на заголовке (headVals).
// Развёрнуто: числа уходят в строку-итог (totalRow), заголовок — только имя.
function _mtxSetBlock(b, collapsed) {
  b.collapsed = collapsed;
  b.chevron.textContent = collapsed ? "▸" : "▾";
  for (const r of b.rows) r.style.display = collapsed ? "none" : "";
  for (const td of b.headVals) td.style.display = collapsed ? "" : "none";
  if (b.totalRow) b.totalRow.style.display = collapsed ? "none" : "";
  if (b.isResult) b.headRow.style.background = collapsed ? "var(--petrol-tint)" : "";
}

// Ячейка значения строки-слагаемого: anchor — заякоренная колонка (тёмная, правая
// линия при hasCols); прочие приглушены; отрицательное — терра; isRef — справочная
// (мьютед). title — точное значение в рублях. Итоговые строки рисует _mtxSumCell
// (другие font-size/padding) — эта функция только для строк-слагаемых, isTotal-ветки
// сюда не добавлять (ревью: неиспользуемый параметр — мёртвый код, который путает
// читателя, будто эта функция тоже умеет рисовать итоги).
function _mtxValCell(val, anchor, hasCols, isRef, i, n) {
  const txt = _mtxCompact(val);
  const noData = (val === null || val === undefined);
  const neg = (!noData && val < 0);
  let color;
  if (noData)       color = "var(--muted)";
  else if (txt === "—") color = "var(--muted)";
  else if (neg)     color = "var(--terra)";
  else if (isRef)   color = "var(--muted)";
  else              color = anchor ? "var(--ink)" : "var(--muted)";
  const weight = (anchor && !isRef && !noData) ? "500" : "400";
  return el("td", {
    title: _mtxTitle(val),
    style: "text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums;" +
           "font-size:var(--fs-xs);padding:6px 10px;border-bottom:0;color:" + color +
           ";font-weight:" + weight + (noData ? ";font-style:italic;" : ";") +
           (anchor && hasCols ? "border-right:1px solid var(--hair);" : "") +
           _mtxPinStyle(i, n, "var(--sheet)"),
  }, txt);
}

// Ячейка значения строки-сводки/итога: компактное число, жирное, anchor-линия при
// колонках; topBorder — линия сверху (для строки-итога под слагаемыми).
function _mtxSumCell(val, anchor, hasCols, topBorder, i, n, isResult) {
  const txt = _mtxCompact(val);
  const noData = (val === null || val === undefined);
  const neg = (!noData && val < 0);
  const color = noData ? "var(--muted)" : (txt === "—") ? "var(--muted)" : neg ? "var(--terra)" : "var(--ink)";
  const bg = isResult ? "var(--petrol-tint)" : "var(--sheet)";
  return el("td", {
    title: _mtxTitle(val),
    style: "text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums;" +
           "font-size:var(--fs-sm);font-weight:" + (noData ? "400" : "700") +
           ";padding:9px 10px;color:" + color + (noData ? ";font-style:italic;" : ";") +
           (anchor && hasCols ? "border-right:1px solid var(--hair);" : "") +
           (topBorder ? "border-top:1px solid #C8DDDB;" : "") +
           _mtxPinStyle(i, n, bg),
  }, txt);
}

// Подпись строки-сводки: шеврон + имя. Для справочного блока — имя группы + хинт
// (курсив). Цвет = категория блока (spec: group.color); isRef → мьютед/курсив.
function _mtxLabelCell(group, chevron) {
  const isRef = !!group.isRef;
  // Имя: канон-имя подытога (group.total.label) для обычного блока; имя группы для ref.
  const name = (!isRef && group.total && group.total.label) ? group.total.label : group.label;
  const parts = [chevron, el("span", {}, name)];
  if (isRef && group.hint) parts.push(el("span", {
    style: "margin-left:10px;font-style:italic;font-weight:400;color:#B0ABA1;",
  }, group.hint));
  return el("td", {
    title: name,
    style: "text-align:left;padding:9px 10px 9px 0;font-size:var(--fs-sm);" +
           "font-weight:" + (isRef ? "400" : "700") +
           ";font-style:" + (isRef ? "italic" : "normal") +
           ";color:" + (isRef ? "var(--muted)" : group.color) + ";" +
           "position:sticky;left:0;z-index:2;width:" + _MTX_LABEL_W + "px;background:" +
           (group.isResult ? "var(--petrol-tint)" : "var(--sheet)") + ";" +
           "white-space:nowrap;overflow:hidden;text-overflow:ellipsis;",
  }, parts);
}

// Публичный вход: рендер матрицы из spec в container.
function renderMatrix(container, spec) {
  if (!container) return;
  spec = spec || {};
  const columns = spec.columns || [];
  const groups = spec.groups || [];
  if (!columns.length && !groups.length) { container.replaceChildren(); return; }

  const hasCols = columns.length > 1;

  // Шапка: «Показатель» + колонки значений (первая с anchor — заякорена).
  const headCells = [el("th", {
    style: "text-align:left;font-weight:600;font-size:var(--fs-2xs);text-transform:uppercase;" +
           "letter-spacing:.04em;color:var(--muted);padding:0 10px 8px 0;" +
           "border-bottom:1px solid var(--hair-strong);" +
           "position:sticky;left:0;z-index:3;width:" + _MTX_LABEL_W + "px;background:var(--sheet);",
  }, "Показатель")];
  columns.forEach((c, i) => {
    const anchor = !!c.anchor;
    headCells.push(el("th", {
      title: c.label,
      style: "text-align:right;font-size:var(--fs-2xs);text-transform:uppercase;" +
             "letter-spacing:.04em;padding:0 10px 8px;border-bottom:1px solid var(--hair-strong);" +
             "color:" + (anchor ? "var(--ink)" : "var(--muted)") +
             ";font-weight:" + (anchor ? "700" : "600") + ";" +
             (anchor && hasCols ? "border-right:1px solid var(--hair-strong);" : "") +
             "white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" +
             _mtxPinStyle(i, columns.length, "var(--sheet)"),
    }, c.label));
  });
  const thead = el("thead", {}, el("tr", {}, headCells));

  // Тело: на каждый блок — строка-сводка (видна, кликабельна) + скрытые слагаемые +
  // строка-итог. По умолчанию всё свёрнуто до сводок.
  const body = [];
  const blocks = [];
  for (const g of groups) {
    const isRef = !!g.isRef;
    const isResult = !!g.isResult;
    const chevron = el("span", {
      style: "display:inline-block;width:16px;color:" + g.color + ";",
    }, "▸");
    const b = { chevron: chevron, rows: [], headVals: [], totalRow: null,
                headRow: null, isResult: isResult, collapsed: true };
    blocks.push(b);

    // строка-заголовок: подпись + числа подытога (видны только свёрнутыми).
    const headVals = columns.map((c, i) => isRef
      ? el("td", { style: "padding:9px 10px;" + _mtxPinStyle(i, columns.length, "var(--sheet)") })
      : _mtxSumCell(((g.total && g.total.values) || {})[c.key], !!c.anchor, hasCols,
                    false, i, columns.length, isResult));
    if (!isRef) b.headVals = headVals;
    const headRow = el("tr", {
      style: "cursor:pointer;user-select:none;border-bottom:1px solid var(--hair);" +
             (isResult ? "background:var(--petrol-tint);" : ""),
    }, [_mtxLabelCell(g, chevron), ...headVals]);
    headRow.onclick = () => _mtxSetBlock(b, !b.collapsed);
    b.headRow = headRow;
    body.push(headRow);

    // строки-слагаемые (скрыты по умолчанию, с отступом под заголовком)
    for (const r of (g.rows || [])) {
      const rowRef = isRef || !!r.isRef;
      const labelCell = el("td", {
        title: r.label,
        style: "text-align:left;padding:5px 10px 5px 28px;border-bottom:0;font-size:var(--fs-sm);" +
               "font-weight:400;color:var(--muted);" + (rowRef ? "font-style:italic;" : "") +
               "position:sticky;left:0;z-index:2;width:" + _MTX_LABEL_W + "px;background:var(--sheet);" +
               "white-space:nowrap;overflow:hidden;text-overflow:ellipsis;",
      }, r.label);
      const valCells = columns.map((c, i) =>
        _mtxValCell((r.values || {})[c.key], !!c.anchor, hasCols, rowRef, i, columns.length));
      const tr = el("tr", { style: "display:none;" }, [labelCell, ...valCells]);
      b.rows.push(tr);
      body.push(tr);
    }

    // строка-итог: «Итого:» + числа подытога под слагаемыми. Видна только развёрнутой.
    if (g.total) {
      const totLabel = el("td", {
        title: "Итого:",
        style: "text-align:left;padding:9px 10px 9px 16px;font-size:var(--fs-sm);font-weight:700;" +
               "color:" + g.color + ";border-top:1px solid #C8DDDB;" +
               "position:sticky;left:0;z-index:2;width:" + _MTX_LABEL_W + "px;background:" +
               (isResult ? "var(--petrol-tint)" : "var(--sheet)") + ";" +
               "white-space:nowrap;overflow:hidden;text-overflow:ellipsis;",
      }, "Итого:");
      const totVals = columns.map((c, i) =>
        _mtxSumCell((g.total.values || {})[c.key], !!c.anchor, hasCols, true, i, columns.length, isResult));
      const totRow = el("tr", {
        style: "display:none;" + (isResult ? "background:var(--petrol-tint);" : ""),
      }, [totLabel, ...totVals]);
      b.totalRow = totRow;
      body.push(totRow);
    }
  }

  // border-collapse:separate — collapse ломает рендер position:sticky ячеек
  // (артефакты границ/фона при скролле) в части браузеров.
  const table = el("table", {
    style: "width:100%;margin-top:4px;border-collapse:separate;border-spacing:0;table-layout:fixed;",
  }, [thead, el("tbody", {}, body)]);

  // Тулбар «развернуть/свернуть всё» (по умолчанию свёрнуто до сводок).
  let allExpanded = false;
  const allLink = el("span", {
    style: "cursor:pointer;font-size:var(--fs-xs);color:var(--petrol);user-select:none;",
  }, "развернуть всё");
  allLink.onclick = () => {
    allExpanded = !allExpanded;
    for (const b of blocks) _mtxSetBlock(b, !allExpanded);
    allLink.textContent = allExpanded ? "свернуть всё" : "развернуть всё";
  };
  const bar = el("div", { style: "display:flex;justify-content:flex-end;margin:2px 0 8px;" }, allLink);

  const wrap = el("div", { class: "tblwrap" }, table);
  container.replaceChildren(bar, wrap);
}

if (typeof window !== "undefined") window.renderMatrix = renderMatrix;
if (typeof module !== "undefined" && module.exports) module.exports = { renderMatrix, _mtxCompact };
