"use strict";

// directive-form-engine.js — общий движок директивных форм, КАБИНЕТНОГО уровня
// (доктрина унификации, правка 25.08: docs/superpowers/specs/2026-08-25-
// directive-input-cabinet-unification-design.md). Единая точка входа на ВЕСЬ
// кабинет — 3 статичных кнопки rail (index.html: #rail-input-template/
// #rail-input-save/#rail-input-upload), НЕ по одному блоку на домен. Домен
// НЕ участвует в контракте вовсе (в отличие от снятого per-payload движка).
//
// Вызывается ОДИН раз при первом успешном рендере отчёта и ЗАНОВО при смене
// КАБИНЕТА (не домена) — см. shared.js::syncCabinetDirectiveInput, единственная
// точка вызова.
//
// Эндпоинты:
//  GET  .../directive-form/registry?cabinet=... -> {"forms": [...]}
//       (список form_code, УЖЕ гейтованный по грейну кабинета на бэкенде —
//       фронт не решает, что применимо, только запрашивает и рисует)
//  GET  .../bundle/empty.xlsx?cabinet=...&forms=a,b
//  GET  .../bundle/actual.xlsx?cabinet=...&forms=a,b
//  POST .../bundle/upload?cabinet=... (тело — сырые байты .xlsx)
//
// Результат upload — плавающий тост (showDirectiveUploadToast), НЕ строка в
// DOM кнопок: переживает переключение домена, пока запрос идёт/только
// завершился (правка 25.08 — секция «Статус» в rail flex:none, переменная по
// длине строка результата внутри нёе реинкарнировала бы гейт вместимости
// панели epic-main-21).
//
// Зависимости: el() из core.js, fetchWithTimeout() (передаётся явно/читается
// как глобал, чтобы движок оставался тестируемым в Node без побочных
// глобалов).

const _DFE_BASE = "/v1/mp-cockpit/directive-form/bundle";
const _DFE_REGISTRY_URL = "/v1/mp-cockpit/directive-form/registry";

function _dfeUrl(action, cabinet, formCodes) {
  return _DFE_BASE + "/" + action +
    "?cabinet=" + encodeURIComponent(cabinet || "") +
    "&forms=" + encodeURIComponent((formCodes || []).join(","));
}

// Формирует читаемое русское резюме bundle-upload — агрегат по формам.
function formatUploadResult(result) {
  const results = (result && result.results && typeof result.results === "object")
    ? result.results : {};
  const unknownSheets = (result && Array.isArray(result.unknown_sheets))
    ? result.unknown_sheets : [];
  const parts = [];
  for (const formCode of Object.keys(results)) {
    const r = results[formCode] || {};
    const upserted = typeof r.upserted === "number" ? r.upserted : 0;
    const errors = Array.isArray(r.errors) ? r.errors : [];
    const warnings = Array.isArray(r.warnings) ? r.warnings : [];
    const unmapped = Array.isArray(r.unmapped) ? r.unmapped : [];
    const blocked = Array.isArray(r.blocked) ? r.blocked : [];
    let line = formCode + ": загружено строк " + upserted + ".";
    if (errors.length) line += " Ошибки (" + errors.length + "): " + errors.join("; ") + ".";
    if (warnings.length) line += " Предупреждения (" + warnings.length + "): " + warnings.join("; ") + ".";
    if (unmapped.length) line += " Не найдены в каталоге (" + unmapped.length + "): " + unmapped.join(", ") + ".";
    // Отклонённые строки агрегируются ПО КОДУ, а не перечисляются поимённо:
    // колонки, питаемые площадкой, отклоняются целым каталогом (на unix_api это
    // сотни SKU на код), потому что actual.xlsx предзаполняет ячейки самими
    // api-значениями и клиент возвращает их нетронутыми. Поимённый список был бы
    // простынёй, скрывающей главное — какие колонки стали read-only. Молчать
    // нельзя: без этой строки клиент видит «загружено N» и не понимает, почему
    // правка не появилась в витрине (AC7 epic-main-24).
    if (blocked.length) {
      const byCode = {};
      for (const item of blocked) {
        const code = (item && item.code) ? item.code : "?";
        byCode[code] = (byCode[code] || 0) + 1;
      }
      const summary = Object.keys(byCode).sort()
        .map((code) => code + " — " + byCode[code]).join(", ");
      line += " Отклонено, у площадки значение свежее (" + blocked.length + "): " + summary + ".";
    }
    parts.push(line);
  }
  if (unknownSheets.length) {
    parts.push("Неизвестные листы (" + unknownSheets.length + "): " + unknownSheets.join(", ") + ".");
  }
  if (!parts.length) parts.push("Загружено строк: 0.");
  return parts.join(" ");
}

// showDirectiveUploadToast(message) — плавающий оверлей поверх страницы
// (правка 25.08): элемент — прямой child document.body (вне #pad/#rail,
// которые подменяются при переключении домена/renderSkeleton), стиль
// .dfe-toast — position:fixed (styles.css, добавляется отдельной задачей
// плана — Task 8, не этой). Авто-скрытие через 10с ИЛИ клик по крестику.
// Повторный вызов заменяет предыдущий тост (не копится очередь).
function showDirectiveUploadToast(message) {
  if (typeof document === "undefined") return;
  const existing = document.getElementById("directive-upload-toast");
  if (existing) existing.remove();
  const toast = el("div", { class: "dfe-toast", id: "directive-upload-toast", role: "status" });
  toast.append(el("div", { class: "dfe-toast-msg" }, message));
  const closeBtn = el("button", { class: "dfe-toast-close", type: "button",
                                   "aria-label": "Закрыть" }, "×");
  closeBtn.addEventListener("click", () => toast.remove());
  toast.append(closeBtn);
  document.body.appendChild(toast);
  setTimeout(() => { if (toast.parentNode) toast.remove(); }, 10000);
}

// fetchCabinetDirectiveForms(cabinetCode, fetchImpl) -> Promise<string[]> —
// запрашивает /registry?cabinet=... (гейтинг по грейну — на бэкенде, фронт
// его не пересчитывает). [] при любой сетевой/HTTP-ошибке — вызывающий код
// держит кнопки disabled на пустом списке (см. renderCabinetDirectiveInput).
function fetchCabinetDirectiveForms(cabinetCode, fetchImpl) {
  const doFetch = fetchImpl || (typeof fetchWithTimeout === "function" ? fetchWithTimeout : fetch);
  return doFetch(_DFE_REGISTRY_URL + "?cabinet=" + encodeURIComponent(cabinetCode || ""), {}, 15000)
    .then((resp) => { if (!resp.ok) throw new Error("HTTP " + resp.status); return resp.json(); })
    .then((data) => (data && Array.isArray(data.forms)) ? data.forms : [])
    .catch(() => []);
}

// renderCabinetDirectiveInput(cabinetCode, formCodes, fetchImpl) — наполняет
// ТРИ СТАТИЧНЫХ кнопки rail (#rail-input-template/#rail-input-save/
// #rail-input-upload, index.html) обработчиками, работающими со СПИСКОМ
// formCodes разом (один xlsx-бандл). Пустой formCodes/cabinetCode -> кнопки
// остаются/становятся disabled (нечего скачивать/загружать, либо кабинет ещё
// не выбран/список не пришёл — см. fetchCabinetDirectiveForms).
function renderCabinetDirectiveInput(cabinetCode, formCodes, fetchImpl) {
  if (typeof document === "undefined") return;
  const templateBtn = document.getElementById("rail-input-template");
  const saveBtn = document.getElementById("rail-input-save");
  const uploadBtn = document.getElementById("rail-input-upload");
  if (!templateBtn || !saveBtn || !uploadBtn) return;
  if (!cabinetCode || !formCodes || !formCodes.length) {
    // Пустой formCodes на практике = либо кабинет ещё не выбран, либо
    // /registry не ответил (fetchCabinetDirectiveForms глотает ошибку в []) —
    // легитимно пустого списка не бывает: даже file-грань всегда видит хотя бы
    // commerce_plan/commerce_c_snapshot. title объясняет причину явно (спека
    // §6 «Обработка ошибок»), не молчаливый disabled без объяснения.
    const reason = cabinetCode
      ? "Не удалось получить список форм директивного ввода"
      : "Кабинет ещё не выбран";
    for (const b of [templateBtn, saveBtn, uploadBtn]) {
      b.disabled = true; b.title = reason; b.setAttribute("aria-label", reason);
    }
    return;
  }
  const doFetch = fetchImpl || (typeof fetchWithTimeout === "function" ? fetchWithTimeout : fetch);

  templateBtn.disabled = false;
  templateBtn.title = "Скачать шаблон директивного ввода";
  templateBtn.setAttribute("aria-label", templateBtn.title);
  templateBtn.onclick = () => { window.location.href = _dfeUrl("empty.xlsx", cabinetCode, formCodes); };

  saveBtn.disabled = false;
  saveBtn.title = "Выгрузить текущие директивные данные";
  saveBtn.setAttribute("aria-label", saveBtn.title);
  saveBtn.onclick = () => { window.location.href = _dfeUrl("actual.xlsx", cabinetCode, formCodes); };

  uploadBtn.disabled = false;
  uploadBtn.title = "Загрузить заполненный файл директивного ввода";
  uploadBtn.setAttribute("aria-label", uploadBtn.title);
  let fileInput = document.getElementById("rail-input-file");
  if (!fileInput) {
    fileInput = el("input", { type: "file", accept: ".xlsx", id: "rail-input-file",
                               style: "display:none;" });
    document.body.appendChild(fileInput);
  }
  uploadBtn.onclick = () => fileInput.click();
  fileInput.onchange = () => {
    const file = fileInput.files && fileInput.files[0];
    if (!file) return;
    uploadBtn.disabled = true;
    const url = _dfeUrl("upload", cabinetCode, formCodes);
    file.arrayBuffer()
      .then((buf) => doFetch(url, { method: "POST", body: buf,
        headers: { "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" } }, 60000))
      .then((resp) => {
        if (!resp.ok) throw new Error("HTTP " + resp.status);
        return resp.json();
      })
      .then((result) => {
        showDirectiveUploadToast(formatUploadResult(result));
        if (typeof reportViewCacheClear === "function") reportViewCacheClear();
        uploadBtn.disabled = false;
        fileInput.value = "";
      })
      .catch((e) => {
        showDirectiveUploadToast("Ошибка загрузки: " + (e && e.message ? e.message : String(e)));
        uploadBtn.disabled = false;
        fileInput.value = "";
      });
  };
}

if (typeof window !== "undefined") {
  window.renderCabinetDirectiveInput = renderCabinetDirectiveInput;
  window.fetchCabinetDirectiveForms = fetchCabinetDirectiveForms;
  window.showDirectiveUploadToast = showDirectiveUploadToast;
}
if (typeof module !== "undefined" && module.exports) {
  module.exports = { renderCabinetDirectiveInput, fetchCabinetDirectiveForms,
                     formatUploadResult, showDirectiveUploadToast };
}
