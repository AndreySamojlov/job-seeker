"use strict";

(async function () {
  const canvas = document.getElementById("correlation-graph");
  const state = document.getElementById("correlation-graph-state");
  const ctx = canvas.getContext("2d");
  let scale = 1;
  let panX = 0;
  let panY = 0;
  let dragging = null;
  let panning = false;
  let lastX = 0;
  let lastY = 0;

  function resize() {
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.floor(innerWidth * dpr);
    canvas.height = Math.floor(innerHeight * dpr);
    canvas.style.width = `${innerWidth}px`;
    canvas.style.height = `${innerHeight}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function screenToWorld(x, y) {
    return { x: (x - panX) / scale, y: (y - panY) / scale };
  }

  try {
    const response = await fetch("/api/correlations/graph");
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const graph = await response.json();
    if (!graph.edges.length) {
      state.hidden = false;
      state.textContent = "Значимых связей не найдено";
      return;
    }

    resize();
    const nodes = graph.nodes.map((n, i) => ({
      ...n,
      x: innerWidth / 2 + Math.cos(i * 2.399) * (80 + 18 * Math.sqrt(i + 1)),
      y: innerHeight / 2 + Math.sin(i * 2.399) * (80 + 18 * Math.sqrt(i + 1)),
      vx: 0,
      vy: 0,
      fixed: false,
    }));
    const byId = Object.fromEntries(nodes.map((n) => [n.id, n]));
    const edges = graph.edges.map((e) => ({ ...e, a: byId[e.source], b: byId[e.target] }));

    function simulate() {
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i], b = nodes[j];
          let dx = b.x - a.x, dy = b.y - a.y;
          const d2 = Math.max(400, dx * dx + dy * dy);
          const f = 17000 / d2;
          const d = Math.sqrt(d2);
          dx /= d; dy /= d;
          a.vx -= dx * f; a.vy -= dy * f;
          b.vx += dx * f; b.vy += dy * f;
        }
      }
      for (const e of edges) {
        let dx = e.b.x - e.a.x, dy = e.b.y - e.a.y;
        const d = Math.max(1, Math.hypot(dx, dy));
        const f = (d - 150) * 0.012;
        dx /= d; dy /= d;
        e.a.vx += dx * f; e.a.vy += dy * f;
        e.b.vx -= dx * f; e.b.vy -= dy * f;
      }
      for (const n of nodes) {
        if (n.fixed) { n.vx = 0; n.vy = 0; continue; }
        n.vx = (n.vx + (innerWidth / 2 - n.x) * 0.0008) * 0.82;
        n.vy = (n.vy + (innerHeight / 2 - n.y) * 0.0008) * 0.82;
        n.x += n.vx; n.y += n.vy;
      }
    }

    function draw() {
      ctx.clearRect(0, 0, innerWidth, innerHeight);
      ctx.save();
      ctx.translate(panX, panY);
      ctx.scale(scale, scale);
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";

      for (const e of edges) {
        ctx.beginPath();
        ctx.moveTo(e.a.x, e.a.y);
        ctx.lineTo(e.b.x, e.b.y);
        ctx.lineWidth = 1 + e.weight * 8;
        ctx.strokeStyle = "#999";
        ctx.stroke();
        const mx = (e.a.x + e.b.x) / 2, my = (e.a.y + e.b.y) / 2;
        ctx.fillStyle = "#f7f7f5";
        ctx.fillRect(mx - 18, my - 9, 36, 18);
        ctx.fillStyle = "#444";
        ctx.font = "11px system-ui";
        ctx.fillText(Number(e.r).toFixed(2), mx, my);
      }

      for (const n of nodes) {
        ctx.beginPath();
        ctx.arc(n.x, n.y, 38, 0, Math.PI * 2);
        ctx.fillStyle = "#e4e4df";
        ctx.fill();
        ctx.strokeStyle = "#777";
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.fillStyle = "#202020";
        ctx.font = "11px system-ui";
        const words = n.label.split(/\s+/);
        const lines = [];
        let line = "";
        for (const word of words) {
          const next = line ? `${line} ${word}` : word;
          if (ctx.measureText(next).width > 62 && line) { lines.push(line); line = word; }
          else line = next;
        }
        if (line) lines.push(line);
        lines.slice(0, 4).forEach((text, i) => ctx.fillText(text, n.x, n.y + (i - (Math.min(lines.length, 4) - 1) / 2) * 13));
      }
      ctx.restore();
    }

    function frame() {
      simulate();
      draw();
      requestAnimationFrame(frame);
    }

    canvas.addEventListener("pointerdown", (event) => {
      const p = screenToWorld(event.clientX, event.clientY);
      dragging = nodes.find((n) => Math.hypot(n.x - p.x, n.y - p.y) <= 42) || null;
      if (dragging) dragging.fixed = true;
      else panning = true;
      lastX = event.clientX; lastY = event.clientY;
      canvas.setPointerCapture(event.pointerId);
    });
    canvas.addEventListener("pointermove", (event) => {
      if (dragging) {
        const p = screenToWorld(event.clientX, event.clientY);
        dragging.x = p.x; dragging.y = p.y;
      } else if (panning) {
        panX += event.clientX - lastX;
        panY += event.clientY - lastY;
      }
      lastX = event.clientX; lastY = event.clientY;
    });
    canvas.addEventListener("pointerup", () => {
      if (dragging) dragging.fixed = false;
      dragging = null; panning = false;
    });
    canvas.addEventListener("wheel", (event) => {
      event.preventDefault();
      const before = screenToWorld(event.clientX, event.clientY);
      scale = Math.max(0.35, Math.min(3, scale * Math.exp(-event.deltaY * 0.001)));
      panX = event.clientX - before.x * scale;
      panY = event.clientY - before.y * scale;
    }, { passive: false });
    window.addEventListener("resize", resize);
    frame();
  } catch (error) {
    console.error(error);
    state.hidden = false;
    state.textContent = "Не удалось загрузить граф корреляций";
  }
})();
