"use strict";

// micro-graphics.js — SVG-примитивы виджетов «Главные показатели»: кольцо, столбики,
// линия дневного ряда, стрелка динамики. Ноль знаний о доменах и о карточке: на вход
// приходят уже готовые доли/значения/ряды и готовый текст подсказки — домен решает,
// что цифры значат, модуль только рисует (доктрина унификации, ось 2; «Разрез шва»,
// §5 CLAUDE.md — у рисования примитива и у сборки карточки разные причины меняться).
//
// Контракт (спека §3, §4, §7):
//   mgRing(shares, tip)        — кольцо доли или структуры. null при сумме долей > 1
//                                 либо пустом массиве: рисовать заведомую ложь нельзя.
//   mgBars(values, tip)        — до 6 столбиков (недель периода). null на седьмом
//                                 значении — это ошибка вызывающего, не повод обрезать.
//   mgLine(values, tip)        — линия дневного ряда, хвост в 7 точек акцентом. null
//                                 при менее чем двух точках — линию не из чего тянуть.
//   mgTrendGlyph(delta, scale) — текст стрелки по величине изменения; scale: "rel"
//                                 (абсолютные величины) | "pp" (доли, в пунктах).
// Каждый примитив: role="img" + aria-label=tip — без этого микро-графика для
// скринридера не существует вовсе (спека §3.2). Числа внутри элемента нет нигде: у
// элемента нет собственной подписи, весь смысл несёт tip.
// Зависимости: _svgEl — собственный локальный хелпер этого модуля (см. ниже),
// el() из core.js не используется вовсе.

// Размеры фиксированы под виджет (макет 16.08): кольцо 44×44 влезает в ряд из четырёх
// карточек, столбики высотой 40, линия узкая (60×40) НАРОЧНО — рядом стоит
// семизначное число, и широкий график ломал колонку (проверено макетом).
var MG_RING = { size: 44, stroke: 8 };
var MG_BARS = { width: 8, height: 40, gap: 3, max: 6 };
var MG_LINE = { width: 60, height: 40, tail: 7 };

// Палитра сегментов кольца. Намеренно НЕ sev-crit/warn/ok и НЕ terra/ochre/grass —
// эти цвета уже несут в приложении смысл «хорошо/плохо», а виджет ничего не
// оценивает (спека §3.3: чипов статуса и любой оценки в элементе нет, оценку даёт
// глава «Что требует внимания»). Petrol/hair-strong/muted — нейтральные тона,
// различающие сегменты между собой и ничего не сообщающие сами по себе; смысл несёт
// только tip. Серые сегменты нарочно взяты из разных концов шкалы (hair-strong —
// светлый, той же светлоты, что и недостающая дорожка кольца ниже; muted — заметно
// темнее) — правка владельца 17.08: соседние ink-soft/muted были слишком близки по
// светлоте и на кольце структуры маржи читались как один и тот же серый.
var MG_RING_COLORS = ["var(--petrol)", "var(--hair-strong)", "var(--muted)", "var(--ink-soft)"];

// Ревью общего шва (kpi-widgets, находка 1, блокирующая): el() из core.js создаёт
// узлы через document.createElement — для SVG-тега это XHTML-неймспейс, а не SVG.
// Браузер строит такой узел как HTMLUnknownElement (instanceof SVGElement===false,
// размеры 0×0, атрибут viewBox ленится в нижний регистр) — на витрине не рисуется
// НИЧЕГО: ни кольцо, ни столбики, ни линия. Правильный узел заводится только через
// document.createElementNS с явным SVG-неймспейсом — отдельный локальный хелпер, а
// не правка el(): el() общий для всей платформы и работает с HTML, трогать его ради
// одного модуля нельзя (инструкция ревью). Заодно el() присваивает class через
// node.className = v — у SVG-элементов className read-only (SVGAnimatedString),
// такое присваивание либо no-op, либо кидает TypeError; здесь class всегда идёт
// через setAttribute, как и остальные атрибуты (имена SVG-атрибутов регистрозависимы
// и уже переданы вызывающим кодом в верном виде: viewBox, stroke-width и т.д.).
var SVG_NS = "http://www.w3.org/2000/svg";
function _svgEl(tag, attrs, children) {
  var node = document.createElementNS(SVG_NS, tag);
  for (var k in (attrs || {})) {
    var v = attrs[k];
    if (v === null || v === undefined) continue;
    node.setAttribute(k, v);
  }
  [].concat(children || []).forEach(function (c) {
    if (c !== null && c !== undefined) node.append(c);
  });
  return node;
}

function _svg(width, height, tip, children) {
  return _svgEl("svg", {
    class: "mg-svg", viewBox: "0 0 " + width + " " + height,
    width: width, height: height, role: "img", "aria-label": tip,
  }, children);
}

// Один сегмент/дорожка кольца — окружность с dasharray/dashoffset: виден только
// участок длиной len, offset двигает его начало. rotate(-90) переносит старт дуги на
// 12 часов — иначе сегменты начинались бы от 3 часов, что не совпадает ни с одним
// привычным «циферблатом» прогресса.
function _ringArc(c, r, circ, len, offset, color) {
  return _svgEl("circle", {
    cx: c, cy: c, r: r, fill: "none", stroke: color, "stroke-width": MG_RING.stroke,
    "stroke-dasharray": len + " " + (circ - len),
    "stroke-dashoffset": -offset,
    transform: "rotate(-90 " + c + " " + c + ")",
  });
}

// Кольцо: одна доля (часть от целого) либо структура (из чего целое состоит).
// Сумма долей больше единицы — противоречие входа, а не повод рисовать сегменты
// внахлёст; пустой массив — рисовать вовсе нечего. Когда сумма меньше единицы, остаток
// кольца — серая дорожка var(--hair): без неё кольцо выглядело бы как полный круг с
// недостающим куском, будто дорисовать забыли, а не как «доля от целого».
function mgRing(shares, tip) {
  var clean = (shares || []).filter(function (v) { return Number.isFinite(v) && v > 0; });
  var sum = clean.reduce(function (a, b) { return a + b; }, 0);
  if (!clean.length || sum > 1.0001) return null;

  var r = MG_RING.size / 2 - MG_RING.stroke / 2;
  var c = MG_RING.size / 2;
  var circ = 2 * Math.PI * r;
  var parts = [];
  if (sum < 0.9999) parts.push(_ringArc(c, r, circ, circ, 0, "var(--hair)"));
  var offset = 0;
  for (var i = 0; i < clean.length; i++) {
    var len = clean[i] * circ;
    parts.push(_ringArc(c, r, circ, len, offset, MG_RING_COLORS[i % MG_RING_COLORS.length]));
    offset += len;
  }
  return _svg(MG_RING.size, MG_RING.size, tip, parts);
}

// Столбики: до шести значений (спека §3.1 — календарный месяц пересекает до шести
// недель, август 2026 именно такой; седьмого значения ни у одного периода витрины не
// бывает). Значения уже приведены вызывающим к сопоставимому виду (среднедневной
// темп недели, а не сумма — иначе крайняя неполная неделя периода была бы
// систематически ниже соседей без всякой связи со спросом, §5 спеки). Семь и больше —
// ошибка вызывающего: null, а не молчаливая обрезка хвоста. Ряд из нулей рисуется
// минимальной высотой, а не пропадает — ноль продаж тоже факт.
function mgBars(values, tip) {
  var clean = (values || []).filter(function (v) { return Number.isFinite(v); });
  if (!clean.length || clean.length > MG_BARS.max) return null;

  var top = Math.max.apply(null, clean.map(Math.abs).concat([0])) || 1;
  var rects = clean.map(function (v, i) {
    var h = Math.max(2, Math.abs(v) / top * (MG_BARS.height - 2));
    return _svgEl("rect", {
      x: i * (MG_BARS.width + MG_BARS.gap), y: MG_BARS.height - h,
      width: MG_BARS.width, height: h, rx: 1.5,
      // Последний столбик — акцентный: это «сейчас», к нему относится стрелка
      // соседнего элемента «линия». Остальные — нейтральный серый.
      fill: i === clean.length - 1 ? "var(--petrol)" : "var(--hair-strong)",
    });
  });
  var width = clean.length * (MG_BARS.width + MG_BARS.gap) - MG_BARS.gap;
  return _svg(width, MG_BARS.height, tip, rects);
}

function _path(pts) {
  return pts.map(function (p, i) { return (i ? "L" : "M") + p[0] + " " + p[1]; }).join(" ");
}

// Линия дневного ряда: серая по всему периоду, последние семь дней — акцентом (это
// «сейчас», к которому относится динамика), на последней точке — кружок-якорь.
// Меньше двух точек — линию не из чего тянуть, null. Стрелка динамики НЕ рисуется
// здесь: mgTrendGlyph — отдельная функция того же модуля (спека: стрелка часть
// элемента «линейный график» по смыслу, но не по коду — движок компонует их рядом).
// narrow (правка владельца 17.08): движок передаёт true, когда рядом встанет стрелка
// динамики — с ней в ряду тесно, и график сам сужается вместо того, чтобы толкать
// соседей.
function mgLine(values, tip, narrow) {
  var clean = (values || []).filter(function (v) { return Number.isFinite(v); });
  if (clean.length < 2) return null;

  var width = narrow ? MG_LINE.width - 10 : MG_LINE.width;
  var lo = Math.min.apply(null, clean), hi = Math.max.apply(null, clean);
  var span = (hi - lo) || 1;
  var step = width / (clean.length - 1);
  var pts = clean.map(function (v, i) {
    return [i * step, MG_LINE.height - 4 - (v - lo) / span * (MG_LINE.height - 10)];
  });
  var tail = pts.slice(-MG_LINE.tail);
  var last = pts[pts.length - 1];
  return _svg(width, MG_LINE.height, tip, [
    _svgEl("path", { d: _path(pts), fill: "none", stroke: "var(--hair-strong)", "stroke-width": 1.5 }),
    _svgEl("path", { d: _path(tail), fill: "none", stroke: "var(--petrol)", "stroke-width": 2 }),
    _svgEl("circle", { cx: last[0], cy: last[1], r: 2.8, fill: "var(--petrol)" }),
  ]);
}

// Пороги языка динамики (спека §4). Абсолютные величины (штуки, рубли) читаются
// относительной шкалой; долевые (маржинальность, СПП) — в процентных пунктах. Общий
// порог 5% на долях объявил бы «движения нет» там, где рост маржи с 47,1% до 49%
// (+1,9 п.п., но всего +4% относительно) стоит сотни тысяч рублей — раздельные шкалы
// этого не делают.
var MG_TREND = { rel: { noise: 0.05, strong: 0.20 }, pp: { noise: 0.02, strong: 0.05 } };

// Стрелка динамики — НЕ считает величину сама: вызывающий уже выбрал базу сравнения
// (последние 7 дней против среднедневного за предыдущие 3 недели, спека §4) и передал
// готовую delta. Эта функция только переводит величину в глиф. delta не число (в т.ч.
// NaN от деления на нулевую базу) — null, рисовать нечего.
function mgTrendGlyph(delta, scale) {
  if (!Number.isFinite(delta)) return null;
  var t = MG_TREND[scale === "pp" ? "pp" : "rel"];
  var abs = Math.abs(delta);
  if (abs < t.noise) return "—";
  var strong = abs >= t.strong;
  return delta > 0 ? (strong ? "▲▲" : "▲") : (strong ? "▼▼" : "▼");
}

if (typeof window !== "undefined") {
  window.mgRing = mgRing;
  window.mgBars = mgBars;
  window.mgLine = mgLine;
  window.mgTrendGlyph = mgTrendGlyph;
}
if (typeof module !== "undefined" && module.exports) {
  module.exports = { mgRing: mgRing, mgBars: mgBars, mgLine: mgLine, mgTrendGlyph: mgTrendGlyph };
}
