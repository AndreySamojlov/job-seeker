"use strict";

// Сцена блока диаграмм (Ф1 движка): главный график слева + живые мини справа;
// всё, что не помещается в колонку сцены, — нижним рядом .ch-rest (те же живые
// мини, кликом промоутятся в главный слот).
// Ретайрит карусель (Ф2) — листания/скрытых страниц здесь нет и не появляется.
// Доменно-агностична. Грузится после chart-render.js.
//
// ИНВАРИАНТ ЧЕСТНОСТИ (CLAUDE.md §5, «нет данных → заглушка, не скрытие»):
// объявленный доменом график ВСЕГДА доезжает до экрана. Сцена не имеет права
// молча отбрасывать спеки — раскладка адаптируется под их число (no silent caps).
//
// Верхний уровень — только декларации (Node-тестируемо: stageOrder чист); DOM/Chart —
// лишь в теле mountStage.

// Сколько мини живёт в правой колонке сцены. Это ГЕОМЕТРИЯ (колонка увязана по
// высоте с главным графиком через --stage-h), а НЕ лимит на число графиков:
// излишек уходит в нижний ряд, а не в небытие.
const STAGE_MAX_MINIS = 3;

// Порядок графиков: primary (или первый) — главный, остальные — мини.
// Без капа: раскладку решает mountStage, но потерять спеку нельзя. Pure.
function stageOrder(specs) {
  const list = (specs || []).filter(Boolean);
  if (!list.length) return [];
  const pi = list.findIndex((s) => s && s.primary);
  const head = pi >= 0 ? pi : 0;
  return [list[head]].concat(list.filter((_, j) => j !== head));
}

// Монтаж сцены в host. Владеет содержимым host (replaceChildren) и пересборкой при промоуте.
function mountStage(host, specs, payload) {
  const order = stageOrder(specs);
  if (!order.length) { host.replaceChildren(); return; }
  let mainId = order[0].id;
  let charts = [];

  const destroyAll = () => {
    charts.forEach((c) => { try { c.destroy(); } catch (e) { /* noop */ } });
    charts = [];
  };

  const render = () => {
    destroyAll();
    host.replaceChildren();
    const mainSpec = order.find((s) => s.id === mainId) || order[0];
    const minis = order.filter((s) => s.id !== mainSpec.id);

    // Колонка сцены держит фиксированное число мини (увязка высот), остальные
    // мини идут отдельным рядом под сценой — ничего не теряется.
    const colMinis = minis.slice(0, STAGE_MAX_MINIS);
    const restMinis = minis.slice(STAGE_MAX_MINIS);

    const stage = el("div", { class: "ch-stage" });
    const mainCol = el("div", { class: "ch-main" });
    const miniCol = el("div", { class: "ch-minis" });
    stage.append(mainCol, miniCol);
    host.append(stage);
    const restRow = restMinis.length
      ? el("div", { class: "ch-rest", role: "group",
                    "aria-label": "Ещё графики раздела" })
      : null;
    if (restRow) host.append(restRow);

    // Сначала вставляем ВСЕ слайды в DOM, и лишь потом монтируем графики: иначе
    // Chart.js при монтаже первой мини (пока она единственная в grid-колонке)
    // захватит высоту всей колонки, а не свою 1/N-долю, и канвас раздуется.
    const mb = buildChartSlide(mainSpec, payload, { mini: false });
    mainCol.append(mb.el);
    const builders = [mb];

    const addMini = (spec, into) => {
      const xb = buildChartSlide(spec, payload, { mini: true });
      xb.el.classList.add("ch-mini");
      xb.el.setAttribute("role", "button");
      xb.el.setAttribute("tabindex", "0");
      xb.el.setAttribute("aria-label", "Показать график: " + (spec.title || spec.id));
      const promote = () => { mainId = spec.id; render(); };
      xb.el.addEventListener("click", promote);
      xb.el.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") { promote(); e.preventDefault(); }
      });
      into.append(xb.el);
      builders.push(xb);
    };

    colMinis.forEach((spec) => addMini(spec, miniCol));
    restMinis.forEach((spec) => addMini(spec, restRow));

    try {
      builders.forEach((b) => { const c = b.mount(); if (c) charts.push(c); });
    } catch (error) {
      destroyAll();
      host.replaceChildren();
      throw error;
    }
  };

  render();
  return {destroy() {
    destroyAll();
    host.replaceChildren();
  }};
}
