"use strict";

// domains.js — механизм самрегистрации доменов (без перечня доменов).
// DOMAIN_MANIFEST + доменные <script>-теги генерит cockpit_engine.web.domain_boot
// (рендер) — продукт зовёт его и пишет результат в свою статику (см. domains-boot.js,
// гружен сразу после этого файла).
// Грузится ДО доменных модулей (они зовут registerDomain на загрузке) и до app.js.
// Добавление домена = 0 правок фронта: домен подхватывается из реестра автоматически.

window.DOMAINS = window.DOMAINS || {};

function registerDomain(cfg) { window.DOMAINS[cfg.key] = cfg; }
window.registerDomain = registerDomain;
