"use strict";

// calculator-engine.js — общий домен-агностичный движок ценового калькулятора
// what-if (доктрина унификации CLAUDE.md §5; спека 2026-07-20-pricing-what-if-
// design.md, контракт §5, обязательные состояния §5.7; карточка task-main-49).
// Белый список рендер-примитивов (как kpi-engine.js/directive-form-engine.js) —
// единственный файл этого среза, трогающий DOM. Домен (pricing.js) несёт только
// декларацию + select-адаптер (selectSkus) и делегирует сюда без ветвлений.
//
// Публичный контракт:
//   CALCULATOR_ENGINE.render(payload, decl, requestFnOverride?)
//     decl: {
//       endpoint, anchorId, hostId, title, caption, priceLabel, marginLabel,
//       selectSkus(payload) -> [{value, label, priceLk, noConfig, category}],
//       missingLabels: { <missing-код>: текст },
//     }
//     requestFnOverride(cabinet, body, skuMeta) -> Promise<ответ §5> — только тесты;
//     в проде параметр не передаётся, движок берёт requestWhatIf ниже.
//   CALCULATOR_ENGINE.clear(hostId?) — снять виджет, отменить всё отложенное.
//     Домен зовёт это из cfg.clearExtras (shared.js clearCharts) ПЕРЕД тем, как
//     скелет пересоберётся — иначе просроченный debounce/промис может дёрнуть
//     уже отсоединённый узел прошлого рендера.
//
// Размещение (AC3 — «на месте графика, не новый интерфейс»): виджет вставляется
// СИБЛИНГОМ сразу после #<decl.anchorId> (канон-глава «Динамика», её единственный
// сегодняшний потомок — #charts-host), внутри ТОЙ ЖЕ главы, без своего h-sec —
// это не новая глава, а карточка на месте снятого графика «Здоровье каталога»
// (спека §5.8).
//
// === ЖИВОЙ ЭНДПОИНТ (task-main-51) ===
// requestWhatIf зовёт реальный POST /v1/mp-cockpit/price-what-if (task-main-50,
// контракт §5 спеки). Дев-фейк снят вместе со снятием фейка — формулы считает
// ТОЛЬКО engine.py на сервере, фронт лишь форматирует.

const CC_DEBOUNCE_MS = 400;

// ===================== ЧИСТЫЕ ФУНКЦИИ (Node-тестируемы) =====================

// Тело запроса по контракту §5.1. mode="solve" -> target_margin_pct (ДОЛЯ,
// не проценты — конвертация из % в долю делает вызывающий код формы, не эта
// функция); mode="forward" -> price_lk.
function ccBuildRequestBody(mode, skuId, dateStr, priceLk, targetMarginPct) {
  if (mode === "solve") {
    return { sku_id: skuId, date: dateStr, mode: "solve", target_margin_pct: targetMarginPct };
  }
  return { sku_id: skuId, date: dateStr, mode: "forward", price_lk: priceLk };
}

// Коды missing -> текст ФРОНТА (спека §5.6: серверный message — не источник UI).
// Неизвестный код (сетка отстала от контракта) — честно печатаем сам код, не
// проглатываем молча.
function ccMissingBullets(missing, labels) {
  return (missing || []).map((code) => (labels && labels[code]) || code);
}

// band_crossed=true -> человекочитаемая заметка о переходе ступени тарифа (AC5
// должен быть виден пользователю, а не только в сырых числах band/base_band).
// Текст — шаблон decl.bandCrossedText (находка 3 ревью: последний доменный
// текст, оставшийся в общем движке; гейт домен-нейтральности его не ловил лишь
// потому, что словоформа не совпала со стеммой). Домен не объявил — узла нет.
function ccBandCrossedText(resp, decl) {
  if (!resp || resp.band_crossed !== true || !resp.band || !resp.base_band) return null;
  const tpl = decl && decl.bandCrossedText;
  if (!tpl) return null;
  const pct = (r) => (r === null || r === undefined ? "—" : Math.round(r * 1000) / 10 + "%");
  return ccFillTemplate(tpl, {
    fromBand: resp.base_band.band_label,
    toBand: resp.band.band_label,
    fromRate: pct(resp.base_band.commission_rate),
    toRate: pct(resp.band.commission_rate),
  });
}

// ===================== ЖИВОЙ ЗАПРОС К ЭНДПОИНТУ =====================

// POST decl.endpoint?cabinet=... — Контракт 3 спеки §5. Эндпоинт ничего не
// пишет (чистое вычисление); POST — из-за тела запроса. `cabinet` — строка
// "marketplace:code" (payload.meta.cabinet, см. ccMount). `fetchWithTimeout`
// определена в shared.js, который грузится ПОСЛЕ этого файла (index.html) —
// но вызывается она не при парсинге, а изнутри запроса пользователя, когда
// shared.js уже точно исполнился, поэтому обращение к глобалу безопасно;
// прямой `fetch` — страховка на случай изолированного вызова (тесты/будущий
// рефактор порядка скриптов). Сетевые и протокольные ошибки (не-2xx, таймаут,
// разрыв соединения) превращаются в rejected promise — triggerRequest ловит
// его в calc-state-error, отдельном от AC4 «Нет данных» (ok:false — валидный
// ответ 200, а не исключение).
function requestWhatIf(cabinet, decl, body) {
  const url = decl.endpoint + "?cabinet=" + encodeURIComponent(cabinet || "");
  const opts = {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  };
  const doFetch = (typeof fetchWithTimeout === "function")
    ? function () { return fetchWithTimeout(url, opts, 30000); }
    : function () { return fetch(url, opts); };
  return doFetch().then(function (r) {
    if (!r.ok) {
      return r.text().then(function (text) {
        throw new Error("HTTP " + r.status + (text ? ": " + text : ""));
      });
    }
    return r.json();
  });
}

// ===================== DOM: сборка панели результата =====================

function ccResultIdle() {
  return el("div", { class: "calc-result calc-state-idle" },
    "Выберите SKU и введите цену или целевую маржу.");
}

function ccResultLoading() {
  return el("div", { class: "calc-result calc-state-loading" }, "Считаю…");
}

function ccResultError(message) {
  return el("div", { class: "calc-result calc-state-error" },
    "Не удалось получить расчёт: " + message + ". Проверьте соединение и попробуйте ещё раз.");
}

function ccResultNoData(missing, missingLabels) {
  const bullets = ccMissingBullets(missing, missingLabels);
  return el("div", { class: "calc-result calc-state-nodata" }, [
    el("div", { class: "calc-nodata-title" }, "Нет данных для расчёта:"),
    el("ul", { class: "calc-missing-list" }, bullets.map((b) => el("li", {}, b))),
  ]);
}

// Текст — три источника по приоритету (debt-main-65 поверх вилки debt-main-68):
// явный параметр (вилка зовёт с текстом СВОЕЙ схемы, decl.unreachableSchemeText),
// иначе decl.unreachableText (общий текст домена), иначе нейтральный фолбэк
// движка — на случай будущего домена, который вообще не объявил текст (доктрина,
// ось 3: узел не должен остаться немым). Плюс строка пола (§6.5 спеки) — сегодня
// эта панель тупик без единого числа, floor_grid_net/floor_config_net сюда всё
// равно приходят (внутри resp либо внутри влитого варианта).
function ccResultUnreachable(resp, decl, textOverride) {
  const text = textOverride || (decl && decl.unreachableText) ||
    "Целевая маржа недостижима ни при одной цене.";
  const parts = [el("div", {}, text)];
  const floorRow = ccFloorRow(resp || {}, decl || {});
  if (floorRow) parts.push(floorRow);
  // task-main-136: ось 2 — та же логика "показывать всегда", что ось 1/3 выше.
  const platformFloorRow = ccPlatformFloorRow(resp || {}, decl || {});
  if (platformFloorRow) parts.push(platformFloorRow);
  const platformNote = ccPlatformFallbackNote(resp, decl);
  if (platformNote) parts.push(platformNote);
  return el("div", { class: "calc-result calc-state-unreachable" }, parts);
}

function ccCostStack(costStack) {
  const rows = (costStack || []).map((row) => el("div", { class: "calc-cost-row" }, [
    el("span", { class: "calc-cost-label" }, row.label),
    el("span", { class: "calc-cost-value num" }, fmtAdaptive(row.value_rub) + " ₽"),
  ]));
  return el("div", { class: "calc-cost-stack" }, rows);
}

function ccBandLadder(bands, currentBand, baseBand) {
  const items = (bands || []).map((b) => {
    const isCurrent = !!(currentBand && b.from === currentBand.from && b.to === currentBand.to);
    const wasBase = !!(baseBand && !isCurrent && b.from === baseBand.from && b.to === baseBand.to);
    const cls = "calc-band" + (isCurrent ? " calc-band-current" : "") + (wasBase ? " calc-band-prev" : "");
    return el("div", { class: cls }, [
      el("span", { class: "calc-band-label" }, b.band_label),
      el("span", { class: "calc-band-rate num" }, fmtPctAdaptive(b.commission_rate)),
    ]);
  });
  return el("div", { class: "calc-band-ladder" }, items);
}

// Простой подстановщик {ключ} -> значение (доктрина унификации, ось 2: движок не
// формирует ни слова текста сам, только подставляет значения в шаблон из decl).
// Незнакомый {ключ} (нет в vars) остаётся как есть — честная поломка вместо
// молчаливой пустой строки, если декларация и движок разошлись по набору ключей.
function ccFillTemplate(template, vars) {
  if (!template) return "";
  return template.replace(/\{(\w+)\}/g, function (whole, key) {
    return Object.prototype.hasOwnProperty.call(vars, key) ? vars[key] : whole;
  });
}

// Строка ценового пола (спека дивергенции ставок §6.2) — печатается ВСЕГДА
// внутри блока результата (доктрина, ось 3: нет данных -> заглушка, не скрытие).
// Домен, не объявивший decl.floorLabel (будущий, ещё не подключивший этот узел),
// не получает узел-призрак — возвращаем null, а не полурисованный элемент.
//   - значение — floor_grid_net (поле ВАРИАНТА при вилке — у каждой схемы своё);
//   - null -> decl.floorUnknownText, узел остаётся;
//   - скобка со вторым числом — только rate_divergent===true И floor_config_net
//     не пуст (floor_config_net — поле ВЕРХНЕГО уровня, одно на SKU, общее для
//     всех схем вилки, потому что от схемы не зависит);
//   - floor_grid_reliable===false -> честная приписка decl.floorUnreliableText,
//     независимо от того, известно ли само число (шатко — значит шатко).
function ccFloorRow(resp, decl) {
  if (!decl || !decl.floorLabel) return null;
  const gridNet = (resp.floor_grid_net === null || resp.floor_grid_net === undefined)
    ? null : resp.floor_grid_net;
  const valueText = (gridNet === null)
    ? (decl.floorUnknownText || "—") : (fmtAdaptive(gridNet) + " ₽");
  const spans = [
    el("span", { class: "calc-floor-label" }, decl.floorLabel),
    el("span", { class: "calc-floor-value num" }, valueText),
  ];
  const cfgNet = resp.floor_config_net;
  const hasCfgNet = cfgNet !== null && cfgNet !== undefined;
  // Находка 1 ревью (блокер), вторая половина: скобку показываем, когда
  // РАСХОДЯТСЯ САМИ ПОЛЫ, а не когда расходятся ставки на фактической цене.
  // Пол по сетке кусочный — его корень может лежать в другой ступени, чем
  // фактическая цена, поэтому полы способны разойтись даже при совпавших там
  // ставках; по старому условию скобка молчала бы, а рядом стояло бы «числа
  // совпадают». Порог 0.5 ₽ — ниже рубля, до которого округляется вывод.
  const floorsDiffer = hasCfgNet && gridNet !== null && Math.abs(gridNet - cfgNet) > 0.5;
  if (floorsDiffer) {
    spans.push(el("span", { class: "calc-floor-config" },
      " (" + (decl.floorConfigLabel || "") + ": " + fmtAdaptive(cfgNet) + " ₽)"));
  }
  if (resp.floor_grid_reliable === false && decl.floorUnreliableText) {
    spans.push(el("span", { class: "calc-floor-unreliable" }, " " + decl.floorUnreliableText));
  }
  return el("div", { class: "calc-floor-row" }, spans);
}

// task-main-136 (ось 2, спека 2026-08-05-pricing-class-c-to-a-design.md §6.6):
// строка платформенного пола — тот же приём, что ccFloorRow (ось 1/3) выше:
// печатается ВСЕГДА, когда домен объявил decl.platformFloorLabel (доктрина,
// ось 3 — нет данных -> заглушка "Нет данных", не скрытие узла), независимо
// от того, откуда взята ставка ЭТОЙ схемы (resp.rate_source — "tariff_grid"
// | "platform" | null). floor_platform_net/platform_commission_rate — поля
// ВАРИАНТА при вилке (как floor_grid_net), одно на SKU только когда схема
// единственная (через _TOP_LEVEL_DUP на сервере).
function ccPlatformFloorRow(resp, decl) {
  if (!decl || !decl.platformFloorLabel) return null;
  const net = (resp.floor_platform_net === null || resp.floor_platform_net === undefined)
    ? null : resp.floor_platform_net;
  const rate = resp.platform_commission_rate;
  const hasRate = rate !== null && rate !== undefined;
  const valueText = (net === null)
    ? (decl.floorUnknownText || "—")
    : (fmtAdaptive(net) + " ₽" + (hasRate ? " (" + fmtPctAdaptive(rate) + ")" : ""));
  return el("div", { class: "calc-floor-row" }, [
    el("span", { class: "calc-floor-label" }, decl.platformFloorLabel),
    el("span", { class: "calc-floor-value num" }, valueText),
  ]);
}

// task-main-136 (побочный выигрыш §6.6): rate_source==="platform" значит у
// ЭТОЙ схемы нет покрытия тарифной сеткой вовсе — расчёт/ладдер построены на
// ОДНОЙ плоской ставке площадки (сервер, _flat_rates). Без явного пояснения
// ладдер из одной "ступени" читался бы как обычное покрытие сетки одним
// широким диапазоном, что неправда.
function ccPlatformFallbackNote(resp, decl) {
  if (!resp || resp.rate_source !== "platform") return null;
  const text = decl && decl.platformFallbackNoteText;
  if (!text) return null;
  return el("div", { class: "calc-warn" }, text);
}

// Плашка источника ставки — три режима по rate_divergent (спека дивергенции
// ставок §6.3). Все тексты — шаблоны в decl.rateSourceNote (pricing.js); движок
// только выбирает режим и подставляет значения (доктрина, ось 2 — ни слова
// готового текста здесь). decl без rateSourceNote (домен не подключил узел) ->
// null, без узла-призрака. Постоянная (печатается независимо от того, разошлось
// ли), и внутри КАЖДОГО блока вилки — источник числа назван на каждом расчёте.
// Расходится ли ПОКАЗАННАЯ ставка (та, из которой посчитаны числа на экране) с
// плановой. Находка 1 ревью (блокер): серверный rate_divergent посчитан на
// ФАКТИЧЕСКОЙ цене дня, а продавец двигает гипотетическую — если судить по нему,
// плашка при переходе ступени назовёт ставку 30% и тут же скажет «плановая та
// же» при плановой 10%. Экранное утверждение обязано опираться на экранное число.
// null — сравнивать не с чем (нет ступени или нет плановой ставки).
function ccShownRateDivergent(resp) {
  const shown = resp.band && resp.band.commission_rate;
  const cfg = resp.config_commission_rate;
  if (shown === null || shown === undefined || cfg === null || cfg === undefined) return null;
  return Math.abs(shown - cfg) > 1e-6;
}

// Ревью общего шва (Б1, блокер): вся эта плашка построена вокруг "комиссия —
// по тарифной сетке Ozon" (same/divergent/neutral шаблоны decl.rateSourceNote,
// pricing.js). В fallback-режиме (resp.rate_source==="platform", §6.6 — сетка
// эту схему не покрыла вовсе, band/bands — синтетическая плоская "ступень" по
// ставке площадки) это утверждение ЛОЖНО: печатать его РЯДОМ с честным
// ccPlatformFallbackNote ("посчитано по ставке площадки, а не по ступеням
// сетки") даёт панель, которая произносит два взаимоисключающих факта о
// происхождении ОДНОГО и того же числа. Единственный источник объяснения в
// этом режиме — ccPlatformFallbackNote; эта функция молчит, а не дублирует
// (тем более противоречиво) её работу.
function ccRateSourceNote(resp, decl) {
  if (!decl || !decl.rateSourceNote) return null;
  if (resp && resp.rate_source === "platform") return null;
  const rsn = decl.rateSourceNote;
  const rd = ccShownRateDivergent(resp);
  const scheme = resp.delivery_scheme || "—";
  if (rd === true) {
    const gridNet = resp.floor_grid_net;
    const cfgNet = resp.floor_config_net;
    const floorsKnown = (gridNet !== null && gridNet !== undefined)
      && (cfgNet !== null && cfgNet !== undefined);
    const vars = {
      scheme: scheme,
      price: fmtAdaptive(resp.price_lk),
      gridRate: fmtPctAdaptive(resp.band && resp.band.commission_rate),
      band: (resp.band && resp.band.band_label) || "—",
      cfgRate: fmtPctAdaptive(resp.config_commission_rate),
    };
    // Один из полов неизвестен -> отдельный шаблон без чисел полов вовсе (иначе
    // fmtAdaptive(null)="—" даёт панель, где скобка пола честно молчит, а
    // плашка тут же произносит прочерк — два разных факта об одном и том же).
    let text = floorsKnown
      ? ccFillTemplate(rsn.divergent, Object.assign({}, vars,
          { floorGrid: fmtAdaptive(gridNet), floorConfig: fmtAdaptive(cfgNet) }))
      : ccFillTemplate(rsn.divergentNoFloor, vars);
    // Хвост про надёжность расчёта — только когда пол по сетке сам не шаток
    // (§6.4: там, где multiple_solutions/solution="none", утверждать правоту нельзя).
    if (resp.floor_grid_reliable === true && rsn.divergentTail) text += rsn.divergentTail;
    return el("div", { class: "calc-source-note" }, text);
  }
  const vars = {
    scheme: scheme,
    band: (resp.band && resp.band.band_label) || "—",
    gridRate: fmtPctAdaptive(resp.band && resp.band.commission_rate),
  };
  const template = (rd === false) ? rsn.same : rsn.neutral; // null/undefined -> neutral
  return el("div", { class: "calc-source-note" }, ccFillTemplate(template, vars));
}

function ccResultOk(resp, decl) {
  const parts = [];
  const isSuggested = resp.mode === "solve";
  parts.push(el("div", { class: "calc-result-price" }, [
    el("span", { class: "calc-result-price-lbl" }, isSuggested ? "Подсказанная цена ЛК" : "Цена ЛК"),
    el("span", { class: "calc-result-price-val num" }, fmtAdaptive(resp.price_lk) + " ₽"),
  ]));
  parts.push(el("div", { class: "calc-result-margin" }, [
    el("span", {}, "Маржа"),
    el("span", { class: "num" }, fmtAdaptive(resp.margin_rub) + " ₽ · " + fmtPctAdaptive(resp.margin_pct)),
  ]));
  const floorRow = ccFloorRow(resp, decl);
  if (floorRow) parts.push(floorRow);
  // task-main-136 (ось 2): третья явная ось сразу под полом по сетке/плану —
  // тот же порядок чтения, что декларирует спека §6.6 (план -> площадка -> сетка).
  const platformFloorRow = ccPlatformFloorRow(resp, decl);
  if (platformFloorRow) parts.push(platformFloorRow);
  if (resp.warnings && resp.warnings.indexOf("multiple_solutions") >= 0) {
    parts.push(el("div", { class: "calc-warn" },
      "Найдено несколько цен для этой маржи — показана минимальная."));
  }
  const crossedText = ccBandCrossedText(resp, decl);
  if (crossedText) parts.push(el("div", { class: "calc-crossed-note" }, crossedText));
  if (resp.cost_stack) parts.push(ccCostStack(resp.cost_stack));
  if (resp.bands) parts.push(ccBandLadder(resp.bands, resp.band, resp.base_band));
  const platformNote = ccPlatformFallbackNote(resp, decl);
  if (platformNote) parts.push(platformNote);
  const sourceNote = ccRateSourceNote(resp, decl);
  if (sourceNote) parts.push(sourceNote);
  return el("div", { class: "calc-result calc-state-ok" }, parts);
}

// ===================== Вилка схем доставки (debt-main-68) =====================
//
// Схема доставки конкретного товара платформе неизвестна (источника нет ни в
// API, ни в файле — см. спеку 2026-07-20-delivery-scheme-fork-design.md §1), а
// комиссия у FBO и FBS разная (3.85 п.п. в среднем, 9 п.п. максимум). Поэтому
// сервер отдаёт scheme_variants — расчёт по каждой схеме, — и виджет показывает
// оба числа вместо одного недостоверного.

// Пустой массив в JS truthy — без явной проверки длины `scheme_variants: []`
// проскочил бы мимо обеих веток и отрисовался прочерками (сервер такого не
// отдаёт, но защита должна быть двусторонней).
function ccVariants(resp) {
  const variants = resp && resp.scheme_variants;
  return (variants && variants.length) ? variants : null;
}

// Вариант -> объект В ФОРМЕ прежнего ответа: ccResultOk рендерит именно её.
// Ключевое решение §5.2: вилка — КОМПОЗИЦИЯ над существующим рендером, а не
// вторая вёрстка. Любая будущая правка блока результата (например итог затрат,
// debt-main-66) применится к обоим блокам вилки сама.
function ccVariantAsResp(resp, variant) {
  return Object.assign({}, resp, variant);
}

// Недостижимость цели у ВСЕХ схем — это состояние «маржа недостижима» целиком,
// а не вилка из двух заглушек. Верхнеуровневый solution при вилке всегда null,
// поэтому прежняя проверка resp.solution здесь бы не сработала.
function ccAllVariantsUnreachable(resp) {
  const variants = ccVariants(resp);
  if (!variants || !variants.length) return false;
  return variants.every(function (v) { return v.solution === "none"; });
}

// Текст — decl.forkNoteText (доменная декларация); домен, ещё не подключивший
// вилку, не объявляет его — движок несёт нейтральный фолбэк, а не молчит узлом.
function ccForkNote(decl) {
  const text = (decl && decl.forkNoteText) ||
    "Схема доставки для этого товара не определена — показаны все доступные варианты.";
  return el("div", { class: "calc-fork-note" }, text);
}

function ccForkColumn(resp, variant, decl) {
  const merged = ccVariantAsResp(resp, variant);
  // Вариант, где цель недостижима именно на ЭТОЙ схеме, говорит это словами:
  // пустой OK-блок с прочерками читался бы как поломка. Текст — decl.unreachableSchemeText
  // (своя формулировка «недостижимо ИМЕННО на этой схеме», не общий unreachableText).
  const inner = (variant.solution === "none")
    ? ccResultUnreachable(merged, decl, decl && decl.unreachableSchemeText)
    : ccResultOk(merged, decl);
  return el("div", { class: "calc-fork-col" }, [
    el("div", { class: "calc-fork-head" }, "По схеме " + variant.delivery_scheme),
    inner,
  ]);
}

function ccResultFork(resp, decl) {
  const cols = ccVariants(resp).map(function (v) { return ccForkColumn(resp, v, decl); });
  return el("div", { class: "calc-result calc-state-fork" }, [
    ccForkNote(decl),
    el("div", { class: "calc-fork" }, cols),
  ]);
}

// Порядок ветвления ФИКСИРОВАН (§5.1): дыра данных -> недостижимость у всех
// схем -> вилка -> одиночный расчёт. Ответ без scheme_variants (старый формат)
// рендерится последней веткой как раньше.
function ccBuildResultPanel(resp, decl) {
  if (!resp) return ccResultIdle();
  if (resp.ok === false) return ccResultNoData(resp.missing, decl.missingLabels);
  // Находка 2 ревью: недостижимость у ВСЕХ схем — всё ещё вилка по полу.
  // floor_grid_net лежит ВНУТРИ варианта, а при вилке верхнеуровневого дубля
  // нет (_TOP_LEVEL_DUP не применяется) — отрисовав здесь один общий блок, мы
  // показали бы «Пол: Нет данных», хотя у каждой схемы пол посчитан и они
  // разные. Поэтому колонки остаются, а «недостижимо» говорит каждая своя.
  if (resp.mode === "solve" && ccAllVariantsUnreachable(resp)) {
    return ccResultFork(resp, decl);
  }
  if (resp.mode === "solve" && resp.solution === "none") {
    return ccResultUnreachable(resp, decl);
  }
  const variants = ccVariants(resp);
  if (variants && variants.length > 1) return ccResultFork(resp, decl);
  if (variants && variants.length === 1) {
    return ccResultOk(ccVariantAsResp(resp, variants[0]), decl);
  }
  return ccResultOk(resp, decl);
}

// ===================== Монтаж/снятие (единственный держатель состояния) =====================

let _ccState = null;

function ccClear(hostId) {
  const id = hostId || (_ccState && _ccState.decl && _ccState.decl.hostId) || "pricing-calculator";
  if (_ccState) {
    if (_ccState.timer) clearTimeout(_ccState.timer);
    _ccState.reqGen++; // осиротить любой уже улетевший запрос текущего инстанса
  }
  const existing = document.getElementById(id);
  if (existing && typeof existing.remove === "function") existing.remove();
  _ccState = null;
}

function ccMount(payload, decl, requestFnOverride) {
  ccClear(decl.hostId);

  const anchor = document.getElementById(decl.anchorId);
  if (!anchor || !anchor.parentNode) return; // нет якоря (глава «Динамика» не собрана) — молча не рендерим

  const meta = (payload && payload.meta) || {};
  const cabinet = meta.cabinet || "";
  const dateStr = meta.obs_date || "";
  const skus = (typeof decl.selectSkus === "function") ? (decl.selectSkus(payload) || []) : [];
  const doRequest = requestFnOverride || function (cab, body, skuMeta) {
    return requestWhatIf(cab, decl, body, skuMeta);
  };

  const container = el("div", { class: "calc", id: decl.hostId });
  container.append(el("div", { class: "calc-head" }, el("h3", {}, decl.title || "Ценовой калькулятор")));
  if (decl.caption) container.append(el("div", { class: "calc-cap" }, decl.caption));

  const state = {
    container: container, mode: "forward", reqGen: 0, timer: null,
    cabinet: cabinet, dateStr: dateStr, decl: decl,
  };
  _ccState = state;

  if (!skus.length) {
    container.append(el("div", { class: "calc-result calc-state-idle" }, "Нет SKU для расчёта."));
    anchor.parentNode.appendChild(container);
    return;
  }

  const skuSelect = el("select", { class: "calc-sku-select" },
    skus.map((s) => el("option", { value: s.value }, s.label)));
  container.append(el("div", { class: "calc-row" }, [el("label", {}, "SKU"), skuSelect]));

  const tabForward = el("button", { class: "calc-tab calc-tab-active", type: "button" }, "Цена → маржа");
  const tabSolve = el("button", { class: "calc-tab", type: "button" }, "Маржа → цена");
  container.append(el("div", { class: "calc-tabs" }, [tabForward, tabSolve]));

  const priceInput = el("input", { type: "number", step: "0.01", min: "0.01", class: "calc-price-input" });
  const priceField = el("div", { class: "calc-field" },
    [el("label", {}, decl.priceLabel || "Цена ЛК, ₽"), priceInput]);
  const marginInput = el("input", { type: "number", step: "0.1", class: "calc-margin-input" });
  const marginField = el("div", { class: "calc-field calc-field-hidden" },
    [el("label", {}, decl.marginLabel || "Целевая маржа, %"), marginInput]);
  container.append(el("div", { class: "calc-input-row" }, [priceField, marginField]));

  const resultHost = el("div", {});
  resultHost.append(ccResultIdle());
  container.append(resultHost);

  function setResult(node) { resultHost.replaceChildren(node); }

  function triggerRequest() {
    // Прямой вызов (смена SKU/вкладки, начальный автозапуск) обгоняет любой уже
    // отложенный debounce от предыдущего ввода — иначе он всё равно выстрелит
    // чуть позже лишним запросом (generation counter не даст ему перезаписать
    // экран, но сеть дёрнется впустую).
    if (state.timer) { clearTimeout(state.timer); state.timer = null; }
    const skuId = skuSelect.value;
    const skuMeta = skus.find((s) => s.value === skuId);
    let body;
    if (state.mode === "solve") {
      const raw = marginInput.value;
      if (raw === "" || raw === null || raw === undefined) { setResult(ccResultIdle()); return; }
      const targetFrac = Number(raw) / 100;
      if (!isFinite(targetFrac)) { setResult(ccResultIdle()); return; }
      body = ccBuildRequestBody("solve", skuId, state.dateStr, null, targetFrac);
    } else {
      const raw = priceInput.value;
      if (raw === "" || raw === null || raw === undefined) { setResult(ccResultIdle()); return; }
      const priceLk = Number(raw);
      if (!isFinite(priceLk) || priceLk <= 0) { setResult(ccResultIdle()); return; }
      body = ccBuildRequestBody("forward", skuId, state.dateStr, priceLk, null);
    }
    const gen = ++state.reqGen;
    setResult(ccResultLoading());
    doRequest(state.cabinet, body, skuMeta)
      .then((resp) => {
        if (gen !== state.reqGen || _ccState !== state) return; // устарел или виджет уже снят
        setResult(ccBuildResultPanel(resp, state.decl));
      })
      .catch((err) => {
        if (gen !== state.reqGen || _ccState !== state) return;
        setResult(ccResultError((err && err.message) || String(err)));
      });
  }

  function scheduleRequest() {
    if (state.timer) clearTimeout(state.timer);
    state.timer = setTimeout(function () { state.timer = null; triggerRequest(); }, CC_DEBOUNCE_MS);
  }

  function setMode(mode) {
    state.mode = mode;
    tabForward.classList.toggle("calc-tab-active", mode === "forward");
    tabSolve.classList.toggle("calc-tab-active", mode === "solve");
    priceField.classList.toggle("calc-field-hidden", mode !== "forward");
    marginField.classList.toggle("calc-field-hidden", mode !== "solve");
    if (mode === "forward" && priceInput.value !== "") triggerRequest();
    else if (mode === "solve" && marginInput.value !== "") triggerRequest();
    else setResult(ccResultIdle());
  }

  tabForward.addEventListener("click", function () { setMode("forward"); });
  tabSolve.addEventListener("click", function () { setMode("solve"); });
  priceInput.addEventListener("input", scheduleRequest);
  marginInput.addEventListener("input", scheduleRequest);
  skuSelect.addEventListener("change", function () {
    const sel = skus.find((s) => s.value === skuSelect.value);
    if (state.mode === "forward") {
      priceInput.value = (sel && sel.priceLk !== null && sel.priceLk !== undefined) ? sel.priceLk : "";
      if (priceInput.value !== "") triggerRequest(); else setResult(ccResultIdle());
    } else {
      setResult(ccResultIdle());
    }
  });

  // Начальное состояние: первый SKU уже выбран (как в реальном <select>) — сразу
  // считаем по его текущей цене, чтобы виджет не открывался пустым.
  const first = skus[0];
  skuSelect.value = first.value;
  if (first.priceLk !== null && first.priceLk !== undefined) {
    priceInput.value = first.priceLk;
    triggerRequest();
  }

  state.skuSelect = skuSelect; state.priceInput = priceInput; state.marginInput = marginInput;
  anchor.parentNode.appendChild(container);
}

const CALCULATOR_ENGINE = { render: ccMount, clear: ccClear };

if (typeof window !== "undefined") window.CALCULATOR_ENGINE = CALCULATOR_ENGINE;
if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    CALCULATOR_ENGINE,
    ccBuildRequestBody, ccMissingBullets, ccBandCrossedText,
    requestWhatIf,
    ccFillTemplate, ccFloorRow, ccRateSourceNote, ccResultUnreachable,
    ccPlatformFloorRow, ccPlatformFallbackNote,
  };
}
