"use strict";

// window.DOMAINS, DOMAIN_MANIFEST и registerDomain определены в domains.js (грузится
// раньше). Доменные модули (commerce/finance/…) саморегистрируются на загрузке;
// подзаголовок навигации задаётся декларативными полями конфига домена.

function updateNavSub(domain) {
  const n = document.getElementById("nav-sub");
  const cfg = window.DOMAINS[domain];
  if (n) n.textContent = (cfg && cfg.navSub) || "";
}

function renderDomainSwitcher(active) {
  const host = document.getElementById("domain-switcher");
  if (!host) return;
  host.replaceChildren();
  for (const { key } of window.DOMAIN_MANIFEST) {
    const cfg = window.DOMAINS[key];
    if (!cfg) continue;
    const b = el("button", { class: "dtab" + (key === active ? " on" : ""),
      type: "button", "data-domain": key }, cfg.label);
    b.addEventListener("click", () => { if (key !== active) switchDomain(key); });
    host.append(b);
  }
}

function switchDomain(domain) {
  const gen = bumpLoadGen();
  setLoading(true);  // покрывает и промежуточный /cabinets-запрос до loadReport
  // Позиция прокрутки (task-main-97, спека §Позиция прокрутки): смена домена — в
  // начало отчёта (набор глав меняется целиком, старая позиция теряет смысл).
  // Смена месяца/категории/кабинета scrollTop НЕ трогает нигде в этом файле —
  // #sheet-scroll переживает замену #pad.innerHTML и сам не сбрасывается (браузер),
  // так и остаёмся "на месте" для этих переключателей без единой строки кода.
  // _railScrollRoot() (не хардкод "sheet-scroll", ревью-блокер 3, фаза 2-3 эпика):
  // на узком экране (<1080px) #sheet-scroll уже не скролл-контейнер (task-main-98) —
  // его scrollTop всегда 0, реально скроллится документ (rail.js, _railScrollRoot()).
  const scroller = (typeof _railScrollRoot === "function") ? _railScrollRoot()
    : document.getElementById("sheet-scroll");
  if (scroller) scroller.scrollTop = 0;
  const q = new URLSearchParams(location.search);
  const prevCabinet = document.getElementById("cabinet-select").value;
  // category НЕ удаляется: срез липкий при смене домена (epic-main-19). date тоже НЕ
  // удаляется: период общий, переживает смену вкладки-домена (решение владельца
  // 2026-07-28, устойчиво липкие селекторы) — сервер сам вернёт 404, если периода нет
  // у нового домена, loadReport в shared.js откатится на последний доступный. unit —
  // legacy-параметр (юниты убраны), чистим бессрочно на случай старой закладки.
  q.set("domain", domain); q.delete("cabinet"); q.delete("unit");
  history.replaceState(null, "", location.pathname + "?" + q.toString());
  const category = q.getAll("category");
  const date = q.get("date");
  renderDomainSwitcher(domain);
  updateNavSub(domain);
  initSelector(domain, prevCabinet).then(() => {
    if (gen !== loadGen) return;  // домен переключили ещё раз, пока грузился список кабинетов
    const cab = document.getElementById("cabinet-select").value;
    // Кабинет резолвится внутри initSelector (тот же кабинет, если есть в новом домене,
    // иначе первый по списку) — записываем итог обратно в URL: адресная строка после
    // q.delete("cabinet") выше молчала про кабинет, и reload сразу после смены вкладки
    // терял его, даже когда шапка уже показывала верное значение.
    const qCab = new URLSearchParams(location.search);
    qCab.set("cabinet", cab);
    history.replaceState(null, "", location.pathname + "?" + qCab.toString());
    // await, а не «выстрелил и забыл»: категория могла не пройти валидацию по
    // справочнику нового домена, и запрос ушёл бы со срезом, которого уже нет в шапке.
    // return обязателен: иначе отказ этой цепочки минует внешний .catch и индикатор
    // загрузки залипнет навсегда.
    return initCategorySelector(cab, domain, date, category).then(() => {
      if (gen !== loadGen) return;
      loadReport(cab, domain, date, "", gen, selectedCategory(category));
    });
  }).catch(() => { if (gen === loadGen) setLoading(false); });  // иначе индикатор не погасить никогда
}

async function initSelector(domain, current) {
  const sel = document.getElementById("cabinet-select");
  sel.replaceChildren();
  let cabs = [];
  try {
    const resp = await fetchWithTimeout("/v1/mp-cockpit/cabinets?domain=" + encodeURIComponent(domain), {}, 60000);
    cabs = (resp.ok ? await resp.json() : {}).cabinets || [];
  } catch (e) { cabs = []; }
  if (cabs.length) {
    for (const c of cabs) sel.append(el("option", { value: c.cabinet }, c.cabinet));
    sel.value = cabs.some((c) => c.cabinet === current) ? current : cabs[0].cabinet;
  } else if (current) {
    sel.append(el("option", { value: current }, current));
  }
  const cabVal = document.getElementById("cabinet-val");
  if (cabVal) cabVal.textContent = sel.value;
  sel.onchange = () => {
    // Поколение берётся СРАЗУ (epic-main-19): между кликом по кабинету и запросом
    // отчёта теперь лежит round-trip справочника категорий, и без гарда запоздавшая
    // цепочка перекрыла бы отчёт домена, выбранного позже.
    const gen = bumpLoadGen();
    setLoading(true);
    if (cabVal) cabVal.textContent = sel.value;
    const q = new URLSearchParams(location.search);
    // category сбрасывается безусловно: смена кабинета — новый ассортимент, старый срез
    // категорий предметно не переносится (частичный разворот epic-main-19, решение
    // владельца 2026-07-28, harness:docs/decisions.md). date НЕ трогаем: период общий,
    // переживает смену кабинета — loadReport в shared.js откатится на последний
    // доступный, если у нового кабинета нет отчёта на эту дату.
    q.set("domain", domain); q.set("cabinet", sel.value); q.delete("category"); q.delete("unit");
    // location.hash сохраняется (мелочь ревью, фаза 2-3 эпика: якорь главы терялся
    // при смене кабинета) — тот же приём, что writeCategoryToUrl ниже.
    history.replaceState(null, "", location.pathname + "?" + q.toString() + location.hash);
    const date = q.get("date");
    initCategorySelector(sel.value, domain, date, []).then(() => {
      if (gen !== loadGen) return;
      loadReport(sel.value, domain, date, "", gen, []);
    }).catch(() => { if (gen === loadGen) setLoading(false); });
  };
}

// Селектор категории (epic-main-19) — общий код шапки, ни строки в доменных <d>.js.
// Срез ЛИПКИЙ при смене вкладки-домена (решение владельца 2026-07-22): значение
// переживает смену URL, а промах по справочнику нового домена реконсилирует сервер —
// syncCategorySelectorOptions (payload.meta.category_selection) молча подстраивает
// выбор под то, что реально доступно (словари категорий api- и file-кабинетов сегодня
// несопоставимы by-design — это дефект, а не норма; видимого баннера для этого случая
// сегодня нет, см. ревью sticky-selectors). При смене КАБИНЕТА срез сбрасывается на
// «Все категории» безусловно — частичный разворот решения 2026-07-22 (решение владельца
// 2026-07-28, harness:docs/decisions.md): новый ассортимент, старый срез категорий предметно не
// переносится.
const categoryPickerState = { options: [], selection: [], draft: [], context: null, bound: false };

function setCategoryPickerRequestContext(cabinet, domain, date, scope) {
  categoryPickerState.context = { cabinet: cabinet || "", domain: domain || "",
    date: date || "", scope: "" };
}

function normalizeCategoryValues(values) {
  const source = Array.isArray(values) ? values : (values ? [values] : []);
  return [...new Set(source.filter((value) => typeof value === "string" && value))];
}

function selectedCategory(fallback) {
  return categoryPickerState.selection.length ? categoryPickerState.selection : normalizeCategoryValues(fallback);
}

function syncCategoryLabel() {
  const value = document.getElementById("category-val");
  const trigger = document.getElementById("category-trigger");
  const selected = categoryPickerState.selection;
  let label = "Все категории";
  if (selected.length === 1) {
    const item = categoryPickerState.options.find((option) => option.value === selected[0]);
    label = item ? item.label : selected[0];
  } else if (selected.length > 1) label = selected.length + " категорий";
  if (value) value.textContent = label;
  if (trigger) trigger.title = label;
}

function writeCategoryToUrl(values) {
  const q = new URLSearchParams(location.search);
  q.delete("category");
  normalizeCategoryValues(values).forEach((value) => q.append("category", value));
  history.replaceState(null, "", location.pathname + "?" + q.toString() + location.hash);
}

function closeCategoryPicker() {
  const picker = document.getElementById("category-picker");
  const trigger = document.getElementById("category-trigger");
  if (!picker || picker.hidden) return;
  categoryPickerState.draft = [...categoryPickerState.selection];
  picker.hidden = true;
  if (trigger) trigger.setAttribute("aria-expanded", "false");
}

function renderCategoryPicker() {
  const picker = document.getElementById("category-picker");
  if (!picker) return;
  const active = categoryPickerState.options.filter((item) => item.availability === "available" && item.value);
  const inactive = categoryPickerState.options.filter((item) => item.availability === "empty" && item.value);
  picker.replaceChildren();
  const addCheckbox = (label, value, checked, onChange) => {
    const input = el("input", { type: "checkbox", value }); input.checked = checked;
    input.onchange = onChange;
    picker.append(el("label", { class: "tblpick-option" }, [input, document.createTextNode(label)]));
  };
  addCheckbox("Все категории", "", categoryPickerState.draft.length === 0, () => {
    categoryPickerState.draft = [];
    renderCategoryPicker();
  });
  for (const item of active) addCheckbox(item.label, item.value,
    categoryPickerState.draft.includes(item.value), (event) => {
      const next = new Set(categoryPickerState.draft);
      if (event.target.checked) next.add(item.value); else next.delete(item.value);
      categoryPickerState.draft = [...next];
      renderCategoryPicker();
    });
  if (inactive.length) {
    const toggle = el("button", { type: "button", class: "category-inactive-toggle", "aria-expanded": "false" }, "Неактивные: " + inactive.length);
    const list = el("div", { class: "category-inactive-list", hidden: "hidden" });
    inactive.forEach((item) => list.append(el("div", { class: "category-inactive-item" }, item.label)));
    toggle.onclick = () => { list.hidden = !list.hidden; toggle.setAttribute("aria-expanded", String(!list.hidden)); };
    picker.append(toggle, list);
  }
  const apply = el("button", { type: "button", class: "tblpick-apply" }, "Рассчитать");
  apply.onclick = () => {
    categoryPickerState.selection = normalizeCategoryValues(categoryPickerState.draft);
    writeCategoryToUrl(categoryPickerState.selection);
    syncCategoryLabel();
    const context = categoryPickerState.context || {};
    closeCategoryPicker();
    loadReport(context.cabinet || "", context.domain || "", context.date || "", "", undefined, categoryPickerState.selection);
  };
  picker.append(apply);
}

function positionCategoryPicker(picker, trigger) {
  const rect = trigger.getBoundingClientRect();
  const left = Math.max(8, Math.min(rect.right - picker.offsetWidth,
    window.innerWidth - picker.offsetWidth - 8));
  // Нижняя кромка (task-main-195, критерий 18): top раньше ставился
  // безусловно как rect.bottom+6 — .category-picker (max-height:420px)
  // уезжал за нижний край окна сильнее, чем меню фильтра колонки. Не
  // помещается снизу — переворачиваем вверх; не помещается и там —
  // прижимаем к верхней кромке тем же отступом, что и по горизонтали.
  // Симметрично _tblOpenFilterMenu в table-engine.js (Ось 4, одна причина,
  // два потребителя).
  const h = picker.offsetHeight;
  const fitsBelow = rect.bottom + 6 + h <= window.innerHeight - 8;
  const top = fitsBelow ? rect.bottom + 6 : Math.max(8, rect.top - h - 6);
  picker.style.left = left + "px";
  picker.style.top = top + "px";
}

function openCategoryPicker() {
  const picker = document.getElementById("category-picker");
  const trigger = document.getElementById("category-trigger");
  if (!picker || !trigger) return;
  // Inline-спека унификации: (1) главы отчёта не затрагиваются; (2) общий
  // app.js обслуживает все домены; (3) выбор категории и URL одинаковы во всех
  // кабинетах. Портал снимает только clipping родительской панели.
  if (picker.parentElement !== document.body) document.body.append(picker);
  categoryPickerState.draft = [...categoryPickerState.selection];
  renderCategoryPicker();
  picker.hidden = false;
  positionCategoryPicker(picker, trigger);
  trigger.setAttribute("aria-expanded", "true");
}

async function initCategorySelector(cabinet, domain, date, current) {
  categoryPickerState.context = { cabinet, domain, date, scope: "" };
  categoryPickerState.selection = normalizeCategoryValues(current);
  syncCategoryLabel();
  const trigger = document.getElementById("category-trigger");
  if (!trigger || categoryPickerState.bound) return;
  categoryPickerState.bound = true;
  trigger.onclick = () => document.getElementById("category-picker").hidden ? openCategoryPicker() : closeCategoryPicker();
  document.addEventListener("keydown", (event) => { if (event.key === "Escape") closeCategoryPicker(); });
  document.addEventListener("pointerdown", (event) => {
    const host = document.getElementById("category-pill");
    const picker = document.getElementById("category-picker");
    if (host && picker && !host.contains(event.target) && !picker.contains(event.target)) closeCategoryPicker();
  });
  // Симметрично _tblBindMenuDismissOnce в table-engine.js (task-main-195,
  // регресс, владелец 18.08: "при попытке скролла любым способом она
  // закрывается", Ось 4 — одна причина, два потребителя): scroll на window
  // с capture:true ловит любую прокрутку в документе, включая прокрутку
  // ВНУТРИ самого пикера (.category-picker имеет overflow:auto — при
  // большом словаре категорий список реально прокручивается). contains()
  // отличает свою прокрутку от чужой по e.target.
  window.addEventListener("scroll", (e) => {
    const picker = document.getElementById("category-picker");
    const t = e.target;
    if (picker && t instanceof Node && picker.contains(t)) return;
    closeCategoryPicker();
  }, true);
}

function setCategoryPickerAvailability(available) {
  const host = document.getElementById("category-pill");
  if (host) host.hidden = !available;
  if (available) return;
  closeCategoryPicker();
  categoryPickerState.options = [];
  categoryPickerState.selection = [];
  categoryPickerState.draft = [];
  writeCategoryToUrl([]);
}

function categoryPickerContextFromUrl() {
  const query = new URLSearchParams(location.search);
  return {
    cabinet: query.get("cabinet") || "",
    domain: query.get("domain") || "",
    date: query.get("date") || "",
    scope: "",
  };
}
function syncCategorySelectorOptions(payload) {
  const meta = (payload && payload.meta) || {};
  const available = meta.category_picker_available !== false;
  setCategoryPickerAvailability(available);
  if (!available || !Array.isArray(meta.category_options)) return;
  categoryPickerState.options = meta.category_options;
  const selection = meta.category_selection || { mode: "all", values: [] };
  categoryPickerState.selection = selection.mode === "selected" ? normalizeCategoryValues(selection.values) : [];

  const previous = categoryPickerState.context || {};
  const fromUrl = categoryPickerContextFromUrl();
  categoryPickerState.context = {
    cabinet: meta.cabinet || previous.cabinet || fromUrl.cabinet,
    domain: meta.domain || previous.domain || fromUrl.domain,
    date: previous.date || fromUrl.date,
    scope: "",
  };

  syncCategoryLabel();
  if (!document.getElementById("category-picker").hidden) renderCategoryPicker();
}
function notifySliceReset(message) {
  // НЕ в #pad: renderReport перезаписывает его целиком (renderSkeleton), и плашка
  // исчезала бы через доли секунды — «видимый сброс» оказался бы молчаливым.
  // Вставляется ПЕРЕД #pad (пункт 7 ревью task-main-96): .sheet.prepend() клал
  // плашку НАД accent-top/брендом, встык к краям листа — теперь она стоит вровень
  // с содержимым, там же, где раньше лежала внутри .nav-bar (боковые отступы —
  // .slice-reset в styles.css, те же, что у .pad). Общий баннер-хелпер: принимает готовый
  // текст, переиспользуется и для fallback периода в loadReport (shared.js).
  const pad = document.getElementById("pad");
  const host = (pad && pad.parentNode) || document.querySelector(".sheet") || document.body;
  const n = el("div", { class: "slice-reset" }, message);
  if (pad) host.insertBefore(n, pad); else host.prepend(n);
  setTimeout(() => n.remove(), 8000);
}

async function init() {
  if (window.__MOCK_PAYLOAD__ && window.__MOCK_DOMAIN__) {
    renderReport(window.__MOCK_PAYLOAD__, window.DOMAINS[window.__MOCK_DOMAIN__]);
    return;
  }
  const q = new URLSearchParams(location.search);
  const first = Object.keys(window.DOMAINS)[0];
  const domain = window.DOMAINS[q.get("domain")] ? q.get("domain") : first;
  const cabinet = q.get("cabinet");
  const date = q.get("date");
  if (q.has("unit")) {
    q.delete("unit");
    history.replaceState(null, "", location.pathname + "?" + q.toString() + location.hash);
  }
  const category = q.getAll("category");
  renderDomainSwitcher(domain);
  updateNavSub(domain);
  await initSelector(domain, cabinet);
  const cab = document.getElementById("cabinet-select").value || cabinet;
  await initCategorySelector(cab, domain, date, category);
  // Значение селектора, а не сырой URL: категория могла не пройти валидацию по
  // справочнику этого кабинета и быть сброшена (epic-main-19, спека §3).
  loadReport(cab, domain, date, "", undefined, category);
}

if (window.__REPORT_AUTO_INIT__ !== false) {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
}
