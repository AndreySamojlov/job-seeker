"use strict";

// Общий рендерер графиков: спека + сырая серия payload → конфиг Chart.js.
// Ноль знаний о домене. Грузится после chart.umd.js, core.js, chart-guard.js.
// chartConfig/COLOR_BY — чистые (Node-тестируемы); renderCharts — монтаж (Task 5).

const CH = {
  petrol: "#0E5C58", terra: "#C2410C", ochre: "#B45309", gold: "#D2A878",
  grass: "#15803D", grey: "#BDB8AD", hair: "#E7E5E0", slate: "#87847C",
};

if (typeof Chart !== "undefined") {
  Chart.defaults.font.family = "'Golos Text',sans-serif";
  Chart.defaults.color = "#6F6C65";
}

// Плагин «мостики» водопада: пунктир от верха ступени к началу следующей, на
// уровне running-итога. Читает options.plugins.waterfallBridges={carries,on}.
if (typeof Chart !== "undefined" && Chart.register) {
  Chart.register({
    id: "waterfallBridges",
    afterDatasetsDraw(chart) {
      const cfg = chart.options.plugins && chart.options.plugins.waterfallBridges;
      if (!cfg || !cfg.on || !cfg.carries) return;
      const meta = chart.getDatasetMeta(0);
      const yScale = chart.scales.y;
      if (!meta || !yScale) return;
      const ctx = chart.ctx;
      ctx.save();
      ctx.strokeStyle = "#A8A39A";
      ctx.lineWidth = 1.4;
      ctx.setLineDash([4, 3]);
      for (let i = 0; i < cfg.carries.length; i++) {
        const a = meta.data[i], b = meta.data[i + 1];
        if (!a || !b) continue;
        const yy = yScale.getPixelForValue(cfg.carries[i]);
        ctx.beginPath();
        ctx.moveTo(a.x + (a.width || 0) / 2, yy);
        ctx.lineTo(b.x - (b.width || 0) / 2, yy);
        ctx.stroke();
      }
      ctx.restore();
    },
  });
}

// Плагин крестовины осей scatter-квадранта: пунктирные линии на x=center.x и
// y=center.y поверх точек. Читает options.plugins.quadrantCrosshair={center,on}.
if (typeof Chart !== "undefined" && Chart.register) {
  Chart.register({
    id: "quadrantCrosshair",
    afterDatasetsDraw(chart) {
      const cfg = chart.options.plugins && chart.options.plugins.quadrantCrosshair;
      if (!cfg || !cfg.on || !cfg.center) return;
      const xScale = chart.scales.x, yScale = chart.scales.y;
      if (!xScale || !yScale) return;
      const { left, right, top, bottom } = chart.chartArea;
      const ctx = chart.ctx;
      ctx.save();
      ctx.strokeStyle = "#A8A39A";
      ctx.lineWidth = 1.2;
      ctx.setLineDash([4, 3]);
      const px = xScale.getPixelForValue(cfg.center.x);
      if (px >= left && px <= right) {
        ctx.beginPath(); ctx.moveTo(px, top); ctx.lineTo(px, bottom); ctx.stroke();
      }
      const py = yScale.getPixelForValue(cfg.center.y);
      if (py >= top && py <= bottom) {
        ctx.beginPath(); ctx.moveTo(left, py); ctx.lineTo(right, py); ctx.stroke();
      }
      ctx.restore();
    },
  });
}

// Плагин опорных линий (task-main-199, §4 спеки controls-design): замена
// dataset-линии (refDatasets ниже, оставлена для line-кодировки, у которой
// ориентации нет и менять нечего). Прежде refs рисовались датасетом-line и
// потому ПРОПУСКАЛИСЬ в hbar (horizontal ? [] : refDatasets(...)) — плагин
// читает готовые по-категориям точки (data, та же форма, что строил
// refDatasets: скаляр -> константа по всем x, fromSeries -> по series) и
// рисует ломаную по пиксельным координатам catAxis/valAxis — работает в
// ЛЮБОЙ ориентации (значения valAxis — как раз то, что "переезжает" при
// смене ориентации, catAxis/valAxis приходят из chartConfig уже с учётом
// opts.orientation). Подпись — в легенде (генерируется в chartConfig), не
// плагином. options.plugins.refMarks = {refs:[{data,label}], catAxis, valAxis, on}.
if (typeof Chart !== "undefined" && Chart.register) {
  Chart.register({
    id: "refMarks",
    afterDatasetsDraw(chart) {
      const cfg = chart.options.plugins && chart.options.plugins.refMarks;
      if (!cfg || !cfg.on || !cfg.refs || !cfg.refs.length) return;
      const catScale = chart.scales[cfg.catAxis];
      const valScale = chart.scales[cfg.valAxis];
      if (!catScale || !valScale) return;
      const ctx = chart.ctx;
      ctx.save();
      // Клип по области графика (правка 1 ревью epic-main-31, часть 2):
      // refs больше не датасет — их значения не участвуют в авторасчёте
      // диапазона шкалы (см. suggestedMax/Min ниже, в bar|hbar-ветке
      // chartConfig), поэтому опора ВЫШЕ максимума данных (или обрезанного
      // оверлеем no-outlier scales.y.max) без клипа рисуется НАД холстом,
      // поверх шапки/легенды.
      ctx.beginPath();
      ctx.rect(chart.chartArea.left, chart.chartArea.top, chart.chartArea.width, chart.chartArea.height);
      ctx.clip();
      ctx.strokeStyle = CH.petrol;
      ctx.lineWidth = 1.4;
      ctx.setLineDash([4, 4]);
      cfg.refs.forEach((ref) => {
        const data = ref.data || [];
        ctx.beginPath();
        let started = false;
        data.forEach((v, i) => {
          // null обрывает путь (новый moveTo на следующей точке), а не
          // просто пропускается — иначе соседняя точка склеивается lineTo
          // ПРЯМО через дыру (правка 3, найдена оркестратором: удалённый
          // dataset-предшественник нёс spanGaps:false, разрыв рисовался как
          // разрыв; живой пример — refs=[{fromSeries:"plan"}] на кодировке с
          // категорией без объявленного плана, значение null в этой позиции).
          if (v == null) { started = false; return; }
          const cp = catScale.getPixelForValue(i);
          const vp = valScale.getPixelForValue(v);
          const x = cfg.valAxis === "x" ? vp : cp;
          const y = cfg.valAxis === "x" ? cp : vp;
          if (!started) { ctx.moveTo(x, y); started = true; } else { ctx.lineTo(x, y); }
        });
        if (started) ctx.stroke();
      });
      ctx.restore();
    },
  });
}

// Цвета баров по правилу spec.colorBy. values — y главной серии; series — вся серия
// (нужна completion для светофора).
const COLOR_BY = {
  neutral: (vals) => vals.map(() => CH.petrol),
  sign: (vals) => vals.map((v) => (v == null ? CH.grey : (v < 0 ? CH.terra : CH.petrol))),
  // Маржа %: <0 терра, <10% золото, иначе петроль (значения — доли).
  marginPct: (vals) => vals.map((v) =>
    (v == null ? CH.grey : (v < 0 ? CH.terra : (v < 0.10 ? CH.gold : CH.petrol)))),
  // Светофор выполнения по series.completion (доли); иначе по самим значениям-долям.
  // Инвариант: ожидает доли (0..1). Сырые значения (qty) дадут ложный «выполнено».
  completion: (vals, series) => {
    const c = (series && series.completion) || vals;
    return c.map((v) => (v == null ? CH.grey
      : (v < 0.8 ? CH.terra : (v >= 1.0 ? CH.petrol : CH.gold))));
  },
  // P&L: последний бар (маржа) — по знаку, остальные — золото.
  pnl: (vals) => vals.map((v, i) =>
    (i === vals.length - 1 ? (v < 0 ? CH.terra : CH.petrol) : CH.gold)),
};

// Форматтер значений оси/тултипа по единице измерения.
function unitFmt(unit) {
  if (unit === "pct") return (v) => nf.format(v * 100) + "%";
  if (unit === "rub") return (v) => fmtCompact(v) + " ₽";
  return (v) => fmtCompact(v);  // qty
}

// Точный форматтер тултипов (в отличие от компактного unitFmt для осей).
function unitFmtPrecise(unit) {
  if (unit === "pct") return (v) => fmtPct(v);
  if (unit === "rub") return (v) => fmt(v) + " ₽";
  return (v) => fmt(v);  // qty
}

// Обрезка подписи категории по БЮДЖЕТУ СИМВОЛОВ (budget, по умолчанию 20 —
// бюджет карточки), а не по числу слов (правка ревью epic-main-31: обрезка
// до 1 слова калибровалась на Коммерции («Спортивные товары для дома») —
// на шести непилотных доменах категориальная ось несёт бакеты/статьи, и
// однословная обрезка делает соседние бары неразличимыми: «ДРР < 10%» и
// «ДРР 10-20%» оба схлопывались в «ДРР…»). budget = Infinity → без обрезки
// (развёрнутый режим, см. _chartConfigFull). Бюджет приходит из
// chartConfig(opts), не читается из глобали — функция остаётся чистой и
// Node-тестируемой (§1 спеки controls-design).
//
// Рез — по границе слова: наибольшее число целых слов, влезающее в бюджет
// (место под «…» зарезервировано заранее — иначе «Прочие удержания sku» при
// budget=20 прошло бы целиком, хотя с «…» вылезает за рамку), плюс
// многоточие. В середину слова режем ТОЛЬКО если само первое слово длиннее
// бюджета. Подпись, укладывающаяся в бюджет целиком, — без многоточия.
//
// .trim() обязателен ДО разбора: клиентские .xlsb нередко дают подписи с
// ведущим пробелом — без trim первый токен String(s).split(/\s+/) пуст, и
// подпись схлопывается в голое «…».
//
// Защита от нуля: budget <= 0 не должен давать пустую подпись — минимум
// показываем первую букву + «…», а не пустую строку.
function shortLabel(s, budget) {
  const str = String(s == null ? "" : s).trim();
  if (!str) return "";
  let b = budget == null ? 20 : budget;
  if (b === Infinity) return str;
  if (b <= 0) b = 2;
  if (str.length <= b) return str;
  const room = b - 1;  // символ, зарезервированный под «…»
  const words = str.split(/\s+/);
  let out = "";
  for (const w of words) {
    const candidate = out ? out + " " + w : w;
    if (candidate.length <= room) out = candidate; else break;
  }
  if (!out) out = words[0].slice(0, Math.max(room, 0));
  return out + "…";
}

// Тики категориальной оси: подпись по shortLabel(budget), либо гашение
// ЦЕЛИКОМ, когда noLabels истинно (task-main-200, §1/§3 спеки controls-
// design: товарная грань держит до 150-300 позиций, и сто пятьдесят
// однословных подписей нечитаемы в любом размере шрифта — товар опознаётся
// тултипом, где имя идёт полностью, data.labels при этом НЕ трогаются).
// extra — доп. поля тиков (font/maxRotation/minRotation/autoSkip/…). Pure.
function _catTicksOpts(extra, budget, noLabels) {
  if (noLabels) return { display: false };
  return Object.assign({}, extra,
    { callback: function (v) { return shortLabel(this.getLabelForValue(v), budget); } });
}

// Плотность категорий гасит скругление углов и потолок толщины бара (правка 6
// ревью epic-main-31, риск 4 спеки controls-design: товарная грань держит до
// 150 позиций на карточке / 300 в развёрнутом — при типичной ширине главного
// слота это 2-6px на бар, и borderRadius/maxBarThickness визуально съедают
// полоску целиком). Порог 40 — эмпирический: ниже него даже мини-слот
// (~260px) даёт заметную толщину бара, где скругление 3-5px ещё читается;
// выше — визуальный шум, а не украшение. Обычные (нетоварные) графики с
// дефолтным guard.overflow=8 порог не задевают — свёртка «Прочие» держит их
// далеко от 40 категорий. Возвращает {borderRadius, maxBarThickness} —
// undefined у maxBarThickness Chart.js читает как «без потолка». Pure.
const BAR_DENSITY_THRESHOLD = 40;
function barDensity(n, radius, thickness) {
  return (n || 0) > BAR_DENSITY_THRESHOLD
    ? { borderRadius: 0, maxBarThickness: undefined }
    : { borderRadius: radius, maxBarThickness: thickness };
}

// Трёхпозиционный порядок индексов сортировки (task-main-199, АС4 §4 спеки
// controls-design): default (исходный) -> asc (по возрастанию) -> desc (по
// убыванию), по РЕАЛЬНОЙ величине (не по модулю — в отличие от ретайренного
// двухпозиционного sortOrder из chart-overlays.js, который сравнивал |v| для
// P&L-знака; новые подписи "по возрастанию/по убыванию" читаются буквально).
// null/undefined в ряду — как 0 (не должны ронять сравнение). Pure.
function sortOrder3(y, mode) {
  const order = (y || []).map((_, i) => i);
  if (mode === "asc") order.sort((a, b) => (y[a] || 0) - (y[b] || 0));
  else if (mode === "desc") order.sort((a, b) => (y[b] || 0) - (y[a] || 0));
  return order;
}

// Применить порядок индексов к произвольному массиву. order===null (режим
// "default"/не объявлен) -> массив как есть, без копии. Pure.
function _permute(arr, order) { return order ? order.map((i) => arr[i]) : arr; }

// Липкое состояние органов развёрнутого режима (chv:<домен>:<id>:orient|sort,
// §4 спеки — тот же префикс/паттерн, что sessionStorage у оверлеев). allowed —
// белый список значений: испорченное/чужого формата значение в sessionStorage
// не должно молча просочиться в chartConfig. Не DOM-safe вне try (sessionStorage
// недоступна в приватных вкладках/Node) — как и остальные sessionStorage-чтения
// движка.
function _readSticky(key, allowed, fallback) {
  try {
    const v = sessionStorage.getItem(key);
    if (allowed.indexOf(v) >= 0) return v;
  } catch (e) { /* noop */ }
  return fallback;
}

// hex (#RRGGBB) → "rgba(r,g,b,a)". Точечным графикам нужна альфа для наложения
// точек; заливка line-encoding (fillOpacity) — тоже через неё.
function hexAlpha(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return "rgba(" + ((n >> 16) & 255) + "," + ((n >> 8) & 255) + "," + (n & 255) + "," + a + ")";
}

// Hover-подсветка бара -- ПРОИЗВОДНАЯ от собственного цвета бара (alpha-блендинг
// со светлым фоном страницы -- сайт светлый, --sheet:#FFFFFF, тёмной темы нет;
// alpha ОСВЕТЛЯЕТ бар к белому на 28%, не затемняет), не литерал: colorBy
// красит бары по-разному (sign/marginPct/completion/pnl -- красный=минус
// и т.п.), единый hoverBackgroundColor стёр бы этот сигнал при наведении
// (прожарка 2026-08-21). 0.72 подобрано визуально, не выводится из формулы.
function _hoverFill(hex) { return hexAlpha(hex, 0.72); }

function _baseScales(unit, horizontal) {
  const fmt = unitFmt(unit);
  const valAxis = { grid: { color: CH.hair }, border: { display: false },
    ticks: { callback: (v) => fmt(v) } };
  const catAxis = { grid: { display: false }, border: { color: CH.hair },
    ticks: { font: { size: 11 } } };
  return horizontal ? { x: valAxis, y: catAxis } : { x: catAxis, y: valAxis };
}

// Разрешить spec.refs в {label, data} — data параллелен labels (скаляр value →
// константа по всем x; fromSeries → по точкам series[fromSeries]). Общая точка
// для refDatasets (line, ниже) и refMarks-плагина (bar|hbar, любая ориентация,
// см. _chartConfigFull). Pure.
function _resolveRefData(spec, series) {
  const refs = (spec && spec.refs) || [];
  const labels = series.x || [];
  return refs.map((r) => ({
    label: r.label || "",
    data: (r.fromSeries && series[r.fromSeries]) ? series[r.fromSeries] : labels.map(() => r.value),
  }));
}

// refs → dataset-линии. Используется ТОЛЬКО кодировкой line (ориентации не
// имеет — менять на плагин незачем); bar|hbar перешли на refMarks-плагин
// (task-main-199 — раньше эта функция звалась и оттуда, и там же
// пропускалась в горизонтали: horizontal ? [] : refDatasets(...)).
function refDatasets(spec, series) {
  return _resolveRefData(spec, series).map((r) => ({
    type: "line", label: r.label, data: r.data, borderColor: CH.petrol,
    borderWidth: 1, borderDash: [4, 4], pointRadius: 0, fill: false,
    spanGaps: false, order: -1,
  }));
}

// Мини-режим: гасим оси/легенду/тултипы/точки, цвета (colorBy) сохраняем — здоровье видно.
// Пост-пасс над generic-формой конфига Chart.js (стабильна для всех кодировок).
function miniifyConfig(cfg) {
  cfg.options.plugins = cfg.options.plugins || {};
  cfg.options.plugins.legend = { display: false };
  cfg.options.plugins.tooltip = { enabled: false };
  const scales = cfg.options.scales || {};
  for (const k of Object.keys(scales)) {
    const ax = scales[k];
    ax.ticks = Object.assign({}, ax.ticks, { display: false });
    ax.grid = Object.assign({}, ax.grid, { display: false });
    ax.border = Object.assign({}, ax.border, { display: false });
  }
  cfg.data.datasets.forEach((d) => {
    if (d.borderWidth) d.borderWidth = Math.min(d.borderWidth, 1.5);
    if ("pointRadius" in d) d.pointRadius = 0;
  });
  return cfg;
}

// Главный билдер: spec + series → конфиг Chart.js. opts.mini → упрощённая мини-версия. Pure.
function chartConfig(spec, series, meta, opts) {
  const cfg = _chartConfigFull(spec, series, meta, opts);
    if (opts && opts.mini) {
      miniifyConfig(cfg);
      if (spec.encoding === "date-scatter") cfg.data.datasets.forEach(ds => {ds.pointRadius = 2;});
    }
    return cfg;
}

// Полный билдер по кодировке. Pure.
function _chartConfigFull(spec, series, meta, opts) {
  const labels = series.x || [];
  const enc = spec.encoding;
  const fmtP = unitFmtPrecise(spec.unit);  // точный форматтер тултипов
  // Бюджет символов подписи категориальной оси: карточка режет до 20, развёрнутый
  // режим (opts.expanded) показывает подпись целиком (§1 спеки controls-design,
  // правка 1 ревью epic-main-31 — бюджет символов, не число слов).
  const catBudget = (opts && opts.expanded) ? Infinity : 20;
  // Товарная грань (task-main-200): spec.labels === false гасит тики
  // категориальной оси целиком, независимо от expanded/бюджета.
  const noLabels = spec.labels === false;

  if (enc === "line") {
    // Area (обогащение движка находками shadcn/charts, 2026-08-21): fill_opacity
    // настраиваемый (дефолт 0.05 из типа -- пиксель-в-пиксель прежний хардкод).
    // dots_below_ref: точка факта красится в CH.terra, когда факт ушёл ниже
    // ВТОРОЙ серии (обычно тёмп плана/тренд); молча не действует при <2
    // сериях или null-значении (нет референса для сравнения). Флаг общий для
    // любого line-графика -- рендерер не знает, у какого именно домена он включён.
    const fillOpacity = spec.fillOpacity != null ? spec.fillOpacity : 0.05;
    const refSeries = (spec.dotsBelowRef && series.series.length > 1) ? series.series[1] : null;
    const petrolFirst = (s, i) => ({
      label: s.name, data: s.y,
      borderColor: i === 0 ? CH.petrol : CH.grey,
      borderDash: i === 0 ? [] : [5, 4],
      backgroundColor: i === 0 ? hexAlpha(CH.petrol, fillOpacity) : "transparent",
      fill: i === 0, tension: 0.3, borderWidth: i === 0 ? 2.5 : 2,
      pointRadius: i === 0 ? 3 : 0,
      pointBackgroundColor: (i === 0 && refSeries)
        ? (ctx) => {
            // ctx.dataset.data -- ЖИВОЙ датасет (учитывает мутации оверлеев,
            // напр. cumulative переписывает datasets[0].data накопительным
            // рядом); s.y -- снимок сборки конфига, для точки-индикатора
            // не годится (рассинхрон факт vs накопленный ряд).
            const idx = ctx.dataIndex;
            const fact = ctx.dataset.data[idx], plan = refSeries.y[idx];
            return (fact != null && plan != null && fact < plan) ? CH.terra : CH.petrol;
          }
        : CH.petrol,
    });
    return {
      type: "line",
      data: { labels: labels,
        datasets: series.series.map(petrolFirst).concat(refDatasets(spec, series)) },
      options: { responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: "bottom",
          labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true, padding: 14 } },
          tooltip: { callbacks: { label: (c) => c.dataset.label + ": " + fmtP(c.parsed.y) } } },
        scales: _baseScales(spec.unit, false) },
    };
  }

  if (enc === "grouped-bar") {
    // Серийная палитра (colorBy не применяется); опц. combo-линия — на 2-й оси.
    // opts.orientation (АС4, task-main-199): нативная — вертикаль; "h" переводит
    // столбики в горизонталь — indexAxis + раскладка catAxis/valAxis (как уже
    // делает _baseScales для bar/hbar), а 2-я ось комбо-линии переезжает
    // y1 -> x1 (спека §4: "тихо терять величину при повороте нельзя").
    const combo = spec.combo || null;
    const palette = [CH.petrol, CH.gold, CH.slate, CH.terra, CH.grass];
    const barSeries = [], lineSeries = [];
    series.series.forEach((s) => {
      if (combo && s.name === combo.line) lineSeries.push(s); else barSeries.push(s);
    });
    const horizontal = !!(opts && opts.orientation === "h");
    // Сортировка (opts.sortMode): опорный ряд — сумма БАРНЫХ серий на позиции
    // (комбо-линия — другая единица измерения, в опору не входит). Порядок —
    // общий для labels + барных, И линейных датасетов: комбо/план едут с
    // категориями, иначе визуальная связка бар↔точка разъедется.
    let lbls = labels;
    let barSeriesR = barSeries, lineSeriesR = lineSeries;
    const sortMode = opts && opts.sortMode;
    if (sortMode && sortMode !== "default") {
      const ref = labels.map((_, i) => barSeries.reduce((s, se) => s + (se.y[i] || 0), 0));
      const order = sortOrder3(ref, sortMode);
      lbls = _permute(labels, order);
      barSeriesR = barSeries.map((se) => ({ name: se.name, y: _permute(se.y, order) }));
      lineSeriesR = lineSeries.map((se) => ({ name: se.name, y: _permute(se.y, order) }));
    }
    const dens = barDensity(lbls.length, 3, 34);
    const datasets = barSeriesR.map((s, i) => ({
      label: s.name, data: s.y, backgroundColor: palette[i % palette.length],
      hoverBackgroundColor: _hoverFill(palette[i % palette.length]),
      borderRadius: dens.borderRadius, maxBarThickness: dens.maxBarThickness,
      categoryPercentage: 0.62, barPercentage: 1.0,
    }));
    const lineUnit = (combo && combo.line_unit) || "pct";
    const fmtLineP = unitFmtPrecise(lineUnit);
    const secondAxisId = horizontal ? "x1" : "y1";
    lineSeriesR.forEach((s) => {
      const ds = { type: "line", label: s.name, data: s.y,
        borderColor: CH.slate, backgroundColor: CH.slate, borderDash: [5, 4],
        borderWidth: 2, pointRadius: 2.5, pointBackgroundColor: CH.slate,
        tension: 0.25, fill: false, order: -1 };
      ds[horizontal ? "xAxisID" : "yAxisID"] = secondAxisId;
      datasets.push(ds);
    });
    const catTicks = _catTicksOpts({ font: { size: 10 }, autoSkip: false }, catBudget, noLabels);
    const scales = _baseScales(spec.unit, horizontal);
    (horizontal ? scales.y : scales.x).ticks = catTicks;
    if (lineSeriesR.length) {
      const fmtLine = unitFmt(lineUnit);
      scales[secondAxisId] = { position: horizontal ? "top" : "right", suggestedMin: 0,
        grid: { display: false }, border: { display: false }, ticks: { callback: (v) => fmtLine(v) } };
    }
    return {
      type: "bar",
      data: { labels: lbls, datasets: datasets },
      options: { indexAxis: horizontal ? "y" : "x", responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: "bottom",
            labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true, padding: 12 } },
          tooltip: { callbacks: { label: (c) => {
            const isLine = c.dataset.yAxisID === "y1" || c.dataset.xAxisID === "x1";
            const val = horizontal ? c.parsed.x : c.parsed.y;
            return c.dataset.label + ": " + (isLine ? fmtLineP(val) : fmtP(val));
          } } } },
        scales: scales },
    };
  }

  if (enc === "sqrt-stack") {
    // Сплит план/вне-плана: стэк на √-шкале (p=0.5) — крупные категории заметно выше,
    // мелкие не исчезают; подписи оси — в исходных штуках, позиции — по √. Линия плана
    // из series.plan; светофор низа — по series.completion. Тултипы точные (core.js
    // fmt/fmtPct), не компактные. Кодировка самодостаточна: редакционная легенда/тултип
    // завязаны на семантику completion (вынести в спеку — хвост Ф2, TD-25).
    const t = (v) => Math.sqrt(Math.max(v || 0, 0));
    let lbls = labels;
    let planned = (series.series[0] && series.series[0].y) || [];
    let unplanned = (series.series[1] && series.series[1].y) || [];
    let plan = series.plan || [];
    let comp = series.completion || [];
    const names = series.series.map((s) => s.name);
    // Сортировка (АС4, task-main-199): «по сумме стека» (спека §4) — В
    // ИСХОДНЫХ штуках, ДО √-трансформации: sqrt(a)+sqrt(b) не эквивалентен
    // по ранжированию sqrt(a+b) (напр. 16/0 и 4/4 дают РАЗНУЮ сумму 16 vs 8,
    // но РАВНУЮ sqrt-сумму 4+0 vs 2+2 — сортировка по трансформированным
    // значениям молча перепутала бы порядок). План-линия и светофор
    // выполнения едут вместе с категориями — переставляем ДО вычисления
    // botColor/tot, дальше код веток не меняется.
    const sortMode = opts && opts.sortMode;
    if (sortMode && sortMode !== "default") {
      const totRaw = planned.map((p, i) => (p || 0) + (unplanned[i] || 0));
      const order = sortOrder3(totRaw, sortMode);
      lbls = _permute(labels, order);
      planned = _permute(planned, order);
      unplanned = _permute(unplanned, order);
      plan = _permute(plan, order);
      comp = _permute(comp, order);
    }
    const tot = planned.map((p, i) => (p || 0) + (unplanned[i] || 0));
    const botColor = comp.map((c) =>
      (c == null ? CH.grey : (c < 0.8 ? CH.terra : (c >= 1 ? CH.petrol : CH.gold))));
    const maxRaw = Math.max(0, ...tot);
    const maxT = t(maxRaw);
    // «Круглый» шаг подписей оси в исходных штуках (~5 делений), позиции — по √.
    const rawStep = (() => {
      const r = maxRaw / 5 || 1;
      const mag = Math.pow(10, Math.floor(Math.log10(r)));
      const k = r / mag;
      return (k <= 1 ? 1 : k <= 2 ? 2 : k <= 2.5 ? 2.5 : k <= 5 ? 5 : 10) * mag;
    })();
    // Легенда: берём из spec.legend (редакционный текст/цвета из спеки),
    // иначе — дефолтные 4 тира светофора (фоллбэк для обратной совместимости).
    const legendItems = (spec.legend && spec.legend.length)
      ? spec.legend.map((L) => ({ text: L.text, fillStyle: L.color, strokeStyle: L.color }))
      : [
          { text: "Невыполнение", fillStyle: CH.terra, strokeStyle: CH.terra },
          { text: "Близко к плану", fillStyle: CH.gold, strokeStyle: CH.gold },
          { text: "Выполнение", fillStyle: CH.petrol, strokeStyle: CH.petrol },
          { text: "Вне плана", fillStyle: CH.grey, strokeStyle: CH.grey },
        ];
    const densStack = barDensity(lbls.length, 3, 30);
    return {
      type: "bar",
      data: { labels: lbls, datasets: [
        { label: names[0] || "Плановые SKU", data: planned.map((p) => t(p)),
          backgroundColor: botColor, stack: "s",
          borderRadius: densStack.borderRadius, maxBarThickness: densStack.maxBarThickness },
        { label: names[1] || "Вне плана", data: planned.map((p, i) => t(tot[i]) - t(p)),
          backgroundColor: CH.grey, stack: "s",
          borderRadius: densStack.borderRadius, maxBarThickness: densStack.maxBarThickness },
        { type: "line", label: "План", data: plan.map((p) => (p == null ? null : t(p))),
          borderColor: CH.petrol, borderWidth: 2, borderDash: [5, 4], pointRadius: 2,
          pointBackgroundColor: CH.petrol, fill: false, spanGaps: false } ] },
      options: { responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: "bottom", onClick: () => {},
            labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true, padding: 12,
              generateLabels: () => legendItems } },
          tooltip: { callbacks: { label: (c) => {
            const i = c.dataIndex;
            if (c.dataset.type === "line") return "План: " + fmt(plan[i]);
            if (c.datasetIndex === 0) return "План. SKU: " + fmt(planned[i])
              + (comp[i] != null ? " (вып. " + fmtPct(comp[i]) + ")" : "");
            return "Вне плана: " + fmt(unplanned[i]) + " · всего " + fmt(tot[i]);
          } } } },
        scales: {
          x: { stacked: true, grid: { display: false }, border: { color: CH.hair },
            ticks: _catTicksOpts({ font: { size: 10 }, maxRotation: 60, minRotation: 45 },
              catBudget, noLabels) },
          y: { stacked: true, min: 0, max: maxT * 1.05,
            grid: { color: CH.hair }, border: { display: false },
            afterBuildTicks: (axis) => {
              const ticks = [];
              for (let rv = 0; rv <= maxRaw + 1e-6; rv += rawStep) ticks.push({ value: t(rv) });
              axis.ticks = ticks;
            },
            ticks: { autoSkip: false, callback: (v) => nf.format(Math.round(v * v)) } } } },
    };
  }

  if (enc === "waterfall") {
    const vals = series.series[0].y;
    const totals = (spec.waterfall && spec.waterfall.totals) || [];
    const set = new Set(totals);
    // Финальный итог (по знаку: грасс/терра) — последний опорный столбец.
    // Контракт: totals задаётся по возрастанию, поэтому последний элемент = последний бар.
    const lastTotal = totals.length ? totals[totals.length - 1] : -1;
    const bars = waterfallBars(vals, totals);
    // Уровни running-итога между баром i и i+1 (для мостиков): опора → верх, ступень → низ.
    const carries = bars.slice(0, -1).map((b) => (b.delta ? b.range[0] : b.range[1]));
    const colors = bars.map((b, i) => {
      if (b.delta) return CH.terra;
      return i === lastTotal ? (vals[i] < 0 ? CH.terra : CH.grass) : CH.slate;
    });
    const scales = _baseScales(spec.unit, false);
    scales.x.ticks = _catTicksOpts({ font: { size: 10 }, maxRotation: 45, minRotation: 0 },
      catBudget, noLabels);
    const densWf = barDensity(labels.length, 4, 56);
    return {
      type: "bar",
      data: { labels: labels, datasets: [{ data: bars.map((b) => b.range),
        backgroundColor: colors,
        borderRadius: densWf.borderRadius, maxBarThickness: densWf.maxBarThickness }] },
      options: { responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false },
          // on: true — визуальный дефолт «мостики нарисованы» живёт ЗДЕСЬ, в
          // кодировке, а не в OVERLAY_DEFS.bridges.default (правка 2 ревью
          // epic-main-31). Карточка (mini) никогда не вызывает overlayControl
          // (§2 спеки controls-design) — если дефолт жил бы только в
          // оверлее, карточка водопада осталась бы без мостиков и без
          // способа их включить. Развёрнутый режим оверлеем может выключить.
          waterfallBridges: { carries: carries, on: true },
          tooltip: { callbacks: { label: (c) =>
            (set.has(c.dataIndex) ? "" : "−") + fmtP(vals[c.dataIndex]) } } },
        scales: scales },
    };
  }

  if (enc === "stacked-hbar") {
    // Стек «часть-целое»: первый датасет по colorBy, остальные — серым.
    // Нативная ориентация — горизонталь; opts.orientation:"v" (АС4, task-main-199)
    // переводит в вертикаль — indexAxis + раскладка catAxis/valAxis через
    // _baseScales (та же функция, что уже разводит bar/hbar).
    const horizontal = !!(opts && opts.orientation ? opts.orientation === "h" : true);
    // Сортировка: опорный ряд — сумма ВСЕХ серий на позиции ("по сумме
    // стека", как и у √-стека — стек есть стек, независимо от √-шкалы).
    let lbls = labels;
    let seriesList = series.series;
    let seriesForColor = series;
    const sortMode = opts && opts.sortMode;
    if (sortMode && sortMode !== "default") {
      const ref = labels.map((_, i) => seriesList.reduce((s, se) => s + (se.y[i] || 0), 0));
      const order = sortOrder3(ref, sortMode);
      lbls = _permute(labels, order);
      seriesList = seriesList.map((se) => ({ name: se.name, y: _permute(se.y, order) }));
      // colorBy "completion" (белый список COLOR_BY) читает series.completion
      // позиционно параллельно series[0].y — переставляем тем же order, иначе
      // светофор первого датасета рассинхронится с переставленными барами.
      if (Array.isArray(series.completion)) {
        seriesForColor = Object.assign({}, series, { completion: _permute(series.completion, order) });
      }
    }
    const colorFirst = (COLOR_BY[spec.colorBy] || COLOR_BY.neutral)(seriesList[0].y, seriesForColor);
    const densHbar = barDensity(lbls.length, 3, 30);
    const fmtPctP = unitFmtPrecise("pct");  // тултип normalize -- поднят из колбэка (единственное исключение в файле)
    // 100%-стек (обогащение движка находками shadcn/charts, 2026-08-21):
    // spec.normalize делит сегменты каждой строки на сумму СВОЕЙ строки ->
    // доля (0..1, та же форма, что unit="pct" везде в движке). Пустая строка
    // (сумма 0) -> 0 для всех сегментов, не NaN. _raw хранится РЯДОМ (не
    // мутирует seriesList[i].y) — тултипу нужен исходный абсолют, не только %.
    const rowSums = spec.normalize
      ? lbls.map((_, idx) => seriesList.reduce((sum, se) => sum + (se.y[idx] || 0), 0))
      : null;
    const datasets = seriesList.map((s, i) => {
      const raw = s.y;
      const y = spec.normalize
        ? raw.map((v, idx) => (rowSums[idx] ? (v || 0) / rowSums[idx] : 0))
        : raw;
      const bg = i === 0 ? colorFirst : CH.grey;
      return {
        label: s.name, data: y, ...(spec.normalize ? { _raw: raw } : {}),
        backgroundColor: bg,
        hoverBackgroundColor: Array.isArray(bg) ? bg.map(_hoverFill) : _hoverFill(bg),
        stack: "s", borderRadius: densHbar.borderRadius, maxBarThickness: densHbar.maxBarThickness,
      };
    });
    // Ось value-шкалы переключается на % при normalize, НЕЗАВИСИМО от
    // spec.unit — иначе подписи оси (штуки) не совпадают с визуальной шириной
    // бара (100% у всех строк). unitFmt("pct") уже существует и ожидает долю
    // (0..1) — та же форма, что и наши normalized-значения, без ручного ×100.
    const scales = _baseScales(spec.normalize ? "pct" : spec.unit, horizontal);
    scales.x.stacked = true;
    scales.y.stacked = true;
    (horizontal ? scales.y : scales.x).ticks =
      _catTicksOpts({ font: { size: 11 } }, catBudget, noLabels);
    if (spec.normalize) {
      (horizontal ? scales.x : scales.y).min = 0;
      (horizontal ? scales.x : scales.y).max = 1;
    }
    return {
      type: "bar",
      data: { labels: lbls, datasets: datasets },
      options: { indexAxis: horizontal ? "y" : "x", responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: "bottom",
            labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true, padding: 12 } },
          tooltip: { callbacks: { label: (c) => {
            const ds = c.dataset;
            const parsed = horizontal ? c.parsed.x : c.parsed.y;
            if (spec.normalize) {
              const raw = ds._raw ? ds._raw[c.dataIndex] : null;
              return ds.label + ": " + fmtP(raw) + " (" + fmtPctP(parsed) + ")";
            }
            return ds.label + ": " + fmtP(parsed);
          } } } },
        scales: scales },
    };
  }

  if (enc === "pie") {
    const values = series.series[0] && series.series[0].y;
    if (!Array.isArray(values) || values.length !== labels.length || values.some(v => !Number.isFinite(v) || v < 0))
      throw new Error("Invalid pie values");
    return {type:"pie", data:{labels:labels,datasets:[{data:values,backgroundColor:[CH.petrol,CH.gold,CH.terra,CH.grass,CH.grey,CH.ochre]}]},
      options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:"bottom"}}}};
  }

  if (enc === "date-scatter") {
    const timezone = meta.timezone || "Europe/Moscow";
    const dateFmt = new Intl.DateTimeFormat("ru-RU",{timeZone:timezone,day:"2-digit",month:"short",year:"numeric"});
    const min = spec.yMin == null ? 0 : spec.yMin, max = spec.yMax == null ? 100 : spec.yMax;
    if (!Number.isFinite(min) || !Number.isFinite(max) || min >= max) throw new Error("Invalid date-scatter range");
    const datasets = series.series.map(s=>{
      if (!Array.isArray(s.data) || s.data.some(p=>!Number.isFinite(p.x)||!Number.isFinite(p.y)||!Number.isFinite(new Date(p.x).getTime()))) throw new Error("Invalid date-scatter points");
      return {label:s.name,data:s.data,pointRadius:3,pointHoverRadius:5,backgroundColor:CH[s.color]||CH.petrol};
    });
    return {type:"scatter",data:{datasets},options:{responsive:true,maintainAspectRatio:false,
      plugins:{legend:{position:"bottom"},tooltip:{callbacks:{label:c=>dateFmt.format(c.parsed.x)+" / "+c.parsed.y}}},
      scales:{x:{type:"linear",title:{display:true,text:spec.xLabel||""},ticks:{callback:v=>dateFmt.format(v)}},
              y:{min,max,title:{display:true,text:spec.yLabel||""}}}}};
  }

  if (enc === "scatter") {
    // Точечный BCG-квадрант: 4 именованных датасета (по сектору), НЕ категориальный
    // x. center — рантайм-поле серии (медиана по кабинету считает Python), не
    // статика спеки — см. _build_quadrant_scatter в domains/assortment/sections.py.
    const fmtX = unitFmt(spec.unitX);
    const fmtY = unitFmt(spec.unitY);
    const fmtXP = unitFmtPrecise(spec.unitX);
    const fmtYP = unitFmtPrecise(spec.unitY);
    const center = series.center || { x: 0, y: 0 };
    // Y — неограниченная величина (growth_units): симметричный диапазон вокруг
    // center.y по данным, +10% отступ, fallback 1 на вырожденный случай (все точки
    // совпадают с центром или единственная точка).
    const allPts = series.series.reduce((acc, s) => acc.concat(s.data || []), []);
    const maxDy = allPts.reduce((m, p) => Math.max(m, Math.abs(p.y - center.y)), 0) || 1;
    const padY = maxDy * 1.1;
    const datasets = series.series.map((s) => {
      const col = CH[s.color] || CH.petrol;
      return {
        label: s.name, data: s.data,
        backgroundColor: hexAlpha(col, 0.55), borderColor: col, borderWidth: 1,
        pointRadius: 3, pointHoverRadius: 5,
      };
    });
    return {
      type: "scatter",
      data: { datasets: datasets },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: { position: "bottom",
            labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true, padding: 12 } },
          quadrantCrosshair: { center: center, on: true },
          tooltip: { callbacks: { label: (c) =>
            (c.raw && c.raw.label ? c.raw.label + ": " : "")
            + fmtXP(c.parsed.x) + " / " + fmtYP(c.parsed.y) } },
        },
        scales: {
          // X — перцентиль доли в категории (sections.py: _build_quadrant_scatter),
          // УЖЕ жёстко ограничен [0,1] по построению — медиана категории всегда
          // РОВНО 0.5, растягивать вокруг центра не нужно (и физически бессмысленно:
          // перцентиль не бывает <0% или >100%, в отличие от сырой доли — TD-93).
          x: { min: 0, max: 1,
            title: { display: true, text: spec.xLabel || "", font: { size: 10 }, color: CH.slate },
            grid: { color: CH.hair }, border: { display: false },
            ticks: { callback: (v) => fmtX(v) } },
          y: { min: center.y - padY, max: center.y + padY,
            title: { display: true, text: spec.yLabel || "", font: { size: 10 }, color: CH.slate },
            grid: { color: CH.hair }, border: { display: false },
            ticks: { callback: (v) => fmtY(v) } },
        },
      },
    };
  }

  // bar | hbar — один датасет, цвет по colorBy. opts.orientation переопределяет
  // нативную ориентацию (АС4, task-main-199); opts.sortMode — трёхпозиционная
  // сортировка (default/asc/desc) поверх УЖЕ пролеченной applyGuard серии:
  // усечение/свёртка (сноска "Показаны N из M") уже случились в applyGuard,
  // здесь только перестановка порядка — счёт сноски не рассинхронивается.
  const nativeHorizontal = enc === "hbar";
  const horizontal = (opts && opts.orientation) ? opts.orientation === "h" : nativeHorizontal;
  const vals0 = series.series[0].y;
  const colors0 = (COLOR_BY[spec.colorBy] || COLOR_BY.neutral)(vals0, series);
  const refItems0 = _resolveRefData(spec, series);
  const sortMode = opts && opts.sortMode;
  const order = (sortMode && sortMode !== "default") ? sortOrder3(vals0, sortMode) : null;
  const labelsOut = _permute(labels, order);
  const vals = _permute(vals0, order);
  const colors = Array.isArray(colors0) ? _permute(colors0, order) : colors0;
  const refItems = refItems0.map((r) => ({ label: r.label, data: _permute(r.data, order) }));
  const catTicks = horizontal
    ? _catTicksOpts({ font: { size: 11 } }, catBudget, noLabels)
    : _catTicksOpts({ font: { size: 10 }, maxRotation: 45, minRotation: 0 }, catBudget, noLabels);
  const scales = _baseScales(spec.unit, horizontal);
  (horizontal ? scales.y : scales.x).ticks = catTicks;
  const catAxisKey = horizontal ? "y" : "x";
  const valAxisKey = horizontal ? "x" : "y";
  // Правка 1 ревью epic-main-31 (часть 1): refs — плагин поверх готовой шкалы,
  // не датасет, поэтому Chart.js не видит их значения при авторасчёте
  // диапазона. Раздвигаем шкалу вручную по Math.max/min(бары ∪ refs) —
  // симметрично для отрицательных опор. Только когда refs объявлены: без них
  // поведение не меняется (обычный авто-диапазон Chart.js по данным).
  if (refItems.length) {
    const refVals = refItems.reduce(
      (acc, r) => acc.concat((r.data || []).filter((v) => v != null)), []);
    if (refVals.length) {
      const allVals = vals.filter((v) => v != null).concat(refVals);
      scales[valAxisKey].suggestedMax = Math.max(...allVals);
      scales[valAxisKey].suggestedMin = Math.min(...allVals);
    }
  }
  const densBar = barDensity(labelsOut.length, 5, horizontal ? 28 : 44);
  return {
    type: "bar",
    data: { labels: labelsOut, datasets: [{ data: vals, backgroundColor: colors,
      hoverBackgroundColor: Array.isArray(colors) ? colors.map(_hoverFill) : _hoverFill(colors),
      borderRadius: densBar.borderRadius, maxBarThickness: densBar.maxBarThickness }] },
    options: { indexAxis: horizontal ? "y" : "x",
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: refItems.length
          ? { display: true, position: "top",
              // onClick:()=>{} (правка 2 ревью epic-main-31, БЛОКЕР): refs — не
              // датасет, у ref-элемента легенды нет datasetIndex. Дефолтный
              // legend.onClick Chart.js адресует датасет именно по нему —
              // chart.isDatasetVisible(undefined) роняет график. Опорную линию
              // скрывать нечего — клик по её пункту легенды не переключает ничего.
              onClick: () => {},
              labels: { boxWidth: 14, usePointStyle: false,
                generateLabels: () => refItems.map((r) => ({
                  // fillStyle прозрачный, НЕ CH.petrol (правка 4, MINOR): рамка
                  // (strokeStyle) невидима на собственной сплошной заливке —
                  // элемент легенды выглядел плашкой серии, а не пунктирным
                  // контуром опорной линии.
                  text: r.label, fillStyle: "rgba(0,0,0,0.1)", strokeStyle: CH.petrol,
                  lineWidth: 1, lineDash: [4, 4] })) } }
          : { display: false },
        refMarks: { refs: refItems, catAxis: catAxisKey, valAxis: valAxisKey, on: refItems.length > 0 },
        tooltip: { callbacks: { label: (c) => fmtP(horizontal ? c.parsed.x : c.parsed.y) } } },
      scales: scales },
  };
}

// ===== Монтаж (DOM + Chart) =====

// id canvas/обёртки графика по спеке. suffix обязателен для второй копии того же
// графика на странице (развёрнутый вид): newChart ищет холст через
// getElementById, и дубль id увёл бы график не в тот холст.
function chartCanvasId(spec, suffix) { return "chart-" + spec.id + (suffix || ""); }

// Применить решение гарда к (spec, series) → {spec, series, action, note}.
function applyGuard(spec, series) {
  const v = assess(spec, series);
  let s = spec, ser = series;
  if (v.action === "reencode" && v.reencodeTo) s = Object.assign({}, spec, { encoding: v.reencodeTo });
  if (v.action === "aggregate") {
    // Порог свёртки — из ЭФФЕКТИВНОГО гарда спеки (spec.guard > дефолт), иначе
    // график, объявивший свой overflow, диагностируется по своему порогу, а
    // лечится по глобальному.
    const agg = aggregateOther(series.x, series.series,
      guardFor(spec).overflow, series.completion);
    ser = Object.assign({}, series, { x: agg.labels, series: agg.series, completion: agg.extra });
  }
  if (v.action === "truncate") {
    // Правка 3 ревью epic-main-31: assess() (chart-guard.js) уже диспетчерит
    // unit="pct" overflow в action="truncate" — здесь подключаем лечение
    // (truncateOther), которого раньше не было: процентные графики выше
    // порога рисовались ЦЕЛИКОМ (без свёртки/усечения), пока сноска assess()
    // всё равно врала «показаны N из M». Тот же эффективный порог, что у
    // aggregate — свёртка/усечение читают один источник.
    const tr = truncateOther(series.x, series.series,
      guardFor(spec).overflow, series.completion);
    ser = Object.assign({}, series, { x: tr.labels, series: tr.series, completion: tr.extra });
  }
  return { spec: s, series: ser, action: v.action, note: v.note };
}

// value-карточка вместо вырожденного графика.
function valueCard(note) {
  return el("div", { class: "ch-value" }, [
    el("div", { class: "ch-value-num" }, "—"),
    el("div", { class: "ch-value-note" }, note || "Нет данных"),
  ]);
}

// Редакционная сноска под графиком.
function chartFootnote(note) {
  return el("div", { class: "ch-foot" }, note);
}

// Серия для спеки: производная из entity_tables (spec.source) или готовая из
// chart_series. Числа уже посчитал движок — здесь только проекция/сорт/срез.
function seriesFor(payload, spec) {
  return spec && spec.source
    ? deriveSeries(payload, spec.source, spec.id)
    : seriesById(payload, spec.id);
}

// entity_tables[from].rows → generic-серия {id,x,series:[{name,y}]}. Pure.
// axis:"time" (report/daily_table.py) — исключение из дефолтной сортировки по
// величине: у временной оси есть естественный порядок (хронология), которую
// сортировка по значению сломала бы. Явный spec.source.sort всё равно
// побеждает — это редакционное решение TOML, не автоматика.
function deriveSeries(payload, src, id) {
  const lvl = (payload.entity_tables && payload.entity_tables[src.from]) || {};
  let rows = (lvl.rows || []).filter((r) => r[src.value] != null);
  if (src.sort) {
    rows.sort((a, b) => (src.sort === "asc"
      ? a[src.value] - b[src.value] : b[src.value] - a[src.value]));
  } else if (lvl.axis !== "time") {
    rows.sort((a, b) => b[src.value] - a[src.value]);
  }
  if (src.top) rows = rows.slice(0, src.top);
  return { id: id, x: rows.map((r) => r[src.label]),
    series: [{ name: "", y: rows.map((r) => r[src.value]) }],
    axis: lvl.axis };
}

// Водопад: значения + индексы опорных столбцов → плавающие пары [низ,верх].
// Опорный (i ∈ totals) рисуется от нуля и задаёт running-итог; прочие —
// вычитаемые ступени от текущего итога вниз. Pure (Node-тестируема).
function waterfallBars(values, totals) {
  const set = new Set(totals || []);
  let running = 0;
  return (values || []).map((v, i) => {
    if (set.has(i)) { running = v; return { range: [0, v], delta: false }; }
    const top = running;
    running = running - v;
    return { range: [running, top], delta: true };
  });
}

// Кодировки, получающие переключатель ориентации (АС4, task-main-199) — их
// нативная ("родная") ориентация. Водопад/√-стек/line/scatter — не получают
// (мостики и √-шкала считают пиксели по вертикальной оси; спека §4).
const ORIENT_NATIVE = { bar: "v", hbar: "h", "grouped-bar": "v", "stacked-hbar": "h" };

// Собрать слайд-«страницу» графика: {el, mount, destroy}. mount() создаёт
// Chart ПОСЛЕ вставки el в DOM (Chart.js требует canvas в дереве для верного
// размера) и, в развёрнутом режиме, органы ориентации/сортировки; повторный
// вызов mount() (клик по «Верт/Гор» или сортировке) ПЕРЕСОБИРАЕТ Chart на том
// же холсте. Шапка .ch-head держит слот .ch-head-actions.
//
// РИСК 1 спеки controls-design («единая точка владения инстансом»): `chart`
// живёт в замыкании ОДИН раз на весь buildChartSlide (не внутри mount()) —
// и mount(), и destroy() читают/пишут ЭТУ ЖЕ переменную. Пересборка = mount()
// вызывает себя же снова (destroy старого + create нового) — никакой ВТОРОЙ
// функции для "внутреннего" ребилда нет, поэтому у вызывающего (chart-
// modal.js) нет соблазна держать свою устаревшую ссылку: closeChartModal
// обязан звать slide.destroy() (не chart.destroy() на когда-то захваченном
// значении), а он ВСЕГДА destroys актуальный chart, сколько бы раз ни
// переключилась ориентация/сортировка.
function buildChartSlide(spec, payload, opts) {
  opts = opts || {};
  const mini = !!opts.mini;
  // Развёрнутый вид: большой холст держит хвост целиком, свёртку снимаем
  // (expandedSpec, chart-guard.js). Кнопку развёртывания у себя же не рисуем.
  const expanded = !!opts.expanded;
  const canvasId = chartCanvasId(spec, opts.idSuffix);
  const raw = seriesFor(payload, spec);
  const wrap = el("div", { class: "ch" });
  const head = el("div", { class: "ch-head" },
    el("h3", {}, slideTitle(spec, raw, payload.meta)));
  const actions = mini ? null : el("div", { class: "ch-head-actions" });
  if (actions) head.append(actions);
  wrap.append(head);
  if (!mini && spec.caption) wrap.append(el("div", { class: "ch-cap" }, spec.caption));
  if (!raw) {
    wrap.append(valueCard("Нет данных"));
    return { el: wrap, mount: () => null, destroy: () => {} };
  }
  const g = applyGuard(expanded ? expandedSpec(spec) : spec, raw);
  if (g.action === "value-card") {
    wrap.append(valueCard(g.note));
    return { el: wrap, mount: () => null, destroy: () => {} };
  }
  const cwrap = el("div", { class: "cwrap" });
  cwrap.append(el("canvas", { id: canvasId }));
  wrap.append(cwrap);
  if (!mini && g.note) wrap.append(chartFootnote(g.note));
  // Расхождение с карточкой проговариваем вслух: она свернула/усекла хвост,
  // мы — нет. Действие карточки читаем по ИСХОДНОЙ (не expanded) спеке —
  // включает и aggregate (рубли/штуки), и truncate (доли, правка 3).
  const cardAction = assess(spec, raw).action;
  if (expanded && (cardAction === "aggregate" || cardAction === "truncate")) {
    wrap.append(chartFootnote("Показаны все категории (" + (raw.x || []).length + ")"));
  }

  const nativeOrient = ORIENT_NATIVE[g.spec.encoding] || null;
  const sortable = nativeOrient !== null || g.spec.encoding === "sqrt-stack";
  const domainKey = (typeof DOMAIN !== "undefined" && DOMAIN) ? DOMAIN.key : "";
  const orientKey = "chv:" + domainKey + ":" + g.spec.id + ":orient";
  const sortKey = "chv:" + domainKey + ":" + g.spec.id + ":sort";

  let chart = null;
  const mount = () => {
    if (chart) { try { chart.destroy(); } catch (e) { /* noop */ } chart = null; }
    const cfgOpts = { mini: mini, expanded: expanded };
    const curOrient = nativeOrient ? _readSticky(orientKey, ["v", "h"], nativeOrient) : null;
    const curSort = sortable ? _readSticky(sortKey, ["default", "asc", "desc"], "default") : "default";
    if (expanded && curOrient) cfgOpts.orientation = curOrient;
    if (expanded && sortable) cfgOpts.sortMode = curSort;
    chart = newChart(canvasId, chartConfig(g.spec, g.series, payload.meta || {}, cfgOpts));
    // Ориентация/сортировка/оверлеи — только в развёрнутом режиме (§2/§4
    // спеки controls-design): карточка остаётся витриной без органов
    // настройки. actions.replaceChildren() на КАЖДУЮ пересборку — единственная
    // точка отрисовки контролов, не дублируем их при повторных mount().
    // БЕЗУСЛОВНО для любого actions, не только expanded (правка 5 ревью
    // epic-main-31): раньше очистка жила только в ветке expanded, а
    // expandButton карточки append()-ился без предварительной очистки —
    // повторный mount() (task-main-200 введёт перерисовку сцены) продублировал
    // бы кнопку развёртывания, сломав AC2 «на карточке ровно один орган».
    if (actions) actions.replaceChildren();
    if (expanded && actions) {
      if (nativeOrient && typeof orientationControl === "function") {
        actions.append(orientationControl(orientKey, curOrient, mount));
      }
      if (sortable && typeof sortControl === "function") {
        actions.append(sortControl(sortKey, curSort, mount));
      }
      if (typeof overlayControl === "function") {
        const ctrl = overlayControl(g.spec, chart, g.series, domainKey);
        if (ctrl) actions.append(ctrl);
      }
    }
    // Кнопка развёртывания — единственный орган карточки. Ветка value-card
    // вышла выше, поэтому заглушка «Нет данных» кнопки не получает.
    if (actions && !expanded && typeof expandButton === "function") {
      actions.append(expandButton(spec, payload));
    }
    return chart;
  };
  const destroy = () => {
    if (chart) { try { chart.destroy(); } catch (e) { /* noop */ } chart = null; }
  };
  return { el: wrap, mount: mount, destroy: destroy };
}

// Заголовок слайда: статичный spec.title (painTitle ретайрен в Ф1 движка диаграмм).
function slideTitle(spec, raw, meta) {
  return (spec && spec.title) || "";
}

// Разрешить спеку под уровень главы «Динамика» (task-main-200, §3 спеки
// controls-design, АС3). spec.levels[level] — объявление из toml
// (build_specs.py): ровно одно из series/source + опциональные
// title/caption/labels/guard. Уровень не объявлен (или spec.levels
// отсутствует вовсе — график без пары, напр. line-серия «Темп продаж») ->
// ИСХОДНАЯ СПЕКА БЕЗ ИЗМЕНЕНИЙ (тот же объект, не копия — «остаются как
// есть»). Необъявленные в уровне поля наследуются от базовой спеки —
// «не объявлены — берутся значения графика». Pure.
function specForLevel(spec, level) {
  const lv = spec && spec.levels && spec.levels[level];
  if (!lv) return spec;
  const out = Object.assign({}, spec);
  if (lv.series) {
    out.id = lv.series;
    delete out.source;
  } else if (lv.source) {
    out.source = lv.source;
  }
  if (lv.title) out.title = lv.title;
  if (lv.caption != null) out.caption = lv.caption;
  if ("labels" in lv) out.labels = lv.labels;
  if (lv.guard) out.guard = Object.assign({}, out.guard, lv.guard);
  return out;
}

// Спека доходит до рендера, если: (а) она производная (spec.source — данные из
// entity_tables, наличие проверяется отдельно в deriveSeries/buildChartSlide) —
// всегда; либо (б) в payload.chart_series ЕСТЬ блок с её id. Блок с пустыми/null y
// НЕ отсекается: это честный «0 совпадений» (напр. pricing floor_gap_top при
// below_floor_count=0) — его показывает buildChartSlide → assess() честной
// заглушкой «Нет данных за период», а не схлопыванием слота (debt-main-44).
// Отсекаются ТОЛЬКО спеки, для которых блока нет вовсе — «протёкшие» с чужой грани
// (settlement обслуживает file- и sku-грань одним статичным списком спек на домен;
// чужая грань блок не эмитит → id отсутствует в byId, спека не занимает слот). Pure.
function specHasSeriesBlock(spec, byId) {
  if (!spec) return false;
  if (spec.source) return true;
  const ser = byId[spec.id];
  return !!(ser && Array.isArray(ser.series));
}

// Уровни главы «Динамика», объявленные движком для домена (task-main-200,
// §3 спеки controls-design): CHART_ENGINE.domains[key].levels — тот же
// список, что chart_levels в toml (build_specs.py), порядок = порядок в
// контроле, первый — дефолтный. < 2 уровней (шесть из семи доменов сегодня)
// -> null, переключателя нет, графики рендерятся как есть.
function _chartLevels(domainKey) {
  const g = (typeof window !== "undefined") ? window
    : (typeof globalThis !== "undefined" ? globalThis : null);
  const ce = g && g.CHART_ENGINE;
  const d = ce && ce.domains && ce.domains[domainKey];
  const lv = d && Array.isArray(d.levels) ? d.levels : null;
  return (lv && lv.length >= 2) ? lv : null;
}

// Текущий выбранный уровень: sessionStorage chlvl:<домен>, липкий, сброс
// при перезагрузке (новая вкладка/новый sessionStorage). Незнакомое/битое
// значение (домен сменился, уровень переименован) не просачивается —
// откат на дефолтный (levels[0]).
function _currentChartLevel(domainKey, levels) {
  try {
    const v = sessionStorage.getItem("chlvl:" + domainKey);
    if (v && levels.indexOf(v) >= 0) return v;
  } catch (e) { /* sessionStorage недоступен (Node/приватный режим) — дефолт */ }
  return levels[0];
}

// Подпись сегмента — из DOMAIN.levels (task-tracker: та же сущность
// категория/товар, что уже несёт signals-table.js для таблицы «Что требует
// внимания», НЕ строковый литерал движка — §3 спеки: «подписи сегментов
// берутся из DOMAIN.levels»). DOMAIN.levels не содержит уровень (легаси/
// тестовый вызов без домена) -> сам ключ уровня как подпись, не пусто.
function _levelLabel(level) {
  const d = (typeof DOMAIN !== "undefined" && DOMAIN && Array.isArray(DOMAIN.levels))
    ? DOMAIN.levels : [];
  const found = d.find((l) => l && l.key === level);
  return (found && found.label) || level;
}

// Слот действий главы «Динамика» (#charts-head-act, module-registry.js
// headActionsId) — сегмент-контрол уровня, идентичный по разметке
// orientationControl/sortControl (chart-overlays.js: .ov-ctrl/.ov-seg),
// вместо реализации UI-стиля дважды. Слот отсутствует (домен без §3, либо
// главы «Динамика» нет в этом .pad) -> no-op.
function _mountChartsHeadActions(domainKey, levels, curLevel, onChange) {
  const slot = (typeof document !== "undefined")
    ? document.getElementById("charts-head-act") : null;
  if (!slot) return;
  slot.replaceChildren();
  if (!levels) return;
  const wrap = el("div", { class: "ov-ctrl" });
  levels.forEach((lvl) => {
    const btn = el("button",
      { class: "ov-seg" + (lvl === curLevel ? " on" : ""), type: "button" },
      _levelLabel(lvl));
    btn.addEventListener("click", () => {
      if (lvl === curLevel) return;
      try { sessionStorage.setItem("chlvl:" + domainKey, lvl); } catch (e) { /* noop */ }
      onChange();
    });
    wrap.append(btn);
  });
  slot.append(wrap);
}

// Точка входа: спеки + payload → сцена в #charts-host (главный + мини).
// Фильтр «протёкших» спек — specHasSeriesBlock (см. выше). Уровень главы
// (task-main-200): если движок объявил ≥2 уровня для домена, спеки
// пропускаются через specForLevel(spec, curLevel) ДО фильтра — та же
// payload.chart_series, без похода на сервер (§3 спеки: «перерисовка сцены
// без похода на сервер»).
function renderCharts(specs, payload) {
  // Перерисовка по новому payload не должна оставлять открытым диалог со старой
  // серией. Через UI недостижимо (фон под модалкой не кликается) — защита от кода.
  if (typeof closeChartModal === "function") closeChartModal();
  const domainKey = (typeof DOMAIN !== "undefined" && DOMAIN) ? DOMAIN.key : "";
  const levels = _chartLevels(domainKey);
  const curLevel = levels ? _currentChartLevel(domainKey, levels) : null;
  _mountChartsHeadActions(domainKey, levels, curLevel, () => renderCharts(specs, payload));
  const host = document.getElementById("charts-host");
  const byId = {};
  for (const s of (payload && payload.chart_series) || []) byId[s.id] = s;
  const resolved = curLevel
    ? (specs || []).map((spec) => specForLevel(spec, curLevel))
    : (specs || []);
  const live = resolved.filter((spec) => specHasSeriesBlock(spec, byId));
  if (typeof mountStage === "function") {
    mountStage(host, live, payload);
  } else {
    // Фоллбэк-грид (если сцена не загрузилась): по графику на ячейку.
    host.replaceChildren();
    const grid = el("div", { class: "charts" });
    live.forEach((s) => { const b = buildChartSlide(s, payload); grid.append(b.el); b.mount(); });
    host.append(grid);
  }
}
