"use strict";

// Общий движок KPI-карточек. Домен передаёт готовые данные, движок не содержит
// доменных терминов и не выбирает метрики.
//
// Контракт (эпик kpi-widgets, спека §7): renderKpiCards(container, cards)
// cards[]: {
//   label,     — подпись карточки, одна строка;
//   value,     — готовая строка значения;
//   sub?,      — нейтральная подпись, одна строка;
//   element?,  — { kind: "ring"|"bars"|"line", data, tip, trend? } — микро-графика
//                справа от числа (спека §3.2). data/tip уже готовы вызывающим: движок
//                ничего не считает и не знает доменных терминов, рисует то, что вернул
//                примитив micro-graphics.js. trend — ТОЛЬКО для kind:"line" (стрелка —
//                часть линейного графика по смыслу, спека §3.1; у кольца и столбиков
//                её не бывает никогда, даже если объявлена по ошибке): { delta, scale,
//                tip }, глиф выбирает mgTrendGlyph. Примитив вернул null (нет данных,
//                вырожденный вход) — элемент просто не рисуется: заглушки на его месте
//                нет, высота виджета не меняется.
//   progress?, — РУДИМЕНТ движка (Коммерция, карточка «Выполнение плана»):
//                нормированное число 0…1, движок ограничивает диапазон и рисует бар.
//                Живёт до перевода Коммерции на новый язык виджета (спека §7) — умрёт
//                вместе со срезом раскатки, не трогать при правках языка виджета.
//   threshold? — РУДИМЕНТ движка (Маркетинг/Ценообразование/Взаиморасчёты, по одной
//                карточке в каждом): { value, floor, floorLabel }; при value < floor
//                выводится красная подпись «Ниже <floorLabel>». Та же судьба, что и
//                progress.
// }
//
// Прочие визуальные механики не поддерживаются: нет valueClass, subClass, badge,
// чипов или доменных условных веток. Порядок: label → value+element → progress → sub.
// value и подписи рендерятся через textNode; HTML-инъекция невозможна.
// Зависимости: el() из core.js; mgRing/mgBars/mgLine/mgTrendGlyph из micro-graphics.js.

// Крупные числа сжимаются до «7,99 млн» (правило владельца 2026-08-16): семизначное
// число съедает ширину виджета и читается по разрядам, а не с первого взгляда — против
// самой цели виджета «понять за пять секунд». Правило живёт ЗДЕСЬ, а не в семи
// доменах: value приходит готовой строкой, поэтому движок распознаёт в ней число сам —
// иначе одно и то же правило пришлось бы дублировать в каждом домене и оно разошлось бы
// при первой же правке.
//
// Осторожность обязательна: движок не знает, ЧТО за величина внутри строки. Сжимается
// только строка, которая целиком является числом (разряды разделены пробелом или NBSP,
// дробная часть — запятой). Проценты, «—», число с приписанной единицей остаются как
// есть: «47,1» → «0,00 млн» было бы не сокращением, а ложью.
var KPI_MLN = 1e6;
var KPI_MLRD = 1e9;

function _kpiParseNumber(text) {
  if (typeof text !== "string") return null;
  var bare = text.replace(/[\s ]/g, "").replace(",", ".");
  if (!/^-?\d+(\.\d+)?$/.test(bare)) return null;
  var n = Number(bare);
  return Number.isFinite(n) ? n : null;
}

// Три значащие цифры (7,99 / 12,3 / 123) — у любого миллионного числа одинаковая
// ширина, поэтому ряд виджетов не пляшет при смене периода.
//
// Возвращается ПАРА {num, unit}, а не готовая строка: «млн» рисуется мелким
// приглушённым суффиксом .u — тем же, каким платформа уже подписывает единицы. Одной
// строкой «4,27 млн» крупным кеглем карточка с линейным графиком не обходится: замер
// на Тесте 16.08 показал перенос «млн» на вторую строку и разъехавшийся по высоте ряд.
function _kpiCompactValue(text) {
  var n = _kpiParseNumber(text);
  if (n === null) return null;
  var abs = Math.abs(n);
  if (abs < KPI_MLN) return null;
  var big = abs >= KPI_MLRD;
  var scaled = n / (big ? KPI_MLRD : KPI_MLN);
  var digits = Math.abs(scaled) >= 100 ? 0 : (Math.abs(scaled) >= 10 ? 1 : 2);
  return { num: scaled.toFixed(digits).replace(".", ","), unit: big ? "млрд" : "млн" };
}

// Цвет треугольника динамики (спека §4, решение реализации): рост — --grass, падение
// — --terra, «—» (движение внутри порога шума) — приглушённый var(--muted). Та же
// палитра, что уже красит рудиментную подпись .kpi .s.up/.dn — язык цвета один на
// платформе, элемент его не изобретает заново.
function _kpiTriClass(glyph) {
  if (glyph === "▲" || glyph === "▲▲") return "up";
  if (glyph === "▼" || glyph === "▼▼") return "dn";
  return "muted";
}

// Открытой может быть максимум ОДНА подсказка на всю страницу (находка 4 ревью
// общего шва: старый код искал плашку через node.parentNode.querySelector(".k-tip")
// — это контейнер только СВОЕЙ карточки, чужие плашки были не видны, и тап по
// второй карточке оставлял открытой первую). Состояние модуля, а не элемента: node
// (host) — какой .k-el её открыл, tip — сам узел плашки в DOM.
var _openTip = null;

function _closeOpenTip() {
  if (!_openTip) return;
  _openTip.tip.remove();
  _openTip = null;
}

// Слушатель "клик мимо закрывает" ставится на document РОВНО ОДИН РАЗ за жизнь
// страницы (флаг _tipOutsideBound), а не внутри _bindTip/_kpiCard — renderKpiCards
// зовётся при КАЖДОЙ смене периода/домена, и вешать addEventListener на каждый
// рендер копило бы обработчики (утечка + N-кратное закрытие на следующий клик мимо,
// N растёт с числом рендеров). document переживает все рендеры карточек, поэтому
// слушателю достаточно быть один раз. event.stopPropagation() в обработчике клика
// по .k-el (ниже) не даёт этому же клику долететь до document и закрыть плашку
// сразу же после открытия.
var _tipOutsideBound = false;
function _ensureTipOutsideListener() {
  if (_tipOutsideBound) return;
  _tipOutsideBound = true;
  document.addEventListener("click", function () { _closeOpenTip(); });
}

// Подсказка элемента обязана открываться и наведением (нативный title — курсор
// мыши), и тапом/кликом, и клавиатурой Enter/Space (спека §3.2 + находка 5 ревью:
// на тач-экране ховера нет вовсе, а тултип — единственный носитель смысла элемента,
// у него самого подписи нет; div с click без tabindex/role клавиатурный пользователь
// не может активировать вовсе). tabindex="0" + role="button" делают .k-el
// фокусируемым и понятным вспомогательным технологиям — сам он не <button>, чтобы не
// тянуть браузерные стили кнопки внутрь карточки.
function _bindTip(node, text) {
  if (!text) return node;
  node.setAttribute("title", text);
  node.setAttribute("tabindex", "0");
  node.setAttribute("role", "button");
  _ensureTipOutsideListener();
  var toggle = function (event) {
    event.stopPropagation();
    if (_openTip && _openTip.host === node) { _closeOpenTip(); return; }
    _closeOpenTip();
    var tip = el("div", { class: "k-tip" }, text);
    node.parentNode.append(tip);
    _openTip = { host: node, tip: tip };
  };
  node.addEventListener("click", toggle);
  node.addEventListener("keydown", function (event) {
    if (event.key !== "Enter" && event.key !== " ") return;
    event.preventDefault(); // Space иначе прокрутил бы страницу.
    toggle(event);
  });
  return node;
}

// Элемент виджета: ring/bars/line + (только у line) треугольник динамики. spec может
// отсутствовать вовсе (домен ещё не переведён на новый язык) — тогда null, ниже по
// коду el() сам выкинет null-ребёнка из разметки без следа.
function _kpiElement(spec) {
  if (!spec) return null;
  // kind !== "line" — trend игнорируется, даже если домен ошибочно его объявил:
  // у кольца и столбиков стрелки не бывает никогда (спека §3.1), это не гибкость
  // движка, а инвариант языка виджета. Глиф считается ДО отрисовки линии — он же
  // решает, нужно ли графику сузиться (правка владельца 17.08).
  var glyph = (spec.kind === "line" && spec.trend)
    ? mgTrendGlyph(spec.trend.delta, spec.trend.scale) : null;
  var draw = { ring: mgRing, bars: mgBars, line: mgLine }[spec.kind];
  var svg = draw === mgLine ? draw(spec.data, spec.tip, !!glyph) : (draw ? draw(spec.data, spec.tip) : null);
  if (!svg) return null;
  // Двойной глиф («▲▲»/«▼▼» — сильное движение) рисуется ДВУМЯ строками одна над
  // другой, не двумя символами в ряд (правка владельца 17.08: бок о бок треугольники
  // читались как случайный мусор, не как «усиленный» вариант одинарной стрелки).
  var chars = glyph ? glyph.split("") : [];
  var triNode = glyph
    ? el("span", { class: "k-tri " + (chars.length > 1 ? "stack " : "") + _kpiTriClass(glyph),
                    title: spec.trend.tip },
        chars.length > 1 ? chars.map(function (ch) { return el("span", {}, ch); }) : glyph)
    : null;
  var wrap = el("div", { class: "k-el" }, [triNode, svg]);
  return _bindTip(wrap, spec.tip);
}

function _kpiCard(c) {
  const t = c.threshold;
  const thresholdSub = t && Number.isFinite(t.value) && Number.isFinite(t.floor) && t.value < t.floor
    ? { text: "Ниже " + (t.floorLabel || String(t.floor)), className: "dn" }
    : null;
  const captions = [c.sub, thresholdSub].filter(Boolean);
  const progress = Number.isFinite(c.progress) ? Math.max(0, Math.min(c.progress, 1)) : null;
  const compact = _kpiCompactValue(c.value);
  return el("div", { class: "k" }, [
    el("div", { class: "lbl", title: c.label }, c.label),
    // Элемент — СПРАВА от числа, в том же ряду (спека §3.2): общий родитель .v,
    // а не отдельная строка виджета; отсутствие элемента — просто на один <div>
    // меньше, высота виджета не меняется.
    // Сжатое число несёт title с точной величиной: обзор не должен стоить точности —
    // «7,99 млн» отвечает на вопрос «порядок?», наведение — на вопрос «сколько ровно?».
    el("div", { class: "v num", title: compact ? c.value : null }, [
      // Число и суффикс — ОДИН flex-элемент: .v раскладывает содержимое через
      // space-between, и врозь «млн» уехало бы в середину карточки, оторвавшись от
      // своего числа.
      compact
        // Неразрывный пробел перед суффиксом — не только отступ (его дал бы и CSS):
        // при копировании числа из карточки уносится «7,99 млн», а не «7,99млн».
        ? el("span", { class: "vnum" },
             [compact.num, el("span", { class: "u" }, " " + compact.unit)])
        : c.value,
      _kpiElement(c.element),
    ]),
    progress !== null
      ? el("div", { class: "bar" }, el("i", { style: "width:" + (progress * 100) + "%" }))
      : null,
    ...captions.map((caption) => {
      const threshold = typeof caption === "object";
      const text = threshold ? caption.text : caption;
      // title = полный текст (находка 3 ревью): после починки min-width:0 у .kpi .k
      // многоточие у .s наконец включается по-настоящему — без title обрезанный
      // смысл невосстановим (у .lbl такой title уже был, здесь тот же приём).
      return el("div", { class: "s" + (threshold ? " " + caption.className : ""), title: text },
        text);
    }),
  ]);
}

// Публичный вход: рендер полосы KPI-карточек из cards в container.
function renderKpiCards(container, cards) {
  if (!container) return;
  // Полная замена карточек уничтожает старую плашку вместе с её DOM (если была
  // открыта) — без сброса _openTip держал бы ссылку на уже отсоединённый узел до
  // следующего клика мимо (не крашится, но и не нужно).
  _closeOpenTip();
  container.replaceChildren(...((cards || []).map(_kpiCard)));
}

if (typeof window !== "undefined") window.renderKpiCards = renderKpiCards;
if (typeof module !== "undefined" && module.exports) module.exports = { renderKpiCards };
