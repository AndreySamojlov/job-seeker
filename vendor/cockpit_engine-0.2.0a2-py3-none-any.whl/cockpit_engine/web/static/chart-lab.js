"use strict";

// Chart Lab (task-gracious-hopper-854d26-1, эпик Chart Lab, Волна 2 -- Задача 5
// плана harness:docs/superpowers/plans/2026-08-20-chart-lab.md, спека
// harness:docs/superpowers/specs/2026-08-20-chart-lab-design.md §4/§6/§17): dev-only
// страница preview production-совместимого chart TOML на реальных данных
// текущего runtime-контекста.
//
// Переиспользует прод-механизмы, а не изобретает свои:
//   - buildChartSlide(spec, payload, opts) -- chart-render.js:835, тот же
//     рендерер, что и в отчёте (mini:false для главного превью). Требует
//     el()/newChart() (core.js) и assess()/expandedSpec() (chart-guard.js) --
//     загружены раньше в chart-lab.html тем же порядком, что index.html.
//   - fetchWithTimeout(url, opts, ms) -- shared.js:491 (таймаут через
//     AbortController), не голый fetch().
// initSelector/initCategorySelector/syncMonthSelector (app.js/shared.js) НЕ
// используются -- они жёстко завязаны на полный доменный report-view/
// loadReport pipeline, которого у Chart Lab нет и не будет (нет доменного
// отчёта, только stateless preview одного графика). Здесь -- свои тонкие
// загрузчики того же вида <select>, того же принципа «опции -> onchange -> перерендер».
//
// Живая галерея сохранённых прототипов (Задача 6, спека §11-16): Save/Update/
// Delete + карточки с живыми миниатюрами через ТОТ ЖЕ /preview (mini:true).
// Битый сохранённый прототип не должен прятать остальные -- try/catch вокруг
// КАЖДОЙ карточки отдельно (тест бэкенд-контракта --
// tests/test_chart_lab_api.py::test_saved_list_includes_broken_entry_
// and_preview_rejects_it_cleanly).
(function () {
  const PREVIEW_URL = "/v1/mp-cockpit/chart-lab/preview";
  const SAVED_URL = "/v1/mp-cockpit/chart-lab/saved";
  const CATEGORIES_URL = "/v1/mp-cockpit/chart-lab/categories";
  // domain=commerce -- технический дефолт ТОЛЬКО ради списка кабинетов:
  // /v1/mp-cockpit/cabinets требует domain (используется для среза «есть отчёт
  // этого домена»), а у Chart Lab нет доменного селектора вовсе (спека §4
  // «There is no Domain selector»). Тот же компромисс, что и дефолтный latest
  // period на бэкенде Preview (app.py::chart_lab_preview) -- задокументирован
  // явно, не тихое допущение.
  const CABINETS_URL = "/v1/mp-cockpit/cabinets?domain=commerce";

  const els = {};
  let mainSlide = null;
  let savedItems = [];
  let galleryBuilders = [];
  let selectedSavedId = null;
  let selectedSavedName = null;

  function byId(id) { return document.getElementById(id); }

  function currentRuntime() {
    const categories = Array.from(els.category.selectedOptions || []).map((o) => o.value);
    const runtime = { cabinet: els.cabinet.value || "", category: categories, scope: "" };
    const period = els.period.value.trim();
    if (period) runtime.period = period;
    return runtime;
  }

  // POST preview -- единая точка входа для главного превью (Задача 5) и
  // мини-карточек галереи (Задача 6): один и тот же прод-контракт, спека §18
  // «Preview and persistence APIs must use the same chart TOML parser».
  async function postPreview(toml, runtime) {
    let resp;
    try {
      resp = await fetchWithTimeout(PREVIEW_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ toml: toml, runtime: runtime }),
      }, 30000);
    } catch (e) {
      const why = e && e.name === "AbortError" ? "превышено время ожидания" : (e && e.message) || "сетевая ошибка";
      return { ok: false, error: { code: "NETWORK", message: why } };
    }
    let body = null;
    try { body = await resp.json(); } catch (e) { /* пустое/невалидное тело ниже */ }
    if (!resp.ok) {
      // HTTPException(status, "строка") у транспортных 400/404/503 -- detail
      // просто строка, не {code,message} (та форма -- только у бизнес-кодов
      // _chart_lab_error, которые приходят статусом 200 с ok:false).
      const detail = body && body.detail;
      const message = typeof detail === "string" ? detail
        : (detail && detail.message) || ("HTTP " + resp.status);
      return { ok: false, error: { code: "HTTP_" + resp.status, message: message } };
    }
    return body || { ok: false, error: { code: "EMPTY_RESPONSE", message: "Пустой ответ сервера" } };
  }

  function clearDiagnostics() {
    els.diagnostics.textContent = "";
    els.diagnostics.classList.remove("clab-diag-err");
  }

  function showDiagnosticsError(error) {
    const code = (error && error.code) || "ERROR";
    const message = (error && error.message) || "Неизвестная ошибка";
    els.diagnostics.textContent = code + ": " + message;
    els.diagnostics.classList.add("clab-diag-err");
  }

  function showDiagnostics(diag) {
    els.diagnostics.textContent =
      diag.chart_type + " · " + diag.source + " · " + diag.source_rows +
      " строк → " + diag.points + " точек · " + diag.status;
    els.diagnostics.classList.remove("clab-diag-err");
  }

  // Главный рендер (спека §6/§16): вызывается по кнопке Render, при смене
  // любого runtime-селектора (если textarea непустая), и (Задача 6) при
  // клике по карточке галереи -- всегда одна и та же функция, TOML в
  // textarea никогда не переписывается селекторами (спека §17).
  async function renderMain() {
    const toml = els.toml.value.trim();
    if (mainSlide) { mainSlide.destroy(); mainSlide = null; }
    els.preview.replaceChildren();
    clearDiagnostics();
    if (!toml) return;
    if (!els.cabinet.value) { showDiagnosticsError({ code: "NO_CABINET", message: "Выберите кабинет" }); return; }

    const result = await postPreview(toml, currentRuntime());
    if (!result.ok) { showDiagnosticsError(result.error); return; }

    const slide = buildChartSlide(result.spec, result.payload, { mini: false });
    els.preview.append(slide.el);
    slide.mount();
    mainSlide = slide;
    showDiagnostics(result.diagnostics);
  }

  // Клик по карточке галереи (спека §16): выбор -> TOML в редактор -> рендер
  // в главном превью -> Update/Delete включаются. Селекторы НЕ трогаем (спека
  // §16 «Do not restore selectors»).
  function selectSaved(saved) {
    selectedSavedId = saved.id;
    selectedSavedName = saved.name;
    els.toml.value = saved.toml;
    els.update.disabled = false;
    els.delete.disabled = false;
    markSelectedCard();
    renderMain();
  }

  function clearSelection() {
    selectedSavedId = null;
    selectedSavedName = null;
    els.update.disabled = true;
    els.delete.disabled = true;
  }

  function markSelectedCard() {
    Array.from(els.gallery.children).forEach((card) => {
      card.classList.toggle("clab-card-selected", card.dataset.savedId === selectedSavedId);
    });
  }

  function destroyGalleryBuilders() {
    galleryBuilders.forEach((b) => { try { b.destroy(); } catch (e) { /* noop */ } });
    galleryBuilders = [];
  }

  // Одна карточка -- своя мини-миниатюра через тот же /preview (mini:true,
  // спека §7/§15: «no separate preview renderer», «not screenshots -- live»).
  // try/catch локальный: упавший прототип не должен мешать соседним карточкам
  // (спека §16).
  async function renderGalleryCard(saved) {
    const card = el("button", { class: "clab-card", type: "button" });
    card.dataset.savedId = saved.id;
    card.setAttribute("aria-label", "Загрузить прототип: " + (saved.name || saved.id));
    card.addEventListener("click", () => selectSaved(saved));
    els.gallery.append(card);
    if (saved.id === selectedSavedId) card.classList.add("clab-card-selected");

    try {
      const result = await postPreview(saved.toml, currentRuntime());
      if (!result.ok) {
        card.append(el("div", { class: "clab-card-err" },
          ((result.error && result.error.code) || "Ошибка") + ": " +
          ((result.error && result.error.message) || "")));
      } else {
        const slide = buildChartSlide(result.spec, result.payload, { mini: true });
        slide.el.classList.add("ch-mini");
        card.append(slide.el);
        slide.mount();
        galleryBuilders.push(slide);
      }
    } catch (e) {
      card.append(el("div", { class: "clab-card-err" }, "Ошибка отрисовки"));
    }
    card.append(el("div", { class: "clab-card-name" }, saved.name || "(без имени)"));
  }

  // Перерисовать миниатюры уже загруженного списка (селектор поменялся --
  // спека §17: «changing cabinet/period/category changes all saved chart
  // previews»). Список НЕ перезапрашивается -- только пересчёт превью.
  async function renderGalleryThumbnails() {
    destroyGalleryBuilders();
    els.gallery.replaceChildren();
    if (!savedItems.length) {
      els.gallery.append(el("div", { class: "clab-empty" }, "Пока нет сохранённых прототипов."));
      return;
    }
    if (!els.cabinet.value) {
      els.gallery.append(el("div", { class: "clab-empty" }, "Выберите кабинет, чтобы увидеть миниатюры."));
      return;
    }
    // Каждая карточка резолвится независимо (Promise.all, не await в цикле) --
    // одна медленная/битая карточка не задерживает остальные.
    await Promise.all(savedItems.map((saved) => renderGalleryCard(saved)));
  }

  async function fetchSavedList() {
    try {
      const resp = await fetchWithTimeout(SAVED_URL, {}, 15000);
      if (!resp.ok) return [];
      return (await resp.json()).items || [];
    } catch (e) {
      return [];
    }
  }

  // После ЛЮБОЙ мутации (Save/Update/Delete) -- перечитать список с бэкенда
  // (спека, план Задача 6: «After any mutation, reload gallery from backend»).
  async function reloadGalleryList() {
    savedItems = await fetchSavedList();
    await renderGalleryThumbnails();
  }

  async function onSave() {
    const toml = els.toml.value.trim();
    if (!toml) { window.alert("Сначала введите TOML в редактор."); return; }
    const name = window.prompt("Имя прототипа:");
    if (!name) return;
    let resp;
    try {
      resp = await fetchWithTimeout(SAVED_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name, toml: toml }),
      }, 15000);
    } catch (e) {
      window.alert("Не удалось сохранить: сетевая ошибка.");
      return;
    }
    if (!resp.ok) {
      const body = await resp.json().catch(() => null);
      const detail = body && body.detail;
      const message = typeof detail === "string" ? detail : (detail && detail.message) || resp.status;
      window.alert("Не удалось сохранить: " + message);
      return;
    }
    const saved = await resp.json();
    selectedSavedId = saved.id;
    selectedSavedName = saved.name;
    els.update.disabled = false;
    els.delete.disabled = false;
    await reloadGalleryList();
  }

  async function onUpdate() {
    if (!selectedSavedId) return;
    const toml = els.toml.value.trim();
    if (!toml) { window.alert("TOML пуст."); return; }
    let resp;
    try {
      resp = await fetchWithTimeout(SAVED_URL + "/" + encodeURIComponent(selectedSavedId), {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: selectedSavedName, toml: toml }),
      }, 15000);
    } catch (e) {
      window.alert("Не удалось обновить: сетевая ошибка.");
      return;
    }
    if (!resp.ok) {
      const body = await resp.json().catch(() => null);
      const detail = body && body.detail;
      const message = typeof detail === "string" ? detail : (detail && detail.message) || resp.status;
      window.alert("Не удалось обновить: " + message);
      return;
    }
    await reloadGalleryList();
  }

  async function onDelete() {
    if (!selectedSavedId) return;
    if (!window.confirm("Удалить прототип «" + (selectedSavedName || selectedSavedId) + "»?")) return;
    try {
      await fetchWithTimeout(SAVED_URL + "/" + encodeURIComponent(selectedSavedId), { method: "DELETE" }, 15000);
    } catch (e) {
      window.alert("Не удалось удалить: сетевая ошибка.");
      return;
    }
    clearSelection();
    els.toml.value = "";
    if (mainSlide) { mainSlide.destroy(); mainSlide = null; }
    els.preview.replaceChildren();
    clearDiagnostics();
    await reloadGalleryList();
  }

  async function onSelectorChange() {
    await renderMain();
    await renderGalleryThumbnails();
  }

  async function loadCabinets() {
    let cabinets = [];
    try {
      const resp = await fetchWithTimeout(CABINETS_URL, {}, 15000);
      if (resp.ok) cabinets = (await resp.json()).cabinets || [];
    } catch (e) { /* пустой селектор при сетевой ошибке -- не блокирует остальную страницу */ }
    els.cabinet.replaceChildren();
    cabinets.forEach((c) => els.cabinet.append(el("option", { value: c.cabinet }, c.cabinet)));
  }

  async function loadCategories() {
    const cabinet = els.cabinet.value;
    els.category.replaceChildren();
    if (!cabinet) return;
    try {
      const resp = await fetchWithTimeout(
        CATEGORIES_URL + "?cabinet=" + encodeURIComponent(cabinet), {}, 15000);
      if (!resp.ok) return;
      const categories = (await resp.json()).categories || [];
      // Пустое значение "" ("Все категории") пропускаем: невыбранный
      // multi-select уже означает «без фильтра по категории» -- отдельная
      // опция-заглушка в этом виджете избыточна.
      categories.filter((c) => c.value !== "")
        .forEach((c) => els.category.append(el("option", { value: c.value }, c.label)));
    } catch (e) { /* категория остаётся пустой -- Render всё равно работает без фильтра */ }
  }

  async function boot() {
    els.cabinet = byId("chart-lab-cabinet");
    els.period = byId("chart-lab-period");
    els.category = byId("chart-lab-category");
    els.toml = byId("chart-lab-toml");
    els.render = byId("chart-lab-render");
    els.save = byId("chart-lab-save");
    els.update = byId("chart-lab-update");
    els.delete = byId("chart-lab-delete");
    els.preview = byId("chart-lab-preview");
    els.diagnostics = byId("chart-lab-diagnostics");
    els.gallery = byId("chart-lab-gallery");

    els.render.addEventListener("click", renderMain);
    els.save.addEventListener("click", onSave);
    els.update.addEventListener("click", onUpdate);
    els.delete.addEventListener("click", onDelete);
    els.cabinet.addEventListener("change", async () => { await loadCategories(); await onSelectorChange(); });
    els.period.addEventListener("change", onSelectorChange);
    els.category.addEventListener("change", onSelectorChange);

    await loadCabinets();
    await loadCategories();
    await reloadGalleryList();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
