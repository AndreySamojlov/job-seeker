"use strict";

function formatBoardCell(column, row, timezone = "Europe/Moscow") {
  const value = row[column.key];
  let text = value == null || value === "" ? "—" : String(value);
  if (column.kind === "number" && value != null) text = new Intl.NumberFormat("ru-RU", {maximumSignificantDigits: 21}).format(value);
  if (column.kind === "datetime" && value != null) {
    const date = new Date(value);
    text = Number.isFinite(date.getTime()) ? new Intl.DateTimeFormat("ru-RU", {dateStyle:"short", timeStyle:"short", timeZone:timezone}).format(date) : "—";
  }
  let href = null;
  if (column.kind === "link") {
    try { const url = new URL(row[column.href_key]); if (["https:", "http:"].includes(url.protocol)) href = url.href; } catch (_) { /* plain text */ }
  }
  return {text, href};
}

function renderBoardTable(container, columns, rows, options) {
  const o = options || {};
  const cs = o.columnState || tblColState();
  cs.sortKey = o.sortKey || cs.sortKey;
  cs.sortDir = o.sortDirection || cs.sortDir;
  const allCols = columns.map((c, i) => ({...c, fixed: c.fixed === true || i === 0, r: c.kind === "number"}));
  const valueOf = (row, key) => row[key];
  let disposed = false;
  let liveWrap = null;
  function rerender(reason) {
    if (disposed) return;
    if (reason === "sort") {
      if (o.onSort) o.onSort(cs.sortKey, cs.sortDir);
      return;
    }
    draw();
  }
  function draw() {
    if (liveWrap) tblDispose(liveWrap, cs);
    const cols = allCols.filter(c => !cs.hidden.has(c.key));
    const head = el("thead", {}, el("tr", {}, cols.map(c => tblHeadCell(c, cs, {
      root:container, rerender, cls:c.r ? "r" : "", getValue:valueOf
    }))));
    const body = el("tbody", {}, rows.map(row => el("tr", {}, cols.map(c => {
      const cell = formatBoardCell(c, row, o.timezone);
      const attrs = {class:c.r ? "r" : ""};
      if (c.kind === "text" || c.kind === "link") { attrs.class += " clip"; attrs.title = cell.text; }
      return el("td", attrs, cell.href
        ? el("a", {href:cell.href, target:"_blank", rel:"noopener noreferrer"}, cell.text)
        : cell.text);
    }))));
    const table = el("table", {}, [tblColgroup(cols, cs), head, body]);
    const wrap = tblWrap(cs, rerender, {cols, rows, filename:"board-page.csv", getValue:valueOf});
    liveWrap = wrap;
    wrap.append(table);
    tblEnableSelection(wrap, cs, {cols, rows, getValue:valueOf});
    const total = o.totalRows || 0, size = o.pageSize || 100, page = o.page || 0;
    if (total > rows.length) {
      const download = wrap.querySelector(".tblexport");
      download.textContent = "⭳ Скачать страницу";
      download.title = "Скачать " + rows.length + " строк текущей страницы; всего в выборке " + total;
    }
    const pager = el("div", {class:"pager ce-board-pager"});
    const prev = el("button", {class:"pg",type:"button"}, "Назад");
    const next = el("button", {class:"pg",type:"button"}, "Далее");
    prev.disabled = page <= 0; next.disabled = (page + 1) * size >= total;
    prev.addEventListener("click", () => o.onPage && o.onPage(page - 1));
    next.addEventListener("click", () => o.onPage && o.onPage(page + 1));
    const first = rows.length ? page * size + 1 : 0;
    pager.append(prev, el("span", {class:"pgi"}, `${first}–${Math.min(page * size + rows.length,total)} / ${total}`), next);
    container.replaceChildren(wrap, pager);
    if (!rows.length) container.append(el("p", {class:"empty"}, "Нет данных"));
  }
  draw();
  return () => {disposed = true; if (liveWrap) tblDispose(liveWrap, cs); liveWrap = null; container.replaceChildren();};
}

if (typeof module !== "undefined") module.exports = {formatBoardCell, renderBoardTable};
