"""Сканер доменов: {key: DomainSpec} из <pkg>.<sub>.spec.DOMAIN_SPEC.

Что делает: обходит подпакеты переданных пакетов, импортит `<sub>.spec`, читает
DOMAIN_SPEC, сортирует детерминированно по (order, key).
Как используется: `domain_registry` зовёт с именами из Registration-API.
От чего зависит: importlib/pkgutil + domain_spec (лист). Тела доменных модулей
не импортит — только spec.py (import-leaf инвариант).
"""
from __future__ import annotations

import importlib
import pkgutil

from cockpit_engine.domain_spec import DomainSpec


def build_registry(package_paths) -> dict[str, DomainSpec]:
    """Собрать {key: DomainSpec} из <pkg>.<sub>.spec.DOMAIN_SPEC во всех package_paths.

    Детерминизм: сортировка (order, key) ВСЕГДА (§5.4). Guard-first: канон требует
    РАЗЛИЧНЫХ order у доменов (10/20/30/40) — любой парный дубль order у двух разных
    доменов есть ошибка конфигурации и роняет ValueError (safety-net против случайного
    дубля). Подпакет без spec.py или без DOMAIN_SPEC — тихо пропускается.

    Идемпотентность по идентичности: опирается на кэш importlib (модуль spec.py
    импортится один раз), поэтому повторные вызовы возвращают ТЕ ЖЕ объекты DomainSpec —
    это важно для потребителей, сверяющих идентичность (domain_registry, §8)."""
    specs: list[DomainSpec] = []
    seen_order: dict[int, str] = {}
    for pkg_name in package_paths:
        try:
            pkg = importlib.import_module(pkg_name)
        except ModuleNotFoundError:
            continue
        for mod in pkgutil.iter_modules(pkg.__path__, prefix=pkg_name + "."):
            if not mod.ispkg:
                continue
            try:
                spec_mod = importlib.import_module(mod.name + ".spec")
            except ModuleNotFoundError:
                continue
            ds = getattr(spec_mod, "DOMAIN_SPEC", None)
            if not isinstance(ds, DomainSpec):
                continue
            if ds.order in seen_order and seen_order[ds.order] != ds.key:
                raise ValueError(
                    f"коллизия order={ds.order}: {seen_order[ds.order]!r} и {ds.key!r}")
            seen_order[ds.order] = ds.key
            specs.append(ds)
    specs.sort(key=lambda s: (s.order, s.key))
    return {s.key: s for s in specs}
