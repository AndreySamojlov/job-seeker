"""Дневная агрегация метрики — третий архетип entity_tables (S17-эквивалент по
дню, не по сущности). Контракт-соседи: entity_tables.py (архетип 1, пивот
сигналов сущностей — строки без попадания правила отбрасываются) и
on_the_fly_sections.py (архетип 2, тот же пивот поверх ПОЛНОГО каталога).
Здесь строка = день периода с суммой метрики — сигналов у дня нет вообще,
поэтому переиспользовать оба существующих архетипа технически нельзя (см.
harness:docs/superpowers/archive/specs/2026-08-20-daily-aggregation-engine-design.md §2)."""
from __future__ import annotations

from collections.abc import Sequence
from decimal import Decimal


def _iso(d) -> str:
    return d.isoformat() if hasattr(d, "isoformat") else str(d)


def _num(v):
    if v is None:
        return None
    return float(v) if isinstance(v, Decimal) else v


def build_daily_table(rows: list[dict], value_keys: Sequence[str], *,
                       date_key: str = "obs_date") -> dict:
    """Просуммировать `rows` (уже отфетченная доменом грань «сущность × день»)
    по дню. Чистая функция — не ходит в БД, как оба соседних архетипа.

    Сумма по дню = сумма непустых значений; день, для которого ни одна строка
    не несёт значение колонки `k`, получает `k: None` (не 0.0 — см. докстринг
    модуля и спеку §3). `Decimal` приводится к `float` на границе — примитив
    общий, не вправе полагаться на приведение вызывающего."""
    by_day: dict[str, dict] = {}
    for r in rows:
        d = r.get(date_key)
        if d is None:
            continue
        iso = _iso(d)
        acc = by_day.setdefault(iso, {k: None for k in value_keys})
        for k in value_keys:
            v = _num(r.get(k))
            if v is None:
                continue
            acc[k] = v if acc[k] is None else acc[k] + v
    out_rows = [{date_key: iso, **vals} for iso, vals in sorted(by_day.items())]
    return {"id_key": date_key, "axis": "time", "rows": out_rows}
