"""Живые тексты правил для веба: код сигнала → {title, description, formula, rationale}.

Снимок текстов не хранит (принцип ADR S14): web подмешивает их из active-конфига
при каждом чтении. Коды сигналов Финансов имеют префикс уровня (sku_loss, …) —
конфиг развёртывается по уровням.
"""
from __future__ import annotations

from ..domain_registry import DOMAIN_REGISTRY

_FIELDS = ("title", "description", "formula", "rationale")


def rule_meta_from_config(rules: dict, domain: str) -> dict:
    """Уровни префикса кодов берём из DomainSpec.levels (Финансы → sku/category/unit);
    домен без levels даёт код как есть."""
    spec = DOMAIN_REGISTRY.get(domain)
    levels = spec.levels if spec is not None else None
    meta = {}
    for code, rc in rules.items():
        entry = {f: rc.get(f) for f in _FIELDS}
        if levels:
            # Уровни делят один read-only entry. Если downstream начнёт обогащать
            # meta поуровнево — копировать entry.copy() на каждый level.
            for level in levels:
                meta[f"{level}_{code}"] = entry
        else:
            meta[code] = entry
    return meta
