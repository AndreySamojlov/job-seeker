"""Общий build_entity_tables семейства on-the-fly доменов (S17 §on-the-fly, debt-main-17).
Архетип 2 из трёх. Архетип 1 — report/entity_tables.py. Архетип 3 (день, не
сущность) — report/daily_table.py.

Что делает: пивот ПОЛНОГО каталога сущностей уровня (rows — как было получено
    запросом домена, каждая запись = строка результата, даже без единого сигнала)
    + rule_hits/money/agg_score из сигналов + eligible-действия (report.actions_eval,
    контракт `actions_by_entity`). Отличие от report/entity_tables.py (Коммерция/
    Финансы — pre-storage семья): та строит строки ПО сигналам — только сущности
    с ≥1 хитом попадают в таблицу. Здесь семья on-the-fly (pricing/logistics/
    marketing/assortment) сознательно показывает весь каталог как master-таблицу
    «Что требует внимания», не только сигнальные строки — контракт закреплён
    спекой harness:docs/superpowers/archive/specs/2026-07-05-pricing-catalog-driven-view-design.md
    («таблица теперь будет содержать все SKU каталога»). Два архетипа сведены к
    ОДНОМУ noisy_or (report.entity_tables.noisy_or, импорт, не копия) — ADR
    2026-07-10 в harness:docs/decisions.md: agg_score БЕЗ округления (было round(...,4) в
    приватных копиях — децимальный дрейф устранён, единая математика с pre-storage
    семьёй). Извлечено из четырёх копипаст-реализаций (debt-main-17); settlement
    (report.py/api_report.py) — вне скоупа этого извлечения (debt-main-38).
Как используется: domains/{pricing,logistics,marketing,assortment}/sections.py →
    build_entity_tables(rows, signals, cfg, cols=...).
От чего зависит: report.actions_eval (eligible_actions — контракт actions_by_entity,
    капит N=3 действия/сущность, дедуп конфликтов, нормирует effect_score — этого
    приватные копии НЕ делали, effect_score оставался всегда None, аналог bug-main-2
    для карточек действий; фикс — побочный эффект унификации), report.entity_tables
    (noisy_or — единственная реализация формулы усиления).
"""
from __future__ import annotations

from .actions_eval import eligible_actions
from .entity_tables import noisy_or
from ..rules.signals import Signal


def build_entity_tables(rows: list[dict], signals: list[Signal], cfg, *,
                        id_key: str = "sku_id", level: str = "sku",
                        cols, effect_baseline: dict | None = None) -> dict:
    """entity_tables.<level> — одна строка на КАЖДУЮ запись rows (весь каталог).

    Args:
        rows: полный набор строк уровня (результат доменного запроса).
        signals: сигналы правил домена (уже с проставленными score — attach_scores).
        cfg: RulesConfig домена (несёт .actions для eligible_actions).
        id_key: имя колонки-идентификатора сущности в rows.
        level: код уровня (по умолчанию "sku" — все 4 домена-потребителя однoуровневые).
        cols: проекция колонок исходной строки в выходную (позиционно, только
              обязательный keyword — явное объявление контракта на стороне вызова).
        effect_baseline: кабинетная нормировочная база effect_score
              (`actions_eval.build_effect_baseline` на ПОЛНОЙ популяции кабинета).
              None — прежнее поведение, максимум берётся по переданной популяции.
              На срезе по категории (epic-main-19) база ОБЯЗАТЕЛЬНА: иначе
              единственное уцелевшее действие получает effect_score = 1.0 просто
              потому, что оно одно, и «полезность» начинает зависеть от того,
              смотрим мы кабинет целиком или одну категорию. Решение владельца
              2026-07-22: линейка всегда кабинетная.

    Returns:
        {level: {id_key, rows}}
        rows: проекция по cols + actions (eligible_actions) + rule_hits
              {code: {score, severity, money}} + agg_score (noisy_or, без округления)
              + money (максимум по попаданиям, None если сигналов без money не было).
    """
    levels = {level: {"id_key": id_key, "rows": rows, "cols": cols}}
    actions_by_entity = eligible_actions(cfg.actions, levels, signals,
                                         baseline=effect_baseline)

    entity_rule_hits: dict = {}
    for s in signals:
        if s.level != level:
            continue
        code = s.rule_code or s.code
        entity_rule_hits.setdefault(s.entity_id, {})[code] = {
            "score": s.score,
            "severity": s.severity,
            "money": s.snapshot.get("money") if s.snapshot else None,
        }

    result_rows = []
    for row in rows:
        entity_id = row.get(id_key)
        rule_hits = entity_rule_hits.get(entity_id, {})
        moneys = [h["money"] for h in rule_hits.values() if h.get("money") is not None]
        scores = [h["score"] for h in rule_hits.values() if h.get("score") is not None]
        out_row = {k: row.get(k) for k in cols}
        out_row["actions"] = actions_by_entity.get(level, {}).get(entity_id, [])
        out_row["rule_hits"] = rule_hits
        out_row["agg_score"] = noisy_or(scores) if scores else None
        out_row["money"] = max(moneys) if moneys else None
        result_rows.append(out_row)
    return {level: {"id_key": id_key, "rows": result_rows}}
