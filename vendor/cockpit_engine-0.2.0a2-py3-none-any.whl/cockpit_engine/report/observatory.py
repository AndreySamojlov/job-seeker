"""Агрегатор read-only витрины «Правила»: каталог правил доменов + живая телеметрия
из снимков entity_tables. Чистая функция, без БД."""
from __future__ import annotations

from cockpit_engine.rules.ast_render import render_predicate, strip_placeholders
from cockpit_engine.rules.formula_render import (
    _UPPER_OPS, feature_codes, render_ast_chips, top_comparison)


def _rule_levels(domain: str, rc: dict) -> list:
    """Членство правила по уровням (#10). Каждое правило несёт скалярный level."""
    lvl = rc.get("level")
    return [lvl] if lvl else []


# id_key таблицы entity_tables → уровень (для счётчика наблюдений #8). Таблицы без
# распознаваемого id_key (напр. pnl_detail) — не наблюдения, в счётчик не идут.
_IDKEY_LEVEL = {"sku_id": "sku", "category": "category",
                "business_unit": "unit", "brand": "brand"}


def _code_index(domain: str, rules: dict) -> dict:
    """Карта «код в rule_hits снимка → код правила в каталоге». Тождество: коды
    сигналов уже совпадают с кодами каталога (finance несёт level в самом коде)."""
    return {code: code for code in rules}


def _new_acc() -> dict:
    return {"count": 0, "sev": {"critical": 0, "warning": 0, "info": 0},
            "money_sum": 0.0, "samples": [], "scores": []}


def _median(values: list) -> float | None:
    """Медиана глубины симптома по сработавшим (#6). max тянул правило к 1.0 —
    у любого кода с групповой нормировкой (score.py: ÷худший/÷макс) есть сигнал
    1.0. Медиана держит балл в теле распределения. Чётное число → среднее двух
    центральных; пусто → None."""
    if not values:
        return None
    xs = sorted(values)
    n = len(xs)
    mid = n // 2
    return xs[mid] if n % 2 else (xs[mid - 1] + xs[mid]) / 2.0


def _condition_op(rc: dict) -> str | None:
    pred = rc.get("predicate")
    if isinstance(pred, dict) and pred.get("op") in {"lt", "le", "gt", "ge"}:
        return pred["op"]
    return None


_SKEW_COMPONENT_RU = {"commission": "комиссии", "logistics": "логистики"}


def _skew_norm_node(component: str, norm: float) -> dict:
    ru = _SKEW_COMPONENT_RU.get(component, component)
    return {"const": norm, "label": f"норма {ru}",
            "desc": f"типовая доля статьи «{ru}» в выручке"}


def _skew_formula_ast(skews: list) -> dict | None:
    cmps = [{"op": "gt", "args": [s["value"], _skew_norm_node(s["component"], s["norm"])]}
            for s in skews]
    if not cmps:
        return None
    return cmps[0] if len(cmps) == 1 else {"op": "or", "args": cmps}


def _formula_ast(rc: dict):
    """AST для блока «формула»: skews_eval → OR-сравнения с нормами; symptom-метрика;
    иначе arg0 верхнего сравнения."""
    skews = rc.get("skews_eval")
    if skews:
        return _skew_formula_ast(skews)
    sm = rc.get("symptom_metric")
    if sm is not None:
        return sm
    cmp_node = top_comparison(rc.get("predicate"))
    if cmp_node is not None:
        return cmp_node.get("args", [None])[0]
    return None


def _gate_ast(rc: dict):
    """AST предиката-гейта — только если предикат трогает фичи помимо
    symptom-метрики (детект применимости). Иначе None."""
    sm = rc.get("symptom_metric")
    pred = rc.get("predicate")
    if sm is None or not isinstance(pred, dict):
        return None
    if feature_codes(pred) - feature_codes(sm):
        return pred
    return None


def _score_ast(rc: dict) -> dict:
    """Display-AST глубины для блока балла, обёрнутый в median (#5/#6, B-доработка).
    Гибрид: пороговая семья (symptom_metric + верх. сравнение lt/le симптома с порогом)
    → (порог − симптом) ÷ порог; прочие (когортные below_zero / деньги-без-симптома /
    перекос skews / фолбэк) → feature-чип symptom_depth (посемейная математика в score.py)."""
    sm = rc.get("symptom_metric")
    thr = rc.get("threshold")
    cmp_node = top_comparison(rc.get("predicate"))
    is_threshold = (
        sm is not None and thr is not None and not rc.get("skews")
        and rc.get("symptom_direction") != "below_zero"
        and cmp_node is not None and cmp_node.get("op") in _UPPER_OPS
        and bool(feature_codes(cmp_node.get("args", [None])[0]) & feature_codes(sm)))
    if is_threshold:
        depth = {"op": "div", "args": [
            {"op": "sub", "args": [{"param": "threshold"}, sm]},
            {"param": "threshold"}]}
    else:
        depth = {"feature": "symptom_depth"}
    return {"op": "median", "args": [depth]}


def _synth_cut(rc: dict) -> list:
    """Синтез условия из AST-предиката, когда bands.cuts отсутствуют.
    op-aware: lt/le→ключ lt, gt/ge→ключ gt; значение из param(threshold)/const.
    Возвращает список cut'ов (0 или 1) с severity правила."""
    cmp_node = top_comparison(rc.get("predicate"))
    if cmp_node is None:
        return []
    rhs = cmp_node.get("args", [None, None])[1]
    if not isinstance(rhs, dict):
        return []
    if "param" in rhs:
        val = rc.get("threshold")
    elif "const" in rhs:
        val = rhs["const"]
    else:
        return []
    if val is None:
        return []
    key = "lt" if cmp_node["op"] in _UPPER_OPS else "gt"
    return [{key: val, "severity": rc.get("severity")}]


def aggregate_observatory(configs: dict, reports: dict, cabinet: str | None = None,
                          feature_registry: dict | None = None) -> dict:
    """configs: {domain: RulesConfig}; reports: {domain: payload|None};
    cabinet: «marketplace:code» вендорящего кабинета (опционально).
    Вернуть {domains:[{domain, rules:[{code,title,enabled,severity,threshold,
    hits,sev_counts,money,samples,actions,score,formula,description,rationale,
    level,bands,cabinets}]}]}."""
    registry = feature_registry or {}
    domains_out = []
    for domain, cfg in configs.items():
        report = reports.get(domain) or {}
        ets = report.get("entity_tables") or {}
        code_index = _code_index(domain, cfg.rules)
        acc: dict[str, dict] = {}
        act_count: dict[str, int] = {}
        viab_count: dict[str, dict[str, int]] = {}
        level_counts: dict[str, int] = {}        # #8: число наблюдений по уровню
        for tbl in ets.values():
            if not isinstance(tbl, dict):
                continue
            id_key = tbl.get("id_key")
            lvl = _IDKEY_LEVEL.get(id_key)
            if lvl is not None:
                level_counts[lvl] = level_counts.get(lvl, 0) + len(tbl.get("rows", []))
            for row in tbl.get("rows", []):
                for hit_code, hit in (row.get("rule_hits") or {}).items():
                    rule_code = code_index.get(hit_code)
                    if rule_code is None:
                        continue
                    a = acc.setdefault(rule_code, _new_acc())
                    a["count"] += 1
                    sev = hit.get("severity")
                    if sev in a["sev"]:
                        a["sev"][sev] += 1
                    money = hit.get("money")
                    if isinstance(money, (int, float)) and not isinstance(money, bool):
                        a["money_sum"] += money
                    s = hit.get("score")
                    if isinstance(s, (int, float)) and not isinstance(s, bool):
                        a["scores"].append(s)
                    if len(a["samples"]) < 3 and id_key:
                        a["samples"].append(row.get(id_key))
                for ea in (row.get("actions") or []):
                    ac = ea.get("action_code")
                    if ac:
                        act_count[ac] = act_count.get(ac, 0) + 1
                        via = ea.get("viability", "ok")
                        vc = viab_count.setdefault(ac, {"ok": 0, "weak": 0, "futile": 0})
                        vc[via] = vc.get(via, 0) + 1
        rules_out = []
        for code, rc in cfg.rules.items():
            a = acc.get(code, _new_acc())
            acts = []
            for ac_code, ac in cfg.actions.items():
                if code not in ac.get("applies_to", []):
                    continue
                eligible = act_count.get(ac_code, 0)
                vb = viab_count.get(ac_code) or {"ok": eligible, "weak": 0, "futile": 0}

                # applicable_when text
                aw_text = render_predicate(ac.get("applicable"))

                # ok_formula: invert first weak guard only (no fallback to futile)
                guards = ac.get("viability_eval") or []
                weak_guards = [g for g in guards if g.get("level") == "weak"]
                first_weak = weak_guards[0] if weak_guards else None
                ok_formula = render_predicate(first_weak.get("when") if first_weak else None,
                                              invert=True)

                # fired_guards: one entry per level, first guard of that level
                seen_levels: set[str] = set()
                fired_guards: list[dict] = []
                for g in guards:
                    lvl = g.get("level", "weak")
                    if lvl in seen_levels:
                        continue
                    count = vb.get(lvl, 0)
                    if count > 0:
                        formula = render_predicate(g.get("when"))
                        if formula:
                            fired_guards.append({"level": lvl, "formula_text": formula, "count": count})
                            seen_levels.add(lvl)

                acts.append({
                    "code": ac_code,
                    "label": ac.get("label", ac_code),
                    "eligible": eligible,
                    "sleeping": eligible == 0,
                    "applicable_when_text": aw_text,
                    "viability_breakdown": vb,
                    "fired_guards": fired_guards,
                    "ok_formula": ok_formula,
                    "recommendation_text": strip_placeholders(ac.get("recommendation", "")),
                    "cost": ac.get("cost"),
                    "confidence": ac.get("confidence"),
                })
            bands = rc.get("bands")
            cuts = (bands or {}).get("cuts") if isinstance(bands, dict) else None
            if not cuts:
                cuts = _synth_cut(rc)
            levels = _rule_levels(domain, rc)
            observations = sum(level_counts.get(l, 0) for l in levels)
            rules_out.append({
                "code": code, "title": rc.get("title"),
                "enabled": rc.get("enabled", True), "severity": rc.get("severity"),
                "threshold": rc.get("threshold"), "hits": a["count"],
                "sev_counts": a["sev"], "money": a["money_sum"],
                "samples": a["samples"], "actions": acts,
                "score": _median(a["scores"]),
                "formula": rc.get("formula"), "description": rc.get("description"),
                "rationale": rc.get("rationale"),
                "levels": levels, "observations": observations,
                "condition_op": _condition_op(rc),
                "bands": {
                    "cuts": cuts or [],
                    "metric_label": (bands or {}).get("metric_label")
                    if isinstance(bands, dict) else None},
                "cabinets": [cabinet] if cabinet else [],
                "formula_chips": render_ast_chips(
                    _formula_ast(rc), registry,
                    {"threshold": rc.get("threshold")}),
                "score_chips": render_ast_chips(
                    _score_ast(rc), registry,
                    {"threshold": rc.get("threshold")}),
                "gate_chips": render_ast_chips(
                    _gate_ast(rc), registry,
                    {"threshold": rc.get("threshold")}),
                "value_chips": render_ast_chips(
                    rc.get("value"), registry,
                    {"threshold": rc.get("threshold")})})
        domains_out.append({"domain": domain, "rules": rules_out})
    return {"domains": domains_out}
