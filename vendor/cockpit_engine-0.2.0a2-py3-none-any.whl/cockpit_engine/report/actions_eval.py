"""Слой прескрипции: eligible-действия из каталога, фиче-строк и сигналов.

Единственный вычислитель действий (DRY). entity_tables/digest/observatory —
потребители его выхода. Чистый модуль, без БД. Грамматика — rules/ast_eval.
"""
from __future__ import annotations

from ..rules.ast_eval import evaluate as ast_evaluate
from ..rules.signals import Signal

_VIA_ORDER = {"ok": 0, "weak": 1, "futile": 2}


def viability_of(guards: list[dict], row: dict) -> str:
    """Худший сработавший уровень guard ('futile'>'weak'>'ok'). По умолчанию 'ok'."""
    worst = "ok"
    for g in guards:
        if bool(ast_evaluate(g["when"], row)):
            if _VIA_ORDER[g["level"]] > _VIA_ORDER[worst]:
                worst = g["level"]
    return worst


def _as_money(value) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return 0.0
    return float(value)


def eval_action_for_entity(code: str, action: dict, row: dict, fired: set) -> dict | None:
    """EligibleAction для одной сущности или None, если действие недоступно.

    Доступно: сработало правило из applies_to (fired ∩ applies_to ≠ ∅) И
    applicable=true (если задано). effect_score проставляется позже (Task 4)."""
    triggered = [c for c in action.get("applies_to", []) if c in fired]
    if not triggered:
        return None
    applicable = action.get("applicable")
    if applicable is not None and not bool(ast_evaluate(applicable, row)):
        return None
    effect = action.get("effect")
    effect_money = _as_money(ast_evaluate(effect, row)) if effect is not None else 0.0
    evidence = {e["key"]: ast_evaluate(e["expr"], row)
                for e in action.get("evidence_eval", [])}
    return {
        "action_code": code,
        "label": action.get("label", code),
        "triggered_by": triggered,
        "effect_money": effect_money,
        "effect_score": None,
        "effect_type": action.get("effect_type"),
        "confidence": action.get("confidence"),
        "evidence": evidence,
        "viability": viability_of(action.get("viability_eval", []), row),
        "cost": action.get("cost"),
        "recommendation": action.get("recommendation"),
        "conflicts_with": list(action.get("conflicts_with", [])),
    }


def _rule_hits_by_entity(signals: list[Signal]) -> dict:
    """{(level, entity_id): set(rule_codes)} из сигналов. У сигнала с префиксом
    уровня (Финансы) ключ — rule_code; иначе code (Коммерция тождественна)."""
    out: dict = {}
    for s in signals:
        out.setdefault((s.level, s.entity_id), set()).add(s.rule_code or s.code)
    return out


def dedup_conflicts(eas: list[dict]) -> list[dict]:
    """Из взаимно-конфликтующих на одной сущности оставить один. Порядок выбора:
    non-futile СТРОГО выше futile (futile никогда не побеждает eligible в конфликте,
    как бы ни были велики деньги), затем больший effect_money, при равенстве — лучший
    viability. Порядок исходного списка сохраняется."""
    order = {"ok": 0, "weak": 1, "futile": 2}
    drop: set[int] = set()
    for i, a in enumerate(eas):
        if i in drop:
            continue
        for j, b in enumerate(eas):
            if j == i or j in drop:
                continue
            if (b["action_code"] in a.get("conflicts_with", [])
                    or a["action_code"] in b.get("conflicts_with", [])):
                key_a = (a["viability"] != "futile", a["effect_money"], -order[a["viability"]])
                key_b = (b["viability"] != "futile", b["effect_money"], -order[b["viability"]])
                drop.add(j if key_a >= key_b else i)
    return [a for k, a in enumerate(eas) if k not in drop]


def build_effect_baseline(result: dict) -> dict:
    """Нормировочная база effect_score: максимум effect_money по уровню.

    Что делает: снимает {level: max(effect_money)} с результата `eligible_actions`,
    посчитанного на ПОЛНОЙ популяции кабинета.
    Как используется: домен считает действия дважды — без фильтра (для базы) и на
    срезе — и передаёт базу вторым вызовом, чтобы «полезность» действия не зависела
    от того, смотрим мы кабинет целиком или одну категорию (epic-main-19, спека §5:
    эталон всегда кабинетный).
    От чего зависит: только на форме результата eligible_actions."""
    return {level: max((e["effect_money"] for eas in per_entity.values() for e in eas),
                       default=0.0)
            for level, per_entity in result.items()}


def eligible_actions(actions_cfg: dict, levels: dict, signals: list[Signal],
                     cap: int = 3, baseline: dict | None = None) -> dict:
    """{level: {entity_id: [EligibleAction]}}. dedup конфликтов + cap N + нормировка
    effect_score по уровню (effect_money / max по уровню).

    `baseline=None` → максимум берётся по самой популяции (прежнее поведение). На
    срезе домен передаёт кабинетную базу (`build_effect_baseline`), иначе единственное
    оставшееся действие получает effect_score = 1.0 просто потому, что оно одно."""
    fired = _rule_hits_by_entity(signals)
    out: dict = {}
    for level, spec in levels.items():
        id_key = spec["id_key"]
        per_entity: dict = {}
        for row in spec["rows"]:
            entity_id = row.get(id_key)
            f = fired.get((level, entity_id))
            if not f:
                continue
            eas = []
            for code, action in actions_cfg.items():
                ea = eval_action_for_entity(code, action, row, f)
                if ea is not None:
                    ea["entity_id"] = entity_id
                    ea["level"] = level
                    eas.append(ea)
            if not eas:
                continue
            eas = dedup_conflicts(eas)
            eas.sort(key=lambda e: e["effect_money"], reverse=True)
            per_entity[entity_id] = eas[:cap]
        max_eff = (baseline.get(level, 0.0) if baseline is not None
                   else max((e["effect_money"] for eas in per_entity.values() for e in eas),
                            default=0.0))
        for eas in per_entity.values():
            for e in eas:
                e["effect_score"] = (e["effect_money"] / max_eff) if max_eff > 0 else 0.0
        out[level] = per_entity
    return out
