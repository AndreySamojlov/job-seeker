"""Каскад секций слоя понимания: декларация входов → что пересчитать по триггеру.

Единственный источник правды о связанности секций. Без БД, без домена. Токены
входов: внешние 'views'/'rules' (меняются триггером) или имена секций-производителей
('signals'/'digest'). Секция затронута, если её входы пересекаются с изменившимся
множеством (по транзитивному замыканию).
"""
from __future__ import annotations

_VIEWS = "views"
_RULES = "rules"

# Секция -> множество её входов.
_INPUTS: dict[str, set[str]] = {
    "charts":        {_VIEWS},
    "signals":       {_VIEWS, _RULES},
    "digest":        {"signals"},
    "entity_tables": {"signals"},
    "mechanics":     {"signals", "digest"},
    "ai":            {"digest"},
}

# Контент-секции (без всегда-пишущейся meta и внешней ai) в порядке записи (topo):
# signals раньше зависимых, digest раньше mechanics. Единственный источник правды —
# и допустимое множество, и порядок пересчёта.
CONTENT = ("signals", "charts", "digest", "entity_tables", "mechanics")

# Имя секции -> ключ в плоском payload (для склейки и бэкфилла).
SECTION_KEY = {
    "meta": "meta",
    "signals": "signals",
    "charts": "chart_series",
    "digest": "digest",
    "entity_tables": "entity_tables",
    "mechanics": "mechanics",
}

_TRIGGER_TOKENS = {"data": {_VIEWS}, "rules": {_RULES}}


def affected_sections(trigger: str) -> set[str]:
    """Секции, затронутые триггером, по транзитивному замыканию входов."""
    if trigger not in _TRIGGER_TOKENS:
        raise ValueError(f"Неизвестный триггер: {trigger!r} (ожидался 'data'|'rules')")
    changed = set(_TRIGGER_TOKENS[trigger])
    affected: set[str] = set()
    progressing = True
    while progressing:
        progressing = False
        for sec, ins in _INPUTS.items():
            if sec in affected:
                continue
            if ins & (changed | affected):
                affected.add(sec)
                progressing = True
    return affected


def content_sections(trigger: str) -> list[str]:
    """Контент-секции для пересчёта, в порядке записи (topo)."""
    aff = affected_sections(trigger)
    return [s for s in CONTENT if s in aff]


def ai_affected(trigger: str) -> bool:
    """Затронут ли вход секции ai (нужно ли метить её stale)."""
    return "ai" in affected_sections(trigger)
