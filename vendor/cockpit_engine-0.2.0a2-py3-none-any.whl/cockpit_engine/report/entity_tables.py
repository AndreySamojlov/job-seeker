"""Единые таблицы сущностей для веба (S17). Архетип 1 из трёх — пивот
сигналов сущностей. Архетип 2 (тот же пивот поверх полного каталога) —
report/on_the_fly_sections.py. Архетип 3 (день, не сущность, сигналов нет) —
report/daily_table.py.

Пивот сигналов по (level, entity_id) + join со строками вьюх понимания.
Строка = сущность: проекция вьюхи + money (max по попаданиям) + agg_score
(noisy-or) + rule_hits {code: {score, severity, money}}. Инвариант: каждый
сигнал уровня с известной сущностью представлен ровно одним входом rule_hits.
Балл сигнала только читается (score уже проставлен движком, Task 1-2). Строки
ранжируются money по убыванию (None -> 0), agg_score — тай-брейк (task-main-90 AC1).

КОНТРАКТ составного entity_id (task-main-62, epic-main-17): любой уровень с
гранью «сущность × доп. измерение» (первый прецедент — «Города» в Логистике,
task-main-63) ОБЯЗАН формировать entity_id через make_composite_entity_id
ниже — голый sku_id для такого уровня СХЛОПНЕТ строки разных измерений в
build_entity_tables/on_the_fly_sections.build_entity_tables/actions_eval.
eligible_actions (все три индексируют по entity_id как по обычному словарному
ключу, ничего не проверяя на уникальность) — не с ошибкой, а тихо (регресс-гейт
и разбор ловушки — tests/report/test_composite_entity_id.py). dimension_value
ДОЛЖЕН быть непустой строкой без NULL (вызывающая вьюха/домен гарантирует это
сами, например COALESCE в SQL, до формирования ключа) — NULL/пустая строка на
месте измерения даёт одинаковый entity_id для всех строк без измерения и
воспроизводит ту же ловушку. entity_id НЕ включать в проекцию `cols` уровня —
это внутренний технический ключ, для подписи строки в UI использовать отдельные
человекочитаемые колонки (sku_id, product_name, название измерения), не разбор
составного ключа.
"""
from __future__ import annotations

from ..rules.signals import Signal

# Разделитель составного entity_id — control-символ (ASCII Unit Separator),
# гарантированно отсутствует и в sku_id (числовой/буквенно-цифровой код), и в
# названии доп. измерения (человекочитаемый текст из справочника/атрибута).
COMPOSITE_ID_SEP = "\x1f"


def make_composite_entity_id(primary_id: str, dimension_value: str) -> str:
    """entity_id для грани «сущность × доп. измерение» (контракт см. докстринг
    модуля). primary_id — id основной сущности (например, sku_id), первым;
    dimension_value — значение доп. измерения (например, город), непустое."""
    return f"{primary_id}{COMPOSITE_ID_SEP}{dimension_value}"


def noisy_or(scores: list[float]) -> float:
    """Вероятность хотя бы одного события при независимых сигналах."""
    p = 1.0
    for s in scores:
        p *= 1.0 - s
    return 1.0 - p


def build_entity_tables(signals: list[Signal], levels: dict,
                        actions_by_entity: dict | None = None) -> dict:
    """Пивот сигналов по уровню и сущности.

    Args:
        signals: список сигналов с уже проставленными score
        levels: {level: {id_key, rows, cols}}
                id_key: имя колонки-идентификатора
                rows: список строк вьюхи понимания
                cols: кортеж имён колонок для проекции

    Returns:
        {level: {id_key, rows}}
        rows: сущность = проекция вьюхи по cols +
              money (максимум по попаданиям) +
              agg_score (noisy-or) +
              rule_hits {code: {score, severity, money}}
    """
    out: dict = {}
    for level, spec in levels.items():
        by_id = {r.get(spec["id_key"]): r for r in spec["rows"]}
        hits: dict[str, dict] = {}
        for s in signals:
            if s.level != level or s.entity_id not in by_id:
                continue
            hits.setdefault(s.entity_id, {})[s.code] = {
                "score": s.score, "severity": s.severity,
                "money": s.snapshot.get("money")}
        rows = []
        for entity_id, rule_hits in hits.items():
            src = by_id[entity_id]
            row = {k: src.get(k) for k in spec["cols"]}
            moneys = [h["money"] for h in rule_hits.values() if h["money"] is not None]
            row["money"] = max(moneys) if moneys else None
            row["agg_score"] = noisy_or(
                [h["score"] for h in rule_hits.values() if h["score"] is not None])
            row["rule_hits"] = rule_hits
            if actions_by_entity is not None:
                row["actions"] = actions_by_entity.get(level, {}).get(entity_id, [])
            rows.append(row)
        # task-main-90 AC1: money — первичный ключ сортировки, agg_score — вторичный
        # (тай-брейк). None money (ни одно попадание не дало ₽) трактуется как 0.
        rows.sort(key=lambda r: (r["money"] or 0, r["agg_score"]), reverse=True)
        out[level] = {"id_key": spec["id_key"], "rows": rows}
    return out
