"use strict";

function formatBoardCell(column, row, timezone = "Europe/Moscow") {
  const value = row[column.key];
  let text = value == null || value === "" ? "—" : String(value);
  if (column.kind === "number" && value != null) text = new Intl.NumberFormat("ru-RU", {maximumSignificantDigits: 21}).format(value);
  if (column.kind === "datetime" && value != null) {
    const date = new Date(value);
    text = Number.isFinite(date.getTime()) ? new Intl.DateTimeFormat("ru-RU", {dateStyle:"short", timeStyle:"short", timeZone:timezone}).format(date) : "—";
  }
  let href = null;
  if (column.kind === "link") {
    try { const url = new URL(row[column.href_key]); if (["https:", "http:"].includes(url.protocol)) href = url.href; } catch (_) { /* plain text */ }
  }
  return {text, href};
}

function renderBoardTable(container, columns, rows, options) {
  options = options || {};
  const table = buildFlatTable(columns, rows, {cellContent(c, row) {
    const cell = formatBoardCell(c, row, options.timezone);
    return cell.href ? el("a", {href:cell.href, target:"_blank", rel:"noopener noreferrer"}, cell.text) : cell.text;
  }});
  table.classList.add("ce-board-table");
  columns.forEach((c, index) => {
    const button = el("button", {type:"button"}, c.label);
    button.addEventListener("click", () => {
      const direction = options.sortKey === c.key && options.sortDirection === "asc" ? "desc" : "asc";
      if (options.onSort) options.onSort(c.key, direction);
    });
    table.querySelectorAll("th")[index].replaceChildren(button);
  });
  const wrap = el("div", {class:"tblwrap"}, table);
  const total = options.totalRows || 0, size = options.pageSize || 100, page = options.page || 0;
  const first = total ? page * size + 1 : 0;
  const pager = el("div", {class:"ce-board-pager"}, `${first}–${Math.min(page * size + rows.length,total)} / ${total}`);
  const prev = el("button", {type:"button"}, "Назад"), next = el("button", {type:"button"}, "Далее");
  prev.disabled = page <= 0; next.disabled = (page + 1) * size >= total;
  prev.addEventListener("click", () => options.onPage && options.onPage(page-1));
  next.addEventListener("click", () => options.onPage && options.onPage(page+1));
  pager.append(prev,next);
  container.replaceChildren(wrap, pager);
  if (!rows.length) container.append(el("p", {class:"ce-board-empty"}, "Нет данных"));
  return () => container.replaceChildren();
}

if (typeof module !== "undefined") module.exports = {formatBoardCell, renderBoardTable};
