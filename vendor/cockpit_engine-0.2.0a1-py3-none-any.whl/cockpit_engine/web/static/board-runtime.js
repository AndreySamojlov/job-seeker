"use strict";

function validateBoardPayload(p) {
  const fail = () => {throw new Error("Invalid board payload");};
  const record = v => v && typeof v === "object" && !Array.isArray(v);
  const array = Array.isArray;
  if (!record(p) || p.schema_version !== 1 || !["live","unavailable"].includes(p.state)) fail();
  if (!record(p.meta) || typeof p.meta.domain !== "string" || !record(p.meta.filters)) fail();
  try { new Intl.DateTimeFormat("ru-RU", {timeZone:p.meta.timezone || "Europe/Moscow"}); } catch (_) {fail();}
  if (!array(p.filters) || !array(p.kpis) || !record(p.charts) || !array(p.charts.specs) || !array(p.charts.chart_series)) fail();
  if (!record(p.table) || !array(p.table.columns) || !array(p.table.rows)) fail();
  const t = p.table;
  if (![t.total_rows,t.page,t.page_size].every(Number.isSafeInteger) || t.total_rows<0 || t.page<0 || t.page_size<1 || t.rows.length>t.page_size || t.rows.length>t.total_rows) fail();
  const keys = new Set();
  for (const c of t.columns) {
    if (!record(c) || typeof c.key !== "string" || !c.key || keys.has(c.key) || typeof c.label !== "string" || !["text","number","link","datetime"].includes(c.kind)) fail();
    keys.add(c.key);
  }
  for (const row of t.rows) {
    if (!record(row)) fail();
    for (const c of t.columns) if (c.kind === "number" && row[c.key] != null && !Number.isFinite(row[c.key])) fail();
  }
  for (const k of p.kpis) if (!record(k) || typeof k.label !== "string" || typeof k.value !== "string") fail();
  const ids = new Set();
  for (const s of p.charts.specs) {
    if (!record(s) || typeof s.id !== "string" || !/^[a-zA-Z][\w-]*$/.test(s.id) || ids.has(s.id) || !["bar","hbar","line","grouped-bar","stacked-hbar","pie","date-scatter"].includes(s.encoding)) fail();
    ids.add(s.id);
  }
  for (const f of p.filters) {
    if (!record(f) || !/^[a-zA-Z][\w_]*$/.test(f.key) || ["domain","page","sort_key","sort_direction"].includes(f.key) || typeof f.label !== "string" || !["select","date"].includes(f.kind)) fail();
    if (f.kind === "select" && (!array(f.options) || !f.options.every(o=>record(o)&&typeof o.value==="string"&&typeof o.label==="string"))) fail();
  }
  return p;
}

function createBoardLoader(dataUrl, onData, onError, fetcher) {
  fetcher = fetcher || fetch;
  let generation = 0, controller = null, destroyed = false;
  return {
    async load(params) {
      if (destroyed) return;
      const id = ++generation;
      if (controller) controller.abort();
      controller = new AbortController();
      try {
        const query = new URLSearchParams(params);
        const response = await fetcher(dataUrl + "?" + query.toString(), {signal:controller.signal, credentials:"same-origin", cache:"no-store"});
        if (!response.ok) throw new Error("Source unavailable");
        const payload = validateBoardPayload(await response.json());
        if (!destroyed && id === generation) onData(payload);
      } catch (error) {
        if (!destroyed && id === generation && error.name !== "AbortError") onError(new Error("Данные недоступны"));
      }
    },
    destroy() {destroyed = true; generation++; if (controller) controller.abort();}
  };
}

function mountBoard(root, config) {
  let chartStage = null, disposeTable = null;
  let params = {domain:config.domains[0].key, page:"0"};
  root.classList.add("ce-board");
  const content = el("section", {class:"ce-board-content"});
  const navigation = el("nav", {class:"ce-board-nav", "aria-label":"Разделы"});
  const title = el("h1", {}, config.title);
  document.title = config.title;
  const status = el("p", {role:"status",class:"ce-board-status"});
  const filters = el("form", {class:"ce-board-filters"});
  const kpis = el("div", {class:"kpi"});
  const charts = el("div", {id:"charts-host"});
  const table = el("div", {class:"ce-board-table-host"});
  content.append(title,status,filters,kpis,charts,table);
  root.replaceChildren(content,navigation);
  const clear = () => {
    if (typeof closeChartModal === "function") closeChartModal();
    if (chartStage) chartStage.destroy(); chartStage=null;
    if (disposeTable) disposeTable(); disposeTable=null;
    kpis.replaceChildren(); charts.replaceChildren(); table.replaceChildren();
  };
  const refresh = () => {status.textContent="Загрузка…"; content.setAttribute("aria-busy","true");return loader.load(params);};
  const loader = createBoardLoader(config.data_url, payload => {
    try {
      if (payload.meta.domain !== params.domain) throw new Error("Domain mismatch");
      clear();
      if (payload.state !== "live") throw new Error("Unavailable");
      status.textContent = payload.meta.fetched_at ? "Обновлено: " + new Intl.DateTimeFormat("ru-RU",{dateStyle:"short",timeStyle:"short",timeZone:payload.meta.timezone||"Europe/Moscow"}).format(new Date(payload.meta.fetched_at)) : "";
      filters.replaceChildren();
      payload.filters.forEach(f => {
        const input = f.kind === "date" ? el("input",{type:"date",name:f.key}) : el("select",{name:f.key});
        if (f.kind === "select") f.options.forEach(o=>input.append(el("option",{value:o.value},o.label)));
        input.value = params[f.key] == null ? String(f.value == null ? "" : f.value) : params[f.key];
        if (params[f.key] == null && input.value !== "") params[f.key] = input.value;
        input.addEventListener("change",()=>{params[f.key]=input.value;params.page="0";refresh();});
        filters.append(el("label",{},[el("span",{},f.label),input]));
      });
      renderKpiCards(kpis,payload.kpis);
      chartStage=mountStage(charts,payload.charts.specs,{meta:payload.meta,chart_series:payload.charts.chart_series});
      const t=payload.table;
      disposeTable=renderBoardTable(table,t.columns,t.rows,{totalRows:t.total_rows,page:t.page,pageSize:t.page_size,timezone:payload.meta.timezone,
        sortKey:params.sort_key,sortDirection:params.sort_direction,
        onPage:page=>{params.page=String(page);refresh();},
        onSort:(key,direction)=>{params.sort_key=key;params.sort_direction=direction;params.page="0";refresh();}});
      content.removeAttribute("aria-busy");
    } catch (_) {clear();status.textContent="Данные недоступны";content.removeAttribute("aria-busy");}
  }, () => {clear();status.textContent="Данные недоступны";content.removeAttribute("aria-busy");});
  config.domains.forEach(d=>{
    const button=el("button",{type:"button"},d.label);
    button.addEventListener("click",()=>{params={domain:d.key,page:"0"};refresh();});
    navigation.append(button);
  });
  filters.addEventListener("submit",event=>event.preventDefault());
  refresh();
  return {destroy(){loader.destroy();clear();root.replaceChildren();}};
}

if (typeof module !== "undefined") module.exports={validateBoardPayload,createBoardLoader,mountBoard};
if (typeof window !== "undefined") window.CockpitBoard={mount:mountBoard};
